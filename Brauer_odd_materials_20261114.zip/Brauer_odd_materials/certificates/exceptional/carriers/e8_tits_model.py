"""Faithful integral E8 Tits action on its 240 Chevalley root vectors.

The asymmetry function is epsilon(a,b)=(-1)^(a^T U b), where U has
diagonal 1, lower entries C_ij, and upper entries 0.  Then
[e_a,e_b]=epsilon(a,b)e_(a+b), [e_a,e_-a]=-h_a, and f_i=-e_-i.
The eight Cartan vectors carry the Weyl action determined by root vectors.
"""
from itertools import product
import sympy as s

C=s.Matrix([[2,0,-1,0,0,0,0,0],[0,2,0,-1,0,0,0,0],
 [-1,0,2,-1,0,0,0,0],[0,-1,-1,2,-1,0,0,0],
 [0,0,0,-1,2,-1,0,0],[0,0,0,0,-1,2,-1,0],
 [0,0,0,0,0,-1,2,-1],[0,0,0,0,0,0,-1,2]])
E=s.eye(8);sim=[]
for i in range(8):
 a=E.copy();a[i,:]-=C[i,:];sim.append(a)
roots={tuple(int(x) for x in E[:,i]) for i in range(8)};todo=list(roots)
while todo:
 r=todo.pop()
 for i in range(8):
  z=list(r);z[i]-=sum(int(C[i,j])*r[j] for j in range(8));z=tuple(z)
  if z not in roots:roots.add(z);todo.append(z)
roots=sorted(roots);ri={r:i for i,r in enumerate(roots)}
assert len(roots)==240 and C.det()==1

def eps(a,b):
 return (-1)**(sum(a[i]*b[i] for i in range(8))+sum(a[i]*int(C[i,j])*b[j] for i in range(8) for j in range(i)))
ID=tuple((i,1) for i in range(240))
def mul(a,b):return tuple((a[j][0],sg*a[j][1]) for j,sg in b)
def inv(a):
 z=[None]*240
 for i,(j,sg) in enumerate(a):z[j]=(i,sg)
 return tuple(z)
def tor(bits):
 return tuple((i,(-1)**sum(r[j]*int(C[j,k])*bits[k] for j in range(8) for k in range(8))) for i,r in enumerate(roots))
simple_actions=[]
for i in range(8):
 aa=[];alpha=tuple(int(x) for x in E[:,i])
 for r in roots:
  m=sum(int(C[i,j])*r[j] for j in range(8));z=list(r);z[i]-=m
  sg=eps(alpha,r) if abs(m)==1 else 1
  aa.append((ri[tuple(z)],sg))
 simple_actions.append(tuple(aa))
def action(word):
 a=ID
 for i in word:a=mul(a,simple_actions[i])
 return a
def red(W):
 Q=W.copy();p=[]
 while Q!=E:
  i=next(i for i in range(8) if all(x<=0 for x in Q[:,i]))
  Q=Q*sim[i];p.append(i)
  assert len(p)<=120
 return list(reversed(p))
def perm(a):return [j+1 if sg==1 else j+241 for j,sg in a]+[j+241 if sg==1 else j+1 for j,sg in a]
def pin_sign(a,r,t):
 j,sg=a[ri[tuple(r)]]
 assert roots[j]==tuple(t)
 return sg

# Tits quadratic and braid relations, and root-vector Lie brackets.
for i in range(8):
 bits=[0]*8;bits[i]=1
 assert mul(simple_actions[i],simple_actions[i])==tor(bits)
 for j in range(8):
  if i!=j and C[i,j]==0:assert action([i,j])==action([j,i])
  if i!=j and C[i,j]==-1:assert action([i,j,i])==action([j,i,j])
 for a in roots:
  ia,sa=simple_actions[i][ri[a]];aa=roots[ia]
  for b in roots:
   ab=tuple(x+y for x,y in zip(a,b))
   if ab not in ri:continue
   ib,sb=simple_actions[i][ri[b]];bb=roots[ib]
   iab,sab=simple_actions[i][ri[ab]]
   assert tuple(x+y for x,y in zip(aa,bb))==roots[iab]
   assert eps(a,b)*sab==sa*sb*eps(aa,bb)

def root_tits(beta):
 z=s.Matrix(beta);peel=[]
 if all(x<=0 for x in z):z=-z
 while sum(z)>1:
  i=next(i for i in range(8) if (C*z)[i]>0 and z!=E[:,i])
  z=sim[i]*z;peel.append(i)
 i=next(i for i in range(8) if z==E[:,i])
 a=action(peel)
 return mul(mul(a,simple_actions[i]),inv(a)),{'conjugator':[j+1 for j in peel],'simple':i+1}
