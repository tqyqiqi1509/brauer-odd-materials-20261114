"""All residual E8 non-toral pinning carriers; no finite q is sampled.

The integral Chevalley model is the explicitly read historical model. We
reconstruct the perpendicular roots, all joint diagram isometries, every
two-color inertia kernel, and the actual e=2 return from that model.
"""
from pathlib import Path
from itertools import permutations, product
import json, sys
import sympy as s
from sympy.matrices.normalforms import smith_normal_form

OUT=Path(__file__).resolve().parent
SRC=OUT
sys.path.insert(0,str(SRC))
from e8_tits_model import C,E,roots,ri,ID,mul,inv,tor,action,red,perm,pin_sign,root_tits,sim

def diagram_auts(M):
    r=M.rows
    return [p for p in permutations(range(r)) if all(M[i,j]==M[p[i],p[j]] for i in range(r) for j in range(r))]

def longest_H(H):
    W=E.copy()
    while True:
        cand=[i for i in H if all(x>=0 for x in W[:,i])]
        if not cand:return W
        W=W*sim[cand[0]]

allout=[]
gap=['Print("E8 residual actual pinning carriers R4ah\\n");','total:=0;; badtotal:=0;; K:=false;;']
rows=[('A1_2',[1,2],2949120,64,46080),('A1_3',[1,2,5],73728,32,2304),
      ('A1_4',[1,2,5,7],6144,16,384),('D4',[2,3,4,5],18432,16,1152)]
for label,Hnodes,Qexp,Aexp,Wexp in rows:
    H=[i-1 for i in Hnodes]
    rr={b for b in roots if all(sum(int(C[i,j])*b[j] for j in range(8))==0 for i in H)}
    pos={b for b in rr if all(x>=0 for x in b)}
    kb=sorted(b for b in pos if not any(tuple(x-y for x,y in zip(b,c)) in pos for c in pos))
    K=[s.Matrix(b) for b in kb]
    assert len(H)+len(K)==8
    B=s.Matrix.hstack(*(E[:,i] for i in H),*K);Bi=B.inv()
    CH=C.extract(H,H);CK=s.Matrix.hstack(*K).T*C*s.Matrix.hstack(*K)
    carriers=[]
    for hp in diagram_auts(CH):
        for kp in diagram_auts(CK):
            W=s.Matrix.hstack(*(B[:,hp[i]] for i in range(len(H))),*(B[:,len(H)+kp[i]] for i in range(len(K))))*Bi
            if not all(x.q==1 for x in W):continue
            assert W.T*C*W==C
            word=red(W);a0=action(word)
            fix=None
            for bits in product(range(2),repeat=8):
                a=mul(tor(bits),a0)
                if all(pin_sign(a,E[:,H[i]],E[:,H[hp[i]]])==1 for i in range(len(H))):
                    fix=(bits,a);break
            assert fix is not None
            bits,a=fix
            carriers.append({'H_permutation':hp,'K_permutation':kp,'word':[i+1 for i in word],
                'torus_correction':bits,'action':a})
    nk=[];kwords=[]
    for beta in K:
        b,word=root_tits(beta);nk.append(b);kwords.append(word)
        assert all(pin_sign(b,E[:,j],E[:,j])==1 for j in H)
    n0=action(red(-E));nh=action(red(longest_H(H)));v=mul(n0,inv(nh))
    assert all(pin_sign(v,E[:,i],E[:,i])==1 for i in H)
    bitsker=[bits for bits in product(range(2),repeat=8) if all(sum(int(C[i,j])*bits[j] for j in range(8))%2==0 for i in H)]
    basis=[];span={(0,)*8}
    for b in bitsker:
        if b not in span:
            basis.append(b);span|={tuple(x^y for x,y in zip(c,b)) for c in list(span)}
    tg=[tor(b) for b in basis];r=len(tg)
    assert 2**r==Aexp
    cg=[x['action'] for x in carriers if x['action']!=ID]
    gens=tg+nk+cg
    assert all(mul(v,a)==mul(a,v) for a in gens)
    vv=mul(v,v);assert mul(vv,vv)==ID
    masks=[]
    for d in range(1,2**r):
        pivot=next(i for i in range(r) if d>>i&1)
        masks.append([perm(mul(tg[i],tg[pivot]) if d>>i&1 else tg[i]) for i in range(r) if i!=pivot])
    gap += ['Print("'+label+'\\n");','gg:=List('+str([perm(a) for a in gens])+',PermList);;',
      'Q:=Group(gg,());; A:=Subgroup(Q,gg{[1..'+str(r)+']});;',
      'blocks:=List([1..240],i->[i,i+240]);; W:=Operation(Q,blocks,OnSets);; pi:=OperationHomomorphism(Q,W);;',
      'Print("orders=",Size(Q),",",Size(A),",",Size(W)," expected='+str(Qexp)+','+str(Aexp)+','+str(Wexp)+'", " toral_kernel=",Kernel(pi)=A,"\\n");',
      'kk:='+str(masks)+';;','bad:=[];;',
      'for j in [1..'+str(2**r-1)+'] do K:=Subgroup(Q,List(kk[j],PermList)); I:=Normalizer(Q,K); B:=Intersection(DerivedSubgroup(I),A); if not ForAll(B.generators,x->x in K) then Add(bad,j); fi; Print("colour=",j," inertia=",Size(I)," comm_intersection=",Size(B)," abelian=",AbelianInvariants(I),"\\n"); od;',
      'total:=total+Length(kk);; badtotal:=badtotal+Length(bad);; Print("all_nontrivial_colours=",Length(kk)," bad=",bad,"\\n");',
      'v:=PermList('+str(perm(v))+');; Print("return_in_Q=",v in Q," order=",Order(Q,v)," centralizes_all=",ForAll(gg,x->x*v=v*x),"\\n");']
    SL=smith_normal_form(C[H,:],domain=s.ZZ)
    allout.append({'name':label,'H_nodes':Hnodes,'perpendicular_roots':kb,
      'perpendicular_Cartan':[list(CK.row(i)) for i in range(len(K))],
      'root_union_index':abs(int(B.det())),'centre_smith':[abs(int(SL[i,i])) for i in range(len(H))],
      'full_torus_two_basis':basis,'diagram_representatives':[{k:v for k,v in x.items() if k!='action'} for x in carriers],
      'root_lift_words':kwords,'return_word_n0':[i+1 for i in red(-E)],'return_word_n0H':[i+1 for i in red(longest_H(H))],
      'carrier_order_expected':Qexp,'overlap_order_expected':Aexp,'quotient_order_expected':Wexp,
      'return_order':1 if v==ID else 2 if vv==ID else 4,'ordinary_colours_to_check':Aexp,
      'generators_permutation':[perm(a) for a in gens]})
    print(label,'root-generated; diagrams',len(carriers),'overlap',Aexp,'return',allout[-1]['return_order'],flush=True)
gap+=['Print("TOTAL_NONTRIVIAL_COLOURS=",total," TOTAL_BAD=",badtotal,"\\n");']
(OUT/'e8_all_residual_pinning.g').write_text('\n'.join(gap)+'\n')
(OUT/'e8_all_residual_pinning.json').write_text(json.dumps({'method':'Integral Chevalley E8 root model; all perpendicular roots; all joint diagram isometries; every central two-color','rows':allout},indent=2,default=int)+'\n')
