"""Check complete stdout from the three standalone GAP carrier inputs.

Run GAP on e6_overlap_gap4.g, e7_overlap_gap4.g, e8_overlap_gap4.g,
redirecting stdout to e6.out, e7.out, e8.out in this directory.
The GAP inputs themselves assert the complete elementary-abelian overlap,
all distinct index-two kernels, every inertia extension, and true returns.
This program additionally checks that every row and all 279 colours ran.
"""
from pathlib import Path
import json,re

HERE=Path(__file__).resolve().parent

def read(name):
    p=HERE/(name+".out")
    text=p.read_text()
    for extra in (p,HERE/(name+".stderr")):
        if extra.exists():
            s=extra.read_text()
            assert not re.search(r"(Error,|Syntax error|brk>|Assertion failed)",s),str(extra)
    return text

def main():
    result={}
    e6=read("e6")
    assert "orders 768 16 48" in e6
    assert "graph 4 true true" in e6
    colours=re.findall(r"colour=(\d+)\s+inertia=(\d+)\s+comm_intersection=(\d+)\s+extends=true",e6)
    assert sorted(int(x[0]) for x in colours)==list(range(1,16))
    assert "TOTAL_NONTRIVIAL_COLOURS=15 TOTAL_BAD=0" in e6
    result["e6"]={"nontrivial_characters":15,"all_extensions":True,
                  "orders":[768,16,48],"return_order":4}
    domain={
        "e7":([(1474560,64,23040),(24576,32,768),(1536,16,96),(36864,32,1152)],140),
        "e8":([(2949120,64,46080),(73728,32,2304),(6144,16,384),(18432,16,1152)],124),
    }
    for name,(orders,total) in domain.items():
        text=read(name)
        actual=re.findall(r"orders=(\d+),(\d+),(\d+)\s+expected=(\d+),(\d+),(\d+)\s+toral_kernel=true",text)
        assert len(actual)==4
        assert [tuple(map(int,r[:3])) for r in actual]==orders
        assert [tuple(map(int,r[3:])) for r in actual]==orders
        returns=re.findall(r"return_in_Q=true\s+order=(\d+)\s+centralizes_all=true",text)
        assert list(map(int,returns))==[4,4,4,2]
        counts=re.findall(r"all_nontrivial_colours=(\d+)\s+bad=\[\s*\]",text)
        assert list(map(int,counts))==[a-1 for q,a,w in orders]
        assert len(re.findall(r"colour=\d+\s+inertia=",text))==total
        assert f"TOTAL_NONTRIVIAL_COLOURS={total} TOTAL_BAD=0" in text
        result[name]={"nontrivial_characters":total,"all_extensions":True,
                      "orders":orders,"return_orders":[4,4,4,2]}
    result["total_nontrivial_characters"]=sum(result[k]["nontrivial_characters"] for k in ["e6","e7","e8"])
    assert result["total_nontrivial_characters"]==279
    (HERE/"CARRIER_VALIDATION.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result,indent=2))

if __name__=="__main__":main()

