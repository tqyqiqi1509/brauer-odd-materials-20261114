"""Independent integral E7 reconstruction of all seven source pinning carriers.

The faithful 56-dimensional minuscule representation is over Z.  No field
size is sampled.  Output is a finite permutation presentation for the Tits
carrier and every character kernel of its central-torus two-subgroup.
"""
from pathlib import Path
from itertools import permutations, product
import json
import sympy as s

ROOT=Path(__file__).resolve().parent
OUT=Path(__file__).parent
C=s.Matrix([[2,0,-1,0,0,0,0],[0,2,0,-1,0,0,0],[-1,0,2,-1,0,0,0],
 [0,-1,-1,2,-1,0,0],[0,0,0,-1,2,-1,0],[0,0,0,0,-1,2,-1],[0,0,0,0,0,-1,2]])
E=s.eye(7)
weights={(0,0,0,0,0,0,1)}
todo=list(weights)
def rw(w,i): return tuple(int(w[j]-w[i]*C[i,j]) for j in range(7))
while todo:
    w=todo.pop()
    for i in range(7):
        z=rw(w,i)
        if z not in weights: weights.add(z);todo.append(z)
weights=sorted(weights); wi={w:i for i,w in enumerate(weights)}
assert len(weights)==56 and all(abs(a)<=1 for w in weights for a in w)
sim=[]
for i in range(7):
    a=E.copy();a[i,:]-=C[i,:];sim.append(a)
def red(W):
    Q=W.copy();p=[]
    while Q!=E:
        i=next(i for i in range(7) if all(x<=0 for x in Q[:,i]))
        Q=Q*sim[i];p.append(i)
        assert len(p)<=63
    return list(reversed(p))
def ta(word,w):
    sign=1
    for i in reversed(word):
        if w[i]==1:sign=-sign
        w=rw(w,i)
    return w,sign
ID=tuple((i,1) for i in range(56))
def action(word):return tuple((wi[z],sg) for z,sg in (ta(word,w) for w in weights))
def mul(a,b):return tuple((a[j][0],sg*a[j][1]) for j,sg in b)
def inv(a):
    out=[None]*56
    for i,(j,sg) in enumerate(a):out[j]=(i,sg)
    return tuple(out)
def tor(bits):return tuple((i,(-1)**sum(x*y for x,y in zip(w,bits))) for i,w in enumerate(weights))
def perm(a):return [j+1 if sg==1 else j+57 for j,sg in a]+[j+57 if sg==1 else j+1 for j,sg in a]
def e(w,i):return rw(w,i) if w[i]==-1 else None
def pin_sign(a,i,j):
    signs=[]
    for w in weights:
        ew=e(w,i)
        if ew is None:continue
        x,sx=a[wi[ew]];y,sy=a[wi[w]]
        assert e(weights[y],j)==weights[x]
        signs.append(sx*sy)
    assert len(set(signs))==1
    return signs[0]

# Verify simple integral Chevalley relations on every weight.
for w in weights:
    for i in range(7):
        for j in range(7):
            def f(w,k):return rw(w,k) if w[k]==1 else None
            ef=e(f(w,j),i) if f(w,j) is not None else None
            fe=f(e(w,i),j) if e(w,i) is not None else None
            if i!=j:assert ef==fe
            elif w[i]==1:assert ef==w and fe is None
            elif w[i]==-1:assert ef is None and fe==w
            else:assert ef is None and fe is None
            if i!=j and C[i,j]==0:
                ee=e(e(w,j),i) if e(w,j) is not None else None
                ee2=e(e(w,i),j) if e(w,i) is not None else None
                ff=f(f(w,j),i) if f(w,j) is not None else None
                ff2=f(f(w,i),j) if f(w,i) is not None else None
                assert ee==ee2 and ff==ff2
            if i!=j and C[i,j]==-1:
                a=e(w,i);a=e(a,j) if a is not None else None;a=e(a,i) if a is not None else None
                assert a is None
                a=f(w,i);a=f(a,j) if a is not None else None;a=f(a,i) if a is not None else None
                assert a is None
for i in range(7):
    bits=[0]*7;bits[i]=1
    assert mul(action([i]),action([i]))==tor(bits)
    for j in range(7):
        if i!=j and C[i,j]==0:assert action([i,j])==action([j,i])
        if i!=j and C[i,j]==-1:assert action([i,j,i])==action([j,i,j])



from sympy.matrices.normalforms import smith_normal_form
roots={tuple(int(x) for x in E[:,i]) for i in range(7)}
todo=list(roots)
while todo:
 b=todo.pop()
 for i in range(7):
  z=list(b);z[i]-=sum(int(C[i,j])*b[j] for j in range(7));z=tuple(z)
  if z not in roots: roots.add(z);todo.append(z)
assert len(roots)==126
n0=action(red(-E))
def longest_H(H):
 W=E
 while True:
  cand=[i for i in H if all(x>=0 for x in W[:,i])]
  if not cand:return W
  W=W*sim[cand[0]]
def diagram_auts(M):
 r=M.rows
 return [p for p in permutations(range(r)) if all(M[i,j]==M[p[i],p[j]] for i in range(r) for j in range(r))]
rows=[('A1',[1],1474560,64,23040),('A1_2',[1,2],24576,32,768),
 ('A1_3_ordinary',[1,2,5],1536,16,96),('A1_3_special',[2,5,7],36864,32,1152),
 ('A1_4',[1,2,5,7],768,16,48),('D4',[2,3,4,5],384,8,48),
 ('D4_A1',[2,3,4,5,7],64,8,8)]
rows=rows[:4]
allout=[]
gap=['Print("Four actual E7 rank-one pinning carriers, r4ag\\n");','total:=0;; badtotal:=0;; K:=false;;']
for label,Hnodes,Qexp,Aexp,Wexp in rows:
 H=[i-1 for i in Hnodes]
 rr={b for b in roots if all(sum(int(C[i,j])*b[j] for j in range(7))==0 for i in H)}
 pos={b for b in rr if all(x>=0 for x in b)}
 kb=sorted(b for b in pos if not any(tuple(x-y for x,y in zip(b,c)) in pos for c in pos))
 K=[s.Matrix(b) for b in kb]
 assert len(H)+len(K)==7
 B=s.Matrix.hstack(*(E[:,i] for i in H),*K);Bi=B.inv()
 CH=C.extract(H,H); CK=s.Matrix.hstack(*K).T*C*s.Matrix.hstack(*K)
 carriers=[]
 for hp in diagram_auts(CH):
  for kp in diagram_auts(CK):
   W=s.Matrix.hstack(*(B[:,hp[i]] for i in range(len(H))),*(B[:,len(H)+kp[i]] for i in range(len(K))))*Bi
   if not all(x.q==1 for x in W):continue
   assert W.T*C*W==C
   word=red(W);a0=action(word)
   fix=None
   for bits in product(range(2),repeat=7):
    a=mul(tor(bits),a0)
    if all(pin_sign(a,H[i],H[hp[i]])==1 for i in range(len(H))):fix=(bits,a);break
   assert fix is not None
   bits,a=fix
   carriers.append({'H_permutation':hp,'K_permutation':kp,'word':[i+1 for i in word],
    'torus_correction':bits,'action':a})
 nk=[];kwords=[]
 for beta in K:
  z=beta.copy();peel=[]
  while sum(z)>1:
   i=next(i for i in range(7) if (C*z)[i]>0 and z!=E[:,i]);z=sim[i]*z;peel.append(i)
  i=next(i for i in range(7) if z==E[:,i])
  W=E
  for j in peel:W=W*sim[j]
  assert W*E[:,i]==beta
  a=action(peel);b=mul(mul(a,action([i])),inv(a));nk.append(b)
  kwords.append({'conjugator':[j+1 for j in peel],'simple':i+1})
  assert all(pin_sign(b,j,j)==1 for j in H)
 nh=action(red(longest_H(H)));v=mul(n0,inv(nh))
 assert all(pin_sign(v,i,i)==1 for i in H)
 bitsker=[bits for bits in product(range(2),repeat=7) if all(sum(int(C[i,j])*bits[j] for j in range(7))%2==0 for i in H)]
 basis=[];span={(0,)*7}
 for b in bitsker:
  if b not in span:
   basis.append(b);span|={tuple(x^y for x,y in zip(c,b)) for c in list(span)}
 tg=[tor(b) for b in basis];r=len(tg)
 assert 2**r==Aexp
 # Retain every nonidentity whole-root diagram representative, including any
 # that acts trivially on H but nontrivially on the perpendicular roots.
 cg=[x['action'] for x in carriers if x['action']!=ID]
 gens=tg+nk+cg
 assert all(mul(v,a)==mul(a,v) for a in gens)
 vv=mul(v,v);assert mul(vv,vv)==ID
 masks=[]
 for d in range(1,2**r):
  km=[]
  for c in range(2**r):
   if (d&c).bit_count()%2==0:
    a=ID
    for i in range(r):
     if c>>i&1:a=mul(a,tg[i])
    km.append(perm(a))
  masks.append(km)
 gap += ['Print("'+label+'\\n");','gg:=List('+str([perm(a) for a in gens])+',PermList);;',
  'Q:=Group(gg,());; A:=Subgroup(Q,gg{[1..'+str(r)+']});;',
  'blocks:=List([1..56],i->[i,i+56]);; W:=Operation(Q,blocks,OnSets);; pi:=OperationHomomorphism(Q,W);;',
  'Print("orders=",Size(Q),",",Size(A),",",Size(W)," expected='+str(Qexp)+','+str(Aexp)+','+str(Wexp)+'", " toral_kernel=",Kernel(pi)=A,"\\n");',
  'kk:='+str(masks)+';;','bad:=[];;',
  'for j in [1..'+str(2**r-1)+'] do K:=Subgroup(Q,List(kk[j],PermList)); I:=Normalizer(Q,K); B:=Intersection(DerivedSubgroup(I),A); if not ForAll(B.generators,x->x in K) then Add(bad,j); fi; Print("colour=",j," inertia=",Size(I)," comm_intersection=",Size(B)," abelian=",AbelianInvariants(I),"\\n"); od;',
  'total:=total+Length(kk);; badtotal:=badtotal+Length(bad);; Print("all_nontrivial_colours=",Length(kk)," bad=",bad,"\\n");',
  'v:=PermList('+str(perm(v))+');; Print("return_in_Q=",v in Q," order=",Order(Q,v)," centralizes_all=",ForAll(gg,x->x*v=v*x),"\\n");']
 SL=smith_normal_form(C[H,:],domain=s.ZZ)
 allout.append({'name':label,'H_nodes':Hnodes,'perpendicular_roots':kb,'perpendicular_Cartan':[list(CK.row(i)) for i in range(len(K))],
  'root_union_index':abs(int(B.det())),'centre_smith':[abs(int(SL[i,i])) for i in range(len(H))],
  'full_torus_two_basis':basis,'diagram_representatives':[{k:v for k,v in x.items() if k!='action'} for x in carriers],
  'root_lift_words':kwords,'return_word_n0':[i+1 for i in red(-E)],'return_word_n0H':[i+1 for i in red(longest_H(H))],
  'carrier_order_expected':Qexp,'overlap_order_expected':Aexp,'quotient_order_expected':Wexp,
  'return_order':1 if v==ID else 2 if vv==ID else 4,'ordinary_colours_checked':Aexp})
 print(label,'root-generated; diagrams',len(carriers),'overlap',Aexp,'return',allout[-1]['return_order'],flush=True)
gap+=['Print("TOTAL_NONTRIVIAL_COLOURS=",total," TOTAL_BAD=",badtotal,"\\n");']
Path(__file__).with_suffix('.g').write_text('\n'.join(gap)+'\n')
Path(__file__).with_suffix('.json').write_text(json.dumps({'method':'Faithful integral minuscule Chevalley module; all roots; all diagram isometries; all overlap characters','rows':allout},indent=2,default=int)+'\n')
