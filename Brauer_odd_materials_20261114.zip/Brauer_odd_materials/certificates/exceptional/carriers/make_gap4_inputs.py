"""Convert freshly generated integral carriers to standalone GAP 4 inputs.

Run the three carrier Python generators first, then this script. It keeps
every input permutation, translates GAP 3 core syntax, and adds exhaustive
full-overlap and genuine-return assertions. No historical path is used.
"""
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent

def translate(source, kind):
    s = source.replace("Group(gg,())", "Group(gg)")
    s = s.replace("Group(gg,());", "Group(gg);")
    s = s.replace(",PermList),())", ",PermList))")
    s = s.replace("Group([bb],())", "Group([bb])")
    s = s.replace("Order(Group([bb]),bb)", "Order(bb)")
    s = s.replace("Operation(Q,blocks,OnSets)", "Action(Q,blocks,OnSets)")
    s = s.replace("OperationHomomorphism(Q,W)",
                  "ActionHomomorphism(Q,blocks,OnSets)")
    s = s.replace("B.generators", "GeneratorsOfGroup(B)")
    s = s.replace("Order(Q,v)", "Order(v)")
    s = s.replace("QUIT;", "")
    if kind == "e6":
        s += r'''
Assert(0,Size(Q)=768 and Size(A)=16 and Size(C)=48);
Assert(0,IsElementaryAbelian(A) and IsNormal(Q,A));
Assert(0,Order(bb)=4 and ForAll(gg,x->Comm(x,bb)=()));
bad:=[];; kernels:=[];;
ag:=GeneratorsOfGroup(A);;
Assert(0,Length(ag)=4);
for mask in [1..15] do
 bits:=List([1..4],i->QuoInt(mask,2^(i-1)) mod 2);
 pos:=Position(bits,1); kg:=[];
 for i in [1..4] do
  if i<>pos then
   if bits[i]=0 then Add(kg,ag[i]);
   else Add(kg,ag[i]*ag[pos]); fi;
  fi;
 od;
 K:=Subgroup(Q,kg);
 Assert(0,IsSubgroup(A,K) and Size(K)=8);
 Add(kernels,K);
 I:=Normalizer(Q,K); B:=Intersection(DerivedSubgroup(I),A);
 if not IsSubgroup(K,B) then Add(bad,mask); fi;
 Print("colour=",mask," inertia=",Size(I),
       " comm_intersection=",Size(B)," extends=",IsSubgroup(K,B),"\n");
od;
Assert(0,Length(Set(kernels))=15 and Length(bad)=0);
Print("TOTAL_NONTRIVIAL_COLOURS=15 TOTAL_BAD=",Length(bad),"\n");
QUIT;
'''
        return s
    result = ['SizeScreen([240,100000]);;']
    return_orders = [4,4,4,2]
    return_index = 0
    for line in s.splitlines():
        if "K:=Subgroup(Q,List(kk[j],PermList));" in line:
            line = line.replace("K:=Subgroup(Q,List(kk[j],PermList));",
                "K:=Subgroup(Q,List(kk[j],PermList)); "
                "Assert(0,IsSubgroup(A,K) and Size(K)*2=Size(A)); "
                "Add(kernels,K);")
        result.append(line)
        if line.startswith('Print("orders='):
            q,a,w = map(int,re.search(r"expected=(\d+),(\d+),(\d+)",line).groups())
            result.append("Assert(0,Size(Q)=%d and Size(A)=%d and Size(W)=%d);"%(q,a,w))
            result.append("Assert(0,IsElementaryAbelian(A) and IsNormal(Q,A) and Kernel(pi)=A);")
        if line == "bad:=[];;":
            result.append("kernels:=[];;")
        if line.startswith("for j in "):
            result.append("Assert(0,Length(Set(kernels))=Size(A)-1 and Length(bad)=0);")
        if "return_in_Q=" in line:
            result.append("Assert(0,v in Q and Order(v)=%d and ForAll(gg,x->x*v=v*x));"%return_orders[return_index])
            return_index += 1
    assert return_index == 4
    total = 140 if kind == "e7" else 124
    result += ["Assert(0,total=%d and badtotal=0);"%total, "QUIT;"]
    return "\n".join(result)+"\n"

def main():
    sources = {
        "e6":"e6_pinning_carrier_checks.g",
        "e7":"e7_rank_one_carriers_rerun.g",
        "e8":"e8_all_residual_pinning.g",
    }
    for kind,name in sources.items():
        p = HERE/name
        if not p.exists():
            raise SystemExit("Run the carrier Python generators first: missing "+name)
        target = HERE/(kind+"_overlap_gap4.g")
        target.write_text(translate(p.read_text(),kind))
        print(target.name)

if __name__ == "__main__":
    main()

