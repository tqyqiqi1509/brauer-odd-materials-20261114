"""Exact E6 integral pinning carriers for all non-toral good-prime sources.

The direct sum of the two 27-dimensional minuscule modules is a faithful
integral Chevalley model, stable under the diagram automorphism.  No q is
sampled.  All finite groups below consist of signed weight permutations.
"""
from pathlib import Path
from itertools import product
from collections import deque
import json
import sympy as sy
from sympy.matrices.normalforms import smith_normal_form

OUT=Path(__file__).parent
n=6
C=[[2,0,-1,0,0,0],[0,2,0,-1,0,0],[-1,0,2,-1,0,0],
   [0,-1,-1,2,-1,0],[0,0,0,-1,2,-1],[0,0,0,0,-1,2]]
E=tuple(tuple(int(i==j) for i in range(n)) for j in range(n)) # columns
gamma=(5,1,4,3,2,0)
def rw(w,i):return tuple(w[j]-w[i]*C[i][j] for j in range(n))
weights={E[0],E[5]};todo=list(weights)
while todo:
    w=todo.pop()
    for i in range(n):
        z=rw(w,i)
        if z not in weights:weights.add(z);todo.append(z)
weights=sorted(weights);wi={w:i for i,w in enumerate(weights)};m=len(weights)
assert m==54 and all(abs(a)<=1 for w in weights for a in w)
ID=tuple((i,1) for i in range(m))
def mul(a,b):return tuple((a[j][0],sg*a[j][1]) for j,sg in b)
def inv(a):
    z=[None]*m
    for i,(j,sg) in enumerate(a):z[j]=(i,sg)
    return tuple(z)
def action(word):
    out=[]
    for w in weights:
        sg=1
        for i in reversed(word):
            if w[i]==1:sg=-sg
            w=rw(w,i)
        out.append((wi[w],sg))
    return tuple(out)
def tor(bits):return tuple((i,(-1)**sum(x*y for x,y in zip(w,bits))) for i,w in enumerate(weights))
def perm(a):return [j+1 if sg==1 else j+m+1 for j,sg in a]+[j+m+1 if sg==1 else j+1 for j,sg in a]
def unsigned(a):return [j+1 for j,sg in a]
def e(w,i):return rw(w,i) if w[i]==-1 else None
def f(w,i):return rw(w,i) if w[i]==1 else None
def pin_sign(a,i,j):
    signs=[]
    for w in weights:
        ew=e(w,i)
        if ew is None:continue
        x,sx=a[wi[ew]];y,ss=a[wi[w]]
        assert e(weights[y],j)==weights[x]
        signs.append(sx*ss)
    assert len(set(signs))==1
    return signs[0]
for w in weights:
    for i in range(n):
        for j in range(n):
            ef=e(f(w,j),i) if f(w,j) is not None else None
            fe=f(e(w,i),j) if e(w,i) is not None else None
            if i!=j:assert ef==fe
            elif w[i]==1:assert ef==w and fe is None
            elif w[i]==-1:assert ef is None and fe==w
            else:assert ef is None and fe is None
            if i!=j and C[i][j]==0:
                ee=e(e(w,j),i) if e(w,j) is not None else None
                ee2=e(e(w,i),j) if e(w,i) is not None else None
                ff=f(f(w,j),i) if f(w,j) is not None else None
                ff2=f(f(w,i),j) if f(w,i) is not None else None
                assert ee==ee2 and ff==ff2
            if i!=j and C[i][j]==-1:
                a=e(w,i);a=e(a,j) if a is not None else None;a=e(a,i) if a is not None else None
                assert a is None
                a=f(w,i);a=f(a,j) if a is not None else None;a=f(a,i) if a is not None else None
                assert a is None
simple=[action([i]) for i in range(n)]
for i in range(n):
    bits=[0]*n;bits[i]=1
    assert mul(simple[i],simple[i])==tor(bits)
    for j in range(n):
        if C[i][j]==0:assert action([i,j])==action([j,i])
        if C[i][j]==-1:assert action([i,j,i])==action([j,i,j])
ga=tuple((wi[tuple(w[gamma[j]] for j in range(n))],1) for w in weights)
assert mul(ga,ga)==ID
for i in range(n):assert mul(mul(ga,simple[i]),ga)==simple[gamma[i]]

def right(M,i):
    u=M[i]
    return tuple(tuple(M[j][k]-C[i][j]*u[k] for k in range(n)) if C[i][j] else M[j] for j in range(n))
words={E:()};todo=deque([E])
while todo:
    M=todo.popleft();w=words[M]
    for i in range(n):
        Z=right(M,i)
        if Z not in words:words[Z]=w+(i,);todo.append(Z)
assert len(words)==51840
w0=next(M for M in words if all(all(a<=0 for a in col) for col in M))
n0=action(words[w0]);b0=mul(n0,ga)
assert all(mul(b0,x)==mul(x,b0) for x in simple)
assert mul(b0,b0)==ID
roots={z for M in words for z in M};assert len(roots)==72

def closure(perms):
    ident=tuple(range(m));out={ident};todo=[ident]
    while todo:
        a=todo.pop()
        for b in perms:
            c=tuple(a[b[i]] for i in range(m))
            if c not in out:out.add(c);todo.append(c)
    return out
def longestH(H):
    M=E;word=[]
    while True:
        good=[i for i in H if all(x>=0 for x in M[i])]
        if not good:return M,tuple(word)
        i=good[0];M=right(M,i);word.append(i)
def root_tits(beta):
    target=next((M,i) for M in words for i in range(n) if M[i]==beta)
    M,i=target;a=action(words[M]);return mul(mul(a,simple[i]),inv(a)),{'conjugator':[j+1 for j in words[M]],'simple':i+1}

cases={'A1':[2],'A1_A1':[1,6],'A1_A1_A1':[1,2,6],
       'A2':[2,4],'A3':[3,4,5],'A2_A2':[1,3,5,6],'D4':[2,3,4,5]}
cases={'A1_A1':[1,6]}
rows=[];gap=['Print("Exact E6 pinning carriers, all q\\n");']
for name,nodes in cases.items():
    H=[i-1 for i in nodes];hb={E[i]:i for i in H}
    comp=[M for M in words if {M[i] for i in H}==set(hb)]
    comp.sort(key=lambda M:(len(words[M]),words[M]))
    cg=[];pg=[];generated={tuple(range(m))};crecord=[]
    for M in comp:
        a=action(words[M]);p=tuple(j for j,sg in a)
        if p in generated:continue
        hp=[hb[M[i]] for i in H]
        signs=[pin_sign(a,i,j) for i,j in zip(H,hp)]
        candidates=[bits for bits in product(range(2),repeat=n)
                    if all(sum(C[j][k]*bits[k] for k in range(n))%2==(0 if sg==1 else 1)
                           for j,sg in zip(hp,signs))]
        assert candidates,(name,'no torus-two pinning correction')
        bits=candidates[0];a=mul(tor(bits),a)
        assert all(pin_sign(a,i,j)==1 for i,j in zip(H,hp))
        cg.append(a);pg.append(p);generated=closure(pg)
        crecord.append({'word':[j+1 for j in words[M]],'H_image':[j+1 for j in hp],
                        'uncorrected_signs':signs,'torus_correction':bits})
    assert len(generated)==len(comp)
    bitsker=[b for b in product(range(2),repeat=n) if all(sum(C[i][j]*b[j] for j in range(n))%2==0 for i in H)]
    basis=[];span={(0,)*n}
    for b in bitsker:
        if b not in span:basis.append(b);span|={tuple(x^y for x,y in zip(c,b)) for c in list(span)}
    ag=[tor(b) for b in basis];gens=ag+cg
    _,hw=longestH(H);nh=action(hw)
    vv=mul(n0,inv(nh));bb=mul(vv,ga)
    hopp=[hb[tuple(-x for x in longestH(H)[0][i])] for i in H]
    bs=[pin_sign(bb,i,j) for i,j in zip(H,hopp)]
    bfix=next(bits for bits in product(range(2),repeat=n)
              if all(sum(C[j][k]*bits[k] for k in range(n))%2==(0 if sg==1 else 1)
                     for j,sg in zip(hopp,bs)))
    bb=mul(tor(bfix),bb);vv=mul(bb,ga)
    assert all(pin_sign(bb,i,j)==1 for i,j in zip(H,hopp))
    assert all(any(mul(mul(inv(x),inv(bb)),mul(x,bb))==tor(bits) for bits in bitsker) for x in gens)
    rr={b for b in roots if all(sum(C[i][j]*b[j] for j in range(n))==0 for i in H)}
    positive={b for b in rr if all(x>=0 for x in b)}
    kb=sorted(b for b in positive if not any(tuple(x-y for x,y in zip(b,c)) in positive for c in positive))
    sl=smith_normal_form(sy.Matrix(C)[H,:],domain=sy.ZZ)
    row={'source':name,'nodes':nodes,'complement_order':len(comp),'A_order':len(bitsker),
         'Q_order_expected':len(comp)*len(bitsker),'centre_snf':[abs(int(sl[i,i])) for i in range(len(H))],
         'perp_roots':len(rr),'perp_simple':kb,'A_basis':basis,'complement_generators':crecord,
         'longest_H_word':[i+1 for i in hw],'graph_correction':bfix,'graph_uncorrected_pinning_signs':bs}
    cm=sy.Matrix(C); base=cm[H,:]
    def root_matrix(M):return sy.Matrix.hstack(*(sy.Matrix(col) for col in M))
    fixed=base
    for record in crecord:
        z=E
        for i in record['word']:z=right(z,i-1)
        fixed=fixed.col_join(root_matrix(z)-sy.eye(n))
    refs=[]
    for M in comp:
        if base.col_join(root_matrix(M)-sy.eye(n)).rank()-base.rank()==1:
            refs.append(tuple(j for j,sg in action(words[M])))
    row['full_centre_fixed_dimension']=n-fixed.rank()
    row['full_centre_reflections']=len(refs)
    row['reflection_generated_order']=len(closure(refs))
    gap+=['Print("'+name+'\\n");','gg := List('+str([perm(a) for a in gens])+',PermList);;',
          'Q := Group(gg,());; A := Subgroup(Q,gg{[1..'+str(len(ag))+']});;',
          'C := Group(List('+str([unsigned(a) for a in cg])+',PermList),());;',
          'Print("orders ",Size(Q)," ",Size(A)," ",Size(C),"\\n");',
          'bb := PermList('+str(perm(bb))+');; vv := PermList('+str(perm(vv))+');;',
          'Print("graph ",Order(Group([bb],()),bb)," ",ForAll(gg,x->Comm(x,bb) in A)," ",ForAll(gg,x->Comm(x,bb)=()),"\\n");']
    # The e=2 split rational forms use v=n0*n0H^-1 on gamma-stable J.
    if name in ('A1','A3','A2_A2'):
        vm=root_matrix(w0)*root_matrix(longestH(H)[0]).inv()
        vbase=base.col_join(vm+sy.eye(n));vbase_rank=vbase.rank()
        vccomp=[M for M in comp if root_matrix(M)*vm==vm*root_matrix(M)]
        vrefs=[tuple(j for j,sg in action(words[M])) for M in vccomp
               if vbase.col_join(root_matrix(M)-sy.eye(n)).rank()-vbase_rank==1]
        row['e2_active_dimension']=n-vbase_rank
        row['e2_rational_complement_order']=len(vccomp)
        row['e2_active_reflections']=len(vrefs)
        row['e2_reflection_generated_order']=len(closure(vrefs))
        gap+=['CV := Centralizer(Q,vv);; AV := Intersection(CV,A);;',
              'wv := PermList('+str(unsigned(vv))+');;',
              'Print("e2 ",vv in Q," ",Size(CV)," ",Size(AV)," ",Size(Centralizer(C,wv))," ",Size(CV)/Size(AV)=Size(Centralizer(C,wv)),"\\n");']
    if name=='A2':
        assert len(kb)==4
        components=[];left=set(kb)
        while left:
            beta=min(left);component={beta};new=[beta];left.remove(beta)
            while new:
                x=new.pop()
                for y in list(left):
                    if sum(x[i]*C[i][j]*y[j] for i in range(n) for j in range(n)):
                        component.add(y);new.append(y);left.remove(y)
            components.append(sorted(component))
        assert sorted(map(len,components))==[2,2]
        vc=ID;vwords=[]
        for component in components:
            for beta in component:
                a,record=root_tits(beta);vc=mul(vc,a);vwords.append(record)
        assert mul(mul(vc,vc),vc)==ID
        assert all(pin_sign(vc,i,i)==1 for i in H)
        row['e3_coxeter_factors']=components;row['e3_v_words']=vwords
        gap+=['v3 := PermList('+str(perm(vc))+');; w3 := PermList('+str(unsigned(vc))+');;',
              'CQ3 := Centralizer(Q,v3);; AQ3 := Intersection(CQ3,A);; CW3 := Centralizer(C,w3);;',
              'Print("e3 ",v3 in Q," ",Order(Q,v3)," ",Size(CQ3)," ",Size(AQ3)," ",Size(CW3)," ",Size(CQ3)/Size(AQ3)=Size(CW3),"\\n");',
              'Print("e3-group ",Size(Centre(CW3))," ",Size(DerivedSubgroup(CW3))," ",Length(ConjugacyClasses(CW3)),"\\n");']
    rows.append(row)
(OUT/'E6_PINNING_CARRIERS.json').write_text(json.dumps({'weight_count':m,'W_order':len(words),'roots':len(roots),'rows':rows},indent=2)+'\n')
(OUT/'e6_pinning_carrier_checks.g').write_text('\n'.join(gap)+'\n')
print(json.dumps([{k:r[k] for k in ['source','complement_order','A_order','Q_order_expected','centre_snf','graph_uncorrected_pinning_signs','graph_correction']} for r in rows],indent=2))
