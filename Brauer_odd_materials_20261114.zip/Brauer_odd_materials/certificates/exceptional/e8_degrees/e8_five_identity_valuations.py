"""All generic E8 ordinary unipotent degrees at e=1,2 and block prime five.
This is cyclotomic valuation algebra with a free integer a>=1, not q sampling.
"""
from pathlib import Path
from fractions import Fraction
from collections import Counter
import ast,json
P=Path(__file__).resolve().parent
raw=(P/'e8_unipotent_five_identity_output.txt').read_text()
records=[]
for line in raw.splitlines():
    if line.startswith(('HC|','DEG|')):records.append(line)
    elif records and line.startswith((' ','[')):records[-1]+=line.strip()
degrees={};series=[]
for line in records:
    f=line.split('|')
    if f[0]=='HC':series.append({'source':f[1] or 'torus','numbers':ast.literal_eval(f[2])})
    else:degrees[int(f[1])]={'name':f[2],'coefficient':Fraction(f[3]),'phi':ast.literal_eval(f[4])}
assert len(degrees)==166
def valuation(n):
    t=0
    while n%5==0:t+=1;n//=5
    return t
def degreeval(d,e):
    c=d['coefficient'];b=valuation(abs(c.numerator))-valuation(c.denominator)
    i=5*e
    while i<=30:b+=d['phi'][i-1];i*=5
    return d['phi'][e-1],b
out={'notation':'(a coefficient, constant) for character defect, a=v5(q-epsilon)>=1',
     'method':'All 166 CHEVIE generic degree objects, exact rational coefficients and all cyclotomic valuations'}
for e in (1,2):
    defects={i:(8-degreeval(d,e)[0],2-degreeval(d,e)[1]) for i,d in degrees.items()}
    target=[i for i,z in defects.items() if z==(4,0)]
    # All other affine defect functions avoid 4a for all integers a>=1.
    other_equal=[]
    for i,(m,b) in defects.items():
        if (m,b)==(4,0):continue
        if m==4:
            if b==0:other_equal.append((i,'all'))
        else:
            x=Fraction(-b,m-4)
            if x.denominator==1 and x>=1:other_equal.append((i,int(x)))
    assert len(target)==25 and not other_equal
    out[str(e)]={'defect_counts':{str(k):v for k,v in sorted(Counter(defects.values()).items())},
                'all_and_only_defect_4a_numbers':target,'other_equal_for_integer_a_ge_1':other_equal}
    if e==1:
        d4=next(h['numbers'] for h in series if h['source']=='D_4')
        assert set(d4)==set(target)
        out['1']['exactly_original_D4_HC_series']=True
(P/'E8_BAD_FIVE_IDENTITY_SYMBOLIC_RECEIPT.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
