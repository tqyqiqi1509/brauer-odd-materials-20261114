RequirePackage("chevie");;
w:=CoxeterGroup("E",8);; uc:=UnipotentCharacters(w);;
deg:=CycPolUnipotentDegrees(w);; names:=CharNames(uc);; d:=false;;
for hc in uc.harishChandra do
 Print("HC|",hc.cuspidalName,"|",hc.charNumbers,"\n");
od;
for k in [1..Length(deg)] do
 d:=deg[k];
 Print("DEG|",k,"|",names[k],"|",d.coeff,"|",List([1..30],j->Valuation(d,j)),"\n");
od;
