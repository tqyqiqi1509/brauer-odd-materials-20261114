"""Write the integrity manifest of this finite-data supplement."""
from pathlib import Path
import hashlib,json

HERE=Path(__file__).resolve().parent
files=[]
for p in sorted(HERE.rglob("*")):
    if not p.is_file() or p.name=="manifest.json" or "__pycache__" in p.parts:
        continue
    files.append({"path":p.relative_to(HERE).as_posix(),
                  "bytes":p.stat().st_size,
                  "sha256":hashlib.sha256(p.read_bytes()).hexdigest()})
out={"schema_version":1,"path_base":".","files":files}
(HERE/"manifest.json").write_text(json.dumps(out,indent=2)+"\n")
print("Manifest:",len(files),"files;",sum(r["bytes"] for r in files),"bytes")

