ODD-PRIME ENDPOINT CERTIFICATES
================================

This directory is the complete finite-data supplement to the odd-prime
endpoint chapter. Paths in this document and in checks.json are relative
to this directory. The article proves the classification coverage, actual
block support, rational source extension and phase statements. The files
here verify the finite integer and rational computations used in those
proofs; no local mathematical manuscript is an input.

REQUIREMENTS AND ENTRY POINT

Python 3.10 or later with SymPy; GAP 4.14 or later core for the integral carriers;
GAP 4.14 or later with CTblLib for the finite ordinary character tables. Re-exporting
the generic E8 unipotent degree objects additionally needs GAP3/CHEVIE.
The bundled degree export itself is complete, so all its valuation
consequences require only Python's standard library.

checks.json is the machine-readable task list: script, runtime, outputs,
expected outputs, dependencies, comparison rule and timeout. Resolve each
path against the directory containing checks.json. Each Python script
locates its own inputs through __file__, and each GAP4 input is standalone.
Thus every command can be launched from another working directory using
an absolute script path. The surrounding article bundle may provide a
convenience runner which reads this task list.

PYTHON_RECONSTRUCTION_VALIDATION.json records six complete JSON equality
checks against the original retained expected data: the 52 bounds, modular
and rank-two calculations, 166-degree valuation calculation, and all three
integral carrier generators. carriers/CARRIER_VALIDATION.json is produced only
after all three complete GAP4 carrier outputs have passed their verifier.
finite/FINITE_VALIDATION.json states explicitly whether it validated retained
outputs or also ran the GAP programs afresh.

1. STRONG EXCEPTIONAL BOUNDS

Run:
  python strong_e/reconstruct_strong_e.py

The input is the four complete public CHEVIE class-word/class-size arrays
in strong_e/chevie_primary. The script constructs integral reflections,
checks the exact order of every class word and the total class-size sum,
factors the characteristic polynomials, and derives the symbolic Burnside
counts. Logarithmic-derivative recurrences construct the partition,
signed-permutation and type-D polynomials over Q[s].

The same program reconstructs all 240 E8 roots, the eight affine maximal
rank centralizers and their Smith factors, the D4/D4 and A2/E6 mutual
centralizers, and the 478 proper three-primary affine faces. It checks
their maximal unipotent weight 90. For all 52 rows it checks nonnegative
coefficients, the degree bound and the exact rational endpoint inequality.
The article explains why these checks imply every larger valuation.

The generated strong_e/STRONG_E_RECONSTRUCTION.json must equal
strong_e/expected/STRONG_E_RECONSTRUCTION.json as a JSON object.
The output contains every coefficient and every retained affine face.

Run also:
  python strong_e/modular_rank_and_rank_two.py

This constructs the order-three class matrices directly from the public
words and computes row ranks modulo 3. The E6 ranks are 3,2,3; the E7
ranks are 2,4,4, with nonzero square of w-1 in all three E7 cases.
The E6 argument uses its ranks and does not assert that every such
square in E6 is nonzero. The same program enumerates W(G2) and W(D4),
of orders 12 and 192, with the actual order-three diagram matrix, and
derives both rational signs of the two rank-two Burnside polynomials.
Compare MODULAR_RANK_AND_RANK_TWO.json with its expected counterpart.

The four input files are by Jean Michel, Chevie.jl, src/tbl:
  weylf4.jl, weyle6.jl, weyle7.jl, weyle8.jl
Source revision:
  2be70d26531685c74f106b2714bf23b7b5dc6805
strong_e/chevie_primary/SOURCE_PROVENANCE.json gives each exact source
URL, size and SHA-256. The license from that revision is included.
No polynomial output is read by the reconstruction algorithm.

2. INTEGRAL SOURCE CARRIERS

Run the generators:
  python carriers/e6_rank_one_carrier_rerun.py
  python carriers/e7_rank_one_carriers_rerun.py
  python carriers/reconstruct_e8_pinning.py

The E8 program imports the local e8_tits_model.py. It has no historical
absolute-path dependency. The article specifies the 56-weight E7 and 240-root E8 integral models.
The faithful 54-weight E6 model is retained as an additional computation
from the earlier materials; the current proof does not use that model.
They verify the Chevalley relations, Tits squares and braids; enumerate
perpendicular root systems and joint diagram isometries; correct all
pinning signs; and retain the full toral two-overlap and true return.

The three JSON outputs must equal the corresponding files in
carriers/expected. The generators also produce GAP3-syntax permutation
files. Translate those newly generated files by:
  python carriers/make_gap4_inputs.py

The --bare option skips automatic optional-package loading; these checks need
only GAP core. The translated GAP4 inputs are already included, so the following three
checks can also be run directly without repeating the generators:
  gap --bare -q -b -T carriers/e6_overlap_gap4.g > carriers/e6.out
  gap -q -b carriers/e7_overlap_gap4.g > carriers/e7.out
  gap -q -b carriers/e8_overlap_gap4.g > carriers/e8.out
  python carriers/verify_carriers.py

The GAP4 inputs contain every required permutation; no external group
file is read. They assert exact carrier orders, normality and elementary
abelianness of the complete overlap, its equality with the toral kernel
where applicable, all distinct index-two character kernels, the full
commutator-intersection extension criterion in every inertia group, and
the exact true return orders. They check 15 + 140 + 124 = 279 nontrivial
overlap characters, with no failures. The verifier also requires that all
rows ran to completion. A shell return code zero by itself is insufficient;
the verifier rejects GAP error text and missing rows.

Provenance of E6 records is intentionally explicit:
  carriers/expected/e6_original_orders.out
is the original short record of the order and graph-return check only.
It does NOT contain the complete 15-colour inertia calculation.
  carriers/e6.out
is the output of the new complete GAP4 input above.
When the completed output is retained as a baseline it is named
  carriers/expected/e6_full_overlap.out.
The E7/E8 original complete outputs are carriers/expected/e7.out and
carriers/expected/e8.out; their newly executed outputs are carriers/e7.out
and carriers/e8.out. The exact all-colour assertion results are summarized
in carriers/CARRIER_VALIDATION.json.

3. ALL 166 GENERIC E8 UNIPOTENT DEGREES

The complete public-CHEVIE export program is e8_degrees/export.g.
With GAP3/CHEVIE:
  gap3 -q < e8_degrees/export.g > e8_degrees/new_degree_export.txt

It calls CoxeterGroup("E",8), UnipotentCharacters and
CycPolUnipotentDegrees. It exports every Harish-Chandra series and all
166 character names, rational scalar coefficients and cyclotomic
valuations through Phi_30. The complete retained export is:
  e8_degrees/e8_unipotent_five_identity_output.txt

Its exact symbolic analysis is:
  python e8_degrees/e8_five_identity_valuations.py

Compare the generated E8_BAD_FIVE_IDENTITY_SYMBOLIC_RECEIPT.json with
e8_degrees/expected/E8_BAD_FIVE_IDENTITY_SYMBOLIC_RECEIPT.json.
For both rational signs and every integer a >= 1, it identifies all and
only the 25 characters of defect 4a. It uses exact rational coefficient
valuations and checks that no other defect expression equals 4a at an
integer a >= 1. No field-size sample substitutes for this argument.

The 166 generic degree objects themselves were not freshly re-exported
in the independent audit or this recovery run. Their complete export and
public export algorithm are supplied. Their full symbolic valuation
consequence was independently recomputed and was again reproduced from
the portable source directory.

4. THE COMPLETE FINITE ORDINARY TABLE DOMAIN

Run:
  gap --bare -q -b -T finite/finite_exceptional_all.g > finite/finite_exceptional_all.out
  gap --bare -q -b -T finite/finite_sporadic_all.g > finite/finite_sporadic_all.out
  gap --bare -q -b -T finite/g24_c2_capacity.g > finite/g24_c2_capacity.out

Or run and compare the entire calculation in one command:
  python finite/verify_finite.py --run --gap /absolute/path/to/gap

The first two programs contain every exact ATLAS table name and outer
order as literal input. They visit all 58 exceptional-cover inputs and
all 48 sporadic/Tits inputs. They use ordinary PrimeBlocks, exclude primes
dividing the centre, and retain precisely the positive-height rows.
Kessar--Malle's height-zero equivalence for all quasisimple groups makes
this exactly the nonabelian-defect domain.

There are 44 exceptional rows and 73 sporadic/Tits rows, for 117 in all.
All except three G2(4) rows satisfy the crude outer-order bound. The
third program computes the actual class fusion, character permutation,
restriction multiplicities, covering block numbers and defects in those
three cases. The covering counts are [14,14], [14,14], and [13].

The original complete expected outputs, in finite/expected, retain
META|GAP|4.16.1|CTblLib|1.3.11. In the previous independent audit all
106 tables, 117 rows and the complete G2(4) data were also reproduced
with GAP 4.14.0 and CTblLib 1.3.9. These version statements are distinct;
the original files have not been relabelled as that independent run.
The portable inputs supplied here were subsequently run with GAP 4.14.0
and CTblLib 1.3.11. Every mathematical record again matched the original
expected output. The resulting finite/FINITE_VALIDATION.json records
mode fresh_execution_exact_match. All newly produced outputs retain
their own actual runtime metadata.

Running finite/verify_finite.py without --run checks the retained output
domain and its exact arithmetic only. With --run it executes all three
GAP programs and compares every TABLE, BLOCK, PAIR, FUSION, CHARPERM and
CAPACITY record against the original expected data. Only whitespace and
META version lines are ignored. It rejects missing tables or GAP errors.
FINITE_VALIDATION.json records which mode actually ran.

FILE INTEGRITY

manifest.json lists every distributed file by relative path, byte size
and SHA-256, excluding itself. Python bytecode, temporary compiler files,
historical manuscripts, unsuccessful attempts and unrelated audit files
are not part of the supplement.
