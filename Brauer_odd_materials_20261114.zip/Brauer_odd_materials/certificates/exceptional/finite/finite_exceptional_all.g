LoadPackage("ctbllib");;
SetInfoLevel(InfoCharacterTable,0);;
SizeScreen([240,100000]);;
families := [
 [2,["A5","2.A5"]], [2,["L3(2)","2.L3(2)"]],
 [12,["L3(4)","2.L3(4)","2^2.L3(4)","4_1.L3(4)","4_2.L3(4)","(2x4).L3(4)","4^2.L3(4)"]],
 [2,["A8","2.A8"]], [2,["U4(2)","2.U4(2)"]],
 [6,["U6(2)","2.U6(2)","2^2.U6(2)","3.U6(2)","6.U6(2)","(2^2x3).U6(2)"]],
 [4,["A6","2.A6","3.A6","6.A6"]],
 [3,["Sz(8)","2.Sz(8)","2^2.Sz(8)"]],
 [1,["S6(2)","2.S6(2)"]], [6,["O8+(2)","2.O8+(2)","2^2.O8+(2)"]],
 [2,["G2(4)","2.G2(4)"]], [2,["F4(2)","2.F4(2)"]],
 [6,["2E6(2)","2.2E6(2)","2^2.2E6(2)","3.2E6(2)","6.2E6(2)","(2^2x3).2E6(2)"]],
 [2,["G2(3)","3.G2(3)"]], [2,["O7(3)","2.O7(3)","3.O7(3)","6.O7(3)"]],
 [8,["U4(3)","2.U4(3)","4.U4(3)","3_1.U4(3)","3_2.U4(3)","6_1.U4(3)","6_2.U4(3)","12_1.U4(3)","12_2.U4(3)"]]
];;
Print("META|GAP|",GAPInfo.Version,"|CTblLib|",PackageInfo("ctbllib")[1].Version,"\n");
for row in families do
 for nm in row[2] do
  t:=CharacterTable(nm);
  if t=fail then Print("MISSING|",nm,"\n");continue;fi;
  cen:=Number(SizesConjugacyClasses(t),x->x=1);
  Print("TABLE|",Identifier(t),"|",Size(t),"|",Length(Irr(t)),"|",row[1],"|",cen,"\n");
  for p in Filtered(PrimeDivisors(Size(t)),p->p<>2 and cen mod p<>0) do
   bl:=PrimeBlocks(t,p);
   opart:=row[1]; while opart mod p=0 do opart:=opart/p; od;
   for j in [1..Length(bl.defect)] do
    inds:=Positions(bl.block,j); kk:=Length(inds); d:=bl.defect[j];
    posh:=Number(inds,x->bl.height[x]>0);
    if posh>0 then
     Print("BLOCK|",Identifier(t),"|",p,"|",j,"|",d,"|",p^d,"|",kk,"|",posh,"|",opart,"|",opart*kk<=p^d,"\n");
    fi;
   od;
  od;
 od;
od;
QUIT;
