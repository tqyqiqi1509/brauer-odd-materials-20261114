"""Validate complete ordinary-table outputs against the printed finite domain.

Usage:
  python finite/verify_finite.py
  python finite/verify_finite.py --run --gap /path/to/gap

Without --run this verifies the retained public-table outputs.
With --run it runs the three standalone GAP programs in this directory,
checks completeness, and compares all mathematical records. Only version
metadata and whitespace may differ. The original META lines are preserved.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re
import subprocess

HERE=Path(__file__).resolve().parent
STEMS=("finite_exceptional_all","finite_sporadic_all","g24_c2_capacity")
RECORD=re.compile(r"^(META|TABLE|BLOCK|PAIR|FUSION|CHARPERM|CAPACITY|MISSING)\|")

def records(path):
    text=path.read_text()
    if "MISSING|" in text or re.search(r"(Error,|Syntax error|brk>)",text):
        raise AssertionError("incomplete/failed GAP run: "+str(path))
    out=[];current=[]
    for line in text.splitlines():
        if RECORD.match(line):
            if current:out.append(re.sub(r"\s+","", "".join(current)))
            current=[line]
        elif current:
            current.append(line)
    if current:out.append(re.sub(r"\s+","", "".join(current)))
    return [r for r in out if not r.startswith("META|")]

def validate_domain(a,b,c):
    tables_a=[x for x in a if x.startswith("TABLE|")]
    tables_b=[x for x in b if x.startswith("TABLE|")]
    rows_a=[x.split("|") for x in a if x.startswith("BLOCK|")]
    rows_b=[x.split("|") for x in b if x.startswith("BLOCK|")]
    assert len(tables_a)==58 and len(tables_b)==48
    assert len(rows_a)==44 and len(rows_b)==73
    failures=[]
    for r in rows_a+rows_b:
        _,name,p,j,d,delta,k,h,actor,ok=r
        p,j,d,delta,k,h,actor=map(int,(p,j,d,delta,k,h,actor))
        assert p>2 and delta==p**d and h>0
        assert (actor*k<=delta)==(ok=="true")
        if ok=="false":failures.append((name,p,j,delta,k))
    assert failures==[("G2(4)",3,1,27,14),("2.G2(4)",3,1,27,14),("2.G2(4)",3,10,27,14)]
    capacities=[x.split("|") for x in c if x.startswith("CAPACITY|")]
    assert len(capacities)==3
    targets=[("G2(4)","1","14","28","[[1,3,14],[2,3,14]]"),
             ("2.G2(4)","1","14","28","[[1,3,14],[2,3,14]]"),
             ("2.G2(4)","10","4","13","[[9,3,13]]")]
    for row,target in zip(capacities,targets):
        assert (row[1],row[3],row[7],row[8],row[10])==target
        assert row[4]=="27" and row[5]=="14"
    assert sum(x.startswith("FUSION|") for x in c)==2
    assert sum(x.startswith("CHARPERM|") for x in c)==2
    return {"exceptional_tables":58,"sporadic_Tits_tables":48,
            "exceptional_positive_height_rows":44,
            "sporadic_Tits_positive_height_rows":73,
            "total_positive_height_rows":117,
            "crude_bound_failures":failures,
            "actual_corrected_cover_counts":[[14,14],[14,14],[13]]}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--run",action="store_true")
    ap.add_argument("--gap",default="gap")
    args=ap.parse_args()
    expected=[records(HERE/"expected"/(stem+".out")) for stem in STEMS]
    report=validate_domain(*expected)
    report["mode"]="retained_output_validation"
    if args.run:
        for stem in STEMS:
            result=subprocess.run([args.gap,"--bare","-q","-b","-T",str(HERE/(stem+".g"))],
                                  text=True,capture_output=True,timeout=900)
            (HERE/(stem+".out")).write_text(result.stdout)
            (HERE/(stem+".stderr")).write_text(result.stderr)
            if re.search(r"(?m)^(?:Error,|Syntax error|#E|brk>)", result.stderr):
                raise RuntimeError("GAP reported an error on stderr: "+stem)
            if result.returncode!=0:
                raise AssertionError(stem+" failed: "+result.stderr[-1000:])
        actual=[records(HERE/(stem+".out")) for stem in STEMS]
        validate_domain(*actual)
        assert actual==expected,"mathematical table records changed"
        report["mode"]="fresh_execution_exact_match"
    report["expected_sha256"]={stem:hashlib.sha256(
        (HERE/"expected"/(stem+".out")).read_bytes()).hexdigest() for stem in STEMS}
    (HERE/"FINITE_VALIDATION.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps(report,indent=2))

if __name__=="__main__":main()

