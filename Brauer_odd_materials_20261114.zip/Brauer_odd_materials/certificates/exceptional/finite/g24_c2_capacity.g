LoadPackage("ctbllib");;
SizeScreen([240,100000]);;
for nm in ["G2(4)","2.G2(4)"] do
 t:=CharacterTable(nm);u:=CharacterTable(Concatenation(nm,".2"));
 Print("PAIR|",Identifier(t),"|",Identifier(u),"\n");
 fus:=GetFusionMap(t,u);if fus=fail then fus:=PossibleClassFusions(t,u)[1];fi;
 Print("FUSION|",fus,"\n");
 perm:=List([1..Length(fus)],i->i);
 for target in Set(fus) do
  fiber:=Positions(fus,target);if Length(fiber)=2 then perm[fiber[1]]:=fiber[2];perm[fiber[2]]:=fiber[1];elif Length(fiber)>2 then Error("bad index2 fiber");fi;
 od;
 a:=PermList(perm);
 ir:=Irr(t);up:=Irr(u);
 charperm:=List(ir,c->Position(ir,Permuted(c,a)));
 Print("CHARPERM|",charperm,"\n");
 bl:=PrimeBlocks(t,3);bu:=PrimeBlocks(u,3);
 restr:=List(up,c->c{fus});
 for j in [1..Length(bl.defect)] do
  inds:=Positions(bl.block,j);kk:=Length(inds);d:=bl.defect[j];
  if ForAny(inds,x->bl.height[x]>0) then
   stable:=Set(charperm{inds})=Set(inds);
   fixed:=Number(inds,i->charperm[i]=i);
   above:=Filtered([1..Length(up)],i->ForAny(inds,j->ScalarProduct(t,restr[i],ir[j])>0));
   covers:=Set(bu.block{above});
   Print("CAPACITY|",nm,"|3|",j,"|",3^d,"|",kk,"|",stable,"|",fixed,"|",(kk+3*fixed)/2,"|",covers,"|",List(covers,c->[c,bu.defect[c],Number(bu.block,x->x=c)]),"\n");
  fi;
 od;
od;
QUIT;
