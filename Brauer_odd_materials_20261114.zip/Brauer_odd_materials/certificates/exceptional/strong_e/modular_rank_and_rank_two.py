"""Exact modular order-three ranks and rank-two twisted Burnside counts."""
from pathlib import Path
from collections import deque
import json
import sympy as sp
from sympy.liealgebras.cartan_type import CartanType
from reconstruct_strong_e import jarray

HERE=Path(__file__).resolve().parent
s,x=sp.symbols("s x")

def rank_mod(M,p):
    a=[[int(v)%p for v in row] for row in M.tolist()]
    r=0
    for c in range(M.cols):
        pivot=next((i for i in range(r,M.rows) if a[i][c]),None)
        if pivot is None:continue
        a[r],a[pivot]=a[pivot],a[r]
        v=pow(a[r][c],-1,p)
        a[r]=[(v*z)%p for z in a[r]]
        for i in range(M.rows):
            if i!=r:
                v=a[i][c]
                a[i]=[(z-v*y)%p for z,y in zip(a[i],a[r])]
        r+=1
        if r==M.rows:break
    return r

def reflections(C):
    rr=[]
    for i in range(C.rows):
        R=sp.eye(C.rows)
        for j in range(C.rows):R[i,j]-=C[j,i]
        rr.append(sp.ImmutableMatrix(R))
    return rr

def ternary(name):
    raw=(HERE/"chevie_primary"/("weyl"+name.lower()+".jl")).read_text()
    if name=="E6":words=jarray(raw,raw.index(":classwords =>"))
    else:
        pos=raw.index(":classwords,")
        words=jarray(raw,raw.index("[Int[]",pos))
        words=[[j for k in w for j in (list(range(7,0,-1)) if k==0 else [k])] for w in words]
    pos=raw.index(":classinfo,")
    orders=jarray(raw,raw.index(":orders",pos))
    sizes=jarray(raw,raw.index(":classes",pos))
    C=CartanType(name).cartan_matrix()
    rs=reflections(C);I=sp.eye(C.rows);out=[]
    for i,(word,order,size) in enumerate(zip(words,orders,sizes),1):
        if order!=3:continue
        M=I
        for k in word:M=M*rs[k-1]
        assert M**3==I and M!=I
        T=M-I;rank=rank_mod(T,3);square=rank_mod(T*T,3)
        if name == "E7": assert square>0
        out.append({"class_index":i,"class_size":size,"word":word,
                    "matrix":M.tolist(),"rank_F3":rank,"square_rank_F3":square,
                    "square_mod3":(T*T).applyfunc(lambda a:int(a)%3).tolist()})
    assert sorted(z["rank_F3"] for z in out)==({"E6":[2,3,3],"E7":[2,4,4]}[name])
    return out

def group(C):
    rs=reflections(C);I=sp.ImmutableMatrix(sp.eye(C.rows))
    seen={I};todo=deque([I])
    while todo:
        M=todo.popleft()
        for R in rs:
            N=R*M
            if N not in seen:seen.add(N);todo.append(N)
    return sorted(seen,key=lambda M:tuple(M))

def burnside(W,gamma,d):
    ans=0
    for M in W:
        fac=sp.factor_list((x*sp.eye(M.rows)-gamma*M).det())[1]
        term=1
        for f,e in fac:
            if sp.expand(f-sp.cyclotomic_poly(d,x))==0:term*=s**e
            elif sp.expand(f-sp.cyclotomic_poly(3*d,x))==0:term*=3**e
        ans+=term
    return sp.expand(ans/len(W))

def rank_two():
    CG=sp.Matrix([[2,-1],[-3,2]])
    CD=sp.Matrix([[2,-1,0,0],[-1,2,-1,-1],[0,-1,2,0],[0,-1,0,2]])
    WG,WD=group(CG),group(CD)
    gamma=sp.eye(4)[[2,1,3,0],:].T
    assert len(WG)==12 and len(WD)==192 and gamma**3==sp.eye(4)
    ng=burnside(WG,sp.eye(2),1);nt=burnside(WD,gamma,1)
    assert sp.expand(ng-(s+3)**2/12)==0
    assert sp.expand(nt-(s+1)*(s+3)/4)==0
    assert burnside(WG,sp.eye(2),2)==ng and burnside(WD,gamma,2)==nt
    return {"G2_order":12,"D4_order":192,"triality":gamma.tolist(),
            "G2_count":str(ng),"triality_count":str(nt),
            "G2_bound":str(sp.expand(4*ng+6)),
            "triality_bound":str(sp.expand(8*nt+6)),
            "endpoint_ratios":["2/3","2/3"]}

def main():
    out={"order_three":{"E6":ternary("E6"),"E7":ternary("E7")},
         "rank_two":rank_two()}
    target=HERE/"MODULAR_RANK_AND_RANK_TWO.json"
    target.write_text(json.dumps(out,indent=2,default=int)+"\n")
    print("Order-three ranks over F3:",{k:[z["rank_F3"] for z in v] for k,v in out["order_three"].items()})
    print("Rank-two exact Burnside counts:",out["rank_two"])

if __name__=="__main__":main()

