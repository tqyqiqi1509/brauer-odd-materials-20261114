"""Independent all-valuation exceptional strong-E reconstruction.

Uses freshly downloaded primary CHEVIE class words; no old result JSON is an
input. Symbolic recurrences are logarithmic-derivative recurrences over Q[s].
The root-datum computation enumerates the 240 E8 roots from Cartan generators,
then constructs all full-rank centralizers by affine node deletion.
"""
from pathlib import Path
import ast, hashlib, json
from functools import lru_cache
import sympy as sp
from sympy.liealgebras.cartan_type import CartanType
from sympy.matrices.normalforms import smith_normal_form
from sympy.polys.domains import ZZ

HERE=Path(__file__).resolve().parent
s,x=sp.symbols('s x')

def jarray(text,start):
    start=text.index('[',start)
    depth=0
    for end in range(start,len(text)):
        if text[end]=='[':depth+=1
        elif text[end]==']':
            depth-=1
            if not depth:return ast.literal_eval(text[start:end+1].replace('Int[]','[]'))
    raise ValueError('incomplete primary array')

def class_data(name):
    path=HERE/'chevie_primary'/('weyl'+name.lower()+'.jl')
    text=path.read_text()
    if name=='E6':words=jarray(text,text.index(':classwords =>'))
    else:
        a=text.index(':classwords,')
        words=jarray(text,text.index('[Int[]',a))
        zero=list(range(7,0,-1)) if name=='E7' else list(range(1,int(name[1])+1))
        words=[[j for k in w for j in (zero if k==0 else [k])] for w in words]
    pos=text.index(':classinfo,')
    sizes=jarray(text,text.index(':classes',pos))
    orders=jarray(text,text.index(':orders',pos))
    assert len(words)==len(sizes)==len(orders)
    C=CartanType(name).cartan_matrix();r=C.rows
    reflections=[]
    for i in range(r):
        M=sp.eye(r)
        for j in range(r):M[i,j]-=C[j,i]
        reflections.append(M)
    classes=[]
    cycl={sp.Poly(sp.cyclotomic_poly(n,x),x).as_expr():n for n in range(1,121)}
    for word,size,order in zip(words,sizes,orders):
        M=sp.eye(r)
        for k in word:M=M*reflections[k-1]
        assert M**order==sp.eye(r)
        assert all(M**d!=sp.eye(r) for d in sp.divisors(order) if d<order)
        factors=sp.factor_list(M.charpoly(x).as_expr())[1]
        spectrum={cycl[sp.Poly(f,x).as_expr()]:e for f,e in factors}
        classes.append({'size':size,'order':order,'cyclotomics':spectrum})
    expected={'F4':1152,'E6':51840,'E7':2903040,'E8':696729600}[name]
    assert sum(sizes)==expected
    return {'type':name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
            'order':expected,'classes':classes}

def burnside(data,p,d=1):
    out=0
    for c in data['classes']:
        exponent=0
        for n,e in c['cyclotomics'].items():
            t=n
            while t%p==0:t//=p
            if t==d and n!=d:exponent+=e
        out+=c['size']*p**exponent*s**c['cyclotomics'].get(d,0)
    return sp.expand(out/data['order'])

def sigma(n):return sp.divisor_sigma(n)

@lru_cache(None)
def exp_series(h):
    """h[j] is coefficient of z^j in log F, h[0]=0."""
    c=[sp.Integer(1)]
    for n in range(1,len(h)):
        c.append(sp.expand(sum(j*h[j]*c[n-j] for j in range(1,n+1))/n))
    return tuple(c)

@lru_cache(None)
def a_series(n,p):
    h=[sp.Integer(0)]
    for j in range(1,n+1):
        value=s*sigma(j)/j
        step=p
        while step<=j:
            if j%step==0:value+=(s-s/p)*step*sigma(j//step)/j
            step*=p
        h.append(sp.expand(value))
    return exp_series(tuple(h))[n]

@lru_cache(None)
def linear(n,p):
    if n%p: return sp.expand(a_series(n,p)/s)
    # At n<=8, only the p=3, n=6 correction is used.
    assert p==3 and n==6
    return sp.expand((a_series(6,3)+8*a_series(2,3))/s)

@lru_cache(None)
def bc_weight(n,p=3):
    h=[sp.Integer(0)]
    for j in range(1,n+1):
        value=(s+3)*sigma(j)/(2*j)
        step=p
        while step<=j:
            if j%step==0:value+=(s-s/p)*step*sigma(j//step)/(2*j)
            step*=p
        h.append(sp.expand(value))
    return exp_series(tuple(h))[n]

def valuation(n,p):
    a=0
    while n%p==0:a+=1;n//=p
    return a

@lru_cache(None)
def d_classes(n,p):
    return sp.expand(sum(exp_series(tuple([sp.Integer(0)]+[
        (s*p**valuation(j,p)+sign)/(2*j) for j in range(1,n+1)]))[n]
        for sign in (1,-1)))

def diagram_type(gram):
    n=gram.rows
    if not n:return []
    adj={i:[j for j in range(n) if i!=j and gram[i,j]!=0] for i in range(n)}
    assert all(gram[i,j] in (0,-1) for i in range(n) for j in range(n) if i!=j)
    unseen=set(range(n));types=[]
    while unseen:
        start=next(iter(unseen));cc={start};stack=[start]
        while stack:
            v=stack.pop()
            for w in adj[v]:
                if w not in cc:cc.add(w);stack.append(w)
        unseen-=cc;r=len(cc);branch=[v for v in cc if len(adj[v])==3]
        if not branch:typ='A'+str(r)
        else:
            assert len(branch)==1
            center=branch[0];arms=[]
            for v in adj[center]:
                length=1;last=center
                while len(adj[v])==2:
                    nxt=next(w for w in adj[v] if w!=last);last,v=v,nxt;length+=1
                arms.append(length)
            arms.sort()
            typ=('D'+str(r)) if arms[:2]==[1,1] else 'E'+str(r)
            assert typ[0]=='D' or arms==[1,2,r-4]
        types.append(typ)
    return sorted(types)

def root_datum():
    C=CartanType('E8').cartan_matrix();assert C.det()==1
    roots=set(tuple(int(i==j) for i in range(8)) for j in range(8))
    frontier=list(roots)
    while frontier:
        v=frontier.pop()
        for i in range(8):
            v1=list(v);v1[i]-=sum(C[j,i]*v[j] for j in range(8));v1=tuple(v1)
            if v1 not in roots:roots.add(v1);frontier.append(v1)
    assert len(roots)==240
    highest=max((v for v in roots if min(v)>=0),key=sum)
    inv=C.inv();rows=[]
    for i,m in enumerate(highest):
        gens=[-sp.Matrix(highest)]+[sp.eye(8)[:,j] for j in range(8) if j!=i]
        B=sp.Matrix.hstack(*gens);gram=B.T*C*B
        types=diagram_type(gram)
        label=inv[:,i]/m
        assert all((v.T*C*label)[0].q==1 for v in gens)
        assert m*label==inv[:,i]
        central=[v for v in roots if v[i]%m==0]
        snf=smith_normal_form(B,domain=ZZ)
        diag=[abs(int(snf[j,j])) for j in range(8)]
        assert diag==[1]*7+[m]
        rows.append({'node':i+1,'m':m,'type':' '.join(sorted(types)),
                     'centralizer_roots':len(central),'lattice_index':abs(int(B.det())),
                     'pi1_smith':diag,'label_root_coordinates':[str(v) for v in label],
                     'simple_generators':[list(map(int,v)) for v in gens]})
    # Every proper affine face, filtered by the necessary 3-power
    # denominator condition. This ranges over centralizer types, not fields.
    aff=sp.Matrix.hstack(-sp.Matrix(highest),sp.eye(8))
    marks=[1]+list(map(int,highest));faces=[]
    exceptional={'D4':14,'D5':20,'D6':42,'D7':65,'D8':120,
                 'E6':30,'E7':76,'E8':166}
    for mask in range(511):
        keep=[i for i in range(9) if mask&(1<<i)]
        omitted=[marks[i] for i in range(9) if not mask&(1<<i)]
        gcd=sp.igcd(*omitted) if len(omitted)>1 else omitted[0]
        z=gcd
        while z%3==0:z//=3
        if z!=1:continue
        B=aff[:,keep];types=diagram_type(B.T*C*B)
        if types==['E8']:continue
        unipotent=sp.prod(sp.partition(int(t[1:])+1) if t[0]=='A' else exceptional[t] for t in types)
        faces.append({'mask':mask,'type':' '.join(types),'omitted_gcd':int(gcd),
                      'unipotent_bound':int(unipotent)})
    assert len(faces)==478
    assert max(v['unipotent_bound'] for v in faces)==90
    core=[]
    for name,ids in [('D4',[1,2,3,4]),('A2',[0,2])]:
        B=sp.eye(8)[:,ids]
        perp=[sp.Matrix(v) for v in roots if B.T*C*sp.Matrix(v)==sp.zeros(len(ids),1)]
        core.append({'core':name,'core_gram_determinant':int((B.T*C*B).det()),
                     'perpendicular_root_count':len(perp),
                     'perpendicular_rank':sp.Matrix.hstack(*perp).rank()})
    assert [(v['perpendicular_root_count'],v['perpendicular_rank']) for v in core]==[(24,4),(72,6)]
    return {'cartan':C.tolist(),'highest_root':list(map(int,highest)),
            'root_count':len(roots),'rows':rows,'proper_three_faces':faces,
            'mutual_core_centralizers':core}

def serialize_poly(f):
    f=sp.Poly(sp.expand(f),s)
    return {'polynomial':str(f.as_expr()),'degree':f.degree(),
            'coefficients':[str(c) for c in reversed(f.all_coeffs())]}

def main():
    data={name:class_data(name) for name in ['F4','E6','E7','E8']}
    rows=[]
    def add(name,p,r,c,actor,K,endpoint=None):
        K=sp.expand(K);poly=sp.Poly(K,s)
        assert poly.degree()<=r and all(v>=0 for v in poly.all_coeffs())
        boundary=p if endpoint is None else endpoint
        at=K.subs(s,boundary);ratio=sp.factor(actor*at/(c*boundary**r))
        assert ratio<1
        rows.append({'name':name,'p':p,'rank':r,'defect_coefficient':c,'actor':actor,
                     'endpoint':boundary,
                     'endpoint_count':str(at),'endpoint_ratio':str(ratio),**serialize_poly(K)})
    # Principal families, both d signs folded when -1 belongs to W.
    principals=[('F4',3,1,4,9,4,25,12),('E6',3,1,6,27,4,270,0),
      ('E6',3,2,4,9,4,30,0),('E6',5,1,6,5,24,30,0),
      ('E7',3,1,7,81,4,128,0),('E7',5,1,7,5,8,128,0),
      ('E7',7,1,7,7,12,128,0),('E8',3,1,8,243,2,256,0),
      ('E8',5,1,8,25,4,256,0),('E8',5,4,4,5,4,256,0),
      ('E8',7,1,8,7,6,256,0)]
    for name,p,d,r,c,a,mul,extra in principals:
        add(f'principal {name} d{d}',p,r,c,a,mul*burnside(data[name],p,d)+extra)
    L=lambda n:linear(n,3)
    K=lambda n:bc_weight(n,3)
    nrel=(s**3+9*s**2+39*s+15)/48
    # All E8 isolated nonabelian 3-blocks, exact source selections.
    e8three=[('D8 toral',8,9,1,256*d_classes(8,3)),
      ('D8 D4',4,3,2,K(4)),('E7 A1 toral',8,81,1,128*burnside(data['E7'],3)*L(2)),
      ('E7 A1 D4',4,3,2,(5*nrel+5)*L(2)),('D5 A3 toral',8,9,2,32*d_classes(5,3)*L(4)),
      ('D5 A3 D4',4,3,4,K(1)*L(4)),('twisted D5 A3 A1^2',6,3,4,K(4)*K(2)),
      ('A7 A1 toral',8,9,2,L(8)*L(2)),('twisted A7 A1 A1^3',5,3,4,(K(4)+K(1))*L(2)),
      ('A4^2 toral',8,9,4,L(5)**2)]
    for name,r,c,a,pol in e8three:add('E8 p3 '+name,3,r,c,a,pol)
    for name,a,pol in [('B4',2,K(4)+K(2)),('C3 A1',2,(K(3)+K(1))*L(2)),('A3 A1',4,L(4)*L(2))]:
        add('F4 isolated '+name,3,4,3,a,pol)
    add('E6 isolated signed scalar',3,6,3,2,3*L(6)*L(2))
    add('E6 isolated signed nonscalar',3,4,3,2,(K(3)+1)*L(2))
    for name,r,c,a,pol in [('D6 A1',7,9,1,64*d_classes(6,3)*L(2)),
      ('A7.2',7,9,2,2*L(8)),('A3^2 A1.2',7,9,4,2*L(4)**2*L(2)),
      ('twisted A7.2',4,3,4,K(4)+K(1)),('A3(q^2) A1.2',4,3,4,L(4)*L(2))]:
        add('E7 isolated '+name,3,r,c,a,pol)
    # New phase-zero E8 p5 seven-family improvement.
    P=lambda n:linear(n,5)
    e8five=[('D8',2,256*d_classes(8,5)),('E7 A1',2,84*burnside(data['E7'],5)*P(2)),
      ('E6 A2',4,30*burnside(data['E6'],5)*P(3)),('A8',4,P(9)),
      ('D5 A3',4,32*d_classes(5,5)*P(4)),('A7 A1',4,P(8)*P(2)),
      ('A5 A2 A1',4,P(6)*P(3)*P(2))]
    for name,a,pol in e8five:add('E8 isolated p5 '+name,5,8,5,a,pol)
    # The nine good-prime rows, using their previously established safe actor.
    good=[('E6 A5 A1',5,6,P(6)*P(2)),('E7 D6 A1',5,7,64*d_classes(6,5)*P(2)),
      ('E7 A7.2',5,7,2*P(8)),('E7 A5 A2',5,7,P(6)*P(3)),
      ('E7 A7.2',7,7,2*linear(8,7)),('E8 D8',7,8,256*d_classes(8,7)),
      ('E8 E7 A1',7,8,128*burnside(data['E7'],7)*linear(2,7)),
      ('E8 A8',7,8,linear(9,7)),('E8 A7 A1',7,8,linear(8,7)*linear(2,7))]
    for name,p,r,pol in good:add('good isolated '+name,p,r,p,4*(p-1),pol)
    # Actual unipotent D4 sources and the rank-two principal endpoints.
    add('unipotent E6 D4 nonthin',3,2,1,2,(s**2+9*s+72)/18,endpoint=9)
    add('unipotent E7 D4',3,3,3,1,5*nrel+5)
    add('unipotent E8 D4',3,4,9,1,90*burnside(data['F4'],3)+76)
    add('principal G2',3,2,3,1,4*(s+3)**2/12+6)
    add('principal triality D4',3,2,9,1,8*(s+1)*(s+3)/4+6)
    out={'weyl_data':data,'e8_root_datum':root_datum(),'capacity_rows':rows}
    (HERE/'STRONG_E_RECONSTRUCTION.json').write_text(json.dumps(out,indent=2,default=str))
    print('Weyl classes',[(n,len(v['classes']),v['order']) for n,v in data.items()])
    print('E8 root datum',[(v['node'],v['m'],v['type'],v['lattice_index']) for v in out['e8_root_datum']['rows']])
    print('All nonnegative-coefficient uniform gates',len(rows))
    for row in rows:print(row['name'],row['endpoint_count'],row['endpoint_ratio'])

if __name__=='__main__':main()
