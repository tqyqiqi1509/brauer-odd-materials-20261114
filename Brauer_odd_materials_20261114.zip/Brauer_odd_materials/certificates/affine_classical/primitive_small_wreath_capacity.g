# Complete ordinary family gate for the actual C2-set with F fixed
# points and one two-point orbit, tensor degree r=2 or 3.
SetPrintFormattingStatus("*stdout*",false);
Print("GAP_VERSION|",GAPInfo.Version,"\n");
for rr in [2,3] do
  ww := WreathProduct(SymmetricGroup(2),SymmetricGroup(rr));
  if Size(ww) <> 2^rr*Factorial(rr) then Error("wrong wreath group"); fi;
  bl := List([1..rr],i->[2*i-1,2*i]);
  if not ForAll(GeneratorsOfGroup(ww),g->ForAll(bl,b->OnSets(b,g) in bl)) then
    Error("wrong block convention");
  fi;
  ccs := ConjugacyClassesSubgroups(ww);
  Print("SUBGROUP_CLASSES|",rr,"|",Length(ccs),"\n");
  index := 0;
  for cc in ccs do
    index := index+1;
    qq := Representative(cc);
    elems := Elements(qq);
    coeff := List([0..rr],i->0);
    paircount := 0;
    for xx in elems do
      for yy in elems do
        if xx*yy=yy*xx then
          paircount := paircount+1;
          hh := Group(xx,yy);
          oo := Length(Orbits(hh,bl,OnSets));
          bb := Length(Orbits(hh,[1..2*rr]));
          aa := bb-oo;
          twist := 2*oo-bb;
          if aa<0 or twist<0 then Error("invalid holonomy count"); fi;
          for jj in [0..aa] do
            coeff[twist+jj+1] := coeff[twist+jj+1]+Binomial(aa,jj)*2^(aa-jj);
          od;
        fi;
      od;
    od;
    if paircount<>Size(qq)*NrConjugacyClasses(qq) then Error("pair total"); fi;
    coeff := coeff/Size(qq);
    target := List([0..rr],j->Binomial(rr,j)*2^j);
    deficit := target-coeff;
    shifted := List([0..rr],j->Sum([j..rr],k->deficit[k+1]*Binomial(k,j)*3^(k-j)));
    Print("KAPPA|",rr,"|",index,"|",Size(qq),"|",StructureDescription(qq),"|",coeff,"|",shifted,"\n");
    if not ForAll(shifted,x->x>=0) then Error("negative translated coefficient"); fi;
  od;
od;
Print("ALL_SHIFTED_COEFFICIENTS_NONNEGATIVE\n");
QUIT;
