#!/usr/bin/env python3
"""Portable, isolated replay of the affine and classical finite certificates.

This runner distinguishes recomputation from consumption of recorded GAP data.
It compares complete mathematical records, preserving their multiplicities.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
from fractions import Fraction
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
PYTHON_CHECKS = [
    ("affine_exact.py", "affine_exact.json"),
    ("boundary_exact.py", "boundary_exact.json"),
    ("classical_exact.py", "classical_exact.json"),
    ("primitive_g6_check.py", "primitive_g6_receipt.json"),
    ("primitive_small_wreath_independent.py", "primitive_small_wreath_receipt.json"),
]
GAP_CHECKS = ["primitive_g6_tables.g", "primitive_small_wreath_capacity.g",
              "primitive_core_source_checks.g"]


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def mathematical_json(value):
    if isinstance(value, dict):
        return {k: mathematical_json(v) for k, v in value.items()
                if k not in {"gap_version", "ctbllib_version"}}
    if isinstance(value, list):
        return [mathematical_json(v) for v in value]
    return value


def gap_records(text, name):
    text = text.replace("\\\n", "")
    lines = [line.strip() for line in text.splitlines() if line.strip()
             and not line.lstrip().startswith("#I")]
    if name == "primitive_core_source_checks.g":
        prefixes = ("MAXES|", "SIMPLE_TABLE|", "U4_MAXIMAL|", "SEVEN_MAXIMAL|", "NO_MAXES|")
        records = [re.sub(r"\s+", "", line) for line in lines if line.startswith(prefixes)]
        counts = {prefix: sum(line.startswith(prefix) for line in records) for prefix in prefixes}
        if counts != {"MAXES|": 5, "SIMPLE_TABLE|": 5, "U4_MAXIMAL|": 5,
                      "SEVEN_MAXIMAL|": 4, "NO_MAXES|": 1}:
            raise ValueError("incomplete core-source character-table records")
        if "NO_MAXES|2.S6(3)" not in records or any(line.startswith("MISSING_") for line in lines):
            raise ValueError("unexpected unavailable core-source table data")
        return Counter(records)
    if name == "primitive_g6_tables.g":
        records = [re.sub(r"\s+", "", line) for line in lines
                   if line.startswith(("TABLE|", "NORMALIZER_INTERVAL|"))]
        if sum(x.startswith("TABLE|") for x in records) != 57:
            raise ValueError("G6 output must contain all 57 table records")
        if sum(x.startswith("NORMALIZER_INTERVAL|") for x in records) != 1:
            raise ValueError("missing complete normalizer interval")
        if any(line.startswith("MISSING|") for line in lines):
            raise ValueError("a required character table is missing")
        return Counter(records)
    records, classes = [], {}
    for line in lines:
        if line.startswith("SUBGROUP_CLASSES|"):
            _, degree, number = line.split("|")
            classes[int(degree)] = int(number)
        if line.startswith("KAPPA|"):
            parts = line.split("|")
            if len(parts) != 7:
                raise ValueError("malformed KAPPA record")
            degree, order = int(parts[1]), int(parts[3])
            coefficients = []
            for part in parts[5:7]:
                if not part.strip().startswith("[") or not part.strip().endswith("]"):
                    raise ValueError("malformed coefficient vector")
                coefficients.append(tuple(str(Fraction(x.strip()))
                                          for x in part.strip()[1:-1].split(",")))
            records.append((degree, order, *coefficients))
    if classes != {2: 8, 3: 33} or len(records) != 41:
        raise ValueError("incomplete signed-wreath subgroup class list")
    if "ALL_SHIFTED_COEFFICIENTS_NONNEGATIVE" not in lines:
        raise ValueError("missing signed-wreath completion marker")
    return Counter(records)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--python", action="store_true")
    mode.add_argument("--gap", action="store_true")
    mode.add_argument("--all", action="store_true")
    parser.add_argument("--gap-executable", default="gap")
    parser.add_argument("--timeout", type=float, default=3600)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if sys.flags.optimize:
        parser.error("do not use Python -O or -OO; certificates use assertions")
    if args.timeout <= 0:
        parser.error("--timeout must be positive")
    requested = "all" if args.all else "gap" if args.gap else "python"
    target = (args.output or HERE / "verification_records" / "runs" /
              datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")).resolve()
    if target.is_relative_to(HERE) and not target.is_relative_to(HERE / "verification_records"):
        parser.error("--output inside the source must be under verification_records/")
    target.mkdir(parents=True, exist_ok=False)
    work = target / "work"
    shutil.copytree(HERE, work,
                    ignore=shutil.ignore_patterns("verification_records", "__pycache__", "*.pyc"))
    logs = target / "logs"
    logs.mkdir()
    receipt = {"started_utc": utc_now(), "requested_mode": requested,
               "python_version": sys.version, "checks": [],
               "scope": "finite certificates; infinite continuations are proved in the article",
               "input_sha256": {str(p.relative_to(work)): sha256(p)
                                for p in sorted(work.rglob("*")) if p.is_file()}}
    env = os.environ.copy()
    env.pop("PYTHONOPTIMIZE", None)
    env["PYTHONHASHSEED"] = "0"
    failed = False
    gap_ok = True

    def execute(name, command, compare, output_name=None):
        nonlocal failed
        row = {"program": name, "command": command, "started_utc": utc_now()}
        started = time.monotonic()
        try:
            result = subprocess.run(command, cwd=work, input="", text=True,
                                    capture_output=True, timeout=args.timeout, env=env)
            (logs / (name + ".stdout")).write_text(result.stdout)
            (logs / (name + ".stderr")).write_text(result.stderr)
            row["returncode"] = result.returncode
            if result.returncode:
                raise RuntimeError("program returned a nonzero exit status")
            if name.endswith(".g") and re.search(
                    r"(?m)^(?:Error,|Syntax error|#E)", result.stdout + "\n" + result.stderr):
                raise RuntimeError("GAP reported an error")
            if output_name:
                (work / output_name).write_text(result.stdout)
            compare(result)
            row["status"] = "passed"
        except Exception as exc:
            row["status"] = "failed"
            row["error"] = f"{type(exc).__name__}: {exc}"
            failed = True
        row["elapsed_seconds"] = round(time.monotonic() - started, 6)
        receipt["checks"].append(row)
        print(f"{row['status'].upper()}: {name}", flush=True)
        return row["status"] == "passed"

    if args.gap or args.all:
        executable = shutil.which(args.gap_executable)
        if executable is not None:
            executable = str(Path(executable).resolve())
        if executable is None:
            failed, gap_ok = True, False
            receipt["checks"].append({"program": "GAP availability", "status": "failed",
                                       "error": "GAP executable not found"})
        else:
            for name in GAP_CHECKS:
                reference = gap_records((HERE / name).with_suffix(".out").read_text(), name)

                def compare_gap(result, reference=reference, name=name):
                    if gap_records(result.stdout, name) != reference:
                        raise ValueError("complete GAP mathematical records differ from reference")

                ok = execute(name, [executable, "-q", "-b", "-T", "-m", "64m", "-o", "1g", name],
                             compare_gap, str(Path(name).with_suffix(".out")))
                gap_ok = gap_ok and ok
    if gap_ok:
        checks = PYTHON_CHECKS if not args.gap else PYTHON_CHECKS[-2:]
        for name, output in checks:
            expected = mathematical_json(json.loads((HERE / output).read_text()))
            # A stale copied reference must never substitute for a new output.
            (work / output).unlink(missing_ok=True)

            def compare_json(result, output=output, expected=expected):
                actual = mathematical_json(json.loads((work / output).read_text()))
                if actual != expected:
                    raise ValueError("complete mathematical JSON differs from reference")

            execute(name, [sys.executable, str(work / name)], compare_json)
    receipt["completed_utc"] = utc_now()
    receipt["all_requested_checks_passed"] = not failed
    receipt["output_sha256"] = {str(p.relative_to(work)): sha256(p)
                                 for p in sorted(work.glob("*.json"))}
    (target / "run_receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(target / "run_receipt.json")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
