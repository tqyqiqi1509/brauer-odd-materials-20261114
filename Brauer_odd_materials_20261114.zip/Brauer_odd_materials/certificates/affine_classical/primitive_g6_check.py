"""Exact arithmetic receipt for the general ordinary degree/class gate G6.

The degree and outer bounds are explicit published inputs, not existence
claims. The continuation arguments are in the accompanying mathematical
note. This script checks their finite starting data and every finite
remaining prime before the monotone coarse bound takes over.
"""
from fractions import Fraction as F
from math import gcd, prod
from pathlib import Path
import json

HERE = Path(__file__).resolve().parent

def ppart(n, p):
    h = 1
    while n % p == 0:
        n //= p
        h *= p
    return h

def prime(n):
    return n >= 2 and all(n % a for a in range(2, int(n**0.5) + 1))

def lorder(n, q, unitary=False):
    return q**(n*(n-1)//2) * prod(q**i - ((-1)**i if unitary else 1)
        for i in range(2,n+1)) // gcd(n, q+1 if unitary else q-1)

def sporder(m, q):
    return q**(m*m) * prod(q**(2*i)-1 for i in range(1,m+1)) // gcd(2,q-1)

# (name, field, rank, weak minimum, field*derivative, next-rank minimum).
# All exponents below are exact rational numbers.
boundaries = [
 ("L3",5,2,F(29),F(55),None),
 ("L4",4,3,F(83),F(228),None),
 ("Ln_n5",2,4,F(29),F(98),F(61)),
 ("U3",5,2,F(19),F(45),None),
 ("U4",4,3,F(47),F(160),None),
 ("Un_n5",3,4,F(53),F(243),F(161)),
 ("Un_n8",2,7,F(63),F(512),F(127)),
 ("C2_odd",9,2,F(40),F(81),None),
 ("C3_odd",5,3,F(62),F(375,2),None),
 ("C4_odd",5,4,F(312),F(1250),None),
 ("Cm_odd_m5",3,5,F(121),F(1215,2),F(364)),
 ("C2_even",8,2,F(196),F(644),None),
 ("Cm_even_m3",4,3,F(256,3),F(1024,3),F(4096,3)),
 ("Cm_even_m5",2,5,F(256,3),F(2048,3),F(1024,3)),
 ("B3",5,3,F(125),F(375),None),
 ("Bm_m4",3,4,F(243),F(1215),F(2187)),
 ("D4",3,4,F(241),F(1215),None),
 ("Dm_m5",2,5,F(126),F(896),F(510)),
 ("G2",5,2,F(124),F(375),None),
 ("3D4",3,4,F(121),F(1215,2),None),
 ("F4",3,4,F(243),F(1215),None),
 ("F4_2_cover",2,4,F(52),None,None),
 ("E6_2E6",2,6,F(128),F(896),None),
 ("E7",2,7,F(128),F(896),None),
 ("E8",2,8,F(128),F(896),None),
 ("2B2",32,2,F(32),F(32),None),
 ("2G2",27,2,F(702),F(1431),None),
 ("2F4",8,4,F(8**5-8**4),F(5*8**5-4*8**4),None),
]

boundary_receipt = []
for name,q,r,d,sdprime,nxt in boundaries:
    # 3^(d/3) >= 32 q^r, cleared of rational exponents.
    lhs, rhs = 3**d.numerator, (32*q**r)**(3*d.denominator)
    assert lhs >= rhs, name
    assert d >= 4
    if sdprime is not None:
        assert sdprime / 3 >= r, name
    if nxt is not None:
        assert (nxt-d)/3 >= q, name  # stronger than log_3(q)
    boundary_receipt.append({"family":name,"q":q,"rank":r,
      "D":str(d),"cleared_exponent_comparison":True,
      "field_derivative_test":None if sdprime is None else str(sdprime/3-r),
      "rank_increment_test":None if nxt is None else str((nxt-d)/3-q)})

# name, actual CTblLib name, defining prime, minimum, safe k bound, outer bound, order
rows = [
 ("A5","A5",5,2,5,2,60),
 ("L2(7)","L2(7)",7,3,6,2,168),
 ("A6","A6",3,3,7,4,360),
 ("L2(11)","L2(11)",11,5,8,2,660),
 ("L2(13)","L2(13)",13,6,9,2,1092),
 ("L3(3)","L3(3)",3,11,12,2,lorder(3,3)),
 ("L3(4)","L3(4)",2,4,10,12,lorder(3,4)),
 ("L4(2)","A8",2,6,14,2,lorder(4,2)),
 ("L4(3)","L4(3)",3,26,29,4,lorder(4,3)),
 ("U3(3)","U3(3)",3,6,14,2,lorder(3,3,True)),
 ("U3(4)","U3(4)",2,12,22,4,lorder(3,4,True)),
 ("PSp4(3)","U4(2)",3,4,20,2,sporder(2,3)),
 ("U4(3)","U4(3)",3,6,20,8,lorder(4,3,True)),
 ("U5(2)","U5(2)",2,10,47,2,lorder(5,2,True)),
 ("U6(2)","U6(2)",2,21,46,6,lorder(6,2,True)),
 ("U7(2)","U7(2)",2,42,239,2,lorder(7,2,True)),
 ("PSp4(5)","S4(5)",5,12,60,2,sporder(2,5)),
 ("PSp4(7)","S4(7)",7,24,94,2,sporder(2,7)),
 ("Sp4(4)","S4(4)",2,18,27,4,sporder(2,4)),
 ("PSp6(3)","S6(3)",3,13,141,2,sporder(3,3)),
 ("PSp8(3)","S8(3)",3,40,528,2,sporder(4,3)),
 ("Sp6(2)","S6(2)",2,7,30,1,sporder(3,2)),
 ("Sp8(2)","S8(2)",2,35,81,1,sporder(4,2)),
 ("O7(3)","O7(3)",3,27,198,2,sporder(3,3)),
 ("O8+(2)","O8+(2)",2,8,53,6,2**12*15*prod(2**(2*i)-1 for i in range(1,4))),
 ("O8-(2)","O8-(2)",2,33,39,2,2**12*17*prod(2**(2*i)-1 for i in range(1,4))),
 ("G2(3)","G2(3)",3,14,24,2,3**6*(3**6-1)*(3**2-1)),
 ("G2(4)","G2(4)",2,12,33,2,4**6*(4**6-1)*(4**2-1)),
 ("3D4(2)","3D4(2)",2,25,36,3,2**12*(2**8+2**4+1)*(2**6-1)*(2**2-1)),
 ("Suzuki8","Sz(8)",2,8,11,3,8**2*(8**2+1)*(8-1)),
 ("Tits","2F4(2)'",2,26,58,2,17971200),
]

actual_tables = {}
raw = (HERE / "primitive_g6_tables.out").read_text()
for line in raw.splitlines():
    if line.startswith("TABLE|"):
        _,name,identifier,order,k = line.split("|")
        actual_tables[name] = {"identifier":identifier,"order":int(order),"k":int(k)}
assert len(actual_tables) == 57
finite_receipt = []
coarse_failures = []
for name,alias,ell,d0,k,o,order in rows:
    d = max(4,d0)
    actual = actual_tables[alias]
    assert actual["order"] == order, name
    assert actual["k"] <= k, name
    if 12*o*k > 3**d:
        coarse_failures.append(name)
    checks = []
    for p in range(3,10001,2):
        if not prime(p):
            continue
        if 6*(p-1)*o*k <= p**d:
            threshold = p
            break
        if p == ell:
            continue
        hp,op = ppart(order,p), ppart(o,p)
        lhs, rhs = 6*(p-1)*(o//op)*k, p**d*hp
        assert lhs <= rhs, (name,p,d,lhs,rhs)
        assert 6*(p-1)*(o//op)*max(k,hp) <= rhs, (name,p,"clipped")
        checks.append({"p":p,"ratio":str(F(lhs,rhs)),"order_p":hp,"outer_p":op})
    else:
        raise AssertionError("No monotone tail boundary")
    finite_receipt.append({"socle":name,"input_minimum":d0,"used_D":d,
      "K_bound":k,"O_bound":o,"actual_table":actual,
      "prime_checks":checks,"coarse_all_prime_tail_from":threshold})
assert coarse_failures == ["A5","L2(7)","A6","L3(4)","PSp4(3)","U4(3)"]

# Rank-one analytic tail starting values, without any p-part saving.
assert 4*17*(17+5) <= 3**8
assert 6*8*(8+1) <= 3**7

sporadic_rows = [
 ("M11",5,1),("M12",6,2),("M22",10,2),("M23",10,1),
 ("M24",10,1),("J1",7,1),("J2",6,2),("J3",10,2),("J4",10,1),
 ("HS",10,2),("McL",10,2),("He",10,2),("Ru",10,1),
 ("Suz",10,2),("ON",10,2),("Co3",10,1),("Co2",10,1),
 ("Co1",10,1),("Fi22",10,2),("Fi23",10,1),("Fi24'",10,2),
 ("HN",10,2),("Ly",10,1),("Th",10,1),("B",10,1),("M",10,1)
]
sporadic_receipt = []
for name,d,o in sporadic_rows:
    k = actual_tables[name]["k"]
    assert 12*o*k <= 3**d
    sporadic_receipt.append({"socle":name,"D":d,"k":k,"O":o,
                             "base_ratio":str(F(12*o*k,3**d))})

# Alternating: exact partition split formula, n=5,...,11, then induction.
def partitions(n, maximum=None):
    if n == 0:
        yield ()
    else:
        for a in range(min(n, n if maximum is None else maximum),0,-1):
            for tail in partitions(n-a,a):
                yield (a,)+tail

alternating_receipt = []
for n in range(5,12):
    parts = list(partitions(n))
    distinct_odd = sum(len(set(t)) == len(t) and all(a%2 for a in t) for t in parts)
    k = (len(parts)+3*distinct_odd)//2
    order = prod(range(1,n+1))//2
    d,o = (4 if n <= 7 else 6), (4 if n == 6 else 2)
    checks=[]
    for p in (3,5,7):
        hp,op=ppart(order,p),ppart(o,p)
        ratio=F(6*(p-1)*(o//op)*k,p**d*hp)
        assert ratio <= 1
        clipped_ratio=F(6*(p-1)*(o//op)*max(k,hp),p**d*hp)
        assert clipped_ratio <= 1
        checks.append({"p":p,"ratio":str(ratio),"clipped_ratio":str(clipped_ratio)})
    assert 6*6*o*k <= 7**d
    alternating_receipt.append({"n":n,"D":d,"k":k,"checks":checks})
assert 12*2**12 <= 3**10

mechanism_checks = {
 "tensor_endpoint_integer_comparison":17**11 < 3**13*5**11,
 "binary_core_endpoint":str(F(1,12)+F(1,480)+F(5,6)),
 "normalizer_interval_from_gap":"[ [ 4, 4 ], [ 8, 5 ], [ 12, 4 ], [ 24, 5 ] ]" in raw,
}
assert mechanism_checks["tensor_endpoint_integer_comparison"]
assert mechanism_checks["binary_core_endpoint"] == "147/160"
assert mechanism_checks["normalizer_interval_from_gap"]

receipt = {"scope":"Exact finite arithmetic and actual ordinary class-table checks; not a proof of representation existence or infinite continuation",
 "gap_version":"4.16.1", "ctbllib_version":"1.3.11",
 "cofinite_boundaries":boundary_receipt,
 "finite_lie_rows":finite_receipt,
 "coarse_p3_failures_repaired":coarse_failures,
 "sporadic_rows":sporadic_receipt,
 "alternating_small_rows":alternating_receipt,
 "mechanism_checks":mechanism_checks,
 "clipped_G6_also_verified":True,
 "all_assertions_passed":True}
(HERE / "primitive_g6_receipt.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps({"boundaries":len(boundaries),"finite_lie_rows":len(rows),
 "ordinary_tables_retrieved":len(actual_tables),"sporadic_rows":len(sporadic_rows),
 "finite_prime_repairs":sum(len(x["prime_checks"]) for x in finite_receipt),
 "all_assertions_passed":True},sort_keys=True))
