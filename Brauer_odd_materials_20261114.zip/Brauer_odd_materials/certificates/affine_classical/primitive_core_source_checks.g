LoadPackage("ctbllib");;
SetPrintFormattingStatus("*stdout*",false);
for nm in ["S6(2)","O8+(2)","O8-(2)","U4(2)","S6(3)","2.S6(3)"] do
  tt := CharacterTable(nm);
  if tt = fail then
    Print("MISSING_TABLE|",nm,"\n");
  elif not HasMaxes(tt) then
    Print("NO_MAXES|",nm,"\n");
  else
    mx := Maxes(tt);
    Print("MAXES|",nm,"|",Length(mx),"|",mx,"\n");
    Print("SIMPLE_TABLE|",nm,"|",Size(tt),"|",NrConjugacyClasses(tt),"\n");
    if nm = "U4(2)" then
      for x in mx do
        mt := CharacterTable(x);
        if mt = fail then
          Print("MISSING_MAXIMAL_TABLE|",nm,"|",x,"\n");
        else
          Print("U4_MAXIMAL|",nm,"|",x,"|",Size(mt),"|",NrConjugacyClasses(mt),"\n");
        fi;
      od;
    fi;
    if nm = "S6(3)" or nm = "2.S6(3)" then
      for x in mx do
        mt := CharacterTable(x);
        if mt = fail then
          Print("MISSING_MAXIMAL_TABLE|",nm,"|",x,"\n");
        elif Size(mt) mod 7 = 0 then
          Print("SEVEN_MAXIMAL|",nm,"|",x,"|",Size(mt),"|",NrConjugacyClasses(mt),"\n");
        fi;
      od;
    fi;
  fi;
od;
QUIT;
