#!/usr/bin/env python3
"""Independent exact affine certificates. Python 3 standard library only.

Domains: alternating degrees 5..16 and every odd socle prime; all
mixed core degrees 2^a*n_o<256; the RM(1,3) binary code; EVERY subgroup
of C2 wr S_r for r=2,3, enumerated as actual signed permutations.
Every polynomial is symbolic. No finite parameter grid is used as an
infinite proof. The written proof supplies the continuation.
"""
from collections import Counter, deque
from fractions import Fraction as F
from itertools import permutations, product
from math import comb, factorial, prod
from pathlib import Path
import json

HERE = Path(__file__).resolve().parent

def factor(n):
    out = {}
    d = 2
    while d*d <= n:
        while n % d == 0:
            out[d] = out.get(d,0)+1
            n //= d
        d += 1
    if n > 1:
        out[n] = out.get(n,0)+1
    return out

def ppart(n,p):
    z = 1
    while n % p == 0:
        z *= p
        n //= p
    return z

# Every odd prime dividing A_n, including the 13 prime-field residuals.
budgets = [7,13,15,22,30,42,56,77,101,135,176,231]
alternating = []
residual = []
for n,k in zip(range(5,17),budgets):
    order = factorial(n)//2
    for p in factor(order):
        if p == 2:
            continue
        h = ppart(order,p)
        q = p*p
        square = F(1,n)+F((q+1)*k,q*q)
        assert square < h, (n,p,square,h)
        base = F(1,n)+F((p+1)*k,p*p)
        if base >= h:
            residual.append([n,p])
        alternating.append(dict(n=n,p=p,h=h,K=k,
                                square_field_ratio=str(square/h),
                                prime_field_coarse=str(base)))
assert len(alternating) == 44
assert residual == [[5,3],[8,3],[8,5],[9,5],[11,7],[12,7],
                    [13,7],[14,5],[14,11],[15,11],[15,13],
                    [16,11],[16,13]]

# Every odd socle/outer prime in the seven nonalternating residual socles.
simple_rows = [
    ("L3(2)",168,2,9,{7}),
    ("L3(4)",2**6*3**2*5*7,12,28,set()),
    ("U3(3)",2**5*3**3*7,2,27,{3}),
    ("U4(2)",2**6*3**4*5,2,25,{3}),
    ("U4(3)",2**7*3**6*5*7,8,80,{3}),
    ("Sp6(2)",2**9*3**4*5*7,1,30,set()),
    ("O8+(2)",2**12*3**5*5**2*7,6,68,set())]
nonalternating = []
nonalternating_residual = []
for name,order,outer,k,native in simple_rows:
    for p in sorted(factor(order*outer)):
        if p==2:
            continue
        h=ppart(order,p)
        q=p*p
        square=F(1,5)+F((q+1)*k,q*q)
        assert square<h,(name,p,square,h)
        base=F(1,5)+F((p+1)*k,p*p)
        if p not in native and base>=h:
            nonalternating_residual.append([name,p])
        nonalternating.append(dict(socle=name,p=p,h=h,K=k,native=p in native,
                                   square_field_ratio=str(square/h),
                                   prime_field_coarse=str(base)))
assert len(nonalternating)==18
assert nonalternating_residual == [
    ["L3(2)",3],["L3(4)",3],["L3(4)",5],["U4(2)",5],
    ["U4(3)",5],["U4(3)",7],["Sp6(2)",5],["O8+(2)",7]]
nonalternating_gates = [
    ("L3(2)",3,F(6,5)),("L3(4)",3,F(149,45)),
    ("L3(4)",5,F(33,25)),("U4(2)",5,F(18649,3750)),
    ("U4(3)",5,F(17,5)),("U4(3)",7,F(1649,245)),
    ("Sp6(2)",5,F(39,25)),("O8+(2)",7,F(1409,245))]
for name,p,value in nonalternating_gates:
    order=next(row[1] for row in simple_rows if row[0]==name)
    assert value<ppart(order,p)

def sporder(r,a):
    return r**(a*a)*prod(r**(2*j)-1 for j in range(1,a+1))

def g(a):
    return {1:3,2:16,3:1139}.get(a,6*(2**a)**(a+1))

mixed = []
mixed_fail = []
for a in range(1,8):
    for no in range(3,256//(2**a)+1,2):
        n = 2**a*no
        if n >= 256:
            continue
        fac = factor(no)
        qo = prod(sporder(r,b) for r,b in fac.items())
        c = ppart(qo,2)*qo*g(a)
        q0 = 2*prod(fac)+1
        ok = (51*c*n)**3 < 100**3*q0**(n-1)
        if not ok:
            mixed_fail.append([a,no])
        mixed.append(dict(a=a,odd_degree=no,n=n,Qodd=qo,C=c,q0=q0,
                          cubed_comparison=ok))
assert len(mixed) == 120
assert mixed_fail == [[1,3],[1,5],[1,9],[2,3]]
thresholds = []
for a,no,q in [(1,5,81),(1,9,31),(2,3,25)]:
    row = next(x for x in mixed if x["a"]==a and x["odd_degree"]==no)
    assert (51*row["C"]*row["n"])**3 < 100**3*q**(row["n"]-1)
    thresholds.append(dict(a=a,odd_degree=no,q=q))
n,q = 18,25
c = next(x["C"] for x in mixed if x["n"]==n and x["a"]==1)
special = 2*c*(F((q-1)*n*n,q**n)+F(n,q**(n//3)))
assert special == F(8542968750000061917364224,
                    2910383045673370361328125)
assert special < 4
# At 256, log_3(256)<6 gives exponent 3+4log_3(256)<27.
tail = F(153*256**27,25*7**85)
assert tail < 2

def rank2(words):
    pivots = {}
    for v in words:
        while v:
            k = v.bit_length()-1
            if k in pivots:
                v ^= pivots[k]
            else:
                pivots[k] = v
                break
    return len(pivots)

words = sorted({sum((b ^ ((a&x).bit_count()%2)) << x for x in range(8))
                for a in range(8) for b in range(2)})
assert len(words) == 16
assert all((u&v).bit_count()%2 == 0 for u in words for v in words)
hist = Counter((a|b).bit_count() for a in words for b in words)
assert hist == {0:1,4:42,6:168,8:45}
classnum = sum(F(nu*3**8,16*3**w) for w,nu in hist.items())
assert classnum == 720

def trans(word,g):
    return sum(((word>>x)&1)<<(x^g) for x in range(8))

def mark(gens):
    todo = set(range(8))
    masks = []
    while todo:
        seed = min(todo)
        orbit = {seed}
        queue = [seed]
        for x in queue:
            for g in gens:
                y = x^g
                if y not in orbit:
                    orbit.add(y)
                    queue.append(y)
        todo -= orbit
        masks.append(sum(1<<x for x in orbit))
    value = 0
    for bits in product(range(2),repeat=len(masks)):
        support = sum(m for bit,m in zip(bits,masks) if bit)
        exponent = 0
        for t in (support,255^support):
            sub = [w for w in words if w&~t == 0]
            dim = (len(sub)).bit_length()-1
            comm = [trans(w,g)^w for w in sub for g in gens]
            exponent += dim-rank2(comm)
        value += 2**exponent
    return value

assert mark([]) == 720
rankone = [mark([g]) for g in range(1,8)]
ranktwo = [mark([a,b]) for a in range(1,8) for b in range(a+1,8)]
assert set(rankone)=={72} and set(ranktwo)=={24}
affine_classes = F(720+21*72+42*24,8)
assert affine_classes == 405
normalized = F(405*16,3**8)
assert normalized == F(80,81)
e16 = F(3*16*15,4)*F(2,3)**16 + F(16*15*14,4)*F(6**4,3**16)
assert e16 == F(12885120,43046721) and e16 < F(3,10)

def wreath(r):
    ambient = [tuple(2*p[i]+(b^sign[i])
                     for i in range(r) for b in range(2))
               for p in permutations(range(r))
               for sign in product(range(2),repeat=r)]
    index = {a:i for i,a in enumerate(ambient)}
    identity = index[tuple(range(2*r))]
    size = len(ambient)
    mul = [[index[tuple(a[b[i]] for i in range(2*r))]
            for b in ambient] for a in ambient]
    inv = [next(j for j in range(size) if mul[i][j]==identity)
           for i in range(size)]

    def closure(gens):
        h = {identity}
        queue = [identity]
        for x in queue:
            for y in gens:
                z = mul[x][y]
                if z not in h:
                    h.add(z)
                    queue.append(z)
        return frozenset(h)

    trivial = frozenset({identity})
    groups = {trivial:()}
    queue = deque([trivial])
    while queue:
        h = queue.popleft()
        gens = groups[h]
        for g0 in range(size):
            if g0 not in h:
                new = closure(gens+(g0,))
                if new not in groups:
                    groups[new] = gens+(g0,)
                    queue.append(new)
    assert len(groups) == {2:10,3:98}[r]
    remaining = set(groups)
    reps = []
    while remaining:
        h = min(remaining,key=lambda t:(len(t),tuple(sorted(t))))
        reps.append(h)
        for x in range(size):
            conj = frozenset(mul[mul[x][y]][inv[x]] for y in h)
            remaining.discard(conj)
    assert len(reps) == {2:8,3:33}[r]

    def orbits(perms,n):
        rem = set(range(n))
        num = 0
        while rem:
            z = min(rem)
            orb = {z}
            todo = [z]
            for x in todo:
                for p0 in perms:
                    y = p0[x]
                    if y not in orb:
                        orb.add(y)
                        todo.append(y)
            rem -= orb
            num += 1
        return num

    rows = []
    for rowno,h in enumerate(reps,1):
        coeff = [F(0) for _ in range(r+1)]
        pairs = 0
        for u in h:
            for v in h:
                if mul[u][v] != mul[v][u]:
                    continue
                pairs += 1
                a,b = ambient[u],ambient[v]
                o = orbits([tuple(a[2*i]//2 for i in range(r)),
                            tuple(b[2*i]//2 for i in range(r))],r)
                signed = orbits([a,b],2*r)
                left,right = 2*o-signed,signed-o
                assert left>=0 and right>=0
                for j in range(right+1):
                    coeff[left+j] += F(comb(right,j)*2**(right-j),len(h))
        deficit = [F(comb(r,j)*2**j)-coeff[j] for j in range(r+1)]
        shifted = [sum(deficit[j]*comb(j,i) for j in range(i,r+1))
                   for i in range(r+1)]
        assert all(x>=0 for x in shifted),(r,rowno,coeff,shifted)
        rows.append(dict(row=rowno,order=len(h),
                         generator_indices=list(groups[h]),
                         generators=[ambient[g0] for g0 in groups[h]],
                         commuting_pairs=pairs,
                         coefficients=list(map(str,coeff)),
                         shifted_deficit=list(map(str,shifted))))
    assert len({tuple(x["coefficients"]) for x in rows}) == {2:6,3:27}[r]
    return dict(r=r,ambient_order=size,actual_subgroups=len(groups),
                conjugacy_classes=len(reps),rows=rows)

receipt = dict(all_assertions_passed=True,
    alternating=dict(rows=alternating,prime_field_residuals=residual),
    nonalternating=dict(rows=nonalternating,residuals=nonalternating_residual,
                        final_gates=[dict(socle=n,p=p,upper=str(v))
                                     for n,p,v in nonalternating_gates]),
    mixed=dict(rows=mixed,residual_profiles=mixed_fail,
               thresholds=thresholds,special_ratio=str(special),
               infinite_tail_start_majorant=str(tail)),
    RM13=dict(words=words,union_histogram=dict(hist),k=str(classnum),
              translation_marks=rankone,plane_marks=ranktwo,
              affine_classes=str(affine_classes),ratio=str(normalized),
              E16=str(e16)),
    wreath2=wreath(2),wreath3=wreath(3))
(HERE/"affine_exact.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(dict(alternating_pairs=len(alternating),
                     nonalternating_pairs=len(nonalternating),
                     mixed_profiles=len(mixed),RM13_classes=str(classnum),
                     wreath_subgroups=[receipt["wreath2"]["actual_subgroups"],
                                       receipt["wreath3"]["actual_subgroups"]],
                     wreath_classes=[8,33],all_assertions_passed=True)))

