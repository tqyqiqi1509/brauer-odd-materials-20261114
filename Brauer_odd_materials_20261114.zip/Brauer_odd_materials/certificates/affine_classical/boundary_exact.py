#!/usr/bin/env python3
"""Exact finite boundary certificates for the affine proof.

No dependencies beyond Python 3. This script checks all alternating
partition starts 5<=n<=63, the five 1139 maximal-subgroup products,
all 13 two-degree-three component starts, all five binary two-cycle
exceptions, and the explicit rational/small-power endpoints listed
in the article. Published group orders, degree minima and maximal
list completeness are inputs, not claims certified by this script.
"""
from fractions import Fraction as F
from math import factorial
from pathlib import Path
import json

HERE = Path(__file__).resolve().parent
def ppart(n,p):
    h=1
    while n%p==0:
        h*=p
        n//=p
    return h

# Euler's exact partition recurrence, with every start retained.
sigma=[0]*64
for d in range(1,64):
    for n in range(d,64,d):
        sigma[n]+=d
part=[1]+[0]*63
for n in range(1,64):
    x=sum(sigma[j]*part[n-j] for j in range(1,n+1))
    assert x%n==0
    part[n]=x//n
partition_rows=[]
for n in range(5,64):
    lhs=2*part[n]
    rhs=n*3**(n//3)
    assert lhs<rhs,(n,lhs,rhs)
    partition_rows.append(dict(n=n,partition=part[n],lhs=lhs,rhs=rhs,gap=rhs-lhs))

maxima=[("U4(2).2",51840,25),("S8",40320,22),
        ("U3(3).2",12096,16),("S3xS6",4320,33),
        ("L2(8).3",1512,672)]
maximal_rows=[]
for name,order,k in maxima:
    gap=1139**2-order*k
    assert gap>0,(name,gap)
    maximal_rows.append(dict(name=name,order=order,class_bound=k,
                             product=order*k,gap_to_1139_squared=gap))
assert all(x<1139 for x in [720,168,36])

spec=[("A5",5,60,2,[3,5,7]),
      ("L2(7)",6,168,2,[3,7,11]),
      ("A6",7,360,4,[3,5,11]),
      ("A7",9,2520,2,[3,5,7,11])]
two_three=[]
for name,k,order,o,primes in spec:
    for p in primes:
        q=p
        h=ppart(order,p)
        op=o//ppart(o,p)
        beta=F(op*k,h)
        tau=F(op*op*k,h*h)
        value=beta/q**2+beta/(order*h)+tau*(F(3,q**3)+F(6,q**4)
                                                     +F(3*(q-1),q**9))
        assert value<F(19,20),(name,p,value)
        two_three.append(dict(socle=name,p=p,q=q,h=h,k=k,outer_pprime=op,
                              beta=str(beta),tau=str(tau),ratio=str(value)))
assert len(two_three)==13
assert max(F(x["ratio"]) for x in two_three)==F(260963,275562)

binary_cycle=[
 ("n4q3-plus",4,3,F(17)),("n4q3-minus",4,3,F(12)),
 ("n4q5",4,5,F(102)),("n4q9",4,9,F(680)),
 ("n8q3-plus",8,3,F(65*46,3)),("n8q3-minus",8,3,F(325)),
 ("n8q5",8,5,F(73710))]
cycle_rows=[]
for name,n,q,k in binary_cycle:
    ratio=F(3*k,q**n)
    assert ratio<1,(name,ratio)
    cycle_rows.append(dict(name=name,n=n,q=q,budget=str(k),
                           Q=q**n,ratio_to_Q_over_3=str(ratio)))

endpoints={
 "native_degree_three_linear":F(208837,218700),
 "native_degree_three_field":F(51844,54675),
 "cross_degree_three_field_tail":F(75264,390625),
 "binary_core_matrix_transfer":F(147,160),
 "small_component_uniform":F(17,18),
 "small_component_exceptions":F(2416,3375),
 "scalar_A5_degree_two_f2":F(2131,2430),
 "scalar_A5_degree_two_f4":F(145411,393660),
 "scalar_A5_degree_two_fge6":F(10391191,15943230),
 "formal_A7_degree_two":F(4002949,5314410),
 "AGL1_5_two_cycle":F(8192,19683),
 "two_native_degree_two":F(3087,3125),
 "one_native_centralizer3":F(14,15),
 "one_native_centralizer_ge4":F(2,3),
 "one_native_degree_two":F(4,5),
 "single_cross_small_p5_L27":F(351,1000),
 "single_cross_small_p5_others":F(21303,25000),
 "single_cross_small_pge7":F(7472,8575),
 "single_degree_three_core4":F(31,32),
 "single_degree_three_A5":F(112,121),
 "single_degree_two_A5_p3":F(20,27),
 "single_degree_two_A5_largecore":F(345,352),
 "twoA5p3largecore":F(49,9*729)+F(49,72),
 "twoA5pge7largecore":F(49,1331)+F(49,72),
 "threeA5q11largecore":F(125,11**7)+F(125,128),
 "single_scalar_L27_q9":F(707,810),
 "single_scalar_p3_fge3":F(5123,7290),
 "single_scalar_p5":F(237,250),
 "ordinary_core_odd_exception9":F(2009395989888,3814697265625),
 "ordinary_core_odd_exception27":F(15383964119940705303040,
                                      65712362363534280139543)}
assert all(0<x<1 for x in endpoints.values())
assert 17**11 < 3**13*5**11
assert 4704**3 < 25**8
assert 35**4 < 3**13 and 35**51 < 2**262
assert 2**132 < 3**89

# All 13 alternating prime-field residuals, using their stated gate.
budgets=[7,13,15,22,30,42,56,77,101,135,176,231]
residual=[(5,3),(8,3),(8,5),(9,5),(11,7),(12,7),(13,7),
          (14,5),(14,11),(15,11),(15,13),(16,11),(16,13)]
alternating_repairs=[]
for i,(n,p) in enumerate(residual):
    k=budgets[n-5]
    h=ppart(factorial(n)//2,p)
    if i<3:
        value=F(1,n)+F(k,p)
        mechanism="dimension-at-least-three"
    else:
        value=F(1,n)+F(1,p)+F(k-1,p*p)
        mechanism="one-exceptional-projective-class"
    assert value<h,(n,p,value,h)
    alternating_repairs.append(dict(n=n,p=p,mechanism=mechanism,
                                    upper=str(value),h=h,ratio=str(value/h)))

# Actual small projective maximal rows for the odd-core seven gate.
seven_rows=[]
for order,k in [(29484,16),(24192,32),(1092,9),(1092,9)]:
    gap=49*256**2-4*order*k
    assert gap>0
    seven_rows.append(dict(order=order,k=k,gap=gap))

receipt=dict(all_assertions_passed=True,
    partition_starts=partition_rows,Sp6_2_1139=maximal_rows,
    O2_free_local_quotient_orders=[720,168,36],two_degree_three=two_three,
    binary_cycle_budgets=cycle_rows,
    rational_endpoints={name:str(value) for name,value in endpoints.items()},
    alternating_prime_field_repairs=alternating_repairs,
    odd_core_seven_maximal_rows=seven_rows,
    integer_power_comparisons_passed=True)
(HERE/"boundary_exact.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(dict(partition_starts=len(partition_rows),
                     maximal_1139_products=len(maximal_rows),
                     two_degree_three_rows=len(two_three),
                     rational_endpoints=len(endpoints),
                     alternating_repairs=len(alternating_repairs),
                     all_assertions_passed=True)))

