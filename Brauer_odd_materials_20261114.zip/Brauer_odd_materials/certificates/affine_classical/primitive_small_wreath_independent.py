"""Independent exhaustive signed-permutation proof of a polynomial family gate.

No GAP subgroup list, character table, or representation existence data is
used in constructing the groups or enumerating their subgroups. The GAP
result is compared only after all coefficients have been computed anew.
"""
from itertools import permutations, product
from fractions import Fraction as F
from collections import deque, Counter
from math import comb, factorial
from pathlib import Path
import json

HERE=Path(__file__).resolve().parent

def orbit_count(gens,degree):
    parent=list(range(degree))
    def root(i):
        while parent[i]!=i:
            parent[i]=parent[parent[i]]
            i=parent[i]
        return i
    for g in gens:
        for i in range(degree):
            a,b=root(i),root(g[i])
            if a!=b:
                parent[a]=b
    return len({root(i) for i in range(degree)})

def run(r):
    els=[]
    for sigma in permutations(range(r)):
        for eps in product(range(2),repeat=r):
            els.append(tuple(2*sigma[i]+(b^eps[i]) for i in range(r) for b in range(2)))
    pos={g:i for i,g in enumerate(els)}
    assert len(els)==2**r*factorial(r) and els[0]==tuple(range(2*r))
    order=len(els)
    mul=[[pos[tuple(g[h[i]] for i in range(2*r))] for h in els] for g in els]
    inv=[next(j for j in range(order) if mul[i][j]==0) for i in range(order)]
    def closure(gens):
        known={0};todo=[0]
        for a in todo:
            for g in gens:
                ag=mul[a][g]
                if ag not in known:
                    known.add(ag);todo.append(ag)
        return frozenset(known)
    trivial=frozenset([0])
    allsubs={trivial:()};todo=deque([trivial])
    while todo:
        h=todo.popleft()
        for x in range(order):
            if x in h:
                continue
            gens=allsubs[h]+(x,)
            k=closure(gens)
            if k not in allsubs:
                allsubs[k]=gens;todo.append(k)
    pending=set(allsubs);reps=[]
    while pending:
        h=min(pending,key=lambda a:(len(a),tuple(sorted(a))))
        conj={frozenset(mul[mul[inv[g]][x]][g] for x in h) for g in range(order)}
        assert conj<=set(allsubs)
        pending-=conj
        reps.append((h,len(conj)))
    out=[]
    for h,nconj in reps:
        coeff=[F(0) for _ in range(r+1)]
        pairs=0
        for x in h:
            for y in h:
                if mul[x][y]!=mul[y][x]:
                    continue
                pairs+=1
                gx,gy=els[x],els[y]
                b=orbit_count((gx,gy),2*r)
                o=orbit_count((tuple(gx[2*i]//2 for i in range(r)),
                               tuple(gy[2*i]//2 for i in range(r))),r)
                a,twist=b-o,2*o-b
                assert a>=0 and twist>=0
                for j in range(a+1):
                    coeff[twist+j]+=F(comb(a,j)*2**(a-j),len(h))
        target=[F(comb(r,j)*2**j) for j in range(r+1)]
        diff=[a-b for a,b in zip(target,coeff)]
        shift3=[sum(diff[k]*comb(k,j)*3**(k-j) for k in range(j,r+1)) for j in range(r+1)]
        shift1=[sum(diff[k]*comb(k,j) for k in range(j,r+1)) for j in range(r+1)]
        assert all(a>=0 for a in shift3)
        assert all(a>=0 for a in shift1)
        out.append({"order":len(h),"conjugates":nconj,"generators":[els[g] for g in allsubs[h]],
                    "kappa_coefficients":[str(a) for a in coeff],
                    "deficit_at_F_equals_1_plus_T":[str(a) for a in shift1],
                    "deficit_at_F_equals_3_plus_T":[str(a) for a in shift3],
                    "commuting_pairs":pairs})
    assert sum(a["conjugates"] for a in out)==len(allsubs)
    return {"degree":r,"ambient_order":order,"actual_subgroups":len(allsubs),
            "conjugacy_classes":len(reps),"rows":out}

results=[run(2),run(3)]
gaprows={2:[],3:[]}
for line in (HERE/"primitive_small_wreath_capacity.out").read_text().splitlines():
    if line.startswith("KAPPA|"):
        _,r,i,order,structure,coeff,shift=line.split("|")
        vals=tuple(F(x.strip()) for x in coeff.strip("[] ").split(","))
        gaprows[int(r)].append((int(order),vals))
for result in results:
    ours=Counter((row["order"],tuple(F(a) for a in row["kappa_coefficients"])) for row in result["rows"])
    assert ours==Counter(gaprows[result["degree"]])
receipt={"theorem":"For r=2 or 3, every actual Q <= C2 wr S_r and the C2-set X with F fixed points plus one two-point orbit satisfy kappa_Q(X^r) <= (2F+1)^r for all integers F>=1.",
 "proof_of_completeness":"The direct enumeration starts with 1 and repeatedly adjoins every ambient element to each known subgroup; induction on a generating set reaches every subgroup. Conjugacy reduction is performed afterwards by all ambient elements.",
 "polynomial_identity":"For a commuting pair, o is its number of coordinate orbits and b its number of signed-position orbits. Its fixed configurations number F^(2o-b)*(F+2)^(b-o).",
 "results":results,"independent_gap_polynomial_multisets_match":True,
 "all_shifted_coefficients_nonnegative":True}
(HERE/"primitive_small_wreath_receipt.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps({"results":[{k:r[k] for k in ("degree","ambient_order","actual_subgroups","conjugacy_classes")} for r in results],
                  "independent_gap_polynomial_multisets_match":True,"uniform_range":"F>=1"}))
