# Affine and classical finite certificates

These files accompany the odd-prime affine and classical chapters of
*Brauer's k(B)-conjecture*. The article contains the infinite-family arguments,
the reductions to the stated finite domains, and the representation-theoretic
inputs. These programs perform the specified exact finite calculations.

## Portable entry point

Python 3.10 or later suffices for the Python checks; they use only the standard
library. Run from any working directory:

```sh
python3 run_checks.py --python
python3 run_checks.py --gap --gap-executable /path/to/gap
python3 run_checks.py --all --gap-executable /path/to/gap
```

Use the appropriate relative or absolute path to `run_checks.py`. The default
mode is `--python`. Do not use Python `-O` or `-OO`: the programs use assertions.
Each invocation copies the certificate files into a new working directory,
preserves all reference outputs, and writes logs and a machine-readable receipt
under `verification_records/runs/`. `--output NEW_DIRECTORY` chooses another
new result directory; `--timeout SECONDS` changes the per-program limit.

The GAP mode runs all three GAP programs and then the two Python consumers on the
newly generated GAP data. A Python-only run uses the retained GAP outputs.
Missing software, nonzero return codes, GAP error messages, incomplete outputs
and mathematical discrepancies produce failure, not a successful skipped check.

## Exact calculations and their limits

| Program | Complete finite domain or calculation | Output |
|---|---|---|
| `affine_exact.py` | All 44 alternating degree/prime pairs for degrees 5–16 and their 13 residual prime-field pairs; 18 nonalternating socle/prime pairs and eight residual repairs; all 120 mixed core profiles below degree 256, the RM(1,3) code, and every actual subgroup of C2 wreath S2 and C2 wreath S3. The latter groups have 10 and 98 subgroups, forming 8 and 33 conjugacy classes. Complete symbolic ordinary-count polynomials are retained. | `affine_exact.json` |
| `boundary_exact.py` | 59 partition starts, the five 1139 maximal-subgroup products, 13 two-degree-three starts, seven binary cycle budgets, 30 exact rational endpoints, 13 alternating repairs, and the specified odd-core and integer-power gates. | `boundary_exact.json` |
| `classical_exact.py` | 192 parameter rows and 34,752 coefficients through weight 180, determinant-one and central-quotient checks, 1,000 graph/equal-factor weights, ten binary starts and nine analytic starts. This coefficient grid is a diagnostic check; the article proves all infinite tails. | `classical_exact.json` |
| `primitive_g6_check.py` | Exact arithmetic at the 28 cofinite Lie-family boundaries, the 31 finite Lie rows, all 26 sporadic rows, seven repairs and the listed mechanism checks. It consumes all 57 retained ordinary character-table records. Published degree lower bounds and the completeness of the classification domains remain the public mathematical inputs cited in the article. | `primitive_g6_receipt.json` |
| `primitive_small_wreath_independent.py` | Independent enumeration of every signed permutation subgroup in degrees 2 and 3 and the complete multiset of symbolic ordinary-count polynomials, compared with the GAP calculation. Multiplicities are preserved. | `primitive_small_wreath_receipt.json` |

The first three programs reconstruct their data from the constants and formulas
in their own source. They do not read a former calculation output. The two
`primitive_...` consumers read the included `.out` records as described above.

## GAP data generation

```sh
gap -q -b primitive_g6_tables.g
gap -q -b primitive_small_wreath_capacity.g
gap -q -b primitive_core_source_checks.g
```

`primitive_g6_tables.g` requires the GAP Character Table Library. It names every
table explicitly and prints its identifier, group order and number of ordinary
irreducible characters, plus the complete indicated S4 normalizer interval.
`primitive_small_wreath_capacity.g` constructs the two actual wreath products,
enumerates their subgroup conjugacy classes and computes their commuting-pair
polynomials. Use a normal GAP distribution with its standard packages. A minimal
core installation can require `--bare` and explicit installation of CTblLib and
its dependencies; this is a runtime configuration choice, not a change to the
mathematical source.

`primitive_core_source_checks.g` retains the public maximal-subgroup table lists
used in the small symplectic/core estimates and the full stated order/class
records. Its original `NO_MAXES|2.S6(3)` record is preserved: this input does not
claim to compute a maximal-subgroup list for the double cover. The argument for
that cover and the meaning of the selected subgroup bounds are supplied in the
article. The complete record lists, including repeated isomorphic maximal
subgroups, are compared by the runner.

The retained G6 and wreath GAP references identify their producer as GAP 4.16.1 and CTblLib
1.3.11. The portable runner ignores these version strings when comparing
mathematical data. It compares all 57 table records and the complete normalizer
interval. For the wreath products it compares all 41 subgroup-class records,
including the group order and both complete coefficient vectors, allowing only
the enumeration order and the names of isomorphic group structures to vary.

## Execution records

The delivery includes fresh isolated Python-run logs and receipts at the root
of the materials package. These identify the actual environment and the exact
inputs. A retained `.out` file is a reference computation, not by itself a new
execution log. The complete-source manifest records all distributed bytes.
New runs are stored separately and never overwrite the references.
