if LoadPackage("ctbllib") = fail then Error("CTblLib unavailable"); fi;
SetPrintFormattingStatus("*stdout*", false);
Print("GAP_VERSION|", GAPInfo.Version, "\n");
Print("CTBLLIB_VERSION|", PackageInfo("ctbllib")[1].Version, "\n");
names := [
  "A5", "L2(7)", "A6", "L2(11)", "L2(13)", "L3(3)", "L3(4)",
  "A8", "L4(3)", "U3(3)", "U3(4)", "U4(2)", "U4(3)", "U5(2)",
  "U6(2)", "U7(2)", "S4(5)", "S4(7)", "S4(4)", "S6(3)",
  "S8(3)", "S6(2)", "S8(2)", "O7(3)", "O8+(2)", "O8-(2)",
  "G2(3)", "G2(4)", "3D4(2)", "Sz(8)", "2F4(2)'",
  "M11", "M12", "M22", "M23", "M24", "J1", "J2", "J3", "J4",
  "HS", "McL", "He", "Ru", "Suz", "ON", "Co3", "Co2", "Co1",
  "Fi22", "Fi23", "Fi24'", "HN", "Ly", "Th", "B", "M"
];;
for name in names do
  tbl := CharacterTable(name);
  if tbl = fail then
    Print("MISSING|", name, "\n");
  else
    Print("TABLE|", name, "|", Identifier(tbl), "|", Size(tbl),
          "|", NrConjugacyClasses(tbl), "\n");
  fi;
od;
s4 := SymmetricGroup(4);;
v4 := Group((1,2)(3,4), (1,3)(2,4));;
iv := Concatenation([v4,s4], IntermediateSubgroups(s4,v4).subgroups);;
data := Set(List(iv, h -> [Size(h), NrConjugacyClasses(h)]));;
Print("NORMALIZER_INTERVAL|", data, "\n");
QUIT;
