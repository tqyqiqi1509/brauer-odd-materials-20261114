#!/usr/bin/env python3
"""Independent exact all-level coefficient and classical boundary checks.

The grid is diagnostic: the text proves all infinite tails.
Domain: p=3,5,7,11,13,17,19,23,29,31; a=1..4; every c|(p-1);
weights 0..180. Also determinant-one ranks p..180 for c=1;
ternary graph/equal-factor identities at weights 1..1000; all
finite rational starts of the analytic and binary-core inequalities.
"""
from fractions import Fraction as F
from math import prod
from pathlib import Path
import json

HERE = Path(__file__).resolve().parent

def vp(n,p):
    e=0
    while n and n%p==0:
        e+=1
        n//=p
    return e

def vfact(n,p):
    e=0
    while n:
        n//=p
        e+=n
    return e

def euler_coeff(N,exponent):
    logarithmic=[0]*(N+1)
    for d in range(1,N+1):
        z=d*exponent(d)
        for n in range(d,N+1,d):
            logarithmic[n]+=z
    a=[1]+[0]*N
    for n in range(1,N+1):
        num=sum(logarithmic[j]*a[n-j] for j in range(1,n+1))
        assert num%n==0
        a[n]=num//n
    return a

def kw(p,a,c,N):
    s=p**a
    b0=c+(s-1)//c
    b=(s-s//p)//c
    return euler_coeff(N,lambda d:b0+b*vp(d,p))

N=180
rows=[]
worst={}
tested=0
typeA_worst=F(0)
typeA_at=None
typeA_exception=[]
for p in [3,5,7,11,13,17,19,23,29,31]:
    for a in range(1,5):
        s=p**a
        for c in [i for i in range(1,p) if (p-1)%i==0]:
            k=kw(p,a,c,N)
            assert all(k[w]<=s**w for w in range(N+1))
            tested+=N+1
            gates=[]
            if p>=7:
                gates.append(("77(p-1)",77*(p-1),p))
            if p==5:
                gates.append(("30",30,5))
                if c==2:
                    gates.append(("61",61,5))
            if p==3 and c==2:
                if a>=2:
                    gates.append(("21",21,3))
                else:
                    gates.extend([("4",4,4),("6",6,5),("26",26,6)])
            for name,budget,start in gates:
                for w in range(start,N+1):
                    delta=s**w*p**vfact(w,p)
                    value=F(budget*k[w],delta)
                    assert value<1,(p,a,c,w,budget,value)
                    if name not in worst or value>F(worst[name]["ratio"]):
                        worst[name]=dict(ratio=str(value),p=p,a=a,c=c,w=w)
            rows.append(dict(p=p,a=a,c=c,weights=[0,N],
                             all_weak_pass=True,strict_budgets=[g[0] for g in gates]))
            if c!=1:
                continue
            for n in range(p,N+1):
                m=min(a,vp(n,p))
                num=k[n]+sum(p**(2*i-2)*(p*p-1)*k[n//p**i]
                             for i in range(1,m+1))
                assert num%s==0
                count=num//s
                delta=s**(n-1)*p**(vfact(n,p)-m)
                value=F((p-1)*count,delta)
                if (p,a,n)==(3,1,3):
                    assert count==16 and delta==9
                    typeA_exception.append(dict(p=p,a=a,n=n,count=count,
                                                 defect=delta,ratio=str(value)))
                else:
                    assert value<1,(p,a,n,count,delta,value)
                    if value>typeA_worst:
                        typeA_worst=value
                        typeA_at=[p,a,n]
                if n>=2*p:
                    assert vfact(n,p)>=m+1
                    assert all(n-n//p**i>=4*i for i in range(1,m+1))
                    assert F(num,s**n)<=F(p*p,p*p-1)

k=kw(3,1,2,1000)
j=euler_coeff(1000,lambda d:1+int(d%2==0)+vp(d,3))
for w in range(1,1001):
    assert 3*j[w]<=k[w],w
    assert (k[w]+3*j[w])%2==0 and (k[w]-j[w])%2==0
    n=(k[w]+3*j[w])//2
    f=(k[w]-j[w])//2
    assert f>=1 and n>=0
    four=F(n*n+3*f*f+6*n+6*f,4)
    assert four<=k[w]**2,(w,four,k[w]**2)

def B(n,q,star=False):
    lead=F((q-1)*(n*n//4+1 if star else n*n+1),2)
    return (lead+F(4,n)*q**(n//2)+F(n,2)*q**(n//4))/q**n

binary=[
 ("q3-rank3",F(135,2)*B(8,3,True)),
 ("q5-rank4",F(5,3)*prod(4**i-1 for i in range(1,5))*B(16,5)),
 ("a2-p3-f2",F(15,2)*2*B(4,9)),
 ("a2-p5-f1",F(45,4)*B(4,5,True)),
 ("a2-p5-f2",F(45,4)*2*B(4,25)),
 ("a3-p3-f2",F(105,2)*2*B(8,9)),
 ("a3-p5-f1",F(2835,4)*B(8,5)),
 ("a3-p7-f1",F(945,2)*B(8,7)),
 ("a2-large-field",F(49,2)*45*B(4,49)),
 ("a3-large-prime",F(11,2)*2835*B(8,11))]
assert all(x<1 for _,x in binary)
assert binary[0][1]==F(935,972)
assert binary[1][1]==F(3977832159,4882812500)

analytic=[
 ("weak_tail",F(22,27)+F(1,7)),
 ("pge7_77",F(77*6,7)*(F(12405,7**7)+F(1,7**6-2))),
 ("p5_30",6*(F(506,5**5)+F(1,623))),
 ("p5_c2_61",F(61,5)*F(32516,396875)),
 ("p3_a2_21",7*F(8,27)*(F(98,216)+F(648,46007))),
 ("p3_w4_4",F(4,3)*(F(51,81)+F(729,17471))),
 ("p3_w5_6",2*(F(108,243)+F(729,17471))),
 ("p3_w6_26",F(26,9)*(F(221,729)+F(729,17471))),
 ("typeA_p11_tail",10*F(6,11)**11+F(1,11**7))]
assert all(x<1 for _,x in analytic)
receipt=dict(all_assertions_passed=True,parameter_rows=len(rows),
             coefficients_tested=tested,max_weight=N,rows=rows,
             strict_budget_maxima=worst,typeA_maximum=str(typeA_worst),
             typeA_maximum_parameters=typeA_at,
             excluded_abelian_projective_boundary=typeA_exception,
             graph_equal_factor_weights=1000,
             binary_gates={name:str(x) for name,x in binary},
             analytic_gates={name:str(x) for name,x in analytic},
             interpretation="The finite grid is diagnostic. Infinite claims use the written monotonicity and Euler-product proofs.")
(HERE/"classical_exact.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps({k:receipt[k] for k in ["all_assertions_passed","parameter_rows",
                                       "coefficients_tested","max_weight",
                                       "graph_equal_factor_weights"]}))

