HISTORICAL MATERIALS — PRESERVED, NOT THE CURRENT ARTICLE

The original complete-source archive, earlier manuscript checkpoint, and
intermediate conditional working edition are retained without altering
their bytes. The input archives r3, r4, r5 and the supplied prime-two source are preserved
intact in original_inputs/. These supplied historical archives may retain
their original reference documents. Newly downloaded third-party papers
are identified by URL and hash, with extraction programs, rather than
added in full to this delivery. Historical completeness claims and
unresolved-input lists must be read with the
dated audit records. Use paper/ for the current mathematical text and
AUDIT_STATUS.json for its delivery status. The old prime-two certificate
family remains inside the original archive for preservation; the current
odd-prime executable checks do not depend on that family.
