BRAUER'S k(B)-CONJECTURE AT ODD PRIMES — MATHEMATICAL MATERIALS
Qiyue Tang
Zhili College, Tsinghua University, Beijing 100084, China
tangqy24@mails.tsinghua.edu.cn
November 14, 2026

START HERE

The current article is in paper/ as a standalone PDF and TeX file. The modular
sources and a reproducible assembler are in paper/modules/ and paper/assemble.py.
Read AUDIT_STATUS.json and the delivery audit report for the mathematical status
of this exact version. Historical manuscripts and reports retain their original
dated conclusions; a historical report is not a verdict on a later source hash.
The PDF in paper/ is the exact compiler output. The separately distributed PDF
preview includes document-provenance metadata; all 170 pages have matching text
and rendered pixels. Both hashes and the comparison program are in the audit.

This package contains mathematical code, exact inputs, reference outputs,
independent audit checks, primary-document reading records, source hashes,
execution receipts and earlier material packages. The separately supplied
Brauer_runtime_sources_20261114.zip contains the original GAP and package source
distributions and offline Python wheels, with their licenses.

CONTENTS

paper/                  Current PDF, standalone TeX, modular source, assembler.
certificates/           Original affine/classical and exceptional finite checks.
audit_checks/           Independent additional checks from this revision.
audits/                 Dated mathematical reviews, proposed repairs, and receipts.
provenance/             History, novelty/style sources, integration/build scripts.
history/                Original complete-source archive and interim working text.
PRIMARY_SOURCE_INDEX.json
                        Exact identities of the primary PDFs inspected.
MANIFEST_SHA256.json     Byte hashes of the delivered fixed inputs and records.

PYTHON REQUIREMENTS

Python 3.10+ without -O or -OO; SymPy 1.14.0; mpmath 1.3.0.
PyMuPDF 1.26.6 is used for primary-PDF extraction checks only.
requirements.txt and requirements_reading.txt pin the versions.

For an offline install, extract the separate runtime archive and run:

  python3 -m pip install --no-index --find-links /path/to/python_wheels \
    sympy==1.14.0 mpmath==1.3.0 PyMuPDF==1.26.6

The bundled PyMuPDF wheel is for CPython 3.10+ on Linux x86_64 with glibc 2.28+.
On another platform, obtain the same version from its official distribution.

REPRODUCE THE CHECKS

From this directory:

  python3 run_verification.py --integrity-only
  python3 run_verification.py --python
  python3 run_audit_checks.py
  python3 run_fresh_checks.py

To regenerate GAP data, first build GAP using build_gap.py in the runtime archive,
then pass the resulting executable to these commands:

  python3 run_verification.py --all --gap-executable /absolute/path/to/gap4-bare
  python3 run_audit_checks.py --regenerate-gap \
    --gap-executable /absolute/path/to/gap4-bare
  python3 run_fresh_checks.py --regenerate-carriers \
    --gap-executable /absolute/path/to/gap4-bare

Each run creates a new directory and preserves the reference inputs and outputs.
Missing dependencies, failed checks and hash mismatches are reported as failures.
The portable replay entry points are the commands listed above. Programs in
audits/ and provenance/ preserve the original review and integration process;
some intentionally retain the original workspace layout and are historical
records, rather than standalone commands for the delivered directory layout.
Use check_primary_sources.py and extract_source_pdf.py for portable source reading.
The --python mode uses the identified reference GAP outputs. The retained
exceptional table outputs identify GAP 4.16.1 and CTblLib 1.3.11;
the current regeneration used GAP 4.14.0 and CTblLib 1.3.11. The older
prime-two records and earlier independent runs retain their stated versions.
The historical GAP3/CHEVIE E8 degree export was not regenerated in GAP3 in this audit; its exact
input data, generating source and independent symbolic checks are preserved.

The checks cover their stated finite sets. They do not certify the universal
theorem, replace the classification arguments, or constitute formal verification.
VERIFICATION_SCOPE.md records the exact distinctions and numerical scope.

READ THE ORIGINAL PAPERS WITH PYTHON

The newly retrieved primary papers are obtained from the public URLs recorded
in PRIMARY_SOURCE_INDEX.json. Save each PDF with
its indexed filename and run, for example:

  python3 check_primary_sources.py --source-dir /path/to/primary_pdfs \
    --only CS25.pdf MS16.pdf CS13.pdf GMP17_fresh.pdf \
    --output verification_records/my_primary_reading.json

  python3 extract_source_pdf.py --help

The first command verifies exact PDF bytes, page count and every page-text hash.
The original versions and PyMuPDF version matter. Reading receipts identify the
source versions; the dated audit reports identify the statements actually checked.

COMPILE THE ARTICLE

Install TeX Live with latexmk, pdfLaTeX, AMS-LaTeX, Latin Modern, microtype,
geometry, enumitem, booktabs, longtable, fvextra, xurl and hyperref.

  python3 build_paper.py

To reassemble the modular sources first:

  python3 build_paper.py --reassemble --output /absolute/path/to/new-build

The standalone TeX has an embedded bibliography and needs no local manuscript
files. Source reassembly may change source-check metadata but should regenerate
the same TeX bytes for the same modules and assembler. A normal installed TeX
distribution is required; TeX Live and the operating system are not bundled.

PRESERVATION

The original complete-source ZIP, its earlier manuscript checkpoint, and all
four supplied input archives (r3, r4, r5 and the prime-two source) are retained
byte-for-byte in history/ and history/original_inputs/. Any reference documents
within those supplied archives remain as originally supplied. Newly retrieved
papers are represented by URLs, hashes and reading programs. The original
prime-two files remain for preservation. The current odd-prime runners do
not call the prime-two certificate family. Earlier completeness statements are
historical and must be read with the dated audit trail and current delivery status.
