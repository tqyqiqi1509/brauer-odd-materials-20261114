#!/usr/bin/env python3
"""Reproduce the finite certificates accompanying Brauer's k(B)-conjecture.

Default: all Python checks, consuming the explicitly identified reference GAP
outputs where needed. --all additionally regenerates the GAP data. A missing
dependency or failed check is never silently accepted as a successful run.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def integrity():
    manifest_path = ROOT / "MANIFEST_SHA256.json"
    data = json.loads(manifest_path.read_text())
    failures = []
    for item in data["files"]:
        path = (ROOT / item["path"]).resolve()
        if not path.is_relative_to(ROOT):
            failures.append({"path": item["path"], "error": "unsafe manifest path"})
        elif not path.is_file():
            failures.append({"path": item["path"], "error": "missing file"})
        elif path.stat().st_size != item["size_bytes"] or digest(path) != item["sha256"]:
            failures.append({"path": item["path"], "error": "byte digest mismatch"})
    return {"manifest": manifest_path.name, "files_checked": len(data["files"]),
            "failures": failures, "passed": not failures}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    for name in ["python", "gap", "all", "gap-carriers", "integrity-only"]:
        mode.add_argument("--" + name, action="store_true")
    parser.add_argument("--gap-executable", default="gap")
    parser.add_argument("--timeout", type=int, default=3600,
                        help="per-program timeout; suite wrappers receive a larger limit")
    parser.add_argument("--output", type=Path, help="new directory for this run")
    args = parser.parse_args()
    if sys.version_info < (3, 10):
        parser.error("Python 3.10 or later is required")
    if sys.flags.optimize:
        parser.error("Python -O and -OO disable assertions and must not be used")
    if args.timeout <= 0:
        parser.error("--timeout must be positive")
    selected = ("integrity-only" if args.integrity_only else "gap-carriers" if args.gap_carriers
                else "all" if args.all else "gap" if args.gap else "python")
    try:
        integrity_result = integrity()
    except Exception as exc:
        print(f"INTEGRITY FAILED: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1
    if args.integrity_only:
        print(json.dumps(integrity_result, indent=2))
        return 0 if integrity_result["passed"] else 1
    if not integrity_result["passed"]:
        print(json.dumps(integrity_result, indent=2), file=sys.stderr)
        return 1
    output = (args.output or ROOT / "verification_records" / "runs" /
              datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")).resolve()
    if output.is_relative_to((ROOT / "certificates").resolve()):
        parser.error("--output must be outside the certificates source directory")
    output.mkdir(parents=True, exist_ok=False)
    work = output / "work"
    shutil.copytree(ROOT / "certificates", work,
                    ignore=shutil.ignore_patterns("verification_records", "__pycache__", "*.pyc"))
    logs = output / "logs"
    logs.mkdir()
    try:
        sympy_version = importlib.metadata.version("sympy")
    except importlib.metadata.PackageNotFoundError:
        sympy_version = None
    receipt = {"started_utc": now(), "requested_mode": selected,
               "python_version": sys.version, "sympy_version": sympy_version,
               "integrity": integrity_result, "checks": [],
               "scope": "finite checks and input validation only; these results do not certify the proposed odd-prime theorem"}
    failed = False
    env = os.environ.copy()
    env.pop("PYTHONOPTIMIZE", None)
    env["PYTHONHASHSEED"] = "0"
    located_gap = shutil.which(args.gap_executable)
    gap = (str(Path(located_gap).resolve()) if located_gap else
           str(Path(args.gap_executable).resolve()) if os.sep in args.gap_executable
           else args.gap_executable)

    def run(identifier, command, cwd, timeout=None, post=None, stdout_path=None, stderr_path=None):
        nonlocal failed
        row = {"id": identifier, "command": command, "started_utc": now()}
        start = time.monotonic()
        try:
            result = subprocess.run(command, cwd=cwd, input="", text=True,
                                    capture_output=True, timeout=timeout or args.timeout, env=env)
            (logs / (identifier + ".stdout")).write_text(result.stdout)
            (logs / (identifier + ".stderr")).write_text(result.stderr)
            if stdout_path:
                stdout_path.write_text(result.stdout)
            if stderr_path:
                stderr_path.write_text(result.stderr)
            row["returncode"] = result.returncode
            if result.returncode:
                raise RuntimeError("nonzero process exit status")
            if re.search(r"(?m)^(?:Error,|Syntax error|#E|brk>)", result.stdout + "\n" + result.stderr):
                raise RuntimeError("GAP error text in output")
            if post:
                post()
            row["status"] = "passed"
        except Exception as exc:
            row["status"] = "failed"
            row["error"] = f"{type(exc).__name__}: {exc}"
            failed = True
        row["elapsed_seconds"] = round(time.monotonic() - start, 6)
        receipt["checks"].append(row)
        print(f"{row['status'].upper()}: {identifier}", flush=True)
        return row["status"] == "passed"

    if not args.gap_carriers:
        child_mode = "--all" if args.all else "--gap" if args.gap else "--python"
        for family in ["affine_classical"]:
            child_output = output / family
            command = [sys.executable, str(work / family / "run_checks.py"), child_mode,
                       "--gap-executable", gap, "--timeout", str(args.timeout),
                       "--output", str(child_output)]

            def child_post(child_output=child_output):
                result = json.loads((child_output / "run_receipt.json").read_text())
                # Different original runner schemas both use explicit failure records.
                checks = result.get("checks", result.get("results", []))
                if result.get("all_requested_checks_passed") is False:
                    raise ValueError("child suite recorded failure")
                if any(x.get("status") in {"failed", "error"} for x in checks):
                    raise ValueError("child suite recorded a failed check")

            run(family, command, work / family, timeout=20 * args.timeout, post=child_post)

    exceptional = work / "exceptional"
    specification = json.loads((exceptional / "checks.json").read_text())
    outcomes = {}
    python_mode = selected in {"python", "all"}
    gap_mode = selected in {"gap", "gap-carriers", "all"}
    for step in specification["steps"]:
        identifier = step["id"]
        runtime = step["runtime"]
        choose = False
        if python_mode and runtime == "python" and identifier not in {
                "verify_all_carriers", "finite_fresh_replay"}:
            choose = True
        if gap_mode and (runtime == "gap" or identifier == "verify_all_carriers"):
            choose = True
        if selected in {"gap", "all"} and identifier == "finite_fresh_replay":
            choose = True
        if not choose:
            continue
        dependencies = [x for x in step.get("depends_on", []) if x in outcomes]
        if any(not outcomes[x] for x in dependencies):
            failed = True
            outcomes[identifier] = False
            receipt["checks"].append({"id": identifier, "status": "failed",
                                       "error": "a required preceding check failed"})
            continue
        script = exceptional / step["script"]
        arguments = [gap if a == "{gap}" else a for a in step.get("arguments", [])]
        command = ([sys.executable, str(script), *arguments] if runtime == "python"
                   else [gap, *arguments, str(script)])
        # Expected results live in separate expected/ directories. Remove the
        # writable outputs so that a no-op cannot pass by reusing copied data.
        for name in step.get("outputs", []):
            target = exceptional / name
            if target.exists():
                target.unlink()

        def post(step=step):
            for name in step.get("outputs", []):
                if not (exceptional / name).is_file():
                    raise ValueError("missing generated output: " + name)
            comparison = step.get("comparison", "")
            if comparison in {"json_equal", "first_output_json_equal"}:
                outputs = step["outputs"]
                for index, expected in enumerate(step["expected"]):
                    actual_json = json.loads((exceptional / outputs[index]).read_text())
                    expected_json = json.loads((exceptional / expected).read_text())
                    if actual_json != expected_json:
                        raise ValueError("complete JSON mismatch: " + outputs[index])

        outcomes[identifier] = run(
            identifier, command, exceptional,
            timeout=max(args.timeout, step.get("timeout_seconds", 0)), post=post,
            stdout_path=exceptional / step["stdout"] if "stdout" in step else None,
            stderr_path=exceptional / step["stderr"] if "stderr" in step else None)
    receipt["completed_utc"] = now()
    receipt["all_requested_checks_passed"] = not failed
    receipt["output_sha256"] = {
        str(p.relative_to(work)): digest(p) for p in sorted(work.rglob("*"))
        if p.is_file() and p.suffix in {".json", ".out", ".g"}}
    (output / "run_receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(output / "run_receipt.json")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
