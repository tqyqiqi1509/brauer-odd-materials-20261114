#!/usr/bin/env python3
"""Compile the standalone article with an installed TeX distribution."""
from pathlib import Path
import argparse
import shutil
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--reassemble', action='store_true',
                        help='First regenerate standalone TeX from paper/modules.')
    parser.add_argument('--output', type=Path,
                        help='New directory for build products (default: paper/build).')
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    paper = root / 'paper'
    if args.reassemble:
        subprocess.run([sys.executable, str(paper / 'assemble.py')], check=True, cwd=paper)
    tex = paper / 'Brauer_kB_odd_primes_20261114.tex'
    out = (args.output or paper / 'build').resolve()
    out.mkdir(parents=True, exist_ok=False)
    common = ['-interaction=nonstopmode', '-halt-on-error', f'-output-directory={out}']
    if shutil.which('latexmk'):
        commands = [['latexmk', '-pdf', *common, str(tex)]]
    elif shutil.which('pdflatex'):
        commands = [['pdflatex', *common, str(tex)]] * 3
    else:
        parser.error('Install TeX Live with pdfLaTeX and the packages listed in README.txt.')
    for i, command in enumerate(commands, 1):
        result = subprocess.run(command, cwd=paper, text=True, capture_output=True)
        (out / f'build_pass_{i}.stdout').write_text(result.stdout)
        (out / f'build_pass_{i}.stderr').write_text(result.stderr)
        if result.returncode:
            print(f'Build failed; see {out}', file=sys.stderr)
            return result.returncode
    print(out / tex.with_suffix('.pdf').name)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
