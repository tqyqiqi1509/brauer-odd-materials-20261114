# 奇素数基础与 Levi 下降：第二批独立审查报告

审查日期：2026-11-14。审查对象是当前源文件，不采用此前“通过”记录作为证据。本报告只审查，不修改正文。

## 1. 结论及范围

**当前稿尚未满足“删去 $p=2$ 正文以后，奇素数部分独立成立”的文本要求。** `all_prime_levi.tex` 有五个对 `prime_two.tex` 的显式引用；此外，几何对象、算子记号、覆盖群上作用的唯一性等定义或证明也留在旧部分中。仅删引用、保留“该论证与素数无关”一句不能完成修改。

在逐行复核的 Levi 模块中，我没有得到足以反驳其主要几何／积分构造的确定反例，也没有发现能够直接断言该 Levi 定理为假的计算错误。下面列出的缺失中，有些可以按本报告给出的公式直接补全；另一些是目前被压缩成一句话的非平凡结构接口，需要在重写稿中作为独立引理证明。**这个局部结论不构成整个 Brauer (k(B)) 猜想已经无条件解决的认证。** 其他模块，尤其从源代数或局部配对向原块的积分内作用转移，不在本报告的通过范围内。

读取覆盖：

- `brauer_article/all_prime_levi.tex`：1–645 行，完整按顺序读取两遍。
- `prime_two.tex`：读取定义与一般基础所在的 4637–4788、4943–5146、5288–5385 行，并检查中间相关段落和引用目标；没有宣称重审全部 8175 行的 $p=2$ 证明。
- 对所有五个 odd 模块进行标签交叉扫描；`odd_affine.tex`、`odd_classical.tex`、`odd_endpoints.tex` 无指向旧 $p=2$ 标签的显式引用。这是句法结论，不能排除未标记的数学依赖。
- 原始文献核验：BR03 Theorem B′；BDR17 §7.A、Theorem 7.2、Lemma 7.4、§7.C；Ruhstorfer arXiv v1 的 Lemma 3.1 及其证明、Assumption 2.25 / Theorem 2.26、Lemma 2.10、Corollary 2.13、Proposition 4.8 前半段；Taylor19 §8.2–8.8。

源文件 SHA-256 与机械扫描结果保存在 `foundations_v2_dependencies.json`。两份主审文件在审查时的 SHA-256 分别为：

- `all_prime_levi.tex`: `d110eb3e244939bdf9312b09e3b35934096095065ff295160bbae12e5ab91784`
- `prime_two.tex`: `95a55e61c457fd54f8c19b28c0b2ce4c9a185d2ce3fcc2c4d34c2ee8d72e2804`

## 2. $p=2$ 依赖的递归清单

| 奇素数稿入口 | 旧文件目标 | 必须迁入的内容 | 迁入后的依赖处理 |
|---|---|---|---|
| Levi 10 行，`sec:geometry` | p2 4637；定义 4639–4668 | $(K,\mathcal O,k)$、有限对偶群、$\mathcal E_p(S,s)$、$e_s^S$、字符／余字符格、“ordinary” 的准确范围 | 重写为奇素数及任意定义特征 $r\ne p$，不能保留“定义特征为奇数”的旧环境限制。 |
| Levi 299 行，`geo:induction-restriction` | p2 5087；论证 5086–5102 | 诱导模型、限制分解、左右积分投射性、左生成性与 $\mathcal O$-自由性 | 原证明引用 `geo:regular-factorization`，位于 p2 4769；新文已有 `lev:regular`，但须补齐 $\widetilde{\mathbf S}$、$\widetilde{\mathbf L}$ 及固定点记号。 |
| Levi 299 行，`geo:dimension` | p2 5106；完整计算 5104–5146 | Frobenius 互反维数等式；诱导算子如何逐一置换提升的右幂等元；独立性与完备性 | 此段后向／前向引用 `geo:generic-span`（p2 5047）；新文对应 `lev:generic-span`。不能只搬维数等式而省略 5112–5143 的算子计算。 |
| Levi 405、441 行，`geo:partial-morita` | p2 5288–5385 | 对称 $\mathcal O$-阶的完整积分支撑／Morita 引理，含四个伴随映射、分裂与秩零、单位下降、中心投影构造 | 原引理证明没有依赖其他 p2 标签；必须整段独立证明，不能只保留 Levi 426–441 的提要。 |
| Global 3055 行，`thm:main` | p2 6 行 | 最后合并 $p=2$ 与奇素数结论 | 这是用户允许保留的唯一 $p=2$ 结果接口。删除旧正文后必须改成明确且可核验的外部结果陈述／出处；本审查不自动认证该 $p=2$ 结果。 |

还须迁入以下没有通过 `\ref` 标记的实际依赖：

1. p2 4945–4963：
   $$
   Y_{\mathbf U}=\{g\mathbf U\in\mathbf S/\mathbf U:
       g^{-1}F(g)\in\mathbf U F(\mathbf U)\},\qquad d=\dim Y_{\mathbf U}.
   $$
   Levi 213 行直接使用 $Y_{\mathbf U},d$，当前本节没有定义。
2. p2 5044、5118–5121：$L_x(m)=xm$、$R_y(m)=my$、对角算子 $\delta(t)$ 的定义及乘法约定；特别是右算子满足反向复合。
3. p2 4781–4788：完美群的中心商上，已存在的自同构提升唯一。两次提升的比给出到中心核的同态，该同态因完美性而平凡。因此实际乘法关系及 $C_G(D)$ 在覆盖积上的平凡作用得到保留。Levi 479–481 目前直接使用后一结论。
4. p2 4762–4777：$\widetilde{\mathbf L}=\mathbf L Z(\widetilde{\mathbf S})$、$\widetilde S=\widetilde{\mathbf S}^F$、$\widetilde L=\widetilde{\mathbf L}^F$，以及两个商环面的同构如何通过 Lang 定理给出 $\widetilde S=S\widetilde L$。
5. 必须明确 $X_{b_S}$ 是 $X$ 中的左块稳定子，而 $\overline X_b$ 是它在标签群中的像；两者不能仅用近似自然语言互代。

### 旧 ordinary 定义不能原样搬用

p2 4643 的环境仅有奇定义特征，4667–4668 因而只特别排除 $G_2(3^f)$ 的例外图自同构。奇素数正文允许 $r=2$，故必须同时说明 $B_2(2^f)$、$F_4(2^f)$ 的例外不可分图自同构由 `lev:steinberg` 处理，而不属于普通 pinned-diagram 模块。否则原定义与奇素数全范围之间存在确定的适用范围缺口。这是定义与覆盖范围问题，不是这里已构造的反例。

Levi 152–162 的 $p=2$ 段应删除，但 `lev:centralizer` 的等式和标签应移入 $p=3,D_4$ 段，否则 167、172 行会失去定义。标题、45 行及定理的量词应统一成“odd primes”。

## 3. 原始文献的假设核验

### 3.1 BR03：不能把连通分量假设误写成全中心化子假设

原文 Theorem B′ 要求 **整个** $C_{\mathbf G^*}(s)$ 包含于所选对偶 Levi。当前稿的原群只有 $C^\circ(s)\le\mathbf L^*$，所以该定理不能直接用于原群 $S$。Levi 255–265 实际把它用于正规嵌入后的提升标签；提升对偶中央化子连通，BDR Lemma 7.4 的证明给出其像落在原 $C^\circ(s)$ 中，于是此处假设可满足。必须把这一步写成明确蕴涵，不能只写“connected-centralizer equivalence”。

原群上 $H_c^i(Y_{\mathbf U},\mathcal O)e_s^L=0$（$i\ne d$）的输入是 BR03 Theorem 11.7，BDR §7.A 明确引用此结论。新稿应列明集中次数；$\mathcal O$-自由性随后可由正规嵌入的积分投射性和限制直和分解证明，不必另作无根据的“无挠”断言。

来源：Bonnafé–Rouquier, *Catégories dérivées et variétés de Deligne–Lusztig*, Publ. Math. IHES 97 (2003), 1–59, DOI `10.1007/s10240-003-0013-3`；作者 PDF <https://www.math.ucla.edu/~rouquier/papers/catderdl.pdf>，本地 `primary/BR03.pdf` / `.txt`，文本相关处约 2980–3024 行。

### 3.2 BDR17：自由轨道与无条件延拓是不同命题

§7.A 与 Theorem 7.2 支持当前的规范最小 Levi、$N/L$ 的 $p'$ 结构、以及两个抛物的中间上同调双模同构。Lemma 7.4 支持提升系列上的自由轨道。§7.C 的正规嵌入计算可以与 BR03 的积分 Morita 结果结合，给出 upstairs 的轨道诱导计算。

不能由这些结论直接写出原 $M$ 上完整正规化子或外部群的严格作用。Ruhstorfer 的 Assumption 2.25 / Theorem 2.26 把相关延拓作为额外假设处理。因此重写应继续使用本文拟证的严格 Sylow 作用与标量障碍消去，不要用 BDR Theorem 7.5 或 Ruhstorfer Theorem 2.26 替换它而省去假设。当前 Levi 259–261 恰当地把 upstairs 诱导和 downstairs 延拓分开；应保留这个数学次序。

来源：Bonnafé–Dat–Rouquier, *Derived categories and Deligne–Lusztig varieties II*, Ann. Math. 185 (2017), 609–670, DOI `10.4007/annals.2017.185.2.5`；<https://www.math.ucla.edu/~rouquier/papers/cdvdl-2.pdf>，本地 `primary/BDR17.pdf` / `.txt`，§7.A 文本约 2440–2555 行，§7.C 约 2640–2860 行。

### 3.3 Ruhstorfer：完整对角比较可以用，稳定代表必须单独论证

已核 v1 Lemma 3.1 及证明中比较映射对完整群 $(G^F\times(L^F)^{\mathrm{op}})\Delta\widehat L^F$ 的等变性。它支持 Levi 217–219 所需的完整对角比较，而不只支持 $S\times L^{\mathrm{op}}$ 的双模同构。

Lemma 2.10 / Corollary 2.13 支持有理 Levi 类的对偶与自同构兼容。Proposition 4.8 的完整陈述另有 $F_0$、交换性及全文设置；当前只引用“初段”获取 $G=DH_0$。该初段可以在当前规范 $C^\circ(s)$-Levi 设置重证，但不应把整条 Proposition 4.8 的全部结论视为自动可用。第 4 节给出足够的重证步骤。

来源：Lucas Ruhstorfer, *Derived equivalences and equivariant Jordan decomposition*, arXiv `2010.04468v1`, 2020-10-09；<https://arxiv.org/pdf/2010.04468v1>，本地 `primary/RuhJordan22v1.pdf` / `.txt`；§2.5–2.6、Lemma 3.1、Prop. 4.8。使用 v1 的编号时应在书目中明确版本，不与期刊版编号混用。

### 3.4 Taylor：循环因子的系列对应确有原文支持

已核 §8.2、Proposition 8.3 及 Corollary 8.8。它们处理 Steinberg 映射循环置换直积因子的情形，给出固定点第一投影与 Deligne–Lusztig 诱导、理性 Lusztig 系列的兼容性。因而 Levi 117–119 的引用主题准确。需要区分 Taylor 使用的未取商 Lang 纤维模型与本文 $\mathbf S/\mathbf U$ 模型；不能把 Taylor 的仿射纤维陈述直接引用成本文的“几何同构”。本文的取商同构可由下面逐分量方程单独证明。

来源：Jay Taylor, *The structure of root data and smooth regular embeddings of reductive groups*, Proc. Edinb. Math. Soc. 62 (2019), 523–552, DOI `10.1017/S0013091518000597`；<https://arxiv.org/pdf/1710.05516>，本地 `primary/Taylor19.pdf` / `.txt`，文本 1175–1325 行。

## 4. 逐段对抗核验：结论与必须补全的步骤

| 源行 | 内容 | 审查判断 |
|---|---|---|
| 3–10 | 系数与术语 | 明确缺定义；需注明标准有限系数系统到 $W(\bar{\mathbb F}_p)$ 的平坦基变换。 |
| 12–43 | Levi 定理 | 自身是带有明确 cover / actual action / proper Levi 假设的工具定理；这些假设是否覆盖全局所有分支须由全局模块另证。不能从本节推出全猜想已完成。 |
| 60–79 | 中心化子分量群、相对 $p'$ 群 | 换位子到中心核的论证成立方向正确；需注明选择的半单提升有有限阶，取其 $p'$ 部分仍映到 $s$。相对群是分量群的子商，因此为阿贝尔 $p'$ 群。 |
| 80–95 | 正规嵌入与内对角作用 | 可补全。权坐标环面的构造须给 $F$ 与图群的作用，及商掉反对角中心后的有限固定点记号。无需指数 $d_0$ 为 $p'$。 |
| 97–121 | 普通域自同构展开 | 已逐式核 $\tau^f=\gamma_{\mathrm{diag}}$、$\tau^{-1}\iota(x)=\iota(F_rx)$。它保存回返关系，不是把域与图群错误地改成独立直积。系列兼容有 Taylor 原文支持。 |
| 123–141 | 固定环面引理 | 已核范数消灭余不变量的挠部分；其阶被 (|P|) 消灭。结论正确，并不依赖 $p=2$。 |
| 143–150 | $p\ge5$ 固定抛物 | 内对角相对像为 $p'$，图群无 $p$ 部分，故中心余字符空间上的稳定子作用平凡；避免有限根超平面可行。 |
| 163–207 | $p=3,D_4$ | 每个真 $D_4$ Levi 的导出因子均为 A 型，故其半单连通中央化子仍为 Levi；最小性给 $C^\circ(s)=L^*$，不要求 $s$ 奇阶。此点涵盖 3′ 标签的 2 部分。根范数论证没有发现 $p=2$ 偷渡；须把等式标签移入本段，并定义根形式给出的配对。 |
| 211–253 | 几何格、标签群、严格 Sylow 作用 | 缺几何与算子定义。群商构造可核，但应把 $\overline X_b$ 定义为 $(S\times L^{op})\rtimes D_0$ 的像；对 $\Gamma$ 的原投影本身不穿过 $K_0$。若称“$D_0$ 的逆像”，必须说明实际商的是 $D_0/\operatorname{Inn}(L)$。 |
| 255–301 | 积分投射性与 generic span | 不能以现有一句“freeness and orthogonality”完成独立证明；须搬入并重证 5112–5146 的诱导算子计算。并应明确 $\widetilde M$ 与正规嵌入的几何上同调同一。 |
| 303–345 | 交换 endomorphism 阶、局部固定环、primitive 选择 | 在上一段的左 progenerator 与 generic span 成立后，双中心化子论证可核。不能以泛型中心直接代替积分中心；当前 313–320 已给出正确的积分桥梁，重写须保留。 |
| 349–382 | 标量 $p'$ 覆盖与主单位障碍 | 群上同调推理可核，见下方公式。需独立给出相对因子集，而不是只宣布障碍群。最终调整无须保留初选 Sylow 矩阵；仅保留已规定的子群作用，当前说明正确。 |
| 384–424 | 右 $\widehat J$ 作用、单一块 | 右作用的逆序乘法核验成立；$p'$ 指数相对平均可推出积分投射性。Morita 结论仍依赖完整对称阶引理；“同一非零格”推出块稳定还应使用该格对支撑块的忠实性。 |
| 426–441 | 对称阶提要 | 不足以满足用户逐步自包含要求；完整引理须作为一般 $p$ 代数引理出现在正文。旧证明各关键分裂步骤局部检查未发现反例，但根代理另在独立重审该引理，不能拿本段提要作替代。 |
| 445–457 | 因子乘积与置换 | 需明确用带次数符号的 Künneth 置换。符号来自几何作用并满足对称群关系；不应擅自改为无符号置换。 |
| 459–481 | $G=DH$、同一 cocycle、$C$ 保留 | 有理调整步骤应独立证明；对 $C$ 的平凡 actor 像依赖完美中心覆盖的提升唯一性。当前不应借“初段”一语隐藏这两个论证。 |
| 483–518 | 环境群 Morita 函子 | overlap 等式可核；给定的 $\Phi,\Psi$ 与原 $D\rtimes H\to DH$ 核相容，不是把原群改成分裂外积。评价／余评价的等变性仍应写出，而不仅说 commute。 |
| 520–532 | 原中心商 | 中心 $p$ 核应按被 (z-1) 消灭的模子范畴限制逆等价，不能通过不存在的积分中心字符幂等元处理。当前区分方向正确，建议用这一模论句明确证明。 |
| 534–557 | $k$、亏群阶、严格中心指数 | 在积分 Morita 已成立后，泛型单模数、Cartan 矩阵与最大初等因子给出前二者；末式利用混合 cocycle 在 $Z(G)$ 上为 1，故 $\pi^{-1}Z(G)\le Z(\widehat H)$。需要补“真 Levi 固定点的定义特征部分较小”的阶公式依据。 |
| 565–642 | Steinberg 根 | 下列逐分量计算可补本文声称的取商几何同构。实际幂次 $F_0^m=F$ 与 $\tau^m=1$ 均保留。族别的对角外群平凡／中央化子连通仍是分类输入，不能因该命题写下便自动覆盖所有例外 Schur cover。 |

### 4.1 必须显式出现的诱导算子计算

记 $\delta(t)$ 为完整对角算子，在 $K\widetilde S\otimes_{KS}KM$ 上有

$$
(g\otimes m)t=gt\otimes\delta(t)^{-1}m,\qquad
\widetilde T_a(g\otimes m)=g\otimes T_am.
$$

取 $n=n_a$、$u=ntn^{-1}$、$h=t^{-1}u\in L$。完整对角兼容性给出

$$
U_a\delta(t)^{-1}=\delta(u)^{-1}U_a,\qquad
hu^{-1}n^{-1}u=n^{-1}.
$$

于是

$$
(g\otimes T_am)u
=gt\otimes L_h\delta(u)^{-1}L_{n^{-1}}U_am
=gt\otimes L_{n^{-1}}\delta(u)^{-1}U_am
=\widetilde T_a((g\otimes m)t).
$$

这才证明诱导算子置换提升的右系列幂等元。把 $\sum_aR_{u_a}T_a=0$ 诱导上去，对每一个提升源幂等元及其互异目标分别投影，由 upstairs 右 Levi 忠实性得到每个 $u_a=0$。再配合维数等式才能得 generic span。这个计算可在奇素数正文独立完成，不能靠计算机例子代替。

### 4.2 标量障碍消去需要的完整接口

选 $R_e$ 的代表 (s(r)) 及相应可逆半线性算子 $U_r$。写

$$
c(r,t)=s(r)s(t)s(rt)^{-1}\in\overline X_b,\qquad
U_rU_t=\rho_X(c(r,t))\,\alpha(r,t)\,U_{rt}.
$$

这里 $\alpha(r,t)\in E_e^\times$；因 $E_e$ 交换，结合律给出有通常 $R_e$ 作用的 2-cocycle 方程。改变 $U_r$ 只改变 coboundary。此后原稿的消去顺序有效：

1. $E_e/\mathfrak m_e=k$，$k^\times$ 上作用平凡；$p$ 次幂在它上面为自同构。
2. 残留类被 $m=|R_e|_{p'}$ 消灭，利用 $1\to\mu_m\to k^\times\xrightarrow{m}k^\times\to1$ 提升为有限标量 cocycle。
3. 剩余类来自 $H^2(R_e,1+\mathfrak m_e)$。严格 Sylow 逆像作用、标量的互素性及 $H^1(\overline P,k^\times)=0$ 共同证明它限制为零。
4. restriction–corestriction 乘以 $[R_e:\overline P]$，而该 $p'$ 次幂由 Hensel 唯一开根在主单位群及其上同调上可逆，故剩余类为零。

不能跳过第 3 步中的 $H^1$ 注入理由，也不能从“模掉极大理想后的障碍为零”直接推出积分障碍为零。当前原稿没有犯后一推断错误；重写应保持完整链条。

### 4.3 有理调整与原环境群

可在 Levi 459–468 改写为以下证明，而不引用某篇文献证明的“初段”：稳定块确定一个稳定的有理 $p'$ 半单标签类；规范 Levi 是该标签的规范函数，故自同构保持其有理 Levi 共轭类。通过 Levi 对偶选择 $g\in S$，令 $g\sigma$ 保持 $\mathbf L$。其对偶把 $s$ 映到某个有理共轭 ${}^{n^*}s$；由于规范 Levi 已稳定，$n^*$ 正规化 $\mathbf L^*$。以对应的有理相对 Weyl 元 $n\in N_S(\mathbf L)$ 再调整，便同时固定 $e_s^L$。把群乘法方向写清，即得每个陪集有 $H_0$ 中代表和 $G=DH_0$。随后由 $A$ 对 primitive idempotents 的传递性得到 $H_0=NH$ 与 $G=DH$。

对中心商的证明应表述为：若 $z\in Z_0$ 在 $M$ 上满足左、右算子相同，则两个逆 Morita 函子把被所有 (z-1) 消灭的模送到相同条件的模，因此限制为商代数的逆等价。这个表述对中心 $p$ 核同样有效；不要求可除以 $|Z_0|$。

### 4.4 Steinberg 根的取商几何计算

下标取 $0,\ldots,m-1$。令 $U_0=U$，$U_i=F_0^{m-i}U$（$i\ge1$），且 $\overline F(g)_i=F_0(g_{i+1})$ 循环取下标。对于 $i\ge1$，有 $F_0(U_{i+1})=U_i$（末项为 $F_0(U_0)=U_{m-1}$）；因而取商方程给

$$
g_iU_i=F_0(g_{i+1})U_i,\qquad
g_iU_i=F_0^{m-i}(g_0)U_i.
$$

第 0 个方程恰成为

$$
g_0^{-1}F_0^m(g_0)\in U F_0^m(U).
$$

所以第一投影的逆由所有正次幂 $(g_0,F_0^{m-1}g_0,\ldots,F_0g_0)$ 给出，且在余陪集上良定义。这里没有取不可分映射的逆。该计算证明当前文中使用的取商模型同构；它与 Taylor 使用的未取商 Lang 纤维模型不同，不应混写。

## 5. 尚未由本次审查关闭的接口

1. **完整全局覆盖。** Levi 定理自身假设 ordinary covering action 已真实提升并保持中央核；对例外 Schur multipliers、小参数和 exceptional graph 分支，必须在全局定理的每一个调用处验证。此处的构造不会自动证明这些前提。
2. **源代数 / 配对向积分内作用的转移。** 另一审查员提出的 `odd_classical.tex` 430–510 行与 Murai13 Theorem 3.13 适用问题已转给负责者。本报告没有把它计为通过。
3. **完整对称阶引理的新一轮独立核验。** 我检查过旧证明的分裂秩零、有限积分扩张中的单位下降、投影构造；尚无反例。父代理正独立核验，不应在合并审核之前写“已经无条件证明”。
4. **严格数学自包含的界限。** 上述审查按“不得引用旧 $p=2$ 证明；可明确调用已核验的公开基础定理”解释。如果用户还要求连 Deligne–Lusztig 上同调、BR03 定理及有理 Levi 对偶本身也从头证明，那是明显更大的基础展开任务，当前文章不满足该更强含义。
5. **所有素数主定理的 $p=2$ 端点。** 用户只允许最后引用该结果，并不使它自动正确。其确切出处、公开版本和已证状态须在最后合并时明确。

## 6. 给下一轮重建审查的交接

优先建立一个奇素数正文自己的“代数与几何基础”段：先定义系数、系列、ordinary 范围、几何格和算子；再证明中心覆盖提升唯一性、正规嵌入限制与 generic span、对称阶积分支撑引理、相对标量障碍引理。然后重写 Levi 正文并逐处调用这些新标签。`lev:fixed-torus`、triality 根范数论证和 Steinberg 取商方程应保留完整证明。

最终静态门槛应是：odd 模块内对旧 `geo:*`、`sec:geometry` 及其他 p2 标签的引用为零，唯一允许的 $p=2$ 结果引用位于最后全素数推论。这个静态门槛只排除文本依赖；最终仍须由新一批审查员核查数学接口，而不能用编译成功或有限计算通过来代替。
