# Independent attack on the remaining toral type-D interface

Agent: `/root/toral_gap_independent_attack`  
Date: 2026-11-14  
Scope: `cl:toral-pending`, and only the two missing inputs there. No manuscript file was edited.

## 1. Verdict

I obtain a candidate complete repair of the **displayed toral interface** for (d=1,2). The repair needs independent rereading before it is incorporated. It does not certify any other part of the odd-prime theorem or the Brauer conjecture.

The key point is to transport **one entire extension map**, not to choose extensions separately in individual character fibers. Standard \(\eta=1\) torus-normalizer characters are good for every toral character; there is no prime-to-\(\ell\) degree restriction in the elementary argument proving this. The full-character correspondence of CS25 Proposition 4.14 then transfers goodness to its inverse images. In the exceptional rational configuration, the actual and standard field–graph groups are only diagonally conjugate modulo inner automorphisms. This suffices for transporting the whole extension map and the stabilizer factorization. Genuine extendibility is established separately: the actual induced field–graph group is cyclic in precisely this exceptional configuration. CS25 Proposition 5.30(b), applied in the original actual mixed group, then handles the central returns.

In particular, this repair does **not** infer genuine extension on the mixed carrier merely from conjugacy in an outer automorphism group. It retains

\[
 (t_1t_2)^2=t_1^2t_2^2,
 \qquad [n,t_1\gamma]=h_0,
 \qquad n^2=h_0
\]

in the exceptional case.

The proof below uses explicit public character-theoretic ingredients. An eventual article satisfying the user's self-containment requirement must expand the MS16/CS13 extension-map construction wherever it is used in the odd-prime argument. Merely inserting the citations below would not satisfy that separate writing requirement.

## 2. Sources checked and their exact scope

The CS25, MS16 and CS13 references below refer to primary documents in `revision_audits/primary/`. The additional Rossi source is linked explicitly.

1. **CS25**, arXiv:2410.20392v2, 1 May 2025: Proposition 4.14 is a full-character statement for arbitrary (d\ge1), under Conditions A(d), B(d). Remark 2.22 explicitly supplies those conditions for type D at (d=1,2). The generic statement of Proposition 4.14 does not assume that (d\ge3).
2. **CS25**, Definition 5.24, Lemmas 5.14 and 5.19, and Proposition 5.25: these define and compare the **actual** induced groups (E^M(K_i)) and the corresponding good sets \(\mathcal T_i\). The proof of Proposition 5.25(e) explicitly states that both induced groups act cyclically in the exceptional configuration.
3. **CS25**, Proposition 5.30(b): maximal extendibility for
   \(M^\circ\lhd ME(M)\) on \(\Irr(M^\circ\mid\mathcal T_1.\mathcal T_2)\). This is a statement about the actual group of Section 5; it has no (d\ge3) hypothesis.
4. **MS16**, Corollary 3.13: an (N\rtimes E)-equivariant extension map from the torus, and a genuine linear extension of each value to the full toral-character inertia group, with the defining return (v\widehat F) in its kernel. Proposition 3.4 describes the descent to the standard finite group and standard field–graph automorphisms. The all-character \(\eta=1\) argument is given explicitly in Section 4 below; it does not require the degree restriction occurring in CS25 Corollary 4.12(b).
5. **CS13**, Propositions 5.9 and 5.3: the analogous construction and descent in type A. They cover active rank three, (D_3^+(q)=\mathrm{SL}_4(q)) and (D_3^-(q)=\mathrm{SU}_4(q)). In the present regular torus situation, the characters being extended are linear.
6. **CS25**, Definition 2.5, Lemma 2.6, and Theorem 2.8: central character triples, restriction/extension consequences, and the precise Butterfly change of carrier. Section 7 below spells out the maps and preimages for the actual carrier. It reconstructs the generic proof behind Proposition 6.3, instead of applying that proposition outside its (d\ge3) assumptions.
7. **Rossi**, *The McKay Conjecture and central isomorphic character triples*, J. Algebra 618 (2023), 42–55: I checked the published Proposition 2.4 and its proof, pp. 45–46, directly at [the author's institutional repository](https://boa.unimib.it/retrieve/a172679d-3dd0-42a7-af2c-6fd44456e140/Rossi-2023-J%20Algebra-VoR.pdf). Its first assertion is a full-character statement; the prime-degree assertion is a separate “Moreover” clause. The input dictionary for its first assertion is \(K=K_1\), \(A_0=N_A(\mathbf S)\), \(J=M^\circ\), \(\mathcal S=\mathcal G_d(K_1)\), \(\mathcal S_0=\Irr(N_1)\), and \(\Psi=\Omega\).

For even (q), the odd-(q) reduction inside MS16 Section 3.B should not be silently reused. Section 4.4 below supplies the elementary split Tits-group construction needed in that case.

## 3. Actual groups and the geometric dictionary

Use the notation of Section 6 of `classical_repair_fresh.md`. Thus the active and residual algebraic factors \(\mathbf K_1,\mathbf K_2\) commute, intersect in \(\langle h_0\rangle\), and have finite fixed-point groups (K_i). A rank-one residual factor is a torus. The rational carrier is

\[
 M_0=K_1K_2,
 \quad M^\circ=(\mathbf K_1\mathbf K_2)^F,
 \quad M=M^\circ\langle n\rangle,
 \quad \widehat M=ME(M),
 \quad E(M^\circ)=E(M)\langle n,h_0\rangle.
\]

All of these are the actual groups of CS25 Section 5, with the relabeling (K_1=G_j), (K_2=G_{3-j}) when necessary. In particular, one must not insist that the active factor is the factor called (G_1) in Table 5.1: at (d=1) in twisted ambient type D the active factor is split and is (G_2) in that table.

Let \(\mathbf S\) be the active Sylow (d)-torus. In the parameter range at issue, its centralizer in \(\mathbf K_1\) is a maximal torus \(\mathbf T_1\). Put

\[
\begin{aligned}
 C_1&=C_{K_1}(\mathbf S)=\mathbf T_1^F,&
 N_1&=N_{K_1}(\mathbf S),\\
 C&=C_{M^\circ}(\mathbf S),&
 N^\circ&=N_{M^\circ}(\mathbf S),\\
 \widehat N&=N_{\widehat M}(\mathbf S),&
 H&=N_{M_0E(M^\circ)}(\mathbf S),
 \qquad C_0=C_1K_2.
\end{aligned}
\]

Here (d=1) has split active factor. For (d=2), the active sign is \((-1)^{\ell_1}\); hence (d) is regular on the active factor in both cases.

### 3.1 The rational index and the product with (C)

The algebraic centralizer is

\[
 C_{\mathbf K_1\mathbf K_2}(\mathbf S)=\mathbf T_1\mathbf K_2.
\]

Indeed, an element can be written (k_1k_2), and the second factor centralizes \(\mathbf S\), so that (k_1k_2) centralizes \(\mathbf S\) exactly when (k_1\in\mathbf T_1).

Taking fixed points of this central product gives

\[
 [C:C_1K_2]\le2,
 \qquad C_1\le Z(C).
\]

The missing rational coset can be represented within (C). Since (h_0\in\mathbf T_1), Lang's theorem on the connected torus \(\mathbf T_1\) gives (u_1\in\mathbf T_1) with (u_1^{-1}F(u_1)=h_0). Choose (u_2\in\mathbf K_2) with the same Lang value. Then (u_1u_2\in C) represents the nontrivial coset of (M^\circ/M_0) when that quotient is nontrivial. Therefore

\[
 M^\circ=CM_0=CK_1,
 \qquad N^\circ=CN_1.
\]

The second equality follows by writing an element of (N^\circ) as (ck_1): since (c) centralizes \(\mathbf S\), (ck_1) normalizes it exactly when (k_1) does. This argument only describes the cosets of (C); it does not replace the chosen elements (t_1,t_2,n) or change any of their multiplication laws.

### 3.2 Intersections and the actual normalizer

CS25 Lemmas 5.13(a) and 5.18(a) give

\[
 M^\circ\cap M_0E(M^\circ)=M_0.
\]

Consequently

\[
 C\cap H=C\cap M_0=C_1K_2=C_0.
\]

Also \(\widehat M=M^\circ M_0E(M^\circ)=C M_0E(M^\circ)\). Taking the normalizer of \(\mathbf S\), and using that (C) centralizes \(\mathbf S\), gives

\[
 \widehat N=CH.
\]

The factors (K_i\lhd\widehat M) are preserved by the actual field–graph operators (CS25 Lemmas 5.12 and 5.17). Thus (K_2\lhd\widehat N), ([N_1,K_2]=1), (H) normalizes (N_1), and (C,C_0,N^\circ\lhd\widehat N). The latter normalities also follow directly by intersecting the normal (M^\circ) or (M_0) with the relevant centralizer/normalizer. We have thereby checked all the group-theoretic hypotheses of `cl:toral-transfer`.

## 4. Why the whole standard \(\eta=1\) family is good

The symbol in the heading means \(\eta=1\), the trivial relative Weyl-group parameter; it is not a new assumption on the degree of the induced character.

### 4.1 An elementary all-character lemma

Work first in the twisted coordinates used for the torus-normalizer construction. Write (T\lhd N), where (T) is abelian, and let (E^\dagger) be the finite covering field–graph group used there. Let \(\widetilde N=N\widetilde T\), where \(\widetilde T\) centralizes (T). Suppose \(\Lambda^0\) is an (NE^\dagger)-equivariant extension map for (T\lhd N), and that for every \(\lambda\in\Irr(T)\) its value has a genuine linear extension

\[
 \widehat\lambda\in\Irr((NE^\dagger)_\lambda),
 \qquad z\in\ker\widehat\lambda,
\]

where (z=v\widehat F) is the central defining return. Set

\[
 \psi_\lambda^0=
 \Ind_{N_\lambda}^{N}\Lambda^0(\lambda).
\]

Clifford theory makes \(\psi_\lambda^0\) irreducible. Then, for **every** \(\lambda\),

\[
 (\widetilde N E^\dagger)_{\psi_\lambda^0}
   =\widetilde N_{\psi_\lambda^0}(E^\dagger)_{\psi_\lambda^0},
 \tag{4.1}
\]

and \(\psi_\lambda^0\) has a genuine extension to \((NE^\dagger)_{\psi_\lambda^0}\) whose kernel contains (z).

**Proof of the factorization.** Let \(te\in(\widetilde N E^\dagger)_{\psi_\lambda^0}\), with \(t\in\widetilde T\), \(e\in E^\dagger\); an (N)-factor can be removed because inner automorphisms fix characters of (N). Restricting to (T), and using that (t) centralizes (T), shows that \(\lambda^e\) is (N)-conjugate to \(\lambda\). Choose (n\in N) such that \(\lambda^{ne}=\lambda\). Equivariance gives

\[
 \Lambda^0(\lambda)^{ne}=\Lambda^0(\lambda).
\]

Induction commutes with conjugation, so \((\psi_\lambda^0)^{ne}=\psi_\lambda^0\), hence \((\psi_\lambda^0)^e=\psi_\lambda^0\). Since (te) fixes the same character, (t) fixes it too. This proves (4.1).

**Proof of genuine extension.** The same argument gives the exact inertia identity

\[
 (NE^\dagger)_{\psi_\lambda^0}
       =N(NE^\dagger)_\lambda.
\]

Induce \(\widehat\lambda\) to the group on the left. Its restriction to (N) is \(\psi_\lambda^0\), by the one-double-coset restriction formula. It is therefore irreducible and is a genuine extension. Since (z) is central and belongs to the kernel of the inducing character, it belongs to the kernel of the induced character.

This also proves the necessary stabilizer assertion about the extension fiber. Every element of \((NE^\dagger)_\lambda\) fixes the *chosen linear extension* \(\Lambda^0(\lambda)\), not merely the set of its possible twists. There is no orbitwise choice left to make, and \(\eta=1\) remains \(\eta=1\) under this stabilizer.

### 4.2 Descent to the standard field–graph group

For active rank at least four and odd (q), the hypotheses of Section 4.1 are exactly MS16 Corollary 3.13. Use the Lang isomorphism in MS16 Proposition 3.4, and then quotient the covering group by \(\langle v\widehat F\rangle\). The kernel condition just proved permits this quotient for the genuine extension, not only for the action on character sets.

The descended extension map is equivariant under

\[
 N_{\operatorname{Inn}(K_1)E^0}(\mathbf S),
 \tag{4.2}
\]

where \(E^0=\langle F_r,\gamma_1\rangle\) is the specific standard field–graph subgroup used in the comparison in CS25 Lemmas 5.14 and 5.19. At active rank four, this uses the indicated order-two graph automorphism; the full triality group need not belong to the carrier. The MS16 extension map is equivariant for the larger permitted diagram group, so its equivariance and extension properties restrict to this subgroup before the argument above is made. The descended character \(\psi_\lambda^0\) extends to

\[
 (K_1E^0)_{\mathbf S,\psi_\lambda^0}.
 \tag{4.3}
\]

The stabilizer statement in (4.1) descends in the form used in MS16 Theorem 3.1: if \(\widetilde K_1\) is a regular embedding and

\[
 O_\lambda=K_1(\widetilde K_1E^0)_{\mathbf S,\psi_\lambda^0},
\]

then

\[
 O_\lambda=(O_\lambda\cap\widetilde K_1)(O_\lambda\cap E^0).
 \tag{4.4}
\]

The proof of MS16 Proposition 3.4 applies to each of the particular characters constructed in Section 4.1. Its transfer does not replace such a character by an unspecified diagonal conjugate. Thus (4.2)--(4.4) hold simultaneously for the entire descended map.

### 4.3 Active rank three

For \(K_1=\mathrm{SL}_4(q)\) at (d=1), or \(K_1=\mathrm{SU}_4(q)\) at (d=2), use CS13 Proposition 5.9 in place of MS16 Corollary 3.13. Here the Sylow torus centralizer is a torus, so its \(\xi\) is our linear \(\lambda\). The hypotheses of Section 4.1 hold verbatim. CS13 Proposition 5.3 gives precisely the required descent, including the defining-return kernel and the standard field–graph group. Equations (4.2)--(4.4) follow by the same per-character argument. No rank padding and no change of (q) are used.

### 4.4 Even defining characteristic

If (q) is even, (h_\alpha(-1)=1). Hence the Tits representatives of the simple reflections satisfy both the braid relations and (n_\alpha(1)^2=1). They generate a subgroup (V\cong W(D_{\ell_1})), with (V\cap\mathbf T_1=1). In the standard (d=1,2) twisted torus coordinates, (N=T\rtimes V_1), where \(V_1=V^{vF}\). Field automorphisms fix these representatives and graph automorphisms permute them; the relevant finite group (E^\dagger) preserves (V_1).

For every \(\lambda\in\Irr(T)\), define

\[
 \Lambda^0(\lambda)(tw)=\lambda(t)
       \quad(t\in T,\ w\in(V_1)_\lambda).
\]

This is a linear character because (w) fixes \(\lambda\). It is an extension of \(\lambda\), and the definition makes the entire map (NE^\dagger)-equivariant. More generally, on

\[
 (NE^\dagger)_\lambda
       =T\rtimes(V_1E^\dagger)_\lambda
\]

the formula \(\widehat\lambda(tu)=\lambda(t)\) defines a genuine linear extension. The return \(v\widehat F\) lies in the complementary factor and therefore has value one. Sections 4.1 and 4.2 apply.

For completeness, in the present active type-D cases (V_1=V): at (d=1) the active Frobenius is split, and at (d=2) its Weyl-group component after multiplication by the longest element is (-1), which centralizes (W(D_{\ell_1})). The semidirect-product construction therefore requires no surjectivity assumption about fixed points of a nonsplit Tits extension. In rank three the same construction may be used through the (D_3=A_3) root realization, or one may use CS13 Proposition 5.9, which is not restricted to odd (q).

## 5. Full-character inverse images are standard good characters

Let

\[
 \Omega:\mathcal G_d(K_1)\longrightarrow\Irr(N_1)
\]

be the full \(\operatorname{Aut}(K_1)_{\mathbf S}\)-equivariant bijection of CS25 Proposition 4.14. Conditions A(d), B(d) are supplied by CS25 Remark 2.22 in type D. For active rank three they are the type-A results of CS13 (equivalently the type-A instance of the criterion used in Proposition 4.14). The set \(\mathcal G_d\) is the full set from CS25 Definition 4.13; it is not restricted to characters of degree prime to an auxiliary prime.

Define

\[
 \chi_\lambda^0=\Omega^{-1}(\psi_\lambda^0).
\]

Then **every** \(\chi_\lambda^0\) has the standard good properties

\[
 (\check K_1E^0)_{\chi_\lambda^0}
     =(\check K_1)_{\chi_\lambda^0}(E^0)_{\chi_\lambda^0},
 \qquad
 \chi_\lambda^0\text{ extends to }K_1(E^0)_{\chi_\lambda^0}.
 \tag{5.1}
\]

Here \(\check K_1=\{g\in\mathbf K_1:g^{-1}F(g)\in Z(\mathbf K_1)\}\), as in CS25 Notation 2.15. Its induced diagonal automorphism group is the same as that of a regular embedding.

To see the factorization, let (A^0=\widetilde K_1E^0). Conjugacy of Sylow (d)-tori gives

\[
 (A^0)_{\chi_\lambda^0}
   =K_1N_{A^0}(\mathbf S)_{\chi_\lambda^0}
   =K_1N_{A^0}(\mathbf S)_{\psi_\lambda^0}
   =O_\lambda.
\]

The first equality uses that every inner automorphism fixes the character of (K_1); the second uses the equivariance of \(\Omega\). Equation (4.4) gives the required factorization in the regular embedding. The factorization is a statement about the permutations induced on \(\Irr(K_1)\), so it transfers to \(\check K_1\), which induces exactly the same diagonal automorphisms.

For extendibility, apply the central-triple relation in Proposition 4.14 to the actual group \(K_1(E^0)_{\chi_\lambda^0}\), with the carrier change described explicitly in Section 7. Its local side is the group in (4.3). Equation (4.3) and CS25 Lemma 2.6(b) transfer genuine extendibility to the global side.

This proves (5.1) directly. In particular, it avoids applying CS25 Corollary 4.12(b) outside its stated degree hypothesis.

## 6. Transporting one whole map to the actual induced group

Put

\[
 I=\operatorname{Inn}(K_1),\qquad
 D=\operatorname{im}(\check K_1\longrightarrow\operatorname{Aut}(K_1)),
 \qquad E'=E^M(K_1).
\]

Thus \(I\lhd D\), and (D) is the full inner-diagonal automorphism group.

### 6.1 Ordinary rational configuration

By CS25 Lemma 5.14, (E'=E^0) as actual subgroups of \(\operatorname{Aut}(K_1)\). Take \(\Lambda_1=\Lambda^0\). Equation (5.1) says

\[
 \Omega^{-1}\left(\Ind_{(N_1)_\lambda}^{N_1}\Lambda_1(\lambda)\right)
       \in\mathcal T_1
       \quad\text{for every }\lambda\in\Irr(C_1),
 \tag{6.1}
\]

where \(\mathcal T_1\) is the **actual** good set in Definition 5.24, not a previously chosen transversal.

### 6.2 Exceptional rational configuration

CS25 Hypothesis 5.15 is the case of negative ambient sign and \(|Z_1|=|Z_2|=4\). Here (f) is odd. If the active factor is the factor called (G_2) in Section 5, Lemma 5.19 again gives (E'=E^0), so no transport is needed. Otherwise the same lemma gives a diagonal automorphism (a_0\in D) with

\[
 IE'=(IE^0)^{a_0}.
\]

The automorphism (a_0) permutes Sylow (d)-tori. Choose one inner correction (i\in I) so that (a=a_0i) normalizes \(\mathbf S\). Since (I) is normal in (IE'), this does not change the equality:

\[
 a\in D_{\mathbf S},
 \qquad IE'=(IE^0)^a.
 \tag{6.2}
\]

Define the whole extension map by

\[
 \boxed{\quad
 \Lambda_1(\lambda)
     =\Lambda^0(\lambda^{a^{-1}})^a
       \quad\text{for every }\lambda\in\Irr(C_1).
 \quad}
 \tag{6.3}
\]

Since (a) normalizes \(\mathbf S\), it normalizes (C_1) and (N_1). Thus

\[
 ((N_1)_{\lambda^{a^{-1}}})^a=(N_1)_\lambda,
\]

and (6.3) is a linear extension of \(\lambda\) on exactly its required inertia group. Every inner-diagonal automorphism is induced by conjugation in the algebraic group and therefore fixes its center pointwise. In particular \(a(h_0)=h_0\); the prescribed value at \(h_0\) is unchanged.

If \(b\in N_{IE'}(\mathbf S)\), then \(aba^{-1}\in N_{IE^0}(\mathbf S)\). The equivariance of the whole standard map gives

\[
 \Lambda_1(\lambda)^b
   =\Lambda^0(\lambda^{a^{-1}})^{ab}
   =\Lambda^0((\lambda^{a^{-1}})^{aba^{-1}})^a
   =\Lambda_1(\lambda^b).
 \tag{6.4}
\]

In particular (b\in N_{IE'}(\mathbf S)_\lambda) fixes the *selected value* \(\Lambda_1(\lambda)\). This proves stabilization of the linear-extension fiber with no independent choices on orbits. Induction and the full equivariance of \(\Omega\) give

\[
 \begin{aligned}
 \psi_\lambda
  &:=\Ind_{(N_1)_\lambda}^{N_1}\Lambda_1(\lambda)
       =(\psi^0_{\lambda^{a^{-1}}})^a,\\
 \chi_\lambda
  &:=\Omega^{-1}(\psi_\lambda)
       =(\chi^0_{\lambda^{a^{-1}}})^a.
 \end{aligned}
 \tag{6.5}
\]

Thus the *same* (a) transports the entire toral extension map, the entire \(\eta=1\) family, and all its global inverse images.

### 6.3 Why the transported inverse images belong to the actual good set

Conjugating (5.1) by (a) proves stabilizer factorization for (D(E^0)^a) at \(\chi_\lambda\). Since inner automorphisms fix every irreducible character of (K_1), equation (6.2) implies that (E') and ((E^0)^a) induce the same permutations on \(\Irr(K_1)\). Consequently

\[
 (DE')_{\chi_\lambda}=D_{\chi_\lambda}(E')_{\chi_\lambda}.
 \tag{6.6}
\]

More explicitly, \(D(E^0)^a=DE'\) as subgroups because \(I(E^0)^a=IE'\) and \(I\le D\). If \(g\) lies in its character stabilizer, the transported standard factorization writes \(g=d_0e_0\), with \(d_0\in D_{\chi_\lambda}\) and \(e_0\in((E^0)^a)_{\chi_\lambda}\). Choose \(e'\in E'\) in the same coset modulo \(I\) as \(e_0\), and write \(e_0=ie'\). Inner automorphisms act trivially on characters, so \(i\in D_{\chi_\lambda}\) and \(e'\in(E')_{\chi_\lambda}\). Hence \(g=(d_0i)e'\in D_{\chi_\lambda}(E')_{\chi_\lambda}\). Pulling this factorization back through \(\check K_1\to D\) gives the version in Definition 5.24. More precisely that definition uses the lifted \(E^M(\check K_1)\) on the finite diagonal enlargement; its restriction kernel acts trivially on \(\Irr(K_1)\) and hence belongs to the appropriate character stabilizer, so the same factorization pulls back to this lifted group. This argument does not require a claim about the uniqueness of a diagonal–field–graph factorization.

For genuine extendibility we use a different argument. In this exceptional configuration, the proof of CS25 Proposition 5.25(e) explicitly identifies

\[
 E^M(G_1)=\langle t_1\gamma,F_r^2\rangle,
 \qquad E^M(G_2)=\langle\gamma_2,F_r\rangle
\]

as **cyclic groups of induced automorphisms**, because \(f\) is odd. This cyclicity can be read directly from the relations: on the twisted factor \(F_r^2\) has odd order dividing \(f\), it commutes with \(t_1\gamma\), and \((t_1\gamma)^2=1\); on the split factor \(F_r\) has odd order dividing \(f\) and commutes with the order-two graph operator. Each group is therefore a product of cyclic groups of relatively prime orders, hence cyclic. Consequently \((E')_{\chi_\lambda}\) is cyclic. Every invariant complex irreducible character extends across a cyclic quotient: let \(\rho_0\) afford the character, let \(u\) lift a generator of the quotient of order \(m\), and let \(T\) be an intertwiner for \(u\). Then \(T^m\rho_0(u^{-m})\) is scalar. Rescale \(T\) by an \(m\)-th root of the inverse scalar. The rescaled operator satisfies \(T^m=\rho_0(u^m)\), as well as the conjugation relation on the normal subgroup, and defines a genuine representation.

Thus \(\chi_\lambda\) extends to \(K_1(E')_{\chi_\lambda}\). Together with (6.6) this proves (6.1) also in the exceptional configuration. No conclusion about genuine extension was drawn from outer conjugacy.

### 6.4 The actual (H)-action and its kernel

Restrict conjugation on (K_1):

\[
 \rho:M_0E(M^\circ)\longrightarrow\operatorname{Aut}(K_1).
\]

Its image is (IE'): (K_1\le M_0) supplies (I), (K_2) centralizes (K_1), and (E(M^\circ)) induces (E') by definition. The action of these automorphisms on (F)-stable algebraic subgroups is well-defined, as in CS25 Section 2.C and the beginning of Section 6.A. A defining Frobenius power in the kernel stabilizes each (F)-stable subgroup. It follows that

\[
 \rho(H)=N_{IE'}(\mathbf S),
 \qquad
 \ker(\rho|_H)=C_H(K_1).
 \tag{6.7}
\]

For the first equality, any lift of an automorphism preserving \(\mathbf S\) already lies in its normalizer, since the kernel acts trivially on the set of (F)-stable subgroups. An element of the second group fixes every element of (N_1\le K_1), so it acts trivially on each extension-map value as a character of ((N_1)_\lambda). Pulling back (6.4), or (4.2) in the ordinary case, therefore proves that \(\Lambda_1\) is genuinely **(H)-equivariant** as a character-valued extension map.

This kernel argument does not assert that the kernel acts trivially on all representations of the later mixed carrier. Its nontrivial central scalars are retained in the next step.

## 7. Change of carrier with the actual normalizer and central kernel

This section gives the exact carrier dictionary that permits the generic character-triple construction to be used for (d=1,2).

Let \(\widetilde T\) be the regular diagonal torus of CS25 Lemma 5.7, and set

\[
 A=M\widetilde T E(M),\qquad J=M^\circ.
\]

Lemma 5.7(c) and the definition of (E(M)) give (K_1\lhd A), (J\lhd A). Conjugacy of the Sylow (d)-tori of (K_1) gives

\[
 A=K_1N_A(\mathbf S).
 \tag{7.1}
\]

The action map is

\[
 \kappa:A\longrightarrow\operatorname{Aut}(K_1),
 \qquad\ker\kappa=C_A(K_1)\le N_A(\mathbf S).
\]

For \(\chi_1\in\mathcal G_d(K_1)\), put \(\psi_1=\Omega(\chi_1)\) and

\[
 \Gamma_0=\kappa(N_A(\mathbf S)),
 \qquad \Gamma_{0,\chi_1}=\Gamma_0\cap\operatorname{Aut}(K_1)_{\chi_1}.
\]

First restrict the full central-triple relation of Proposition 4.14 to

\[
 (K_1\rtimes\Gamma_{0,\chi_1},K_1,\chi_1)
 \ \ge_c\
 (N_1\rtimes\Gamma_{0,\chi_1},N_1,\psi_1).
 \tag{7.2}
\]

This restriction is necessary, for example when the full active automorphism group contains triality that is absent from the actual carrier.

The image of the left-hand carrier in (7.2) is

\[
 I\Gamma_{0,\chi_1}=\kappa(A_{\chi_1}),
\]

by (7.1) and \(\Omega\)-equivariance. The image of the right-hand carrier is \(\Gamma_{0,\chi_1}\), because the inner automorphisms induced by (N_1) already belong to this group. Its full preimage in (A_{\chi_1}) is exactly

\[
 \kappa^{-1}(\Gamma_{0,\chi_1})\cap A_{\chi_1}
      =N_A(\mathbf S)_{\chi_1}
      =N_A(\mathbf S)_{\psi_1}.
 \tag{7.3}
\]

The kernel (C_A(K_1)) is included, rather than divided out. Therefore the Butterfly theorem with these precise maps gives

\[
 (A_{\chi_1},K_1,\chi_1)
 \ \ge_c\
 (N_A(\mathbf S)_{\psi_1},N_1,\psi_1).
 \tag{7.4}
\]

The central condition in (7.4) includes the common scalars on (C_A(K_1)), in particular on (K_2) and on (h_0\in K_1\cap K_2). This is what an argument using only images in an outer automorphism group would lose.

### 7.1 Lifting from (K_1) to (J=M^\circ)

The usual character-triple correspondence applied to (7.4), and then Clifford induction over (A)-orbits, yields an (N_A(\mathbf S))-equivariant bijection

\[
 \Pi:\Irr(J\mid\mathcal G_d(K_1))
       \longrightarrow\Irr(N_J(\mathbf S))=\Irr(N^\circ).
 \tag{7.5}
\]

Here is the relevant construction and its two properties. For a fixed \(\chi_1\), choose the associated projective representations (P,P') in the definition of (7.4). On

\[
 J_{\chi_1}/K_1
    \ \cong\
 N_J(\mathbf S)_{\psi_1}/N_1
\]

their factor sets coincide. Tensoring (P), respectively (P'), with the **same** irreducible projective representation having the inverse factor set gives the corresponding irreducible characters over \(\chi_1\), respectively \(\psi_1\). Inducing the corresponding Clifford characters gives (7.5). Choose the projective data on one (N_A(\mathbf S))-orbit and transport it to the other points; the central-triple construction is compatible with inertia and with this transport. Equivalently, this is the generic construction used in the proof of CS25 Proposition 6.3(c), whose character-triple ingredients here have all been verified without an assumption (d\ge3).

First, if \(\chi\leftrightarrow\psi\) under (7.5), then

\[
 A_\chi=J N_A(\mathbf S)_\psi,
 \qquad
 \chi\text{ extends to }U
 \ \Longleftrightarrow\
 \psi\text{ extends to }N_U(\mathbf S)
 \tag{7.6}
\]

for (J\le U\le A_\chi). Indeed, the obstruction factor sets on the two isomorphic quotient groups are the same; they become coboundaries simultaneously. This is also CS25 Lemma 2.6(b) applied to the resulting central triple.

Second, if \(\varphi_2\in\Irr(K_2)\) has the same central character as \(\chi_1\) on \(\langle h_0\rangle\), then

\[
 \Pi\bigl(\Irr(J\mid\chi_1.\varphi_2)\bigr)
    =\Irr(N^\circ\mid\Omega(\chi_1).\varphi_2).
 \tag{7.7}
\]

To justify the unchanged \(\varphi_2\), the projective matrices of (P) and (P') on (K_2\le C_A(K_1)) are scalar with the *same* scalars. Tensoring with the common inverse-factor-set representation therefore gives the same (K_2)-constituents on the two sides. The same scalar identity on (h_0) ensures that both central products are defined. Clifford induction preserves the assertion. Thus (7.7) is not a separately assumed compatibility of a set bijection.

The construction in this paragraph is the generic central-triple lifting lemma, rather than a new assertion about Lie type. Its fully formal version is the result cited as Rossi, J. Algebra 618 (2023), Proposition 2.4, in CS25's proof of Proposition 6.3(c).

## 8. Completion of the two required inputs

Choose the residual representative \(\varphi_2\) in an (E^M(K_2))-stable diagonal transversal \(\mathscr T_2\subseteq\mathcal T_2\). Such a transversal follows from CS25 Proposition 5.25(a) and the stabilizer-factorization definition of \(\mathcal T_2\). In detail, for a good character, the stabilizer in (E^M(K_2)) of its diagonal orbit fixes the character itself. One can choose a good representative for one orbit of diagonal orbits and propagate it by (E^M(K_2)); the preceding stabilizer statement makes propagation well-defined. This gives an invariant transversal.

Let \(\lambda\in\Irr(C_1)\) have the compatible (h_0)-value. Use the single map \(\Lambda_1\) from Section 6 and set

\[
 \psi_1=\Ind_{(N_1)_\lambda}^{N_1}\Lambda_1(\lambda),
 \quad\chi_1=\Omega^{-1}(\psi_1),
 \quad\Phi=\psi_1.\varphi_2.
\]

By (6.1), \(\chi_1\in\mathcal T_1\). The central-triple scalar identity gives

\[
 \frac{\chi_1(h_0)}{\chi_1(1)}
   =\frac{\psi_1(h_0)}{\psi_1(1)}
   =\lambda(h_0),
\]

so \(\chi_1.\varphi_2\) is defined. For arbitrary

\[
 \psi\in\Irr(N^\circ\mid\Phi),
\]

put \(\chi=\Pi^{-1}(\psi)\). By (7.7),

\[
 \chi\in\Irr(M^\circ\mid\chi_1.\varphi_2)
       \subseteq\Irr(M^\circ\mid\mathcal T_1.\mathcal T_2).
\]

CS25 Proposition 5.30(b), in the actual group \(\widehat M=ME(M)\), gives a genuine extension of \(\chi\) to \(\widehat M_\chi\). Applying (7.6) with (U=\widehat M_\chi) gives a genuine extension of \(\psi\) to

\[
 N_{\widehat M_\chi}(\mathbf S)
    =N_{\widehat M}(\mathbf S)_\psi
    =\widehat N_\psi.
\]

This proves the second missing assertion for **every** indicated \(\psi\). Section 6.4 already proved the first missing assertion, (H)-equivariance of \(\Lambda_1\).

Finally (C) induces diagonal automorphisms on (K_2), whereas (H) acts by inner automorphisms and (E^M(K_2)). The invariant diagonal-transversal property gives

\[
 (CH)_{\varphi_2}=C_{\varphi_2}H_{\varphi_2}.
\]

Explicitly, if (ch) fixes \(\varphi_2\), then \(\varphi_2^h\) belongs to both its diagonal orbit and \(\mathscr T_2\), so it equals \(\varphi_2\); then (c) fixes it as well. The hypotheses of `cl:toral-transfer` are now all verified, and that lemma supplies the genuine extension of every \(\tau\in\Irr(C\mid\lambda.\varphi_2)\) to \(\widehat N_\tau\).

### 8.1 Simultaneous diagonal transport of source data

No independent active good representative is chosen after the residual representative. The map above works for every \(\lambda\). Therefore a single diagonal transport used to put the residual source character in \(\mathscr T_2\) may carry the active toral character to any of its transported values, and that value is still covered by the same assertion (6.1).

More concretely, CS25 Lemma 5.7(b) shows that the ambient regular diagonal torus induces the full required diagonal action on (K_2). If a chosen diagonal transporter moves \(\mathbf S\), multiply it by an element of (K_1) returning the transported Sylow (d)-torus to \(\mathbf S\). This correction acts trivially on (K_2). The resulting single transporter normalizes \(\mathbf S\) and transports the full source tuple, including its block and its active toral character. One then applies the all-(lambda) construction above. If the carrier itself is transported, all of (n,t_i,E(M)) and their relations must be transported along with it. There is no step which separately regularizes \(\lambda\) while keeping a previously chosen incompatible residual tuple fixed.

## 9. Exact points for the fresh independent reviewer

The proof should be checked in the following order.

1. Section 4.1: the all-character \(\eta=1\) lemma is the reason no prime-degree hypothesis survives. Its two inductions and the stabilizer equality are elementary and should be recomputed directly.
2. Sections 4.2--4.4: standard-coordinate descent preserves the whole chosen map and its return kernel; rank three and even (q) are covered separately.
3. Section 5: full Proposition 4.14, rather than the prime-degree correspondence or Corollary 4.12(b), is used.
4. Sections 6.2--6.4: one diagonal (a) transports the entire map; the actual (H)-action factors through exactly the displayed normalizer. Outer conjugacy is used only for the character-set action and the factorization. Actual cyclicity supplies genuine global extension in the exceptional configuration.
5. Section 7: first restrict the full automorphism group to the image of the actual normalizer; then check both carrier images and the full preimage, retaining the centralizing kernel. The generic central-triple lifting retains the (K_2)-constituent and actual extension obstruction.
6. Section 8: Proposition 5.30(b) is applied to the original actual (M^\circ\lhd\widehat M). It is the step which preserves and handles ([n,t_1\gamma]=h_0). No abstract replacement with commuting involutions occurs.

The report uses no finite computation as a substitute for a uniform argument, and it supplies no claim that a two-primary obstruction can be absorbed in a counting budget. That alternative was not needed for this candidate repair.
