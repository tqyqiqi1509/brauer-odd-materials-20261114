# Fresh sequential audit of the affine and classical chapters

Reviewer: `/root/affine_classical_final_fresh`  
Date: 2026-11-14  
Scope: mathematical audit, independent of the earlier PASS reports. This report does not certify the whole paper.

## 1. Reading record and current disposition

I read the frozen `odd_affine.tex` in order, in the successive ranges 1–500, 501–1050, 1051–1600, 1601–2160, 2161–2730, 2731–3260, and 3261–3610. I then read all of `odd_classical.tex`, in the ranges 1–560, 561–1140, and 1141–1546, and all 167 lines of `central_quotient_note.tex`. I additionally read the first 528 lines of `odd_global_capacity.tex`, including the complete-probe definition, two-cycle theorem, Hall-coset lemma, and mixed two-cycle proof. Later changes to the affine outer-order estimate were separately reread.

Initial hashes:

| File | SHA-256 |
|---|---|
| `brauer_odd_revision/odd_affine.tex` | `4538712323d7a968edc159436f86b68f42a5461e33c5f9270af3af78509dc5fe` |
| `brauer_odd_revision/odd_classical.tex` | `8158106e133ab59696e5520820ce851725b5cbe085b65f457975d786482a2bc9` |
| `revision_audits/central_quotient_note.tex` | `d5edc60ac3c7918b405d91e62367c7234bf7f4966956244e3e22b59d23f2397b` |
| `brauer_odd_revision/odd_global_capacity.tex` | `277090440070f9f432830071ad8cb38f5c108a60815af585318555dc19fdba27` |

The first affine patch, introducing `aff:outer-three-bound`, was read at hash `f5a480c25d694008a18118845ae165ff234e705c724a3c32e27039c6ed8dd1d6`. The lemma was initially nested inside another proof. Root moved it before `aff:binary-profile`, and I reread the statement, proof, and both consumers after that move. The final audited affine hash is `67cce3a57a67f2b1788fc660ed254e85871dd43ca7a31564259eb18102de6702`.

Disposition:

1. **Confirmed false assertion in the initial affine text:** the blanket bound for the full outer automorphism order. This has a concrete counterexample and a valid local repair, detailed in §2.
2. **No error found in the new scalar-average calculation, the principal-root argument, the two abstract Clifford transfer lemmas, or the central-quotient note:** their actual arguments were checked, rather than accepted from an earlier audit. Details are in §§3–5.
3. **The frozen classical chapter is explicitly conditional at its mixed toral interface.** That conditional text cannot itself certify the unconditional main theorem.
4. **A new repair of that precise interface is supplied in §6.** It does not apply CS25 §6 outside its stated range. It reconstructs the needed argument from the all-character correspondence, the ordinary toral extension map, the actual mixed groups, and the actual extension theorem of CS25 §5. In particular, it addresses the difference between outer conjugacy and genuine extension. This new argument requires a separate fresh adversarial review before being treated as integrated proof.

## 2. Confirmed affine error and its repair

### 2.1 The original assertion is false

The proof of `aff:coarse-profile` originally asserted

\[
 |\operatorname{Out}(S)|\leq 2\sqrt\mu,
\]

where \(\mu\) is the least nontrivial permutation degree of a nonabelian finite simple group. For \(S=\operatorname{PSL}_3(4)\), the projective-point action has degree 21, and

\[
 |\operatorname{Out}(S)|=3\cdot2\cdot2=12>2\sqrt{21}.
\]

The same full-order assertion is printed in GMP17, Lemma 7.7. I opened the author PDF and visually inspected its printed page 18: this is not an OCR error. A citation to that sentence cannot validate the assertion.

Primary source: R. M. Guralnick, A. Maróti, L. Pyber, *Normalizers of primitive permutation groups*, author PDF, <https://www.renyi.hu/~maroti/pyber19.pdf>, Lemma 7.7 and its proof, printed pp. 18–19.

### 2.2 The precise weaker bound needed by this paper is valid

The last assertion of the same lemma, supported separately by its classification proof, gives

\[
 |\operatorname{Out}(S)|\leq\sqrt\mu
\]

outside \(A_6,L_2(27),L_3(4),L_3(16)\). The exceptions are:

| \(S\) | \(\mu\) | \(|\operatorname{Out}(S)|\) | \(|\operatorname{Out}(S)|_{3'}\) | Square versus \(4\mu\) |
|---|---:|---:|---:|---:|
| \(A_6\) | 6 | 4 | 4 | \(16\leq24\) |
| \(L_2(27)\) | 28 | 6 | 2 | \(4\leq112\) |
| \(L_3(4)\) | 21 | 12 | 4 | \(16\leq84\) |
| \(L_3(16)\) | 273 | 24 | 8 | \(64\leq1092\) |

Consequently

\[
 |\operatorname{Out}(S)|_{3'}\leq2\sqrt\mu
\]

holds for every nonabelian finite simple group. This is the repaired lemma now inserted by root. I checked that the proof's classification branches cover alternating and sporadic groups, the Tits group, the linear groups of degree two, higher linear groups, unitary groups, the triality family, and the remaining Lie families. The higher linear calculation leaves precisely \((d,q)=(3,4),(3,16)\); the degree-two calculation leaves \(q=27\); \(A_6\) is dealt with separately. The repair uses this final assertion and its four checks, not the false preceding assertion.

### 2.3 Why the prime-to-three order is enough

The chapter defines the multiplicative composition profile \(J_3\), and proves

\[
 J_3(X)\leq |X|_{3'}.
\]

Each successive kernel in an actual subgroup of the outer base embeds in a subgroup of \(\operatorname{Out}(S)\). Its profile is therefore at most its own prime-to-three order, and hence at most \(|\operatorname{Out}(S)|_{3'}\). The quotient acting on the simple factors is paid by the independent permutation-profile estimate. Thus both `aff:binary-simple-factor` and `aff:coarse-nonabelian-cost` need only the repaired prime-to-three bound. No monotonicity of ordinary class number on arbitrary subgroups is being used here.

The local patch is mathematically sufficient. Moving its statement outside the proof of `aff:binary-profile` is an organizational correction.

## 3. Affine chapter and two-cycle checks

### 3.1 The new scalar-average estimate

I checked the denominator, the projective packets, and the three-variable symmetry in the new scalar-average calculation. For a scalar subgroup of order \(z\), the average over a scalar multiple of the second member of a commuting pair is

\[
 \frac1z\sum_{\mu}q^{\dim C_W(\mu y)-D}
 \leq\frac{q^{\dim W-D}+(z-1)q^{-D}}{z}.
\]

Summing over the scalar lifts of the first member gives the stated per-projective-class bound

\[
 \frac{q^{-\sigma}}{z|B|_p}
 +\frac{2q^{-D/2}}{z|B|_p}
 +\frac{zq^{-D}}{|B|_p}.
\]

Potential fusion among scalar lifts only creates an overcount. Centralizers of scalar multiples agree. The maps interchanging the two members, and replacing one by their product, preserve the commuting-pair set and the common fixed space. The final union bound therefore gives exactly the coefficients 3, 6, 3; I found no lost factor of \(z\) or \(|B|_p\).

### 3.2 The p-solvable and two-cycle dictionary

The p-solvable affine reduction uses the action on \(V/(u-1)V\), removes an actual normal p-kernel, and passes to a Hall p'-subgroup on the same class/label pairs. The Hall subgroup meets the required pair orbits by Hall conjugacy in the actual stabilizers. This is compatible with the independent coprime affine theorem.

The use of `cap:mixed-two-cycle` supplies complete p'-probe bounds, not just one untwisted orbit count. The whole scalar correction and actual return are retained in the groupoid central cover. In particular:

- Removing a p-primary scalar sector compares its orbitwise isotypic dimension with the trivial p-sector, while retaining the same residual character and return.
- Replacing the return by its p'-part preserves the two-cycle because p is odd.
- The unique p-power lift of a p-element through a central p'-cover makes the section decomposition compatible with transporters.
- The Hall-coset comparison is applied in the actual centralizer extension, which is p-solvable.
- A fixed-label summand has a complete p'-probe bound because every whole corrected probe is a summand of the corresponding probe of the original category.
- The number of p-element conjugacy classes is at most the order of a Sylow p-subgroup.

I also read the full ordinary two-cycle proof. The radical construction uses the full additive tensor image and its actual module natural transformations; the targets are coinduced rather than incorrectly quotiented. The induced probe is over the full inverse image of its stabilizer and keeps one whole cochain. The return transports the actual axis data after a single gauge. The final positive hom-matrix argument then gives \(m(F+1-m)\). I did not find a new counterexample to this chain. This is an audit of the displayed proof, not a formal verification of all fusion-category foundations.

### 3.3 Other sensitive affine steps

The following were checked during the sequential reading:

- Semisimplification retains the p-kernel cost and bounds its lifts; it does not silently identify the original module with its semisimplification.
- The large fixed-space tensor argument uses scalar commutators only after proving that the dominant intersection is nonzero.
- Tensor cycles are counted by actual tensor-word orbits, including p-divisible cycle lengths.
- The signed-code argument distinguishes puncture and shortening and does not assume monotonicity of a coinvariant rank under deletion.
- The four-group module calculation uses the seven ideals of the actual group algebra.
- The eight-coordinate first-order Reed–Muller calculation gives the pair multiplicities 1, 42, 168, 45 and the final ratio \(80/81\).
- The \(\operatorname{AGL}_1(5)\) exception uses the actual cyclic-module quotient and the degree-at-most-one fixed kernel, not a uniform norm-distribution assumption.
- The primitive and imprimitive profile arguments use actual successive kernels.

Several classification tables and published character-degree estimates are external inputs. Reading their application in this chapter does not replace independently proving those external classification results.

## 4. Classical root and Clifford arguments

### 4.1 Principal root and central quotients

For \(D\in\operatorname{Syl}_p(U)\), \(Z(D)\) is a Sylow p-subgroup of \(C_U(D)\): any larger p-subgroup would commute with D and enlarge it. Thus \(DC_U(D)/D\) has p'-order, and the principal canonical root is the trivial character. Its trivial extension has trivial pairing with every root stabilizer. Murai's criterion therefore removes every operator centralizing D.

This argument is reapplied inside each actual central quotient \(U/Z\). It does not assert that centralizers commute with taking that quotient. That is the correct repair of the earlier determinant-torus problem.

I read Murai13, §3, including the definitions before Lemma 3.12, Theorem 3.13, Corollary 3.14, and the integral-inner equivalence in Lemma 2.1. The dictionary in `cl:root-pairing` matches the normal subgroup, root, centralizer, stabilizer, and canonical character in that source. Its integral conclusion is genuinely the one supplied there.

### 4.2 Independent-coordinate source lemma

The argument proving that the scalar base is characteristic uses an independent permutation module. A moved p-cycle has Jordan length at least p, whereas the hypothetical abelian normal subgroup would force \((\sigma-1)^2=0\). This argument is valid for the independent-coordinate sources to which the lemma is now restricted. It is not valid for the determinant-one torus after a central p-quotient; the new principal-root lemma deals with that case separately.

The actual maximal-pair transfer retains the same centralizer algebra and root, rather than substituting a perfect isometry. The averaging of the derivation on \(Q/A\), zero on its Sylow p-subgroup, gives \(\delta(u)=a-u(a)\) with \(a\in C_A(D)\). I checked the coset independence and the sign of this equation.

### 4.3 The two abstract Clifford lemmas

For `cl:Clifford-gluing`, extension of the constituent and the abelian quotient make the relevant Clifford correspondent restrict irreducibly. The two intertwining representations therefore differ by scalars on that constituent, which is enough to glue the genuine representations. The induced extension has the required irreducible restriction. The proof uses no assertion that an arbitrary projective extension is already genuine.

For `cl:toral-transfer`, I checked both cases of the index-at-most-two central extension. In the extension case, the irreducible restriction to \(C_0\) makes the two intertwining operators agree up to scalar. In the induction case, C fixes the toral character and the two core constituents are distinct; since \(N_1\) centralizes the core, its stabilizer is exactly the toral stabilizer. The actual transversal factorization gives \(\widehat N_\tau=CH_\theta\). The final \(\tau\)-isotypic subspace has multiplicity one and yields a genuine representation of \(\widehat N_\tau\).

Both lemmas are valid as abstract finite-group statements on their displayed hypotheses. They do not supply the actual mixed type-D hypotheses automatically.

## 5. Central quotient note and minor scope corrections

The note's group is

\[
 A=(\mathbb Z/3^a)^2/\langle(3^{a-1},3^{a-1})\rangle,
 \qquad D=A\rtimes C_3,
\]

with \(|D|=3^{2a}\). For \(a=1\), the permutation becomes trivial modulo the diagonal centre, so \(D\cong C_3^2\), and the old torus subgroup is not characteristic. For \(a\geq2\), reduction modulo 3 leaves the matrix

\[
 \sigma=\begin{pmatrix}2&2\\1&0\end{pmatrix},\qquad
 \sigma-I=\begin{pmatrix}1&2\\1&2\end{pmatrix},
\]

whose square is zero but which is nonzero. This establishes the precise failure of the independent-coordinate Jordan argument after quotienting. It is not restricted to the defect-81 example. The note correctly refrains from claiming failure of characteristicity for all \(a\geq2\), or a counterexample to Brauer's conjecture.

Minor points:

- `cl:central-quotient` begins with unrestricted \(\operatorname{SL}_n^\epsilon(q)\), but invokes perfection. The intended ordinary quasisimple scope should be stated explicitly, or the small nonperfect groups separated. The main application already lies in that scope.
- If the central-quotient note is distributed as a standalone document, state its commutator convention when the first explicit commutator is used.
- The new outer-order lemma initially stood inside the proof of the binary-profile lemma. Root has corrected its placement, and I checked the correction.

## 6. Proposed complete repair of the mixed toral interface

This section gives a new proof of the two missing inputs in `cl:toral-pending`. Its substantive extra point is the argument in §6.5: outer conjugacy transports the required splitting condition, while a separate theorem supplies genuine extension in the exceptional rational configuration. One must not conflate those two facts.

### 6.1 Actual groups and the claim

Use the actual rational groups of CS25, Notation 5.1 and Table 5.1, with total rank at least five. Relabel its two factors so that \(K_1\) is active and \(K_2\) is residual; the active factor need not be the factor called \(G_1\) in CS25. Let \(d\in\{1,2\}\), and let S be the selected active Sylow d-torus. Its active centralizer is a maximal torus. Put

\[
 C_1=C_{K_1}(S),\quad N_1=N_{K_1}(S),\quad
 C=C_{M^\circ}(S),\quad N^\circ=N_{M^\circ}(S),
\]

\[
 \widehat M=ME(M),\quad
 \widehat N=N_{\widehat M}(S),\quad
 H=N_{M_0E(M^\circ)}(S),\quad C_0=C_1K_2.
\]

Here \(M_0=K_1K_2\), \(M^\circ=(\mathbf K_1\mathbf K_2)^F\), and \(E(M^\circ)=E(M)\langle n,h_0\rangle\), exactly as in CS25. Neither \(h_0\) nor the rational joining element is divided out.

**Claim.** There is an H-equivariant extension map \(\Lambda_1\) for \(C_1\lhd N_1\) such that, for every \(\lambda\in\operatorname{Irr}(C_1)\), every compatible residual representative \(\varphi_2\) in an H-stable diagonal transversal, and

\[
 \Phi=\left(\operatorname{Ind}_{(N_1)_\lambda}^{N_1}
                 \Lambda_1(\lambda)\right).\varphi_2,
\]

every \(\psi\in\operatorname{Irr}(N^\circ\mid\Phi)\) extends to its actual stabilizer \(\widehat N_\psi\).

The claim includes active rank three. In that rank the active groups are \(\operatorname{SL}_4(q)\) at d=1 and \(\operatorname{SU}_4(q)\) at d=2. No lower active rank occurs in the nonabelian toral case under audit.

### 6.2 An ordinary toral map and its induced characters

Temporarily write \(G=K_1\), \(T=C_1\), and \(N=N_1\). Let \(\widetilde G\) be a regular embedding, let \(E_0\) be the standard field–graph group needed on this factor, and put

\[
 \widetilde N=N_{\widetilde G}(S),\qquad
 \widehat N_0=N_{GE_0}(S).
\]

For active type D of rank at least four, MS16, Corollary 3.13, supplies an \(\widehat N_0\)-equivariant extension map \(\Lambda_0\) such that \(\Lambda_0(\lambda)\) has a genuine linear extension to \((\widehat N_0)_\lambda\). The source constructs this first in its \(vF\)-model; its extension kills the actual central closing element \(v\widehat F\), and Proposition 3.4 transports it to the finite groups just written. Thus this is an assertion about the actual finite field–graph group, not just its action modulo inner automorphisms. At active rank four one may restrict the full triality group in MS16 to the graph subgroup induced by the ambient rank-at-least-five group.

For active rank three the identical assertion is CS13, Proposition 5.9, transported by its Proposition 5.3. The character of the torus is linear, so its extension here is linear.

For clarity, the trivial-centre case excluded during the difficult part of MS16 §3 has an elementary direct proof. When q is even, the Tits group V has \(V\cap\mathbf T=1\) and maps isomorphically onto the Weyl group. In the standard \(vF\)-model,

\[
 N=T\rtimes V^{vF}.
\]

The standard field–graph operators preserve the complement. Define \(\Lambda_0(\lambda)(tu)=\lambda(t)\) on \(T\rtimes(V^{vF})_\lambda\). The same formula on the full stabilizer in \(T\rtimes(V^{vF}\rtimes E)_\lambda\) is a genuine extension. It kills \(v\widehat F\), which lies in the complement, and hence descends and transports as above. This also proves equivariance. The rational decomposition follows directly from the isomorphism \(V\to W\): a fixed Weyl element has its unique fixed lift in V.

Set

\[
 \chi_\lambda=
 \operatorname{Ind}_{N_\lambda}^{N}\Lambda_0(\lambda).
\]

It is irreducible by Clifford theory. Equivariance gives

\[
 (\widehat N_0)_{\chi_\lambda}
       =N(\widehat N_0)_\lambda.
\]

Inducing the genuine linear extension of \(\Lambda_0(\lambda)\) from \((\widehat N_0)_\lambda\) to this group gives a genuine extension of \(\chi_\lambda\): its restriction to N is \(\chi_\lambda\), by the one-double-coset restriction formula. This argument explicitly identifies the required constituent; no choice of another member of its diagonal orbit is needed.

### 6.3 The induced character already has the required splitting property

Let \(\widetilde T=C_{\widetilde G}(S)\). Then \(\widetilde N=N\widetilde T\), and \(\widetilde T\) centralizes T. For \(t\in\widetilde T\), the two linear extensions of \(\lambda\) satisfy

\[
 \Lambda_0(\lambda)^t=\Lambda_0(\lambda)\nu_t,
 \qquad \nu_t\in\operatorname{Lin}(N_\lambda/T).
\]

Suppose \(th\) fixes \(\chi_\lambda\), where \(h\in\widehat N_0\). The constituents on T show that \(\lambda^h\) is N-conjugate to \(\lambda\). Multiply h on the right by an element of N to arrange \(\lambda^h=\lambda\); this does not change whether the character of N is fixed. Equivariance gives \(\Lambda_0(\lambda)^h=\Lambda_0(\lambda)\). The equality of the induced characters and uniqueness of the Clifford correspondent over \(\lambda\) give

\[
 \Lambda_0(\lambda)\nu_t^h=\Lambda_0(\lambda).
\]

Since \(\Lambda_0(\lambda)\) is linear, \(\nu_t=1\). Thus t and h each fix \(\chi_\lambda\). It follows that

\[
 (\widetilde N\widehat N_0)_{\chi_\lambda}
    =\widetilde N_{\chi_\lambda}(\widehat N_0)_{\chi_\lambda}.
\tag{6.1}
\]

This is the eta-equals-one specialization behind MS16, Theorem 3.18, and CS13, Proposition 5.13, with its elementary proof written out. In particular, it holds for every toral \(\lambda\), irrespective of the p-part of \(|N:N_\lambda|\).

### 6.4 Use the all-character correspondence, not only a p'-degree correspondence

Conditions A(d) and B(d) for active type D at d=1,2 are recorded in CS25, Remark 2.22. At active rank three, A(d) follows from CS13, Theorem 5.1/Proposition 5.13; its Corollary 5.14 supplies the equivariant regular-embedding torus extension map required for B(d). The other maximal-extendibility part of B(d) follows from the cyclic quotient \(\widetilde N/N\).

Therefore CS25, Proposition 4.14, applies. Its statement allows every d≥1 and every type in its §2.C. Its proof for a regular d is the case needed here, since \(C_{\mathbf K_1}(S)\) is a torus. It provides an all-character, \(\operatorname{Aut}(G)_S\)-equivariant bijection

\[
 \Omega:\mathcal G_d(G)\longrightarrow\operatorname{Irr}(N)
\]

with the central character-triple relation. Put \(\phi_\lambda=\Omega^{-1}(\chi_\lambda)\).

The splitting (6.1) transfers to the standard global splitting

\[
 (\widetilde GE_0)_{\phi_\lambda}
        =\widetilde G_{\phi_\lambda}(E_0)_{\phi_\lambda}.
\tag{6.2}
\]

Indeed every element of the global stabilizer can be multiplied by an element of G so that it normalizes S, since the Sylow d-tori of G are G-conjugate. Such multiplication leaves \(\phi_\lambda\) fixed. Equivariance of \(\Omega\) then identifies its stabilizer with the local stabilizer in (6.1). Finally \((GE_0)_{\phi_\lambda}=G(E_0)_{\phi_\lambda}\), since G fixes its irreducible characters.

The genuine local extension from §6.2 and the central character-triple relation imply genuine extension of \(\phi_\lambda\) to \(G(E_0)_{\phi_\lambda}\). This is the extension equivalence of CS25, Lemma 2.6(b), applied after restriction to this actual overgroup. Equality of factor sets is what transports the extension; equality merely of outer actions would not suffice.

Thus \(\phi_\lambda\) lies in the good set for the standard field–graph group. Its central character equals that of \(\chi_\lambda\), and hence that of \(\lambda\), on \(Z(G)\), in particular on \(h_0\).

### 6.5 Match the actual mixed actor, including its exceptional rational configuration

Let \(E^M(G)\) denote the group of automorphisms of the active factor induced by \(E(M^\circ)\), as in CS25, Definition 5.24.

In the ordinary configuration, CS25, Lemma 5.14, identifies this group with the standard field–graph group in \(\operatorname{Aut}(G)\). The map \(\Lambda_0\) is consequently H-equivariant and its inverse images \(\phi_\lambda\) lie in the actual good set \(\mathcal T_1\).

In the exceptional configuration of Hypothesis 5.15, the factor called \(G_2\) in CS25 still has the standard group, by Lemma 5.19. If that factor is active, again nothing must be changed. On the factor called \(G_1\), Lemma 5.19 says that the two field–graph subgroups are conjugate in the outer automorphism group by the specified diagonal class. Choose a representative \(a\in\widetilde N\) of that class. Such a representative exists: start with a diagonal representative in \(\widetilde G\), and multiply it by an element of G to make it normalize S. Define

\[
 \Lambda_1(\lambda)
       =\Lambda_0(\lambda^{a^{-1}})^a.
\tag{6.3}
\]

This is an actual extension on \(N_\lambda\). It has the prescribed value on \(h_0\), since diagonal automorphisms fix the centre. To check H-equivariance, take the inverse image of each field–graph subgroup after adjoining \(\operatorname{Inn}(G)\). Outer conjugacy gives an equality of these two subgroups of \(\operatorname{Aut}(G)\) after conjugation by a. Every member that normalizes S is represented on the standard side by an element of \(N_{GE_0}(S)\). The equivariance of \(\Lambda_0\), followed by (6.3), proves H-equivariance. This assertion concerns actual actions on \(T\lhd N\); elements in the action kernel act trivially on the characters and cause no ambiguity.

By equivariance of \(\Omega\), the inverse image of the induced character of (6.3) is the a-conjugate of the corresponding \(\phi_\lambda\). Equation (6.2), viewed on irreducible characters, depends only on outer actions, so it transports to the actual mixed splitting condition.

It remains essential to check the extension part of membership in \(\mathcal T_1\). It does **not** follow just from outer conjugacy. Hypothesis 5.15 forces the field exponent f to be odd, by CS25, Remark 5.16. CS25, Proposition 5.25(e), then gives

\[
 \mathcal E_1=\mathcal E_2=\varnothing
\]

for the actual groups of Definition 5.24. By that definition, \(\mathcal E_i\) is exactly the set of characters satisfying the splitting condition but failing the required genuine extension. Hence the character with the transported splitting condition does belong to the actual \(\mathcal T_1\). This separate empty-obstruction-set theorem is the missing justification that outer conjugacy alone cannot supply.

We have proved, in all configurations and all active ranks under consideration, that one H-equivariant extension map satisfies

\[
 \Omega^{-1}\!\left(
      \operatorname{Ind}_{(N_1)_\lambda}^{N_1}\Lambda_1(\lambda)
              \right)\in\mathcal T_1
 \quad\text{for every }\lambda\in\operatorname{Irr}(C_1).
\tag{6.4}
\]

### 6.6 Genuine extension in the actual mixed carrier

Choose the residual representatives \(\varphi_2\) in an \(E^M(K_2)\)-stable diagonal transversal contained in \(\mathcal T_2\), using CS25, Proposition 5.25(a) and its splitting property. Such a transversal can be obtained orbit by orbit: the splitting property means that the external stabilizer of a diagonal orbit already fixes a representative. It is H-stable because \(N_1\) centralizes \(K_2\).

Write \(\chi_1=\operatorname{Ind}\Lambda_1(\lambda)\) and \(\varphi_1=\Omega^{-1}(\chi_1)\). The equality of central characters in §6.4 makes \(\varphi_1.\varphi_2\) a well-defined character of \(K_1K_2\), with the original common value at \(h_0\).

The character-triple argument used to establish CS25, Proposition 6.3(b,c), now applies from its proof, with the all-character input from §6.4. Here are the needed group hypotheses, which do not use d≥3:

- \(K_1\) is normal in the actual group \(\mathcal A=\widetilde M E(M)\), by CS25, Lemmas 5.6(d) and 5.7(c).
- \(C_{\mathcal A}(K_1)\leq N_{\mathcal A}(S)\). In this setup the finite automorphism group of \(K_1\) acts on its F-stable tori, as explained before CS25, Notation 6.2. The kernel of the action of \(\mathcal A\) on \(K_1\) therefore stabilizes S. This is setwise normalization of the algebraic torus; it is not the incorrect assertion that S is a subgroup of the finite group \(K_1\).
- \(\mathcal A=K_1N_{\mathcal A}(S)\), by conjugacy of the Sylow d-tori of \(K_1\).
- For each corresponding pair \((\varphi_1,\chi_1)\), the two projective representations have the same factor set on the local stabilizer and the same scalar on its centralizer, including \(h_0\).

Apply the central character-triple transfer to \(J=M^\circ\). It gives a bijection

\[
 \Pi:\operatorname{Irr}(M^\circ\mid\mathcal G_d(K_1))
         \longrightarrow\operatorname{Irr}(N^\circ)
\]

which has the following two concrete properties:

\[
 \Pi\bigl(\operatorname{Irr}(M^\circ\mid
                 \varphi_1.\varphi_2)\bigr)
   =\operatorname{Irr}(N^\circ\mid\chi_1.\varphi_2),
\tag{6.5}
\]

and genuine extension of a character on the left to its stabilizer in \(\widehat M\) is equivalent to genuine extension of its image to its stabilizer in \(\widehat N\).

These properties follow by the same Clifford construction as CS25, Proposition 6.3: on each inertia group, tensor the matching projective representation with the same inverse-factor-set projective representation of the common quotient, and induce. Equality of the factor sets identifies the extension obstructions. Equality of the scalar representations on the centralizer preserves the selected \(K_2\)-constituent and its value on \(h_0\). This explicitly states the additional data used beyond the Butterfly theorem itself. CS25's proof invokes its Theorem 2.8 and the ordinary character-triple lifting construction; the only d-dependent input is precisely the all-character correspondence already supplied in §6.4.

By (6.4), \(\varphi_1\in\mathcal T_1\), and by choice \(\varphi_2\in\mathcal T_2\). CS25, Proposition 5.30(b), therefore says that **every** character in \(\operatorname{Irr}(M^\circ\mid\varphi_1.\varphi_2)\) extends to its stabilizer in the actual group \(\widehat M=ME(M)\). This proposition belongs to §5 and has no assumption d≥3. Applying (6.5) proves the claim of §6.1 for every \(\psi\) above \(\Phi\).

In particular, the relations

\[
 (t_1t_2)^2=t_1^2t_2^2,\qquad
 [n,t_1\gamma]=h_0
\]

in the exceptional rational configuration are retained by Proposition 5.30(b) and the equality of factor sets. We do not replace \(\widehat M\) by a split abstract group or discard a faithful value at \(h_0\).

### 6.7 Check the remaining hypotheses of `cl:toral-transfer`

For computing the joining coset, choose \(u_1\) in the connected active torus \(C_{\mathbf K_1}(S)\) with Lang value \(h_0\); Lang's theorem on this torus permits that choice. The element \(u_1t_2\) represents the same coset of \(M_0\) in \(M^\circ\) as \(t_1t_2\), and centralizes S. This choice of a coset representative does not redefine the fixed elements used in \(E(M)\) or their commutator relations. Consequently

\[
 N^\circ=CN_1,\qquad C_1\leq Z(C),\qquad [C:C_1K_2]\leq2.
\]

The group identities in CS25, Lemmas 5.13(a) and 5.18(a), give \(M^\circ\cap M_0E(M^\circ)=M_0\). Taking the relevant centralizer/normalizers gives \(C\cap H=C_1K_2\) and \(\widehat N=CH\). The active and residual algebraic factors commute, so \([N_1,K_2]=1\). Normality of the factors and the definition of H give all remaining normality requirements.

Finally, if \(ch\) fixes the chosen residual representative with \(c\in C\) and \(h\in H\), then its c-image and h-image lie in the same diagonal orbit. The h-image lies in the chosen stable transversal. They are therefore the same representative, so c and h separately fix it. Thus

\[
 (CH)_{\varphi_2}=C_{\varphi_2}H_{\varphi_2}.
\]

All hypotheses of `cl:toral-transfer` are now supplied. That lemma gives the genuine extension of every selected \(\tau\) to \(\widehat N_\tau\), and restriction gives the invariant source-inertia extension used later in the chapter.

This finishes the proposed repair of the smallest outstanding classical interface. A fresh reviewer should specifically challenge §§6.4–6.6, including the use of the all-character correspondence and the actual \(\mathcal E_i=\varnothing\) conclusion, before the conditional main statement is changed.

## 7. The alternative factor-two route is not free

I did not prove that the remaining root-pairing image has order at most two. Such a claim cannot be inferred solely from the displayed commutator \(h_0\). Moreover a blanket extra factor two is not paid by the current uniform coefficients:

| Endpoint | Existing numerical situation | After a blanket extra factor two |
|---|---|---|
| \(p=s=3,c=2,w=3\) | \(K=23,\delta=81\), \(2K=46\) | \(4K=92>81\) |
| \(p=s=5,c=2,w=5\) | \(K=254,\delta=15625\), \(32K=8128\) | \(64K=16256>15625\) |
| \(p=s=7,c=6,w=7\) | \(K=12406,\delta=5764801\), \(64(p-1)K=4763904\) | \(128(p-1)K=9527808>5764801\) |

Special-case refinements could alter a particular endpoint, but the existing coarse proof does not justify the blanket payment. The repair in §6 instead supplies the original extension input without changing any coefficient budget.

## 8. Primary-source verification and independent check material

I independently opened the primary PDFs with Python/PyMuPDF and located the cited statements in the PDFs themselves, rather than only reading the preexisting text files. Their hashes are:

| Source PDF | Pages | SHA-256 |
|---|---:|---|
| CS25 | 68 | `9f95e88fb175cf3e82d2ab9e7cfa167cddb154ec8388d103f1a5c34e2543754e` |
| MS16 | 40 | `52f788543920f20e4f11323deb85995f346bba43ec05a8fffe417b6b5f80e68b` |
| CS13 | 39 | `536f7a8565b3b6faf81d90d5c684e53a1821069f5a7ae46fda3cda14c128e221` |
| GMP17, independently downloaded from arXiv | 44 | `19741f57241f1c274d05c1fee338bc35f1b9a10166bafc2078c48f6ceccd13eb` |

The PDF page checks located CS25 Remark 2.22 at p. 15, Proposition 4.14 at p. 36, Remark 5.16 at p. 43, Proposition 5.25 at p. 48, and Proposition 5.30 at p. 51; MS16 Corollary 3.13 at PDF p. 12 and Theorem 3.18 at p. 15; CS13 Proposition 5.9 at p. 18 and Corollary 5.14 at p. 22. The source statements and the relevant proofs were read in the accompanying primary text files, with the mathematical quantities checked against the actual PDF extraction. GMP17 was independently obtained from <https://arxiv.org/pdf/1603.00187> after the author server rejected a direct download; Python extraction of its p. 18 confirms both the false full-order sentence and the separately usable four-exception final assertion. The downloaded file is `revision_audits/primary/GMP17_fresh.pdf`.

The companion independent checker, `revision_audits/affine_classical_fresh_checks.py`, records the four outer-order exceptions, the three factor-two margins, the central quotient invariant factors, and the primary PDF anchors. Its output is `revision_audits/affine_classical_fresh_checks.json`; all assertions passed. It is supporting arithmetic and source-integrity material; it does not purport to machine-prove the representation-theoretic arguments.
