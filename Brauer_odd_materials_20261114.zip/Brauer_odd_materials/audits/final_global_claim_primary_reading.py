#!/usr/bin/env python3
"""Recompute source identity/reading receipts for the fresh global audit.

This checks PDF bytes, page extraction, and location of named results.
It does not mechanically verify their mathematical proofs.
No extracted third-party text is written to the output receipt.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import fitz


SOURCES = [
    {
        "filename": "Murai13.pdf",
        "url": "https://ir.library.osaka-u.ac.jp/repo/ouka/all/26820/ojm50_04_1007.pdf",
        "markers": ["Lemma 2.1.", "Theorem 3.5."],
    },
    {
        "filename": "AnEaton04_fresh_foundations.pdf",
        "url": "https://eprints.maths.manchester.ac.uk/51/1/pc09k1q7ac55wpyb.pdf",
        "markers": ["Theorem 3.1"],
    },
    {
        "filename": "LL20_global_fresh.pdf",
        "url": "https://arxiv.org/pdf/2004.10131v1",
        "markers": ["Theorem 1.1.", "Proposition 2.4", "Proposition 3.3.", "Proposition 3.4."],
    },
]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-dir", type=Path, default=Path(__file__).resolve().parent / "primary")
    parser.add_argument("--output", type=Path, default=Path(__file__).with_suffix(".json"))
    args = parser.parse_args()
    results = []
    for source in SOURCES:
        path = args.source_dir / source["filename"]
        data = path.read_bytes()
        with fitz.open(stream=data, filetype="pdf") as document:
            page_texts = [page.get_text() for page in document]
        marker_pages = {
            marker: [i + 1 for i, text in enumerate(page_texts) if marker in text]
            for marker in source["markers"]
        }
        if not all(marker_pages.values()):
            raise RuntimeError(f"A named source result was not extracted: {path.name}")
        results.append({
            "filename": path.name,
            "url": source["url"],
            "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest(),
            "page_count": len(page_texts),
            "extraction_sha256": hashlib.sha256("\f".join(page_texts).encode()).hexdigest(),
            "marker_pdf_pages": marker_pages,
        })
    receipt = {
        "scope": "Source identity and named-result extraction; not formal mathematical verification.",
        "pymupdf_version": fitz.VersionBind,
        "sources": results,
        "all_markers_found": True,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(f"PASS: {len(results)} source PDFs; named-result markers found.")


if __name__ == "__main__":
    main()
