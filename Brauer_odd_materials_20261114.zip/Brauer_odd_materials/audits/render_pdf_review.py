#!/usr/bin/env python3
"""Render every PDF page and contact sheets for visual document review."""
from pathlib import Path
import argparse
import hashlib
import json
import fitz


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pdf', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--receipt', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    doc = fitz.open(args.pdf)
    outside, blank, matches = [], [], {}
    colored = 0
    needles = ['Regular blocks and diagonal', 'An integral Morita criterion',
               'The final all-prime deduction', 'rank-three', 'References']
    for i, page in enumerate(doc):
        text = page.get_text()
        if len(text.strip()) < 15:
            blank.append(i+1)
        for needle in needles:
            if needle in text:
                matches.setdefault(needle, []).append(i+1)
        for block in page.get_text('dict')['blocks']:
            for line in block.get('lines', []):
                for span in line['spans']:
                    colored += span['color'] != 0
                    x0, y0, x1, y1 = span['bbox']
                    if (x0 < -0.5 or y0 < -0.5 or x1 > page.rect.width+0.5
                            or y1 > page.rect.height+0.5):
                        outside.append({'page': i+1, 'text': span['text'],
                                        'bbox': span['bbox']})
        page.get_pixmap(alpha=False).save(args.output/f'page_{i+1:03}.png')
    for offset in range(0, len(doc), 16):
        contact = fitz.open()
        cw, ch = 260, 382
        sheet = contact.new_page(width=4*cw, height=4*ch)
        for k, i in enumerate(range(offset, min(offset+16, len(doc)))):
            x, y = (k % 4)*cw, (k // 4)*ch
            sheet.draw_rect(fitz.Rect(x+2, y+2, x+cw-2, y+ch-2),
                            color=(.7, .7, .7), width=.5)
            sheet.insert_text((x+8, y+13), f'Page {i+1}', fontsize=9,
                              color=(.15, .3, .55))
            sheet.show_pdf_page(fitz.Rect(x+4, y+20, x+cw-4, y+ch-4), doc, i)
        sheet.get_pixmap(alpha=False).save(args.output/f'contact_{offset//16+1:02}.png')
        contact.close()
    logpath = args.pdf.with_suffix('.log')
    log = logpath.read_text(errors='replace') if logpath.exists() else ''
    warnings = [s for s in log.splitlines()
                if 'Warning' in s or 'Overfull' in s or 'undefined' in s]
    receipt = {'pdf': args.pdf.name,
               'pdf_sha256': hashlib.sha256(args.pdf.read_bytes()).hexdigest(),
               'pages': len(doc), 'page_size_points': list(doc[0].rect),
               'outside_page_text_spans': outside, 'blank_pages': blank,
               'colored_text_spans': colored, 'section_page_search': matches,
               'rendered_pages': len(doc), 'contact_sheets': (len(doc)+15)//16,
               'compile_warning_lines': warnings,
               'visual_review_status': 'Rendered; human/assistant visual inspection pending.'}
    args.receipt.parent.mkdir(parents=True, exist_ok=True)
    args.receipt.write_text(json.dumps(receipt, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps(receipt, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
