# Toral type D integrated TeX: fresh independent adversarial audit

审查员：`/root/toral_tex_final_independent`  
日期：2026-11-14  
工作目录：`/workspace/scratch/8a38714ad82e`  
任务范围：新 `toral_type_d_repair.tex` 全文；`odd_classical.tex` 的 `cl:toral-transfer`、`cl:toral-pending`、相邻 \(d\geq3\) 消费者；`odd_endpoints.tex` 的 classical toral source 接口。另查新 `ep:cyclic-outer-completion` 的 actual return、线性修正及 selected-block 接口。

## 1. 结论及严格范围

**最终冻结的 1335 行 toral 补证，在本文明确列出的 MS16、CS13、CS25 公共定理作为输入的意义下，本轮独立推导没有发现尚未闭合的数学步骤。可以把该补证接入已经核对的 `cl:toral-transfer` 接口。**

这项结论是在本轮发现并实际修复以下问题之后给出的：

1. rank-three 原稿用全 \(1\) 反对角矩阵 \(j\) 比较 pinned graph，数学上不正确；真正的 \(v_0\) 满足 \(v_0^2=-I_4=h_0\)。最终稿现在显式计算乘法缺陷，并给出 scalar correction；unitary 部分另外在实际循环惯性群里构造 genuine extension。
2. exceptional rational configuration 的条件原写为两个完整中心的阶为四，漏掉 rank-one residual torus。现改为 CS25 的 distinguished \(Z_i\)，并且把 source 负因子上的 \(t_-\) 与重编号后的 active \(t_1\) 区分。
3. η=1 引理补明了需要的群正规性；最终稿明确 Lang 运输的方向及 rank-three 的运输对象。

审查覆盖所有 ordinary toral \(\lambda\)，包括诱导特征标次数被所研究奇素数整除的情形；覆盖每个 \(\psi\in\operatorname{Irr}(N^\circ\mid\Phi)\)，以及 \(\lambda(h_0)=-1\) 的情形。覆盖的混合秩为总秩至少五、active rank \(m\geq4\)，或 \(m=3\) 且 residual rank 至少二。

**这不是整篇 odd-prime \(k(B)\) 论文的无条件通过证书。** 本轮没有重新审完全部 exceptional endpoints、integral foundation、全局归纳和最终主定理；公共输入也没有全部从零重证。主消费者尚需完成集成后，另作全链依赖审查。

## 2. 文件锁定、读取范围及原始来源

先顺序完整读初始 1139 行稿，之后顺序完整重读 1309 行修改稿，最后完整读取最终 1335 行冻结稿。没有把前一轮 audit 的 PASS 当作证明；旧报告仅 §15 用作待审项目清单。

| 文件/状态 | SHA256 |
|---|---|
| `brauer_odd_revision/toral_type_d_repair.tex`，最终 1335 行 | `cbdc921d1842e7bc2bdc9474478d8fadd252799f705aaae358e9c47054c5d036` |
| 同文件，完整读过的 1309 行修复稿 | `484b69f8805cd90e8f78d4f67a909258339ba0acdefa412809331c03e778e509` |
| 同文件，初读 1139 行稿 | `0bd4b89a83176379206338a0f68d1c79b86a476829e032ee8be6fcfbe45188bd` |
| `brauer_odd_revision/odd_classical.tex`，本轮消费者读取时 | `3924e3a44ebc8eebcc96c27b1acc7f6258461e5b752a8eb3925f4c007cdbc362` |
| `brauer_odd_revision/odd_endpoints.tex`，新 cyclic lemma 最后核对时 | `671ea8bb0d81a78ccd3cf136e7eb6743f0b0d94f7b41ac2ef11f5b192e46ba61` |
| `revision_audits/primary/MS16.txt` | `c6c5f3e6f2ad23667a71610733a95033daaae748f38f070172698e2d3fd49156` |
| `revision_audits/primary/CS13.txt` | `b228ff79b69e160a49bd898b9bbe87a5138a5287062e5ee8fd6a94cb417fcdc8` |
| `revision_audits/primary/CS25.txt` | `132179073b8f2002d95ef105037a17e71ec132c569bb3e43a422fcd425a2b142` |
| `revision_audits/primary/BR23.txt`，提供的来源指纹 | `4d1201728aecb3c2fbac861428c7a8673dd739aff6f54dd48b8a100b72e59f8e` |

实际核对的公共输入：

| 输入 | 实际核对的范围 |
|---|---|
| MS16 §2.C、Propositions 3.4/3.8/3.10、Lemma 3.12、Corollary 3.13 | \(D\subset B\) 及 toral cover 的原始比较。新稿只把有限 \(D_B\lhd V_B\) maximal extendibility 留作有限输入，其余这里重新推导。 |
| CS13 §3.1–3.2、Theorem 5.1、Propositions 5.3/5.5/5.9、Corollary 5.14 | rank-three signed-monomial construction、真正 pinned graph、Lang comparison、\(A(d),B(d)\) 范围。§3 的 local statements 本身没有排除 \(\mathrm{SU}_4(2)\) 等 exceptional-multiplier small groups。 |
| CS25 §2.C–2.E、Remark 2.22、Definition 4.13、Proposition 4.14、Corollary 4.12 | ordinary bijection、central triple、全 ordinary 的 part (a) 与带 degree gate 的 part (b) 区分。 |
| CS25 Notation 5.1、Lemmas 5.2–5.7、Definition 5.10、Lemmas 5.12–5.19 | 两因子实际群、\(t_i,n,h_0\) 返回关系、包括 rank-one residual 的适用范围。 |
| CS25 Definition 5.24、Propositions 5.25/5.30、Assumption 6.1、Proposition 6.3 | lifted actor good sets、stable transversal、实际 \(J\lhd\widehat M\) 扩张、\(d\geq3\) 接口；没有把 §6 的 \(d\geq3\) 假设偷偷删掉应用于 \(d=1,2\)。 |

BR23 没有成为新增 toral 证明的必要输入；没有因此认证 BR23 所有 source statements 或本文其他 type-B 分支。

## 3. 本轮发现的实质错误及修复证据

### 3.1 原 rank-three graph comparison 确实错误

设 \(j\) 为全 \(1\) 反对角矩阵，\(\gamma_0(g)=(g^{\mathsf T})^{-1}\)。在固定的中间 simple root 上有

\[
\operatorname{Int}(j)\gamma_0(I+uE_{32})=I-uE_{32}.
\]

所以它不是 CS13 §3.2 / pinned \(D_3=A_3\) graph involution。该符号不能以“约定不同”直接消除；固定 simple root 上的负号正是不同 involution 类型的区别。

真正的矩阵是 \( (v_0)_{k,5-k}=(-1)^{k+1}\)，其性质为

\[
v_0^2=z_0=-I_4,\qquad\gamma_0(v_0)=F_r(v_0)=v_0,
\qquad\gamma=\operatorname{Int}(v_0)\gamma_0.
\]

我既直接计算了四阶矩阵，也与 CS13 §3.2 的定义核对。最终稿 `tdr:A-pinned-return` 使用这一矩阵；`tdr:A-multiplication-defect` 和 `tdr:A-standard-representation` 保留并消除 genuine multiplication defect，详见 §7。

### 3.2 Distinguished \(Z_i\) 和 source/active 编号

CS25 Hypothesis 5.15 的条件为 “\( |Z_1|=|Z_2|=4\)”，其中

\[
Z_i=\langle h_0,\prod_{j\in I_i}h_{e_j}(\varpi)\rangle^F.
\]

CS25 Lemma 5.3 明确：rank one 时它不必等于整个 torus 中心。例如 active \(D_4^+(7)\) 与 residual \(D_1^-(7)\) 的总秩五情形，residual torus 阶为八，但 distinguished subgroup 阶为四，仍属于 exceptional configuration。初稿的完整中心条件会遗漏此例。

最终稿 `tdr:distinguished-centers` 修正了条件；`t_-` 始终指 source 负号因子上的 joining element，避免 \(d=1\) active 是 source \(G_2\) 时把它错当 active \(t_1\)。实际 \(n^2=h_0\)、\([n,t_-\gamma]=h_0\) 未变，适用 CS25 的 rank-one 边界。

## 4. Rational carrier identities

从 \(C_{\mathbf K_1\mathbf K_2}(\mathbf S)=\mathbf T_1\mathbf K_2\) 得到 \(C_1\leq Z(C)\)。乘积映射的核阶至多二，fixed-point exact sequence 给 \([C:C_1K_2]\leq2\)。

选 \(u_1\in\mathbf T_1\) 满足 \(u_1^{-1}F(u_1)=h_0\)，则 \(u_1t_2\in C\) 且 \((u_1t_2)(t_1t_2)^{-1}\in K_1\)，因此

\[
J=CK_1,\qquad N^\circ=CN_1.
\]

这里没有替换已规定的 \(t_i\) 或 \(n\)。由源文的 \(E(J)\cap J=\langle h_0\rangle\) 得

\[
C\cap H=C_1K_2=C_0,\qquad\widehat N=CH.
\]

其余正规性来自 \(K_i,J,M_0\lhd\widehat M\) 与 normalizer/centralizer 的交。`cl:toral-transfer` 所有群假设均得到实际验证。

## 5. \(D_m\subset B_m\) Tits construction

两 simply connected coroot lattices 同为偶坐标和格，故在相同 torus 上 \(D_B=D_0\)，且 \(V\lhd V_B\) 的指数二。有限 \(B\)-Tits maximal extendibility 给 \(V_B\)-equivariant map 后，可以限制到 \(V\)-inertia。

关键扭转 \(t=\prod_i h_{e_i}(\zeta)\)，\(\zeta\) 八次本原根。\(W(D_m)\) 只改变偶数个坐标符号，且

\[
h_{e_i}(\zeta^2)h_{e_j}(\zeta^2)
=h_{e_i+e_j}(-1)\in D_0.
\]

因此 \(t\) 正规化 \(V\)。还可直接消除 graph lift 的符号疑问：令 \(\varpi=\zeta^2\)，按稿中 Chevalley convention，

\[
b=n_{e_1}(1)h_{e_1}(\varpi)
=n_{e_1}(-\varpi)=h_0n_{e_1}(\varpi).
\]

这与 CS25 Lemma 2.23 的 pinned graph lift 只差 central \(h_0\)，故确实互换 \(n_1,n_2\)、固定其他 \(n_i\)。由 \(V_B^t\) 同时包含 \(V\) 和 \(b\)，最终 transport map 的 \(V\langle\gamma\rangle\)-equivariance 成立。这里在 rank four 只需要并只声称指定的 graph involution。

## 6. \(V^{vF_0}=V\)、cover kernel 和 Lang descent

canonical longest Tits representative 的 conjugation 是 braid-group opposition；在 \(D_m\) 中为 \(\gamma^{m\bmod2}\)。因此该作用与 \(F_0\) 的 graph part 相消，每个 Tits generator 被 \(vF_0\) 固定。Weyl action 为标量 \(+1\) 或 \(-1\)，故所有 Weyl elements 有固定 Tits lifts，得到 \(N=TV\)。

covering field generator 取阶 \(2ef\)，\(e=|v|\)。由于 \(v\widehat\kappa\) 的阶整除 \(2e\)，可以选 field linear character \(\epsilon\) 使

\[
\epsilon(\widehat F_r^f)=\rho_0(v\widehat\kappa)^{-1}.
\]

这杀掉的是 \(z=v\widehat F_0\)，不改变 λ 在 \(h_0\) 的值。该 \(z\) 还被所有 cover field/graph generators 固定，故在相关惯性群中为 central，诱导扩张亦杀掉它。

若 \(gF_0(g)^{-1}=v\)，且 \(a(v)=v\)，则 \(g^{-1}a(g)\in\mathbf K^{F_0}\)。这正是 field/graph transporter 与标准 operator 相差 **inner** 元而非任意 diagonal 元的理由。最终稿明确从 torus coordinates 经 \(\iota^{-1}\) 输回。cover kernel 为 \(\langle\widehat F_0\rangle\)，其 torus-side 像为 \(\langle z\rangle\)。这一步没有杀掉实际 carrier 中的 \(h_0,n,t_1t_2\)。

## 7. Rank three：全部返回关系的独立复算

### 7.1 Signed monomial fiber

\(D_0\) 的 character 可由 subset \(A\) 表示，且恰在 \(A,A^c\) 间有同一 restriction。块 determinant character 满足 \(\rho_{A^c}=\rho_A\delta\)。因 \(\delta|_V=1\)，在允许交换 \(A,A^c\) 的 inertia 上，原 restriction invariant，指数至多二的 cyclic extension 可用。这确实给出整个 \(V\)-equivariant map，而非逐个不协调的选择。

\(F_r,\gamma_0\) pointwise 固定 \(V\)，所以 common-extension formula 直接给所有 \(\lambda\) 的 cover extensions，并杀掉 \(\widehat F_1\)。even characteristic 是 \(D_0=1\) 的直接情形。

### 7.2 Split pinned graph：必须保留 \(-I_4\)

设已有 genuine \(R_\lambda\) 扩张 \(\psi_\lambda^*\) 到 \(N\rtimes(E_1)_{\psi_\lambda^*}\)，其中 \(E_1=\langle F_r,\gamma_0\rangle\cong C_f\times C_2\)。标准外群为 \(E^0=\langle F_r,\gamma\rangle\cong C_f\times C_2\)。两个群对 \(\operatorname{Irr}(N)\) 的作用对应，因为 \(v_0\in N\)。

对 \(x=(n,F_r^a\gamma^b)\) 定义

\[
\sigma(x)=(nv_0^b,F_r^a\gamma_0^b).
\]

逐项相乘得到

\[
\sigma(x)\sigma(y)=z_0^{bb'}\sigma(xy).
\]

这不是群同构；其缺陷正是稿中保留的 central return。因为 \(R_\lambda(z_0)=\lambda(z_0)I\)，选 \(c_\lambda^2=\lambda(z_0)^{-1}\) 后

\[
R_\lambda^0(x)=c_\lambda^bR_\lambda(\sigma(x))
\]

的乘法缺陷为 \((c_\lambda^2\lambda(z_0))^{bb'}=1\)。这在任意实际 stabilizer subgroup，包括 mixed field–graph subgroup 上都成立；没有使用 \(\lambda(h_0)=1\)。当 \(\lambda(h_0)=-1\) 时可取 \(c_\lambda=\pm i\)，原 \(h_0\) scalar 仍是 \(-1\)。

### 7.3 Unitary：运输 cover 与 actual cyclic group 分开

取 \(F_1=\gamma_0F_r^f\)，\(F=\operatorname{Int}(v_0)F_1\)，Lang 元满足 \(hF_1(h)^{-1}=v_0\)。直接计算

\[
F_1(h)=v_0^{-1}h,\quad F(h)=hv_0^{-1},\quad
F_1^2(h)=z_0h,\quad F_1^4(h)=h.
\]

所以 field cover 阶 \(4f\) 确实容纳 \(h\)。若只取 \(2f\) 并把 \(h\) 假定在同一有限群里，会丢掉 \(z_0\)；最终稿没有这样做。

设 \(a_r=hF_r(h)^{-1}\)，则

\[
F(a_r)=hv_0^{-1}(F_r(h)v_0^{-1})^{-1}=a_r.
\]

因此 transported field operator 与标准 field operator 的差是 \(K=\mathrm{SL}_4^F\) 内元素。graph operator 同理，且 \(\gamma_0=\operatorname{Int}(v_0^{-1})\gamma\)。整个 map、torus、normalizer 同时运输，operator groups 在 adjoining \(\operatorname{Inn}(K)\) 后相等。

cover 的返回关系是

\[
\theta(\widehat F_1)=z=v_0\widehat F_1,\qquad
z^2=z_0\widehat F_r^{2f}.
\]

杀掉 \(z\) 后给的是 \(\widehat F_r^{2f}=z_0^{-1}\)，不能误称标准 external semidirect product。最终稿明确保留此式，另在 actual standard group 中使用

\[
E^0=\langle F_r\rangle,\quad\gamma=F_r^{-f},\quad F_r^{2f}=1.
\]

所以 actual local inertia modulo \(N^\theta\) 为 cyclic。cyclic-extension lemma 将 intertwiner 归一化为 \(T^s=R(u^s)\)，使用真实 \(u^s\in N^\theta\)，故得到 genuine extension。这是正确的 actual-group 闭合，未把覆盖群商偷偷替换成标准群。

### 7.4 选定 map value 保持不变

从 \(\psi_\lambda^0\) 的 genuine extension 中取唯一的 λ-isotypic line。该 line 维数一，在 \((X^0)_\lambda\) 下稳定，其 \((N_1)_\lambda\)-character 恰为原选定 \(\Lambda^0(\lambda)\)。因此得到的是选定值本身的 full-inertia extension；不需要更换 fiber。

## 8. η=1 引理与 full ordinary Ω

若 \(tx\) 稳定 \(\psi_\lambda\)，其中 \(t\in\widetilde T\) centralizes \(T\)，则 \(\lambda^x\) 必与 \(\lambda\) \(N\)-共轭。map equivariance 随即使 \(x\) 本身稳定 \(\psi_\lambda\)，进而 \(t\) 也稳定它。这证明 separability，且完全不需要 \(p'\)-degree。

由 \(X_\psi=NX_\lambda\)，从 \(X_\lambda\) 诱导所选线性扩张，restriction 正好是 \(\psi_\lambda\)，因而是 genuine irreducible extension。

CS25 Proposition 4.14 的目标确实是全部 \(\operatorname{Irr}(N_1)\)，定义域为 Definition 4.13 的 \(\mathcal G_d\)。这里使用的 Ω 不是只在 ℓ′-degree characters 上定义的 McKay bijection。rank-three 的 \(A(d),B(d)\) 输入有 CS13 对应 local 定理和 regular-embedding cyclic quotient；本文没有把 universal-cover reduction 的 small-group 排除搬到 local theorem 上。

## 9. Butterfly 的显式 factor set 公式成立

采用 \(P(g)P(h)=\alpha(\bar g,\bar h)P(gh)\) 的 convention，并使 \(K\) 方向 ordinary。设 \(h_xh_y=n(x,y)h_{xy}\)、\(a_x=\kappa(h_x)\)。

对 \(c_n=(n^{-1},\operatorname{Int}(n))\) 有共同 scalar \(s(n)\)，因此

\[
P(1,\operatorname{Int}(n))=s(n)P(n,1).
\]

又因 \(a_xa_y=\operatorname{Int}(n(x,y))a_{xy}\)，

\[
P(1,a_x)P(1,a_y)=
\frac{\alpha(a_x,a_y)s(n(x,y))}
{\alpha(\operatorname{Int}(n(x,y)),a_{xy})}
P(n(x,y),1)P(1,a_{xy}).
\]

故 `tdr:carrier-factor-set` 中分母、scalar 及 actual return 的方向全部正确。与 \(P(k,1)\) 混乘只引入 ordinary conjugation，不再产生新 factor。

对 \(c\in C_A(K)\)，写 \(c=nh_x\)，则 \((n,a_x)\) 在 split carrier 中 centralizes \(K\)，从而 \(Q(c),Q'(c)\) 有同一 scalar。这保留整个 \(C_A(K)\)，而非只比较 outer images。相同 quotient factor set 的 coboundary criterion 给扩张等价。

## 10. Actual lifted actor、逐元素 separability、restriction kernel

不能仅从 image subgroup factorization 拉回 external semidirect-product factorization；最终稿没有采用该错误推理。

它先在真正的 \(\widetilde K_1\rtimes E^0\) 中使用 pair decomposition 的唯一性：若 \(d e\) 稳定 \(\chi\)，则 lift \(d\) 与 \(e\) 分别稳定 \(\chi\)。再 conjugate 整个 assertion by 同一 \(a\in D_{\mathbf S}\)。当 \(e'=i_0e_0\) 时，\(i_0\in\operatorname{Inn}(K_1)\) 固定所有 ordinary irreducible characters，因此得到 \(d,e'\) 逐元素分离。最后对 lifted pair 应用该结论，得到 Definition 5.24 所需的 actual factorization。

对扩张，限制映射

\[
K_1\rtimes(\mathcal E_1)_\chi\longrightarrow
K_1\rtimes(E'_1)_\chi
\]

的核恰为 \(\{1\}\times L_1\)。inflation 是 ordinary representation，且核与 embedded \(K_1\) 交为一，所以不会把 \(h_0\in K_1\) 的 scalar 改掉。

exceptional negative factor 上的 induced generators \(t_-\gamma,F_r^2\) commute，阶分别整除二及奇数 \(f\)；positive factor 同理为 γ 与阶整除 \(f\) 的 field generator。故相关 images 和 stabilizers cyclic，扩张可在该 actual image semidirect product 内进行。

最后 \(\rho(H)=N_{IE'_1}(\mathbf S)\)、kernel 为 \(C_H(K_1)\)。CS25 §2.C 及 Notation 6.2 前的 finite action on \(F\)-stable algebraic subgroups 保证此处 lifting；kernel pointwise 固定 \(N_1\)，因而在 extension-map values 上无作用。

## 11. Π：全部 ordinary、保留 \(K_2\)、每个 ψ

先 restrict split triple 到实际 \(\Gamma_{0,\chi_1}\)，再用 butterfly。其全 kernel \(C_A(K_1)\) 包含 \(K_2\)，所以 resulting central-triple scalar condition 对每个 \(k_2\in K_2\) 都成立。active triality 等不在 carrier 的 automorphism 不会被 adjoin。

给定 Clifford inertia \(L\)，每个 ordinary representation over \(\chi_1\) 可写成 \(P|_L\otimes Q\)，其中 \(Q\) 是 quotient 上 factor set \(\alpha^{-1}\) 的 projective representation。local side 用同一 \(Q\)。这是 ordinary Clifford correspondence 的全部 irreducibles，不带 degree filter。

同一 scalar cochain 决定共轭后的 \(Q\)，所以 Π equivariant；同一 quotient 和 factor set 决定 \(Q\) 是否延伸，所以对每个实际 \(J\leq U\leq A_\chi\) 有

\[
\chi\text{ extends to }U
\iff\Pi(\chi)\text{ extends to }N_U(\mathbf S).
\]

\(P(k_2),P'(k_2)\) 逐元素同 scalar，加上同一 \(Q\)，保留全部 \(K_2\)-constituents。两边 Clifford induction 可选同一 \(N^\circ\) transversal，因为 \(J=K_1N^\circ\)，因此得到 `tdr:Pi-residual` 的集合等式。

对任意指定 \(\psi\in\operatorname{Irr}(N^\circ\mid\psi_\lambda.\varphi_2)\)，其唯一 \(\chi=\Pi^{-1}(\psi)\) 在 \(\operatorname{Irr}(J\mid\chi_\lambda.\varphi_2)\)。CS25 Proposition 5.30(b) 对这个 χ 直接给 \(\widehat M_\chi\) 扩张，再经 Π 得 \(\widehat N_\psi\) 扩张。没有只选其中一个 ψ。

## 12. `cl:toral-transfer` 本身

两个 Clifford cases 均重新核对。

* 若 \(\tau|_{C_0}=\theta\)，令 \(V=(N_1)_\tau\)。τ 与 \(\sigma=(\Lambda_1(\lambda)|_V).\varphi_2\) 在 irreducible \(C_0\)-module 上一致，intertwiner ratio 为 scalar，所以矩阵可胶合为 \(CV\) 上扩张；同样的 multiplicity-one argument 给 \(H_\tau\)-invariance。
* 若 \(\tau=\operatorname{Ind}_{C_0}^C\theta\)，两个 \(C\)-conjugates 的 \(K_2\)-constituents 不同，而 \(N_1\) centralizes \(K_2\)，故 \((N_1)_\tau=(N_1)_\lambda\)。诱导 \(\Lambda_1(\lambda).\varphi_2\) 得 τ 的 invariant extension；residual separability 给 \(\widehat N_\tau=CH_\theta\)。

两种情形诱导至 \(N^\circ\) 后均 lying over Φ，故可用 “every ψ” 输入。最终扩张的 τ-isotypic space 维数恰为 \(\tau(1)\)，在 actual \(\widehat N_\tau\) 下稳定，从而得到所需 ordinary extension。

## 13. \(d\geq3\) 修复与主消费者状态

CS25 Corollary 4.12(a) 明确对每个 \(\lambda\in\operatorname{Irr}(C_1)\) 给 actual standard toral inertia 的 genuine extension。part (b) 另有 “\(\ell\nmid|N_1:(N_1)_\lambda|\)”，不能自动把全部 ordinary 的诱导 characters 放入 good set。

最终稿末段的正确替代链是

\[
4.12(a)\;\longrightarrow\;\eta=1\text{ lemma}
\;\longrightarrow\;4.14\text{ full ordinary }Ω
\;\longrightarrow\;\mathcal T_1
\;\longrightarrow\;\Pi,\;5.30(b).
\]

这条链的每一步已经在新文件中证明，且 rank/regularity gates 匹配已读消费者：nonabelian \(d\geq3\) active rank 至少十；abelian endpoint 对应使用处至少八。它不需要把 CS25 §6 的陈述用于 \(d=1,2\)。

本轮所读 `odd_classical.tex` 仍保留旧 \(d\geq3\) 叙述和 `cl:toral-pending`，`odd_endpoints.tex` 仍保留条件性入口。root 明确这是等待本轮审核的集成门，不是声明已经修好主稿。这些主消费者必须接入新链，不能保留旧 “Corollary 4.12 自动给全 ordinary good family” 的捷径。新的消费者版本不在上表哈希覆盖范围内。

## 14. 额外检查 `ep:cyclic-outer-completion`

在原有 \(C_U(S)=Z(U)\)、\(p\nmid|U:S|\)、\(D\) abelian/actual Brauer correspondent 的上下文下，此新短引理的专门步骤无额外阻断。

1. \(Z(S)=1\) 给 \(SZ=S\times Z\)，\(U/SZ\) cyclic 且 \(SZ/S\) central，故 \(Q=U/S\) abelian。equivariance 与 Frattini 识别 \(J/S\cong N_J(D)/N_S(D)\)。
2. \(g^m=sz\) 中 \(s\in N_S(D)\)、\(z\in Z\)。选择 scalar root 使 \(T_\chi^m=\rho_\chi(s)\nu(z)\)，global/local 两边分别得到 genuine extension，使用相同实际返回元和相同 ν，而非把 lift 假定为阶 \(m\)。
3. \(Z\leq I\) 且 \(p\nmid|Z|\)。中央 implementers 的适当 \(p'\)-次幂是有限 \(p'\)-scalar；block centre 为 local，有限 \(p'\)-torsion 的 lift 唯一，故 implementer 本身是 scalar。`ep:green-identity` 在 nonzero \(X\) 上给 \(u_z=v_z\)。
4. 因而 discrepancy δ 在 \(SZ/S\) 上 trivial。它下降到 cyclic group \(J/SZ\) 的 subgroup，并可延伸且仍在 \(SZ/S\) 上为一。局部 system 的线性修正不改变 factor set 或 central anchor。
5. 在 `ep:factor-completion` 与 `ep:same-label` 的已建立接口下，修正使同一 inverse-factor coefficient 的 \(K\)-label 完全相同，故匹配的是指定 upper block 与实际 Brauer-correspondent block。

这里读取了 `ep:inner-kernel`、`ep:strict-green`、`ep:same-label`、`ep:factor-completion` 的相关文字，以检查短引理输入输出；没有据此对这些较大 integral/Green 理论作新的一轮完整独立证明认证。

## 15. 最终 gate

| 项目 | 最终本轮结论 |
|---|---|
| \(D_m\subset B_m\) Tits conjugation、\(V^{vF}=V\)、cover kernel | 逐式成立，有限 \(B\)-Tits theorem 为明确外部输入 |
| rank-three signed monomial map | 成立，涵盖 \(A/A^c\) inertia |
| rank-three pinned graph | 原稿错误；最终稿已以 \(v_0^2=h_0\) 和显式 scalar correction 修复 |
| unitary Lang transport 与 actual finite extension | 成立；cover return 与标准 cyclic return 分开 |
| butterfly explicit factor set | 公式的分母、共同 scalar、actual return 均核对成立 |
| lifted actor kernel 与 separability | 逐元素证明充分，inflation 不改变 \(h_0\) |
| Π full ordinary、\(K_2\) preservation、every ψ | 成立，未使用 degree 限制 |
| mixed rank-one residual | 最终 distinguished \(Z_i\) 与 \(t_-\) 记号修复后包含 |
| `cl:toral-transfer` | 两种 Clifford cases 独立核对，无发现缺口 |
| \(d\geq3\) 替代链 | 新文件中的 part (a) 路线成立；旧主消费者待 root 集成 |
| 新 cyclic-outer short lemma | 专门 return/linear correction/selected-block 接口成立，依赖原 integral lemmas |
| 整篇 \(k(B)\) 无条件结论 | **不属于本轮认证范围；不可凭本报告直接改为无条件主定理。** |

本报告只锁定表中最终 toral 文件和当时读取的接口版本。后续任何集成改动、删除条件性假设或强化主定理，都需要对修改后的依赖链重新审查。
