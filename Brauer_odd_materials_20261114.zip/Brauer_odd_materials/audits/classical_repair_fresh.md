# Classical module: fresh reconstruction and remaining extension input

Author of this audit: `/root/classical_repair_fresh`  
Date: 2026-11-14  
Edited body file: `brauer_odd_revision/odd_classical.tex`

## 1. Verdict and scope

**This audit does not certify an unconditional proof of the odd-prime theorem.** The former type-A source argument has been replaced, and the local-to-global root dictionary and two Clifford-theoretic gluing arguments have been written out. A specific toral type-D extension input remains unproved in this reconstruction. It is displayed in `cl:toral-pending`; `cl:strong-bound` now explicitly assumes it in those cases. The old paragraph saying that Butterfly restriction automatically supplies the missing input has been deleted.

The next reviewer should attempt the input in Section 6 below, rather than regard the proposed substitution of references as a proof. In particular, a standard field–graph transversal on a spin factor is not by itself an extension on the actual mixed rational carrier.

I read the entire old `brauer_article/odd_classical.tex` and the entire report `revision_audits/affine_classical_v2.md` before editing. I also read the relevant primary statements and their proofs listed in Section 7. The all-level coefficient inequalities and the determinant/central-quotient estimates in the first part of the module were retained after reading; their numerical reruns were performed by the previous independent auditor. I have not rerun those numerical programs in this round and do not present that earlier computation as a new independent check. The global `cap:probe` theorem and the affine module are outside my assigned file.

## 2. Type A: the exact repair

### 2.1 Scope of the independent-coordinate argument

The source table now includes type A only when

\[
d_A=\operatorname{ord}_p(\kappa q)>1,
\qquad \kappa=1\text{ for linear groups},\quad
\kappa=-1\text{ for unitary groups}.
\]

Then (p\nmid q-\kappa), so the determinant map has (p')-image, the relevant central isogeny kernel has (p')-order, and the active cyclic (p)-coordinates survive independently. The statement that residual amalgamations are 2-primary is restricted to B, C and D; in type A only (p')-order is asserted.

The old argument involving a permutation cycle of length at least (p) on (A/pA) is now used only in these independent-coordinate rows. Its proof is explicit: an abelian normal subgroup containing a nontrivial permutation (\sigma) would give ((\sigma-1)^2A=0), whereas a moved (p^j)-cycle on an independent permutation module has minimal polynomial ((X-1)^{p^j}).

The determinant-one, central-(p) principal type-A situation is excluded from this argument entirely.

### 2.2 The old counterexamples are genuine scope failures

For (\operatorname{PSL}_3(7)) at (p=3), the old source (A=T_3/Z) is cyclic of order three, a three-cycle centralizes it in the quotient but does not lie in the torus, and the resulting defect group is (C_3^2). Thus both the asserted centralizer equality and the asserted characteristicity fail in that range.

For (q\equiv1\pmod3) with (s=(q-1)_3=3^a), (a\ge2), write the determinant-one torus as

\[
T_3=\{(x,y,-x-y):x,y\in\mathbb Z/s\mathbb Z\},
\qquad Z=\langle(s/3,s/3)\rangle.
\]

Here (Z\le3T_3), so (A/3A\cong\mathbb F_3^2) for (A=T_3/Z). The three-cycle acts by

\[
\sigma=\begin{pmatrix}-1&-1\\1&0\end{pmatrix},
\qquad
(\sigma-I)^2=0\ne\sigma-I\quad\text{over }\mathbb F_3.
\]

This is a length-two Jordan block, not a length-three block. The family is not confined to defect 81: (q=19,s=9) gives defect order 81; (q=109,s=27) gives defect order 729. This calculation refutes the old proof sentence; it does **not** assert that (A) is noncharacteristic for (q=19) or for all (a\ge2).

Root independently rebuilt the matrix check in `revision_audits/verify_type_a_scope.py`, with its result in `type_a_scope_result.json`. The earlier independent counterexample program is `brauer_article/revision_audits/affine_classical_source_scope_check.py`. The replacement proof does not depend on a finite list of checked values.

### 2.3 New principal-root lemma

`cl:principal-root` applies to an arbitrary finite group (U), its principal block, and (D\in\operatorname{Syl}_p(U)).

1. (Z(D)) is a Sylow subgroup of (C_U(D)), since a larger (p)-subgroup of the centralizer could be multiplied with (D).
2. (DC_U(D)/D\cong C_U(D)/Z(D)) has (p')-order.
3. The canonical principal root character is (1_{DC_U(D)}).
4. Its extension to (\langle x,DC_U(D)\rangle) is the trivial character for any operator (x) centralizing (D).
5. Every Murai pairing is one, so (x) acts integrally inner on the principal block algebra.

For a central quotient (U/Z), the argument is repeated in the quotient with its own centralizer and its own Sylow subgroup. No assertion that centralizers commute with a central-(p) quotient is used. This handles the (d_A=1) branch without the false torus characteristicity premise.

## 3. The source–root dictionary and genuine gluing

### 3.1 Source definitions

The previously undefined (\mathbf L_s^*) is replaced by a defined construction. The semisimple (p')-label is (s_0); the selected unipotent cuspidal datum in (C^\circ_{\mathbf G^*}(s_0)) is ((\mathbf M^*,\alpha)); and

\[
\mathbf L^*=C_{\mathbf G^*}\bigl(Z^\circ(\mathbf M^*)_{\Phi_d}\bigr).
\]

The text defines (d)-split Levi, (d)-cuspidality, the selected constituent (\lambda), the torus coordinates and the residual factor. The signs (\varepsilon_d=(-1)^{d+1}) and the type-A sign (\kappa) are distinct. The character (\rho\in\operatorname{dz}(K)), the abelianization map defining (K), and the full source inertia group (N=N_S(A,b_L)) are defined before use.

### 3.2 Murai's criterion

The new `cl:root-pairing` states the exact public criterion used from Murai. For a maximal pair ((D,e_D)) in a block (c) of (U), set

\[
C_0=C_U(D),\quad U_0=DC_0,\quad T=N_U(D,e_D).
\]

The canonical character (\theta) belongs to the covering block (e) of (U_0), and for an actual operator (x) centralizing (D), an extension (\widehat\theta) to (U_x=\langle x,U_0\rangle) defines

\[
\widehat\theta^{\,t}=\widehat\theta\nu_t,
\qquad \langle\!\langle t,x\rangle\!\rangle_\theta=\nu_t(x).
\]

The proof checks the cyclic extension, the trivial action of (T) on its cyclic quotient, and independence of the chosen extension. The dictionary into Murai's Theorem 3.13, Corollary 3.14 and Lemma 2.1 is stated explicitly.

### 3.3 The source-to-global transfer

`cl:source-root` now identifies literally, rather than up to an unnamed correspondence,

\[
C_N(D)=C_S(D),\quad DC_N(D)=DC_S(D),
\quad N_N(D,e_D)=N_S(D,e_D).
\]

Thus the root idempotent (e_D), its covering block (e), its canonical (\theta), the cyclic extension by (x), and every conjugation defining the pairing are the same for (N) and (S).

The proof also expands the matrix-order isomorphism, the characteristic-base argument in its corrected range, the normalizer argument for maximal pairs, the explicit averaging of a derivation vanishing on a Sylow subgroup, and the kernel/surjectivity calculation giving the full inertial quotient (N_W(P)/P). The integral lattice used in the matrix factor is the restriction of a lattice for the genuine cyclic extension, so the implementing matrix is integral.

### 3.4 `cl:Clifford-gluing`

The proof now uses the double inertia group. If (\theta_0\in\Irr(K_0)) is under (\theta\in\Irr(L)), let (\tau) be the Clifford correspondent on (L_{\theta_0}), and set

\[
V=M_\theta\cap M_{\theta_0},\qquad
J=N_\theta\cap N_{\theta_0}=L_{\theta_0}V.
\]

Uniqueness of the Clifford correspondent proves (\tau^v=\tau) for (v\in V). Only then is Schur's lemma used to identify the intertwiner with the matrix of the genuine extension (\sigma(v)). The proof checks the common intersection, multiplicativity of the product representation, the one-double-coset restriction, irreducibility, and external invariance. This replaces the invalid shortcut “the two matrices differ by a scalar” without first establishing (\tau)-invariance.

The endpoint author has an independent analogous lemma in their own file. This file does not cite that lemma, so no classical–endpoint circular dependency was introduced.

## 4. Paired sources and notation repairs

The paired Tits section now defines the pinning, (n_\beta(t)), (h_\beta(t)), the ambient type-B realization of type D, the Weyl projection, the coordinate orbits, the fourth root (\varpi), (h_0,h_j,c_j,p_j), the two permutation-system maps, and (c_i',p_i',V',C',P',H'). The source's recursive definition of (c_i') is used; the unsupported identity (c_i'=c_{2i-1}c_{2i}) for all (i) is not used.

The finite group (E), the regular embedding, (H=[\mathbf L,\mathbf L]^F), (K_0=HH'), (M=HV'), and the different full and selected normalizers are distinguished. A transversal and an equivariant extension map are defined. The field return

\[
F_r^f=\operatorname{Int}(v^{-1})\gamma_0^{-1}
\]

is retained. The faithful value at (h_0) remains part of the construction.

The rational-enlargement reference is correctly **Lemma** 3.19 of CS25, applied to its finite group (\check H_k=\{g:g^{-1}F(g)\in Z(\mathbf H_k)\}). It is not a theorem about an arbitrary unnamed regular enlargement. Rank-one residual tori are handled as central tori, not by this finite-spin-group definition. The extension to the regular Levi is then constructed through the product of the finite derived-factor enlargements and a finite central torus preimage, with a matching character on the central kernel.

The new paired proof is more explicit than the old text, but it should still receive fresh scrutiny, especially the independent-diagonal-transversal assertion and the central-product descent from the finite enlargements. I have not certified the entire module merely because its source statements now have precise labels.

For toral B, the undefined local symbols (\psi,\zeta,x,h,t,F) were removed. The text uses the actual extension-map assertion in CS19 Proposition 5.19, its group from (5.16.1), and BR23 Remark 9.11 for an arbitrary residual B-core. It does not attribute a stronger separate kernel statement to Proposition 5.19.

## 5. The independently proved toral-transfer lemma

`cl:toral-transfer` is a purely finite-group statement. Its hypotheses are written in the body, including

\[
C\lhd\widehat N=CH,\quad N^\circ=CN_1\lhd\widehat N,
\quad C_0=C_1K_2\lhd\widehat N,
\quad C_1\le Z(C),\quad [C:C_0]\le2,
\]

and the precise normalizations/intersections. The two nonformal inputs are an (H)-equivariant toral extension map and extension of the indicated characters of (N^\circ) to their actual inertia groups in (\widehat N).

Its proof treats both Clifford possibilities separately.

- If (\tau|_{C_0}=\lambda.\varphi_2), it glues the representation of (\tau) to the restriction of (\Lambda_1(\lambda).\varphi_2) over the double inertia group. This gives an invariant extension (\rho) of (\tau).
- If (\tau=\Ind_{C_0}^C(\lambda.\varphi_2)), it induces the genuine product character from ((N_1)_\lambda K_2). The diagonal-transversal factorization is used explicitly to prove (\widehat N_\tau=CH_{\lambda.\varphi_2}).

In each case (\psi=\Ind_{(N^\circ)_\tau}^{N^\circ}\rho) satisfies

\[
\widehat N_\psi=N^\circ\widehat N_\tau.
\]

An extension of (\psi) then has a (\widehat N_\tau)-stable (\tau)-isotypic subspace of dimension (\tau(1)). That subspace gives the desired genuine extension. No projective representation is silently promoted to a genuine one.

## 6. Exact remaining input for the next fresh reviewer

### 6.1 Groups and central returns

Let (\mathbf K_1,\mathbf K_2) be the active and residual commuting spin subgroups on the two orthogonal summands, intersecting in (\langle h_0\rangle). Rank one denotes the relevant torus. In the rational model of CS25 Section 5 put

\[
K_i=\mathbf K_i^F,\quad M_0=K_1K_2,\quad
M^\circ=(\mathbf K_1\mathbf K_2)^F=M_0\langle u\rangle,
\quad u=t_1t_2,
\]

where (t_i^{-1}F(t_i)=h_0). In particular

\[
u^2=t_1^2t_2^2\in M_0.
\]

Let (M=M^\circ\langle n\rangle), using the **actual** rational graph lift (n) of CS25 Table 5.1, and let (\widehat M=ME(M)), with (E(M)) from Definition 5.10. This fixes the central extension, rather than just its image in an outer automorphism group.

The pinned short-root lifts (n_1^\circ,n_2^\circ) satisfy ([n_1^\circ,n_2^\circ]=h_0). The table uses (n=n_1^\circ n_2^\circ), (t_1n_1^\circ n_2^\circ), (t_1t_2n_1^\circ n_2^\circ), or (t_jn_1^\circ n_2^\circ), according to the two signs and the orders of the indicated central 2-subgroups (Z_i=\langle h_{J_i}(\varpi),h_0\rangle^F). An attempted proof must retain that table's (n^2) and commutators, rather than impose (n^2=1) abstractly.

In the ordinary rational configuration, (E(M)=\langle F_r,\gamma\rangle). In the exceptional configuration (ambient sign minus and (|Z_1|=|Z_2|=4)), it is (\langle F_r^2,t_1\gamma\rangle). Here (f) is odd, (r\equiv3\pmod4), and CS25 Lemma 5.17 gives

\[
(t_1\gamma)^2=1,\quad [n,F_r^2]=1,\quad
[n,t_1\gamma]=h_0,
\]

with (E(M)) cyclic of order (2f). This is precisely why conjugating the image in (\Out(K_1)) is not an adequate substitute for a compatible construction on the actual group.

For the active (\Phi_d)-torus (\mathbf S_d), set

\[
\begin{aligned}
C_1&=C_{K_1}(\mathbf S_d),&N_1&=N_{K_1}(\mathbf S_d),\\
C&=C_{M^\circ}(\mathbf S_d),&N^\circ&=N_{M^\circ}(\mathbf S_d),\\
\widehat N&=N_{\widehat M}(\mathbf S_d),&
H&=N_{M_0E(M^\circ)}(\mathbf S_d).
\end{aligned}
\]

The source character is (\tau\in\Irr(C\mid\lambda.\varphi_2)), where (\lambda\in\Irr(C_1)), the residual representative (\varphi_2\in\mathcal T_2\subseteq\Irr(K_2)), and

\[
\lambda(h_0)\varphi_2(1)=\lambda(1)\varphi_2(h_0).
\]

The (H)-stable residual diagonal transversal provides ((CH)_{\varphi_2}=C_{\varphi_2}H_{\varphi_2}). The fresh reviewer should also explicitly check the group dictionary (C\cap H=C_0) in the actual rational model; it is part of the transfer lemma's hypotheses, not a consequence of its proof.

### 6.2 The smallest missing assertion

For the cases in the next subsection, construct an (H)-equivariant extension map (\Lambda_1) for (C_1\lhd N_1), compatible with the central value at (h_0), such that, for

\[
\Phi=\bigl(\Ind_{(N_1)_\lambda}^{N_1}\Lambda_1(\lambda)\bigr).\varphi_2,
\]

every (\psi\in\Irr(N^\circ\mid\Phi)) extends to (\widehat N_\psi). It is enough to prove this for the selected source characters, though the displayed formulation is the convenient all-character version used in CS25 Lemma 6.6.

Once this is proved, `cl:toral-transfer` supplies the entire remaining Clifford-theoretic passage to the source extension.

### 6.3 Exact parameter range and branches already separated

For nonabelian toral defect, the active rank is

\[
\ell_1=e\sum_iw_i,\qquad\text{some }w_i\ge p.
\]

| Parameters | Route recorded in the revised body |
|---|---|
| (d\ge3), nonempty residual core | (p\ge5,e\ge2,\ell_1\ge10). Active sign satisfies (d\mid2\ell_1) and (\varepsilon_1=(-1)^{2\ell_1/d}); CS25 Assumption 6.1 applies. Corollary 4.12, Proposition 6.3, Proposition 5.30(b), Lemma 6.6 and Proposition 6.7 give the required input. |
| (d\ge3), empty core | Direct doubly regular active-torus result, CS25 Corollary 4.12. |
| (d=1), split ambient D | Source is a rational parabolic Levi. Späth D-I Theorem 3.1 applies to its cuspidal source character; Hypothesis 2.14 is supplied by CS25 Theorem 3.16(a). |
| (d=1,2), empty core | Direct ambient Sylow-(d)-torus result, MS16 Corollary 3.13 and Theorem 3.18. |
| (d=1,2), active rank three, total rank four | The residual (D_1) must be a (p')-torus. Its order is (q+1) at (d=1), (q-1) at (d=2); both ambient groups are (D_4^-(q)). The active torus is an ambient Sylow-(d)-torus, so the same direct MS16 result applies. |
| **(d=1), twisted ambient D, nonempty core, total rank at least five** | **Remaining input above.** |
| **(d=2), nonempty core, total rank at least five** | **Remaining input above.** |

In the last two rows, the active rank is at least four except possibly (p=3,\ell_1=3,\ell_2\ge2). The latter active factor is (D_3^+(q)\cong\SL_4(q)) at (d=1), and (D_3^-(q)\cong\SU_4(q)) at (d=2). There is no unsupported rank padding or change of (q). The special (D_4^-) discussion does not claim that every proper source in rank four is a large-rank CS25 case.

The difficult faithful-(h_0) issue occurs in odd defining characteristic. I have not added a separate proof removing every even-(q) member from the displayed remaining range; the next reviewer may be able to do so by the direct-product simplification (h_0=1). This report keeps that distinction explicit instead of assuming it.

### 6.4 Candidate route, not a proved replacement

The active input at (d=1,2) is supplied in standard field–graph coordinates by MS16 Corollary 3.13 and Theorems 3.17–3.18; rank three uses CS13 Propositions 5.9 and 5.13. Theorem 3.17 is needed for both (d=1,2); MS16 Proposition 3.16 is stated only for (d=1).

CS25 Proposition 4.14 is an all-character central-triple statement for general (d\ge1), subject to its A(d), B(d) hypotheses. CS25 Proposition 5.30(b), on the actual carrier (M^\circ\lhd\widehat M), does not impose (d\ge3). The missing compatibility is to choose the active extension map so that the corresponding inverse images belong to the good transversal for the **actual** induced group (E^M(K_1)), simultaneously with the required (H)-equivariance and the common (h_0)-value.

A plausible strategy is to use the full family of induced linear extensions of toral characters, its diagonal/field/graph action, and the actual good transversal of CS25 Proposition 5.25. That strategy still requires a proof that one can make the choices equivariantly over the relevant toral characters and then apply the central-triple lifting with the rational returns intact. I did not write it into the body as a completed argument.

Späth D-II's standard (E(G))-stable transversal of all irreducible characters supplies a residual character input, but does not on its own establish this rational-carrier compatibility.

## 7. Primary sources read and exact citation corrections

The following primary PDFs and extracted text are in `revision_audits/primary` (D-I was read on the publisher's primary page).

| Source | Exact uses and scope |
|---|---|
| [Murai 2013](https://ir.library.osaka-u.ac.jp/repo/ouka/all/26820/ojm50_04_1007.pdf) | Lemma 2.1, Theorem 3.13, Corollary 3.14; canonical-root pairing and integral inner action. |
| [Enguehard 2013](https://arxiv.org/pdf/1312.0106v1) | Assumption 2.1.2, Propositions 2.1.4–2.1.7 and central-defect/source construction; ordinary classical odd-prime scope. |
| [Brough–Ruhstorfer 2023](https://arxiv.org/pdf/2307.14730v1) | Sections 7–8 Tits construction; Propositions 9.1–9.2; Lemmas 9.5–9.6; Propositions 9.7–9.8; Remark 9.11. The global theorem's prime restriction is not used to excuse a missing source proof. |
| [Cabanes–Späth 2025, v2](https://arxiv.org/pdf/2410.20392v2) | Theorem 3.16; **Lemma** 3.19; Corollary 4.12; Proposition 4.14; Section 5 actual carriers, especially Table 5.1, Definition 5.10, Lemma 5.17, Propositions 5.25 and 5.30; Assumption 6.1; Proposition 6.3; **Lemma** 6.6; Proposition 6.7. All numbering refers to v2, 1 May 2025. |
| [Cabanes–Späth 2019](https://arxiv.org/pdf/1903.11667v1) | Proposition 5.19 and its proof, with the groups defined in (5.16.1). |
| [Cabanes–Späth 2013](https://arxiv.org/pdf/1305.6407v1) | Propositions 5.9 and 5.13 for type-A torus extension and inertia factorization, including the defining return. |
| [Malle–Späth 2016](https://annals.math.princeton.edu/wp-content/uploads/annals-v184-n3-p06-p.pdf) | Corollary 3.13 and Theorems 3.17–3.18; the general (d=1,2) torus/normalizer constructions are public character-theoretic results. This is not a citation to any local (p=2) manuscript. |
| [Späth, D-I, 2023](https://www.cambridge.org/core/journals/nagoya-mathematical-journal/article/extensions-of-characters-in-type-d-and-the-inductive-mckay-condition-i/2D04AB92EB95E46C93682EBEC6829B48) | Theorem B, Theorem 3.1, Hypothesis 2.14; split ambient D and standard parabolic Levi. No twisted-ambient or (d=2) conclusion was silently added. Bibkey `cl:SpaethD23I` was added by root. |

## 8. Final text and compile checks

After modification I reread the source-definition, principal-root, source-root, double-stabilizer gluing, paired Tits, toral-transfer, and remaining-input portions in sequence. I corrected the superscript typo in the root pairing, the two obsolete source theorem numbers, a long Tits display, and a four-column `split` environment that needed `aligned`. The old type-A unrestricted table, the old unproved Butterfly paragraph, and the undefined toral-B local symbols are gone.

The standalone wrapper is `revision_audits/classical_compile.tex`. It includes the current shared preamble, this module, and the shared bibliography. The compile command is

```sh
TEXMF='{.,/usr/share/texlive/texmf-dist,/usr/share/texmf,/etc/texmf}' \
pdflatex -interaction=nonstopmode -halt-on-error \
  -output-directory=../revision_audits ../revision_audits/classical_compile.tex
```

Run from `brauer_odd_revision`, it compiled successfully twice and produced a 23-page diagnostic PDF. The second log contains no undefined control sequence, no undefined citation, and no overfull box. Its only undefined references are the intentionally external `cap:defect-zero` and `cap:probe`. This wrapper is a syntax/layout diagnostic, not the requested final paper or a certificate of the mathematics. Root should compile and visually inspect the complete document after integration.

**Frozen handoff:** the precise new source proofs and generic transfer lemma are in the body; the remaining mixed toral input is explicitly conditional. The complete odd-prime theorem must not be described as unconditionally proved on the strength of this audit.
