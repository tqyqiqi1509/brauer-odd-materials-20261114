# Final independent audit: prime-two isolation and external theorem scope

Date: 2026-11-14  
Reviewer: `/root/final_selfcontainment_fresh`  
Reviewed manuscript: `Brauer_kB_odd_primes_20261114.tex`  
Initial SHA-256: `bbd43d426c582f46e437a4a6e7c356938476a7fa305edda3f609b8da336c7f00`  
Final reviewed SHA-256: `00b072a50a96e7b45b7657c696688308c75e44c063dae0b2d8585fb9abe7492f`

## Conclusion and scope

I found **no new confirmed mathematical obstruction in the passages and external interfaces examined in this audit**. The prime-two paper is cited once in the body, in the final all-prime corollary. The odd-prime statement and its concluding proof have the same universal quantifiers: every odd prime, every finite group and every block. The endpoint's induction assumptions are explicitly supplied by the final minimal-counterexample argument; they are not additional hypotheses of the main theorem.

This is a focused independent audit, not a claim to have re-proved every statement in the entire manuscript. I independently read the title, abstract, introduction, notation, affine statement and induction convention, affine degree-budget proof, final affine induction, almost-simple endpoint statement and its complete exhaustion/closing proof, the final odd-prime reduction, and the final all-prime deduction. I also traced the lexical candidates listed below and compared nine primary PDFs at the specified theorem interfaces. I did not repeat the full type-D reconstruction, all exceptional carrier calculations, every finite certificate, or the external prime-two proof. Those are not claimed as freshly verified by this report.

The relevant meaning of self-containment here is independence from the user's other manuscripts and full presentation of the new odd-prime argument. The article does cite standard public block theory, classification and representation-theoretic results. It should not be described as a derivation of the classification of finite simple groups or of every cited theorem from axioms.

## 1. Prime-two isolation

The sole body citation of `TangPrimeTwo26` is in `main:theorem`, after the entire odd-prime proof. The bibliography entry is public and identifies the theorem used. The other prime-two mentions in the abstract and introduction describe the final deduction and provide no intermediate lemma or technique.

The odd-prime sections define their own factor sets, whole corrections, probe bounds, integral crossed products and selected sectors. The core reductions refer internally to these constructions rather than to a prime-two result. In particular:

- The weak affine result is stated and proved for odd characteristic in the article. Its coprime input is the published coprime `k(GV)` theorem, not the user's prime-two paper.
- The complete probe realization is an internal theorem. Its evaluation sector and central extension are developed in the article.
- The capacity theorem and the selected ordinary residue are internal arguments; the closing odd-prime proof points to their labels directly.
- The equal-defect branch invokes the internal almost-simple endpoint and proper-Levi constructions. It does not invoke the final all-prime corollary or its prime-two source.

A lexical scan of the complete body found no second prime-two citation and no external TeX `input` or `include`. This check proves the source-isolation property, not the correctness of every internal lemma.

## 2. Main theorem and induction hypotheses

The abstract's all-odd-prime claim agrees with `cap:odd-main`. That theorem imposes no solvability, defect-type, rank, Lie-type or extendibility hypothesis.

The almost-simple theorem `ep:theorem` is explicitly an induction step. It permits smaller defect for arbitrary finite groups, and equal defect at smaller central index. In `cap:odd-completion`, these are supplied by the lexicographic minimum. The proof distinguishes:

1. Every component defect is strictly smaller than the original defect. Actual probe realization allows the first induction coordinate to furnish the necessary complete budgets.
2. One component defect equals the original defect. The exact defect identity forces one positive-defect component, a defect-zero residual block and a prime-to-`p` remaining quotient. Only the one actual correction is realized. A strict central-index decrease gives induction; equality gives the stated almost-simple endpoint with exactly its available hypotheses.

This inspection found no mismatch between the universal statement and those terminal induction assumptions. The separate agent assigned the global mathematical argument is responsible for the deeper re-derivation of the reduction lemmas; this report does not replace that work.

The affine statement similarly closes its initially assumed lower-dimensional inequalities in its final strong induction. Its signed-coordinate argument explicitly uses dimensions below the current one. The lower-dimensional hypotheses found by the text scan are not left as open assumptions of `aff:theorem`.

## 3. External range checks outside the new type-D repair

The following source statements were read directly. Page numbers below are PDF page numbers, starting at one.

| Source and location | Published scope relevant here | Manuscript use and assessment |
|---|---|---|
| Ruhstorfer, `Ruh22Sigma.pdf`, p. 35, Corollary 12.5 | Type A; nondefining block prime at least five; inductive Alperin–McKay condition | The opening of `ep:exhaustion` states both the nondefining and prime-at-least-five restrictions. No use at three was found in that entrance. |
| Brough–Ruhstorfer, `BR23.pdf`, pp. 2 and 21, Theorem C and Theorem 9.12 | Types B and C over an odd field; nondefining block prime at least five | The manuscript keeps the odd-field and prime restrictions. The separate even-field C cases and D cases are not claimed to follow from this theorem. |
| Kessar–Malle, `KM15.pdf`, pp. 17–18, Theorem 3.14(d),(e) | Quasi-central source parametrization for odd primes; the unrestricted source bijection has a good-prime condition and a triality exception at three | The exceptional crosswalk uses it for good primes at least five. The bad prime five in E8 is explicitly assigned to KM13/KM25 instead. Thus the displayed use does not erase either restriction. |
| Malle, `Malle19.pdf`, p. 24, Proposition 6.4 and its proof | After the defining, small-type and exceptional-cover reductions, nonprincipal unipotent blocks in the listed exceptional families at primes at least five have abelian defect | The manuscript uses this structural fact together with its separate defining-characteristic, small-type and finite-cover branches. It does not infer the entire new main theorem from Malle's minimal-counterexample proposition. |
| Lee, `Lee21_fresh.pdf`, pp. 5–6, Proposition 2.1 and Table 2.1 | Cross-characteristic lower bounds for representations of quasisimple covers, with small exceptional parameters | The affine degree-budget proof expressly uses cover-degree bounds, retains the small-parameter complement, and treats defining characteristic separately. In particular, F4(2)'s 52 and the exceptional cover minimum 1938 for twisted E6(2) are retained. I compared the source table and the weakening mechanism; I did not repeat every numerical continuation test in this audit. |
| Fulman–Guralnick, `FulmanGuralnick12_fresh.pdf`, p. 3, Corollary 1.2 | Uniform class bound for a simple Chevalley socle and separate larger bounds for almost-simple extensions | The displayed `16 s^r` bound is applied to the simple socle; the outer factor is budgeted separately. The source's smaller constant for the socle implies the manuscript's bound. |
| Sambale, `Sambale17_fresh_selfcontainment.pdf`, p. 1, Theorem A | Abelian defect with no elementary abelian direct summand of order `p^4` | This is exactly the universal condition used in `ep:exhaustion`; it is not merely a theorem about groups of order at most `p^3`. The use for `(C_(p^a))^r` with `a >= 2` is valid because such a homocyclic group has no direct `C_p` summand. |
| Ardito–Sambale, `AS22_fresh_selfcontainment.pdf`, pp. 22 and 24, Theorems 17 and 19 | Abelian three-defect rank at most five; arbitrary three-defect order at most 81 | These are the respective rank and defect-order conditions used in the endpoint. The theorem with defect 81 does not require the resulting actual block to remain almost simple. |
| Navarro–Späth, `NS14_fresh_selfcontainment.pdf`, pp. 42–44, Proposition 6.2 and Corollary 6.3 | An actual proper intermediate subgroup containing the defect normalizer, together with a block-isomorphism relation of character triples | The manuscript allows precisely this intermediate subgroup rather than insisting that the cited theorem immediately produces the full normalizer. It then uses the lower abelian-defect height-zero set and the retained factor sets to pass to upper ordinary characters. The strict central-index comparison uses containment of the original center. |

For the last interface, a positive-defect group in the quasisimple prime-to-`p`-center situation is noncentral. Its radical condition is the usual defect-normalizer fact: the Brauer correspondent has the same defect group, and the normal `p`-subgroup of the normalizer is contained in that defect group. This fits the noncentral-radical input of the cited result. The cyclic-block entrance refers separately to its published block-character-triple construction.

These checks concern the source theorems' actual scope and the uses visible at the endpoint. They do not establish new classification theorems by computation.

## 4. Lexical candidate review

I searched the complete source for prime-two references, previous/local-draft dependencies, conditional or pending language, and occurrences of `assume`, `assumption`, `admissible`, `source`, `verification` and `could`.

The mathematical occurrences in the examined contexts fall into these categories:

- Explicit hypotheses of local lemmas, such as Clifford gluing and invariant extension statements. These are not appended to the main theorem.
- Strong-induction assumptions, closed by the affine proof or the final block induction.
- Definitions of admissible whole corrections: a cochain must satisfy the specified coboundary equation. This is a definition of the object quantified over, rather than an unproved existence condition silently imposed on the theorem.
- Representation-theoretic sources and their stated stabilizers or relative groups.
- Exact finite-domain computations. The article identifies their input domain and does not present finitely many tests as a proof for an unbounded field or rank.
- The single speculative-sounding `could contribute` occurrence is part of a numerical upper-bound argument, not an unproved existence assertion.

Four defensive prose clauses were reported to root and removed without changing a mathematical statement or calculation: the clauses about no assumed splitting, no assumed complement, no assumed uniform norm distribution, and no assumed invariant central-character extension. Their surrounding constructions already state the actual objects being used.

## 5. Final diff review

I read the actual diff from the initial frozen text to the final hash above. It contains only:

1. The four prose removals just listed.
2. The CTblLib bibliography version correction from 1.3.9 to 1.3.11, matching the delivered computational environment.
3. A local end-of-bibliography page enlargement for the final address.

No theorem, hypothesis, formula, proof construction, internal label or citation to a mathematical theorem changed in this diff. The conclusions of the present audit therefore apply to the final reviewed hash.

## 6. Reproducibility files

- `final_selfcontainment_source_check.py`: accepts explicit source-directory, manuscript and output paths. It uses PyMuPDF to record PDF identity, page count and numbered-anchor locations, then checks prime-two isolation and standalone-source structure.
- `final_selfcontainment_source_receipt.json`: successful result on the final reviewed manuscript; all nine input PDFs found and all four lexical checks passed.
- `final_selfcontainment_primary_index.json`: URLs, byte sizes and SHA-256 values for the three additional primary PDFs used in this audit: NS14, Sambale17 and AS22. Six other inputs are already in the main primary-source index.

Example, with paths adapted to the extracted materials package:

```sh
python3 final_selfcontainment_source_check.py \
  --source-dir /path/to/downloaded-primary-pdfs \
  --manuscript /path/to/Brauer_kB_odd_primes_20261114.tex \
  --output /path/to/selfcontainment-source-receipt.json
```

The matching rule records cross-references as well as statement pages; the source table above identifies the pages actually read for their statements. PDF hashes and extraction receipts establish which source versions were consulted. They are not certificates of mathematical truth. Full third-party paper text need not be redistributed with the materials.
