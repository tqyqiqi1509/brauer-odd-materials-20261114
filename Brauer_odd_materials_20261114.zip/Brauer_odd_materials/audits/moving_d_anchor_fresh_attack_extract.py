#!/usr/bin/env python3
"""Reproduce the primary-text extracts used in the fresh moving-D audit.

No mathematical theorem is checked by this script.  It records the exact PDFs,
their hashes, and page text so that the human mathematical audit is traceable.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import fitz


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "revision_audits" / "moving_d_anchor_fresh_attack_evidence"
SOURCES = (
    (
        "CS25",
        ROOT / "revision_audits/primary/CS25.pdf",
        (12, 13, 15, 21, 22),
        "Proposition 2.12, Theorem 2.18, proof of Theorem 3.11",
    ),
    (
        "BR23",
        ROOT / "revision_audits/primary/BR23.pdf",
        tuple(range(3, 12)),
        "Lemmas 2.1-2.2, Proposition 2.3, Corollary 3.4, "
        "Lemma 3.5, Proposition 3.7, Corollary 4.3 and Section 4.2",
    ),
    (
        "SpaethD25",
        ROOT
        / "revision_audits/exceptional_final_independent_checks/SpaethD25_published.pdf",
        (3, 19, 20),
        "Theorem A (printed p. 47), Section 3.3 (printed pp. 63-64)",
    ),
)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    receipt = {
        "audit": "moving_d_anchor_fresh_attack",
        "description": "Primary PDF extraction; not a proof verification program",
        "pymupdf_version": fitz.VersionBind,
        "page_number_convention": "PDF physical pages, starting at 1",
        "sources": [],
    }
    for tag, path, pages, purpose in SOURCES:
        document = fitz.open(path)
        parts = [f"{tag}\nPurpose: {purpose}\nPDF SHA256: {sha256(path)}\n"]
        for page in pages:
            if not 1 <= page <= len(document):
                raise ValueError((tag, page, len(document)))
            parts.append(f"\n===== PDF PAGE {page} =====\n")
            parts.append(document[page - 1].get_text(sort=False))
        target = OUT / f"{tag}_selected_primary_pages.txt"
        target.write_text("".join(parts), encoding="utf-8")
        receipt["sources"].append(
            {
                "tag": tag,
                "pdf": str(path.relative_to(ROOT)),
                "sha256": sha256(path),
                "total_pdf_pages": len(document),
                "extracted_pdf_pages": list(pages),
                "purpose": purpose,
                "extract": str(target.relative_to(ROOT)),
                "extract_sha256": sha256(target),
            }
        )
    target = OUT / "primary_extraction_receipt.json"
    target.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"receipt": str(target), "sources": len(SOURCES)}))


if __name__ == "__main__":
    main()
