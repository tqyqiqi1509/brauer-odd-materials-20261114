# Fresh audit of the affine degree and class budgets

Date: 14 November 2026.

## Scope and conclusion

I independently read `aff:degree-gates` in `odd_affine.tex`, its degree and
class tables, the defining-characteristic and low-degree arguments, and its
consumers in the component-transfer and multiple-orbit bounds. I read the
primary degree table of Lee and the published class bounds of Fulman and
Guralnick through fresh Python PDF extraction. I did not treat previous
audit verdicts or numerical output as proof of the inequalities.

The displayed order margin is `|Out(S)| k(S) <= |S|/4`, not
`16 |Out(S)|^2 k(S) <= |S|`. I found no counterexample to the required
degree/order estimates after making the explicit small A5 qualification
described below. The original notation and wording do require the repairs
listed here. In particular, the full-outer-group half bound really fails at
two degree-two A5 endpoints; its valid replacement uses the implemented
linear outer group. This is a substantive scope qualification, not an
arithmetic consequence of the full-outer definition of beta.

The root agent is making the listed revisions. This report is an audit of
the indicated argument and an explicit repair list; it does not purport to
certify all later edits or the general Brauer conjecture. The remaining
global and local-endpoint problems are outside this narrow audit.

## Primary documents actually read

1. Melissa Lee, *Regular orbits of quasisimple linear groups I*,
   arXiv:1911.05785v2, 49 PDF pages:
   <https://arxiv.org/pdf/1911.05785v2>.
   File: `revision_audits/primary/Lee21_fresh.pdf`.
   SHA-256: `272460b7b2f737eba000c0b1fb554f460cc8bd09b59098c9d240504ad9d9fa86`.
   I read Proposition 2.1 and Table 2.1, including the quasisimple-cover
   hypotheses and every exceptional entry relevant to the manuscript table.

2. Jason Fulman and Robert Guralnick, *Bounds on the number and sizes of
   conjugacy classes in finite Chevalley groups with applications to
   derangements*, published TAMS version, 48 PDF pages:
   <https://dornsife.usc.edu/jason-fulman/wp-content/uploads/sites/224/2023/06/bounded.pdf>.
   File: `revision_audits/primary/FulmanGuralnick12_fresh.pdf`.
   SHA-256: `d2de50a847f207cd0dff3a479fe6b6442770b3f39a2889f6a77d6062d16471bc`.
   I read Corollary 1.2, Corollaries 3.7 and 3.11, Proposition 3.10 and the
   exceptional-group class table in Section 4.

`affine_degree_bound_final_fresh_checks/primary_reading_index.json` contains
the PDF and page-text hashes obtained with PyMuPDF 1.26.6. It identifies the
versions read; it does not assert that all results in those papers were audited.

## Corrections required in the manuscript

### 1. Two different field exponents and a Sylow valuation

The representation field must be introduced as `t=p^f`, while the defining
field of a Lie-type group is `s=ell^a`. The final order-margin paragraph
needs `O <= 2 a N`, with `N` the number of positive roots, rather than
`O <= 2 f N`. In addition, the defining-characteristic paragraph had reused
`a` for `log_p |S|_p`. It should use `a_p=v_p(|S|)` there, so that

```
O <= 2 a_p,
a_p <= f d(d-1)/2,
beta^+ <= f d(d-1).
```

Merely changing the last `f` to `a` without removing the intervening
redefinition would still leave the notation ambiguous.

### 2. The degree-two A5 half bound

With the manuscript's full-outer definition,

```
S=A5, d=2, t=11: beta=10 > 11/2,
S=A5, d=2, t=19: beta=10 > 19/2.
```

The manuscript's trace argument proves that the outer involution is not
implemented linearly on those degree-two modules. The required implemented
outer image is therefore trivial, and its budget is `5 <= t/2` in both
cases. The two fifth-root trace values are `u` and `u^2-2`, with
`u^2+u-1=0`. Equality would imply `u=-1/2` and hence characteristic five;
it is impossible in characteristics eleven and nineteen.

The lemma should explicitly exempt these two cases from the full-beta
half inequality and state the implemented-linear-outer replacement. Its
other inequalities can retain the full outer group. The later consumers
already discuss the actual implemented outer group at these degree-two
endpoints, but their variables should refer unambiguously to that budget.

The small fields `7,13,17,23` are excluded by the required factor five in
`|GL_2(t)|`; in characteristic three an actual module has `t>=9`.
The remaining full-beta half bounds pass. The formal A7 allowance is an
enlarged numerical domain, not an assertion of existence of a module.

### 3. A safe Tits class bound is not its exact class number

The stored independent GAP table line is

```
TABLE|2F4(2)'|2F4(2)'|17971200|22
```

Thus `58` is a safe class bound, not `k(S)` itself. The Tits case should be
written separately with `k(S)<=58`, `|Out(S)|=2`, and
`4 |Out(S)| k(S) <=464 <17971200`. Its outer automorphism of order two
is not a field-only outer group for the field of order two. The phrase
“their field-only outer groups” must apply only to the non-small Suzuki
and Ree families.

The same distinction applies to G2(3): its stored table has 23 classes,
while the manuscript uses the valid bound 24. The small defining rows
`PSU3(3)` and `PSp4(3)` have respectively 14 and 20 classes.

## Independent derivation of the order margin

For ordinary Lie types, let `r` be the untwisted rank and
`N=|Phi^+|`. The standard order products give

```
|S| >= s^(2N+r)/(4(r+1)).
```

The outer-order formulas give `O<=2aN`. For example, type A has
`O<=2a(r+1)<=2aN`; even orthogonal type has `O<=8a`, and D4 has
`O<=24a=2aN`. The exceptional types satisfy the same coarser bound.
The scalar `a<=s/2` follows from `s=ell^a>=2^a`.
Using `k(S)<16s^r`, one obtains

```
4 O k(S) <128aN s^r <=64N s^(r+1).
```

Consequently `4Ok(S)<=|S|` follows from

```
256N(r+1) <= s^(2N-1).
```

At the smallest positive-root counts in ranks 2, 3, and 4 this starts at

```
2304 <=5^5,
6144 <=3^11,
12800 <=2^19.
```

For fixed `r,s>=2`, increasing `N` multiplies the right-to-left ratio
by `s^2 N/(N+1)>1`. At minimal type-A roots `N=r(r+1)/2`, the rank
increment increases the exponent by `2(r+1)` while the polynomial
coefficient grows by less than four for `r>=4`; the factor
`2^(2(r+1))` is larger. This proves the infinite rank continuation.
Increasing `s` is immediate.

The exceptional lower-field starts are also explicit:
`(r,N,s)=(2,4,4),(2,6,3),(3,9,2)` satisfy the same inequality.
The remaining ordinary cases are the listed finite A2 cases and
PSp4(3), together with `L4(2)=A8`, handled in the alternating argument,
and `U4(2)=PSp4(3)`. Non-simple small full groups are represented by
their standard simple isomorphisms, such as `G2(2)'=U3(3)`.

For Suzuki, small Ree and large Ree, do not use the ordinary-root
order bound. Use respectively

```
|S| >=s^5/2, s^7/2, s^26/4,
O=a<=s/2,
k(S)<16s^2, 16s^2, 16s^4.
```

The needed margins reduce respectively to `64<=s^2`, `64<=s^4`,
and `128<=s^21`. These hold at the smallest simple parameters
`s=8,27,8` and increase with `s`. The published exact upper bounds
`s+3`, `s+8`, and `s^2+4s+17` are stronger.

## Defining-characteristic class budgets

The assertion `k(S)<=|S|_p` can be expanded without a hidden small-rank
exception as follows, for the odd prime `p` used in this paper.

- For ordinary rank at least three, `|S|_p=s^N`,
  `N-r>=3`, and `s>=3`; hence `16s^r<=s^N`.
- For PSL3(s), Corollary 3.7(2) gives
  `k(S)<=s^2+5s<=s^3` for odd `s>=3`.
- For PSU3(s), Corollary 3.11(2) gives
  `k(S)<=s^2+8s<=s^3` for odd `s>=5`; at `s=3`, use `14<=27`.
- For C2 at odd `s>=5`, use `16s^2<=s^4`; at `s=3`, use `20<=81`.
- For G2, `|S|_p=s^6`, and `16s^2<=s^6` already holds at `s=3`.
- For PSL2(s), use the exact class formula `(s+5)/2<=s` at odd
  simple parameters `s>=5`.
- For small Ree at `s>=27`, Section 4's bound `s+8<=s^3` applies.
  The isomorphic small derived exception is treated in its standard
  PSL2(8) description, not by a false ordinary G2 order formula.

The rest of the defining degree argument then follows from the actual
embedding into PGL_d(t), which gives
`|S|_p <= t^(d(d-1)/2)`. The scalar inequalities start at
`2 f d(d-1)=24<=27=t^(d-1)` for `d=4,t=3` and increase thereafter.
The displayed `d=3,t=3` bound and the PSL2 degree-two case are the
separate small-dimensional cases.

## Degree-table source comparison

Every displayed weakened D0 formula is below Lee's actual Table 2.1
bound in its stated range. In particular:

- The unitary floor bound is at least `(s-1)s^(n-2)-1`.
- For even symplectic groups the ratio to `s^(2m-2)` is
  `s^2/(2(s+1)) (1-s^(-m))(1-s^(1-m))`, at least `7/16`
  for `s>=2,m>=3`. Thus `s^(2m-2)/3` is safe.
- The displayed B and D powers are below the rational root-system
  formulas in the source table; the exceptions B3(3), D4+(2) and
  the indicated A-type covers remain in the finite complement.
- Lee gives `(s^5-s^4)*sqrt(s/2)` for large Ree. The manuscript's
  weaker `s^5-s^4` is valid for `s>=8`.
- The explicit F4(2) and twisted E6(2) exceptions are respectively
  52 and 1938, as retained in the manuscript.

The 28-start exponential comparisons and subsequent field/rank
monotonicity use these valid lower bounds. The coefficient
`12Ok<=3^D0` implies the clipped G6 inequality because
`max(1,k(S)/|S|_p)<=k(S)` and `(x-1)/x^D` decreases for
`x>=3,D>=2`. The six finite coarse failures are the stated
A5, L2(7), A6, L3(4), PSp4(3), U4(3) rows.

Faithful projective representations need not be assumed absolutely
irreducible for these lower degree bounds: pass to an absolutely
irreducible nontrivial composition factor of the quasisimple lift.
Such a factor exists, since otherwise the perfect image would be
solvable. Its projective kernel in the simple quotient is trivial,
and its dimension is at most the original dimension. For the
degree-two/three classification and trace argument, a nonabelian
simple projective image cannot be reducible or imprimitive in
those small dimensions; the stated small-group analysis applies.

## Saved finite checks

`affine_degree_bound_final_fresh_checks/` contains the full input,
standard-library script `check_degree_order_bounds.py`, expected actual
`output.json`, README and the primary-PDF identity record.

The script was actually executed and passed 22 exact comparisons:
six ordinary-root starts, three Suzuki/Ree starts, eight finite order
margins, three small defining class bounds and both A5 corrections.
It records `universal_verification: false`. Infinite continuations and
source theorem hypotheses are mathematical arguments above, not conclusions
of this finite program.
