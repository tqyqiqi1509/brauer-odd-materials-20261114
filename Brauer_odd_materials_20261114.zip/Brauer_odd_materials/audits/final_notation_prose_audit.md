# Fresh sequential notation and prose audit

Date: 2026-11-14 (UTC)

Auditor: /root/final_notation_prose_audit

Current closure: the frozen final source bbd43d426c582f46e437a4a6e7c356938476a7fa305edda3f609b8da336c7f00 has no outstanding notation, prose, or citation-boundary finding from this audit. See the final-snapshot addendum below. Earlier pending statuses are retained as audit history.

## Scope and snapshot

This is a fresh audit of the assembled standalone manuscript, not a reuse of an earlier PASS report. The manuscript was read sequentially from the preamble and abstract through the final all-prime corollary and all 85 bibliography entries. All displayed mathematics and tables in that reading were inspected for notation, local definitions, prose, stated hypotheses, and citation placement. This was not an independent re-proof of every classification theorem, source-extension construction, or computer computation; separate mathematical and executable-data auditors own those checks.

The principal snapshot read was:

- File: brauer_odd_delivery_20261114/Brauer_kB_odd_primes_20261114.tex
- SHA-256: 8d481a13c692bbca8ee51e982a56fd3faf3bf53ec175964d923f62d5d9d8bf3f
- 15,550 lines, 71,804 whitespace-separated tokens, 411 labels, 85 bibliography entries.

The first part of the sequential read preceded the first small definition patch. The same sections were followed by label, and the three early fixes were subsequently identified in the new snapshot. Later fixes were being made in the module sources while the assembled snapshot remained unchanged. Exact labels below therefore take precedence over shifted line numbers. A final-snapshot verification addendum will distinguish changes actually re-read from changes only reported by the editor.

## Findings sent to the editor, in reading order

| ID | Anchor | Finding and minimal correction |
| --- | --- | --- |
| N01 | cap:mixed-two-cycle | X was not defined before the action groupoid and p-section formula. Define X as the product of the two simple-label sets, and specify the action groupoid. |
| N02 | Affine subsection “Moments and actual tensor algebras” | M was used in b_t(J,M) before its local definition. Set M=F_q^d, regarded as an F_p-module. |
| N03 | Canonical affine core / pure binary case | m and z in q^m and the class-number expression were not defined locally. Define the K[R]-multiplicity m and z=|Z|. |
| N04 | aff:degree-gates | Introduce S and t=p^f locally. Separate the p-part exponent from the defining-field exponent a. Define N as the positive-root count; use 2aN in the final outer bound and explain a≤s/2. |
| N05 | Affine nondefining-component safe-type table | “A weaker degree allowance enlarges a range and asserts no representation exists” reverses the intended meaning. Replace by “The degree allowances enlarge the range to be checked.” |
| N06 | Preliminary notation / aff:ordinary-cycle | Define the integer radical rad(n), the odd-order class count k_{2'}, the partition function P(n), and σ_1(j). In ordinary-cycle also define U, Z=Z(D)=Z(R), z, q=p^f, and the empty-layer multiplicity. |
| N07 | aff:delete-code | R is a vector space and was used as a coordinate subset in Ω minus R. Name the orbit Δ and write R=F_2^Δ, replacing both set complements by Ω minus Δ. |
| N08 | Signed-coordinate boundary discussion | H was used before introducing the actual signed-coordinate group. Define its sign kernel N and permutation image U before the boundary count. |
| N09 | aff:primitive-class-ratio; aff:binary-profile | Unify partition counts as P. A follow-up check of the patched module found three remaining p(t) occurrences in the proof of aff:binary-profile; these must also become P(t). |
| N10 | cap:coset-trace, inside cap:long-cycle | The summation domain X^{s,t} refers to a single-factor label set. The commuting operators act on tuples, so the required domain is (X^a)^{s,t}. This is a real domain error, not cosmetic notation. |
| N11 | Application before lev:cover-local | Delete the unused alias M_0=M_e (written M_0=Me), and describe M_e as the bimodule used in the application. |
| N12 | cap:corrected-order-rank | rk of a split semisimple algebra can be confused with the rank of an integral order. Use rk of its representation category or explicitly define the algebra shorthand. |
| N13 | cl:graph-mark | Define the first occurrence of the partition count mathfrak p(n), or write it as a coefficient of P(t). A coefficient convention F_w=[t^w]F(t) also defines J_w and T_m uniformly in this section. |
| N14 | tdr:A-unitary-Lang and following comparison | The unitary branch uses E^0 in the inner/outer comparison before its branch-specific definition. Introduce E^0=〈F_r,γ〉 on K before that first comparison. |
| N15 | cl:Fourier-units | Define the annihilator T^perp in Γ and the orbit block e_{ξT}=eξ before the Fourier unit sum. |
| N16 | ep:classical-sources, moving isolated type-D branch, near old line 10688 | The isolated formula Ann(I_b)=ω_s(A_{L*}(s)^F_α) has undefined maps and labels, and I_b collides with the earlier integral-inner automorphism group. This requires an explicit source/Jordan/diagonal-stabilizer dictionary, not just a spelling change. Details below. |
| N17 | ep:carriers, near old line 10743 | H first denotes a positive source root base and then a finite group in Irr(H). Use Δ_H for the simple root base and retain H for the derived rational source group. Define the Lie Cartan operator by h_i e_w=w_i e_w. |
| N18 | ep:carrier-representation | Name the previously chosen linear extension ν_α before using it, with domain I_α and restriction α to the overlap A_2. |
| N19 | ep:exceptional-support, generic E8 degree export | A generic unipotent degree includes a power of q. Write c q^u times the cyclotomic product, and note that p does not divide q, so the q^u factor contributes no p-valuation. The displayed valuation formula itself remains unchanged. |
| N20 | ep:source-root | Introduce the selected maximal Brauer pair (D,e) containing (A,b_L) before the first occurrence of x in C_U(D)_e. |
| N21 | ep:e8-five | The preceding subsection defines finite K=𝐊^F and T=𝐓^F, but this subsection writes K^F and T^F again. Distinguish algebraic groups from finite points consistently. Define Λ, Ψ_i, ω_i and θ in the lattice calculation. |
| N22 | ep:B-polynomial | Define s=(q^d−1)_p, using the effective signed parameter when appropriate. Earlier s=(q−ε)_p does not by itself define the E8 d=4 entry. |
| N23 | ep:exhaustion, following the e=3,4,6 toral table | “Its four order factors” has an ambiguous antecedent after the discussion shifts to D8 and E6. Explicitly state that the factors belong to the unitary A4(q^2) group. |
| N24 | ep:exhaustion | Unify the isolated φ_{2,1} notation with the existing φ_{21} notation for the same A2 label. |
| N25 | cap:normal-p-linearization | The lemma uses B in its conclusion but only introduces Q and G. State that B is a block of G, or give a clear section-wide convention before the lemma. |
| N26 | cap:one-cover-arrows | Name the newly constructed covering groupoid widehat G before its first symbolic occurrence in cap:selected-center-lattice. |

## Prose recommendations

The title and abstract are concise and direct. No generic promotional or AI-disclosure passage was present. The following small edits remove redundant process or adversarial phrasing while preserving the mathematics:

- “final public extension input” → “extension input”.
- “Rossi's independent unipotent theorem” → “Rossi's unipotent parametrization”.
- Delete “broad” from “broad derived-source representation”.
- Delete the sentence “No upper bound on a guessed Sylow exponent enters this argument.”
- Delete “legally” from the connected-centre Jordan-decomposition sentence.
- Replace “If 3 divides 6” by “For n=6 and p=3”.
- Delete the sentence about a loose numerical bound leaving no unhandled block after the defect-81 argument; the preceding theorem application already proves the assertion.
- Phrase the source-pair construction positively: “To select the actual source pair, start with …”.

The two rational Clifford-gluing lemmas are closely related and have largely parallel proofs. Consolidation would be an optional editorial shortening, not a correctness requirement. No late consolidation is needed for this audit to close.

## Source check for N16

I read the retained original public source CS25, version arXiv:2410.20392v2, in revision_audits/primary/CS25.txt, at its proof of Theorem 3.11 on pages 21–22 (text lines approximately 1454–1477). There ω_s is the injective commutator-lift map from the semisimple centralizer component group to the centre of the simply connected cover. Its image is called B(s). The annihilator concerns the regular-diagonal stabilizer of an ordinary character, and the second stabilizer concerns its unipotent Jordan label. This is not literally the integral-inner group I_b defined in the manuscript at cl:actor-definition.

The editor and the independent mathematical integration auditor were notified. The manuscript must either spell out the selected-source dictionary that gives the stated block-level conclusion, or replace the isolated equation by the applicable correctly quantified source statement. This report does not independently certify that missing dictionary.

## Whole-file automated checks

On SHA-256 8d481a13c692bbca8ee51e982a56fd3faf3bf53ec175964d923f62d5d9d8bf3f:

- 411 labels; no duplicate labels.
- Every ref, eqref, autoref and pageref resolves to a defined label.
- Every citation resolves to one of the 85 bibliography entries; all 85 entries are cited.
- Exactly one body citation to TangPrimeTwo26, in the proof of the final all-prime corollary.
- No external input/include command in the assembled standalone TeX.
- No local absolute workspace, temporary-directory, or obsolete manuscript path in the paper.
- No AI use, Scholarly Credit, acknowledgment, TODO, FIXME, TBD, or conditional placeholder section.
- Author Qiyue Tang, address, email tangqy24@mails.tsinghua.edu.cn, and date November 14, 2026 are present.
- The odd-prime theorem cap:odd-main has no additional conditional hypothesis. The final all-prime statement is a corollary of that theorem and the sole allowed prime-two citation.
- The conditional hypotheses of the internal almost-simple endpoint are induction hypotheses explicitly discharged in the final odd-prime proof; they are not leftover conditions on the main theorem.

The preamble has 11pt AMS article style, restrained blue links, blue theorem numbers, blue equation tags, and a blue statement of the principal inequality. This is source-level inspection; PDF visual QA belongs to the separate delivery workflow.

## History and bibliography

The entire introduction and bibliography were read. This audit did not redo the team's complete novelty search or independently verify all historical references. One potentially questionable author initial was checked against the primary MFO record at https://publications.mfo.de/handle/mfo/4345: the record names Noelia Rizo and Mandi A. Schaeffer Fry, so the manuscript's N. Rizo and M. A. Schaeffer Fry are correct. The primary record gives 2025-11-24 and Snapshots 2025-06. The other historical verification remains with the separate source audit.

## Materials and paths

The named exceptional supplement exists at Brauer_odd_materials/certificates/exceptional, with README.txt and manifest.json. The paper's relative directory name is correct within the materials root. I read that README but did not rerun or rehash the entire computational supplement in this notation audit.

One README wording issue was reported: it describes the supplementary 54-weight E6 carrier model as specified in the article, although the current article explicitly details the E7 and E8 models and deletes the relevant E6 non-toral source. Keep the extra E6 files, as requested by the user, but describe them as retained additional computations rather than a model used by the current proof.

## Current status

Sequential reading is complete. Early definition/domain fixes were reported by the editor as applied in module sources. Final verification of the fully reassembled snapshot is pending; N16 additionally needs the mathematical source dictionary. This is a notation/prose/citation-boundary report, not a blanket proof certificate.


## Module revision recheck (2026-11-14)

The editor's changes for N01–N15 and N17–N26 have now been inspected in the actual module files. All 25 reported items are resolved there. This includes the three formerly remaining binary-profile partition counts, now written with the globally defined mathfrak p; the correct tuple fixed-set domain; the representation-category rank; the already defined bimodule M_e; the coordinate orbit Δ; the separate Lie Cartan operators H_i; the named overlap extensions; the finite/algebraic-group distinction in the E8 argument; and the omitted q-power in generic degrees. The listed prose deletions were also verified.

The exceptional README now correctly identifies the 54-weight E6 model as retained additional material, rather than a model used by the current proof. The materials contain the five fresh_degree files and a primary-source index of 28 files. These are presence checks, not a new execution of their computations.

The exact module snapshot hashes are recorded in final_notation_module_recheck.json:

| Module | SHA-256 |
| --- | --- |
| brauer_odd_revision/preliminaries.tex | 565126ae8d72fe2f89f1b597dfc229421a89218d3c550f00379189a86ccf9020 |
| brauer_odd_revision/odd_affine.tex | 582f0379f4c971c61f4843c027b36c4ecb1bc59d8931cec5f0f5c9d23b6ba910 |
| brauer_odd_revision/odd_global_capacity.tex | 74e9b957353096fe05348431d021e22f591b7dbaeed87461865449515887e905 |
| brauer_odd_revision/all_prime_levi.tex | 07b4e808ef708498822a4e83ea5d6075d755ed65aea4a2599e5f37bdecef7999 |
| brauer_odd_revision/odd_classical.tex | c7d40072ade87c366a388545c3de08e42aa37f13b1ca21232d9f908e21472b4b |
| brauer_odd_revision/toral_type_d_repair.tex | 1bb101c2845f2cebae6fb23e944f099cf59c50dc6587ace107e7f3bf07659654 |
| brauer_odd_revision/odd_endpoints.tex | a0354b833cf80d7e0e2e4e4ef04ef4153d954864905f1d9085f06c82a6e23a8f |

N16 is being replaced by the separate candidate moving_d_anchor_replacement.tex and has not yet been merged at this stage. I read that candidate for notation and sent two additional minimal corrections: introduce ν at its first use as the selected central character on Z(U); and define the scalar function on the fibre product explicitly by a(s r c)=η(c), with s in ΔS, r in a chosen section and c in the central subgroup C. The independent mathematical auditors retain responsibility for the validity of that replacement.

Final assembled-source label/citation and sole-prime-two-citation checks remain to be repeated on the unified final snapshot.


## Final-snapshot addendum: frozen source

Date: 2026-11-14 (UTC).

Final file: brauer_odd_delivery_20261114/Brauer_kB_odd_primes_20261114.tex

SHA-256: bbd43d426c582f46e437a4a6e7c356938476a7fa305edda3f609b8da336c7f00

The frozen source has 15,798 lines and 73,356 whitespace-separated words. This final check combines the earlier sequential reading of the complete article, inspection of all submitted notation/prose modifications in the actual modules, complete reading of the newly inserted type-D paragraph, and a final static check of the assembled source. It is not represented as a second fresh sequential reading of all unchanged lines.

### All earlier notation fixes are present

All 25 changes N01–N15 and N17–N26 are present in the assembled source and pass the explicit fragment/domain checks. The checks also confirm that the old lowercase partition notation, unused M_0 alias and single-factor long-cycle summation domain have not returned.

### N16 is replaced and its notation is closed

The former isolated annihilator identity has been removed, together with the graph-torsor lemma and all its uses. It has been replaced by the paragraph labelled ep:d-regular-anchor, containing ep:d-regular-blocks and ep:d-central-discrepancy. I read that complete inserted argument in the assembled source.

The replacement defines the regular group, local normalizer and centralizer, selected covering and corresponding blocks, diagonal orbit length, actual inertia, central character ν, discrepancy ζ, fibre product and its two central kernels. Its scalar correction has the following explicit conventions in the frozen source:

- ν is defined before the first use of ν(z).
- ξ is explicitly a character of Z(X_1), the domain on which the two regular extensions agree.
- The chosen quotient representatives include 1 for the identity coset.
- The scalar function is explicitly a(s c r)=η(c), with s in ΔS and c in the central subgroup C.
- The induced character of K(Y/S)/(Y/S) is the character extended to J/Y in the final linear-extension step.

These changes remove the ambiguity reported under N16; the old I_b formula is not being silently reinterpreted. The mathematical validity of the replacement is the subject of the separate integration audit, while this review closes its notation, group-domain and citation-reference findings.

### Final static results

- 414 labels, no duplicates and no unresolved internal references.
- 85 bibliography entries, no unresolved citation keys and no uncited bibliography entry.
- Exactly one body citation to TangPrimeTwo26, at line 15,230, within the final all-prime deduction.
- No external input/include commands, local absolute file paths, disclosure/credit/acknowledgment sections, conditional placeholders, or listed process-style remnants.
- Author, email, date, AMS 11pt class and blue-link settings are present.
- The odd-prime main theorem remains unconditional, and the sole prime-two proof citation remains confined to the final all-prime deduction.

The reproducible source-inspection program is final_notation_static_check.py; its complete final output is final_notation_static_recheck.json. It uses only Python's standard library and identifies its scope as source-level checking, not mathematical verification. The exact invocation was:

    python revision_audits/final_notation_static_check.py brauer_odd_delivery_20261114/Brauer_kB_odd_primes_20261114.tex --output revision_audits/final_notation_static_recheck.json

The program returned exit code 0 and source_checks_pass=true. No unresolved notation/prose/citation-boundary finding from this audit remains in this frozen snapshot. PDF visual verification and proof-level mathematical certification remain separate review scopes.
