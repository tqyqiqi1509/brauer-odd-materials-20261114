# Final independent audit: foundations, Levi descent, and the global argument

Date: 2026-11-14. Reviewer: `/root/foundations_global_final_fresh`.

## Verdict and scope

I read the following four files completely, in order, after their repair author had frozen them. I did not edit the mathematical text. Earlier review reports were treated as change indexes, not as evidence of correctness.

| File | Lines | SHA-256 of the reviewed version |
|---|---:|---|
| `preliminaries.tex` | 139 | `e9fae91208a028c02acada7585ef94972f6de9d36e42cc7a736de51f268dd183` |
| `integral_foundations.tex` | 158 | `e248a3db903a2c141b15f657dce045f4c1a79cd5071ec5e8e2a977a5d30a9ce4` |
| `all_prime_levi.tex` | 1282 | `146d84c48326b440acc9f2563eb02c7dd4886be8f47d39cabfcc23eeb1c3224b` |
| `odd_global_capacity.tex` | 3061 | `77a1ea221a6daa6473b2b032c0a1fa161bfc8c3721178e5c8b17260a935fe3e1` |

**No confirmed mathematical error or concrete counterexample was found in these four reviewed versions.** The newly expanded integral Morita argument, pointed-bimodule count, normal-p block comparison, single relative-block selector, and defect/central-index induction withstand the specific checks below. This is a local audit result, not a certificate that Brauer's conjecture has been proved. The global final proof explicitly consumes the independent affine theorem and the almost-simple endpoint theorem. Neither theorem's full proof belongs to this assignment. An unresolved classical or exceptional input therefore still prevents an unconditional final conclusion.

The final prime-two citation is confined to the last all-prime deduction. There is no prime-two-paper dependency in the preceding four modules. This audit does not independently certify the public prime-two theorem cited there.

## 1. Preliminaries

The twisted-class proof of `pre:projective-count` uses the actual conjugation action on each conjugacy-class subspace of the twisted algebra. The regularity criterion, one-dimensional contribution, and split-semisimple center dimension agree.

The subgroup and normal-subgroup class inequalities are used in the correct directions. In the Clifford sum, multiplying by the inertia index and then summing orbit sizes yields the stated blockwise bound; it does not assume that conjugacy-class number is subgroup-monotone.

The commuting-pair identity counts each orbit with factor `|H:H_x| |H_x| k(H_x)`. The affine specialization uses the canonical extension of a linear character to its split inertia subgroup. No nonsplit inertia is substituted at this point.

The modular system, ordinary and Brauer characters, decomposition and Cartan matrices, and defect-order notation are explicit. Standard block-theory foundations remain public inputs, accurately signposted in this version.

## 2. Integral Morita criterion

I independently checked the left/right orientations of the two dual identifications. In particular, a tensor `n tensor m` in `M^vee tensor_A M` represents the left-A-linear map `x -> alpha(n)(x) m`, so the right-action map has the stated opposite-algebra convention.

Both units and both counits have the correct source and target. Their four triangle identities follow from the displayed dual-basis formulas. The tensors that are asserted to be free over O are direct summands of finite sums of free modules, by the relevant one-sided projectivity.

The generic right-action surjection selects a central direct factor `KB c_K`; faithfulness makes `KM` a generator on the A side. Thus the generic unit and counit on A are isomorphisms. Tensoring by the two dual modules produces split integral maps whose complementary O-free modules have generic rank zero. This justifies the integral isomorphisms at that stage.

The unit-descent argument also checks out: `Z(A)` injects into `End_{B-B}(Q)`, the latter is commutative because its generic fiber is a center, and it is finite and integral over `Z(A)`. A monic equation for the inverse of the central scalar gives the inverse inside `Z(A)`. The subsequent use of full faithfulness is on an object already in the essential image of G, so it is not an unsupported conservativity assertion on all B-modules.

Finally, the B-bimodule projection really gives a central idempotent; identifying its quotient map with the actual right action proves the algebra, rather than merely module, identification. The generator and primitive-support conclusions follow. I found no hidden use of the former prime-two proof in this lemma.

## 3. Levi descent

### 3.1 Geometry and the actual finite actors

The perfect-cover uniqueness argument removes the possible central homomorphism between two lifts. The fixed-point regular-embedding identities follow from Lang surjectivity for the connected algebraic kernels. The relative normalizer quotient is tied to the rational series stabilizer; the component-group argument establishes its abelian prime-to-p property.

I checked the field-unfolding fixed-point equations and the quotient-variety maps. They use positive Frobenius powers and right cosets by the corresponding radicals. Thus they do not invert an inseparable morphism. The return `F_r^f = gamma^{-1}` is retained. The displayed graded tensor signs satisfy the usual permutation relations.

For the p=3 triality branch, proper D4 Levis have type-A derived factors, so the connected centralizer is itself a Levi and minimality forces it to equal the selected Levi. In the adjoint dual, its center lattice is torsion-free. Applying the norm identity at the fixed prime-to-p semisimple label gives the contradiction needed to avoid every outside-root hyperplane. The argument is applied to the full stabilizer action, not only to its permutation on diagram nodes.

The label-group quotient kills the inner-Levi overlap in its correct position. The map from the full diagonal group has the stated central kernel. A strict geometric action on the inverse image of a Sylow subgroup is therefore available before the cohomological adjustment.

### 3.2 Endomorphisms, cochain adjustment, and support

The upstairs use of the Bonnafé--Rouquier equivalence first checks the full-centralizer hypothesis for every lifted semisimple label. The free lifted-series orbits give a full idempotent, and composing the two upstairs Morita bimodules produces the right normalizer action.

I recomputed the induced right action and the identity for `T_a`. The source/target idempotent argument proves independence of the summands. Frobenius reciprocity and the displayed restriction identity then give the required dimension equality. These are sufficient for the generic span.

The full diagonal endomorphism algebra is commutative. Selecting a left block by its diagonal orbit identifies its stabilizer endomorphism algebra with a factor of that commutative algebra. The invariant-center calculation uses the integral double centralizer after generic commutation has been upgraded by torsion-freeness. Its localness gives transitivity of the internal relative group on primitive summands, and hence a Sylow-fixed primitive summand.

The relative factor set lies in a commutative local unit group. Its residue has a prime-to-p scalar representative. The principal-unit class restricts to zero on the Sylow group; injectivity at that restriction uses `H^1(P,k^times)=0`, and restriction/corestriction together with the uniquely divisible prime-to-p power map kills the remaining class. No unrestricted prime-to-p averaging is used on a p-group.

The new paragraph extending a changed corner intertwiner to a full diagonal unit is essential and is valid as written: extend by the identity to the other primitive summands, then by conjugation to the diagonal block orbit. The stabilizer-endomorphism condition makes this extension independent of the representative. Repeating the independence/dimension argument for the adjusted operators avoids an unjustified claim that arbitrary corner units preserve a previously chosen linear span.

The right-action calculation has the correct reverse multiplication. The scalar kernel acts on the right by the inverse scalar character. The prime-to-p index averaging proves right projectivity; the integral Morita lemma then selects one block.

### 3.3 Central quotient and ambient equivalence

The rational Levi and series adjustment establishing `G = D H_0` follows the actual dual-normalizer dictionary in the source. Transitivity on primitive summands gives `G = D H` and the exact intersection `D cap H`.

The central kernel is removed before the ambient equivalence is constructed. The relation `z m = m z` makes the two inverse local functors preserve modules killed by `z-1`, including the central p-part. This avoids introducing an unconstructed ambient central cover. The same scalar cocycle pulls back to the actual H, whose intersection extension is the stated quotient of the covering intersection group.

I checked the Hom action, the tensor action, scalar cancellation, the balance relation, and agreement on the intersection. They yield an action of the actual quotient `D semidirect H -> G`. Both evaluation and unit are equivariant. The original centralizer elements have identity operators on the bimodule, so the original centralizer-block condition is retained. Morita equivalence preserves the Cartan elementary divisors and ordinary simple counts.

Properness and strict central index are used with `Z(G) <= C_G(D) <= H`. The scalar cocycle is trivial on mixed arguments involving that centralizer, so preimages of `Z(G)` are central. Merely adding a central cover would not by itself imply the strict index conclusion; the text supplies the necessary subgroup inequality.

### 3.4 Steinberg-root scope

The proposition now explicitly requires equality of the actual finite order and the order modulo inner-diagonal automorphisms. That hypothesis prevents an unaccounted earlier inner return. The quotient-variety proof retains the genuine cyclic closing relation and does not use negative powers of the root endomorphism.

The cited ordinary automorphism descriptions cover the perfect members of the stated B2/F4/G2/Suzuki/Ree families; nonperfect small parameters and exceptional Schur covers are expressly outside this module. These restrictions must still be checked at every endpoint application. I did not rederive the full finite-group automorphism classification in Carter's books.

## 4. Tensor capacity

### 4.1 New pointed-bimodule expansion

The pairing radicals are identified as kernels of actual module translation functors, including their comparison maps. Passing to full tensor images, rather than quotienting the target categories, is the correct operation. Surjectivity on simple objects justifies testing module naturality after restriction only for functors that already possess the relevant module structures.

After dividing by the two radicals, the normal stabilizers act on a regular quotient label set. The diagonal right-group orbits in `X times X` are exactly the graphs of the equivariant permutations. Each graph has stabilizer the abelian right kernel. A left-translation functor exists on each graph and has one-dimensional entries, so its comparison maps trivialize that graph's multiplier. The number of simples on the graph is therefore the order of that abelian stabilizer. The total matches the number of pairwise nonisomorphic left translations. This validates the new explicit endofunctor count.

The resulting tensor equivalence is the standard invertibility criterion. GP16 Theorem 7.9 applies; GP16 Remark 3.1 is also a precise reference for the tensor-functor formulation. Coinduction leaves each complete probe bound intact because inverse images of transitive label sets remain transitive. The return is transported using one global gauge. The two permutations of indecomposable summands need not be inverse, and the proof only needs at most m fixed pairs. Positivity and the column budget then give `m(F+1-m)`.

### 4.2 Sections, cycles, and permutations

The Hall-coset lemma keeps the central character and the actual generating coset. The cyclic extension argument describes the relevant eigenspace, and the Hall class map is compatible with the central-character sector. The passage to groupoids transports the base object along with the loop.

In the mixed two-cycle estimate, the p-primary correction is removed by comparing central-character multiplicities in a common loop-class permutation space. Section decomposition is normalizer-natural because p-elements have unique p-element lifts in the prime-to-p central cover. Stable sections admit the actual transporter return. The fixed-label subcategory has a probe category which is a direct summand of the original probe category.

For stationary factors, the restriction matrix gives a nonnegative matrix with positive eigenvector and spectral radius equal to the subgroup index. For a long cycle, the projection of the commuting base actor to one coordinate is injective; dropping the closing label condition gives the required upper bound. The trace formula retains its scalar phases before absolute values are taken.

The cyclic completion lemma uses a fixed simple to trivialize the quotient associator, and the injectivity of cyclic H3 for prime-to-p roots is in the correct direction. Coupling is performed by a kernel and quotient; the orbit averaging and `|U|_p = |K_0|_p |U/K_0|_p` retain coupled bases.

The permutation lemma separately treats orbit size two, where the general subgroup class bound would be insufficient. Its intransitive step uses a subgroup normal in the transitive ambient image. In the capacity theorem, p-solvability is required only of coordinate actors and their base kernels; the top permutation group remains arbitrary.

The defect-three coordinates invoke the affine theorem after the other cases have been proved. This is not an internal cycle in the capacity proof, provided the affine theorem only invokes the earlier mixed two-cycle result, as its separate reviewer must check.

## 5. Actual probes and actor size

The prime-to-p cohomology calculation gives an associative integral order with the requested residual ordinary category. The coinduced-center construction retains the literal original quasisimple group. I checked the displayed Shapiro cochain: the four-variable cocycle identity gives `dc = iota(z)` with the indicated right translation action.

The evaluation idempotent selects the kernel-trivial sector, whose algebra is the corrected order. The scalar comparison with the genuine group algebra is a central cocycle and becomes a finite prime-to-p scalar cover. The proof that the resulting sector is a single block uses the nonisomorphic indecomposable bimodule summands and their local endomorphism rings; the equal diagonal residues are sufficient to rule out a nontrivial central idempotent.

The final Fong reduction is applied to a normal prime-to-p group and a positive-defect block with `O_p(I)=1`. The first general conclusion of An--Eaton Theorem 3.1 has the required scope; the later TI hypotheses are not imported. The perfect derived subgroup above the simple socle and the centralizer calculation give the desired almost-simple central extension and central-index bound.

LL20's Green injection does apply to actual automorphism bimodules: Example 1.2 identifies them as trivial-source modules. The kernel bound and normalizer quotient come from the normal-defect source algebra. The Schur--Zassenhaus complement contains the inertial subgroup because that subgroup is the unique prime-to-p complement inside its direct product with the inner p-kernel. The independent-base-pair argument then improves the usual quadratic bound by a factor of p; its right GL2 action has prime-to-p orbit stabilizers.

The mass bounds use complete corrected probes, including a whole correction furnished by a fixed label. They do not assume that every subgroup admits a correction without verifying this. The small cyclic defects 3 and 5 are handled with the full normal-source actor bound, not just an order bound on one chosen subgroup.

## 6. Blockwise reductions and the final induction

### 6.1 Normal p-subgroup comparison

The central-fiber matrix identity follows by Fourier inversion on a central p-subgroup and the freeness of primitive corners over its local group algebra. The row-count inequality is a separate center-permutation-lattice argument; it is not inferred from equality of Gram matrices.

For an abelian normal p-subgroup, the original and split groups have the same p-regular lift classes and the same centralizer orders. Consequently the full Brauer Gram matrices, Cartan matrices, and connected block partitions agree. The proof does not incorrectly identify these blocks with the quotient's blocks.

For each `(lambda,c)` packet, nonnegative modular induction together with the central-fiber incidence graph puts the whole packet in a single matched block. The same induction matrix and partition apply to the split group. Taking one orbit representative lambda and one actual quotient block c prevents repeated counting. Iterating along a central elementary series preserves the previously split layers, and produces the asserted elementary abelian V.

In normal-p descent, the normal p-subgroup lies in every defect group. The Brauer images of distinct covering blocks would split the primitive centralizer-block idempotent, giving uniqueness. The Sylow-preimage block and the identical coefficient-deletion Brauer map give the lower defect bound, while normal-block intersection gives the upper bound. Thus the comparison really produces a smaller-defect counterexample.

### 6.2 Relative selector and ordinary comparison

The minimum is lexicographic in defect order, central index, and group order. Fong--Reynolds proper inertia, defect-zero quotient, and faithful central-character quotient are used with the correct decreasing coordinate. All remaining component blocks have positive defect, which is needed to exclude component permutations from the integral-inner subgroup. Cancellation of bimodule restrictions justifies factorwise innerness.

The primitive selector d is fixed before ordinary evaluation. Central idempotents lift under the complete central specialization because the lifted off-diagonal corners have zero reduction and vanish by Nakayama. The second tensor factor is free over R, which suffices for the Cartan corner-rank calculation; the proof does not require the block order A to be free over its center.

Murai's integral-inner characterization identifies the ramification subgroup, and his uniqueness theorem applies to the selected block c. The common idempotent in the Sylow preimage then proves the exact relative p-factor in the defect identity.

The full ordinary comparison is performed on one action groupoid. Restriction to N and conjugation of its centralizer coordinates have a common residual value because all ordinary central evaluations of the local center have the same residue. The principal-unit part becomes one finite central p-cover, after a residue-one gauge. The same d0 lifts at every object and is transported by every arrow; hence its sum is a central selector in the entire covering groupoid algebra. The central-p multiplicity comparison can therefore be made without changing to an unrelated lower block.

The residual quotient retains the actual carry in N. Its associator is scalar because its N-degree is one, not because the entire relative center is scalar. Comparing the actual and component tensor product systems through integral units gives one central ratio and hence one tuple-independent cochain. This is the required whole correction on Q.

### 6.3 Final two branches

When every component has smaller defect, the actual-probe theorem supplies the induction input irrespective of the realizing group's order. In the equality case, positivity of every component and the exact product force one component, a defect-zero relative block, and a prime-to-p effective quotient. The realization has no larger central index. A strict decrease uses the second coordinate; equality uses only the stated almost-simple endpoint and its own strict-Levi or smaller-defect induction hypotheses.

This dependency skeleton has no additional circular use of the odd-prime conclusion. Its unconditional closure still depends on the complete affine and endpoint proofs, including their classical-source inputs.

## 7. Small revisions recommended

1. Define the Frattini notation at its first use: `Phi(D) = D^p [D,D]` for a finite p-group D.
2. Before defining `A_b`, state that `Pic(A)` is the group of isomorphism classes of invertible `(A,A)`-bimodules, with tensor product over A.
3. For readers outside fusion-category theory, define `Vec(A,omega)` explicitly as finite-dimensional A-graded vector spaces with the indicated associator. This adds a definition, not a new hypothesis.
4. GP16 Remark 3.1 can be added to the existing Theorem 7.9 citation to match the new endofunctor proof precisely.

These are notation or exposition recommendations. They do not resolve or replace any independent gap in the classical and exceptional parts.

## 8. Primary-source verification and limits

The following source statements were inspected directly in this audit:

- Bonnafé--Rouquier, Theorem 11.7 and Theorem B-prime: `revision_audits/primary/BR03.pdf` and its extracted text, DOI https://doi.org/10.1007/s10240-003-0013-3.
- Bonnafé--Dat--Rouquier, section 7.A, Theorem 7.2, Lemma 7.4, and the upstairs construction in section 7.C: https://doi.org/10.4007/annals.2017.185.2.5.
- Ruhstorfer, arXiv:2010.04468v1, Lemma 2.10, Corollary 2.13, Lemma 3.1 with its proof, Remark 4.7, and the rational adjustment in Proposition 4.8: https://arxiv.org/abs/2010.04468v1.
- Taylor, Lemma 6.5 with its proof, Proposition 8.3, and Corollary 8.8, in the local original PDF and extracted text.
- Galindo--Plavnik, Remark 3.1 and Theorem 7.9: https://arxiv.org/pdf/1407.2783v4. The pointed invertibility criterion and its required bitransitivity/nondegeneracy match the construction.
- Linckelmann--Livesey, Theorem 1.1, Example 1.2, Propositions 2.4, 3.3, 3.4: https://arxiv.org/pdf/2004.10131.
- Murai, Lemma 2.1 and Theorem 3.5: https://ir.library.osaka-u.ac.jp/repo/ouka/all/26820/ojm50_04_1007.pdf.
- An--Eaton, section 3 and the first conclusion of Theorem 3.1: https://eprints.maths.manchester.ac.uk/51/1/pc09k1q7ac55wpyb.pdf.
- Halasi--Podoski's general coprime base-two statement was checked against the authors' arXiv record, https://arxiv.org/abs/1212.0199. Fetching the versioned PDF failed in this audit; the independent base-pair argument after that standard theorem was checked in the manuscript.

No numerical test is used here as a substitute for these universal arguments. No theorem of the old local prime-two draft is accepted as a black box. Complete proofs of Lang--Steinberg, the classification of finite simple groups and their outer automorphism descriptions, basic block theory, and the cited public geometric results are not reproduced by this audit. Those remain explicitly identified established inputs.
