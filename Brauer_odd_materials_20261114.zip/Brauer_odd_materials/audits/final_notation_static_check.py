#!/usr/bin/env python3
"""Reproduce the final source-level notation/citation checks (not a proof verifier)."""
from __future__ import annotations

import argparse
import collections
import hashlib
import json
import re
from pathlib import Path


def inspect(source: Path) -> dict:
    s = source.read_text()
    flat = " ".join(s.split())
    labels = re.findall(r"\\label\{([^}]+)\}", s)
    refs = [
        key.strip()
        for group in re.findall(r"\\(?:ref|eqref|autoref|pageref)\*?\{([^}]+)\}", s)
        for key in group.split(",")
    ]
    keys = re.findall(r"\\bibitem(?:\[[^]]*\])?\{([^}]+)\}", s)
    citations = [
        (match.start(), [key.strip() for key in match.group(1).split(",")])
        for match in re.finditer(r"\\cite\w*\*?(?:\[[^]]*\]){0,2}\{([^}]+)\}", s)
    ]
    cited = [key for _, group in citations for key in group]

    fragments = {
        "N01": [r"Let \(X\) be the set of isomorphism classes of simple objects of \(\mathcal C_1\boxtimes\mathcal C_2\)"],
        "N02": [r"let $M=\F_q^d$ with its underlying $\F_p$-module structure"],
        "N03": [r"Put $m=\dim_K(V)/n$ and $z=|Z|$"],
        "N04": [r"where $t=p^f$", r"$a_p=v_p(|S|)$", r"O\le2aN", r"Using $a\le s/2$"],
        "N05": ["The degree allowances enlarge the range to be checked."],
        "N06": [
            r"\operatorname{rad}(n)=\prod_{\ell\mid n}\ell",
            r"$\sigma_1(n)=\sum_{a\mid n}a$",
            "$k_{2'}(H)$",
            "Let $U$ be the module of one coordinate.",
            r"Put $Z=Z(D)=Z(R)$, $z=|Z|$ and $q=p^f$",
            r"$m=\dim_{\F_q}(U)/n$",
        ],
        "N08": ["Let $H$ be the signed-coordinate group, with sign kernel $N$ and coordinate image $U$."],
        "N10": [r"\sum_{x\in (X^a)^{s,t}}"],
        "N11": [r"Apply Lemma~\ref{lev:partial-morita} to the bimodule $M_e$"],
        "N12": [r"\rk\operatorname{Rep}_K(K\otimes_\cO\mathcal R_\beta)"],
        "N13": [
            "For a formal power series $F(t)$, write $F_w=[t^w]F(t)$.",
            r"Let $\mathfrak p(n)$ denote the number of integer partitions of $n$",
        ],
        "N14": [r"For the action on characters, put $E^0=\langle F_r,\gamma\rangle$ on $K=\SL_4^F$"],
        "N15": [r"Write $T^\perp=\{\gamma\in\Gamma:\xi(\gamma)=1\text{ for all }\xi\in T\}$ and $e_{\xi T}=e\xi$."],
        "N17": [
            r"Let \(H=[\mathbf L,\mathbf L]^F\) be the derived source group.",
            r"\(\Delta_H\)",
            r"Put \(H_ie_w=w_i e_w\)",
        ],
        "N18": [r"extension by \(\nu_\alpha\in\Irr(I_\alpha)\), so \(\nu_\alpha|_{A_2}=\alpha\)"],
        "N19": [r"For each generic degree write \(cq^u\prod_{j=1}^{30}\Phi_j(q)^{e_j}\)"],
        "N20": [r"Let \((D,e)\) be the selected maximal Brauer pair containing the source subpair \((A,b_L)\)"],
        "N21": [
            r"Let \(\Lambda\) be the \(E_8\) root lattice",
            r"\(Q(\Psi_i)\) be its root lattice.",
            r"K/\operatorname{im}(\mathbf K_{\mathrm{sc}}^F)",
            r"N_S(T,\lambda)=N_K(T)",
        ],
        "N22": [r"For scalar Frobenius, put \(d=\operatorname{ord}_p(q)\) and \(s=(q^d-1)_p\)."],
        "N23": [r"The four nontrivial order factors of \({}^2A_4(q^2)\) are"],
        "N25": [r"Let \(Q\triangleleft G\) be a normal \(p\)-subgroup, and let \(B\) be a block of \(G\)."],
        "N26": [r"Construct the finite covering groupoid \(\widehat{\mathscr G}\)"],
    }
    item_checks = {
        name: all(fragment in flat for fragment in pieces)
        for name, pieces in fragments.items()
    }
    item_checks["N07"] = (
        r"\Omega\setminus R" not in s
        and s.count(r"\Omega\setminus\Delta") >= 2
    )
    item_checks["N09"] = s.count(r"\mathfrak p(t)") == 3
    item_checks["N11"] &= r"M_0=Me" not in s
    item_checks["N24"] = r"\phi_{2,1}" not in s and r"\phi_{21}" in s

    new_type_d_checks = {
        "old_annihilator_identity_removed": r"\epAnn(I_b)" not in s,
        "graph_torsor_removed": "ep:graph-torsor" not in s,
        "nu_defined_at_first_use": (
            r"\(\nu\in\Irr(Z)\) be the central character prescribed" in flat
        ),
        "xi_domain_explicit": r"\(\xi\in\Irr(Z(X_1))\)" in flat,
        "section_normalized": r"with \(1\) representing the identity coset" in flat,
        "scalar_function_explicit": r"a(s c r)=\eta(c)\qquad(s\in\Delta S,\ c\in C)" in flat,
        "quotient_character_domain_explicit": r"\(K(Y/S)/(Y/S)\) to \(J/Y\)" in flat,
    }
    patterns = {
        "disclosure_or_placeholder": (
            r"AI use|Scholarly Credit|acknowledg|\bconditional\b|TODO|FIXME|TBD"
        ),
        "local_absolute_path": r"/workspace/|/mnt/data/|/tmp/",
        "removed_process_prose": (
            r"final public extension input|independent unipotent theorem|"
            r"broad derived-source|guessed Sylow exponent|"
            r"Jordan decomposition legally|loose numerical bound"
        ),
    }
    scans = {
        name: [
            {"line": line_no, "text": line}
            for line_no, line in enumerate(s.splitlines(), 1)
            if re.search(pattern, line, re.IGNORECASE)
        ]
        for name, pattern in patterns.items()
    }
    scans["unexpanded_old_partition_p"] = [
        {"line": line_no, "text": line}
        for line_no, line in enumerate(s.splitlines(), 1)
        if re.search(r"(?<![A-Za-z_])p\((?:n|d|t)\)", line)
        and "mathfrak p" not in line
    ]
    prime_two_positions = [
        pos for pos, group in citations if "TangPrimeTwo26" in group
    ]
    results = {
        "scope": "source-level notation and citation checks; not mathematical verification",
        "file": str(source),
        "sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
        "lines": len(s.splitlines()),
        "whitespace_words": len(s.split()),
        "label_count": len(labels),
        "bibliography_count": len(keys),
        "duplicate_labels": [
            key for key, count in collections.Counter(labels).items() if count > 1
        ],
        "unresolved_refs": sorted(set(refs) - set(labels)),
        "unresolved_citations": sorted(set(cited) - set(keys)),
        "uncited_bibliography": sorted(set(keys) - set(cited)),
        "prime_two_body_citation_count": len(prime_two_positions),
        "prime_two_body_citation_lines": [
            s[:pos].count("\n") + 1 for pos in prime_two_positions
        ],
        "prime_two_only_in_final_deduction": (
            len(prime_two_positions) == 1
            and s.index(r"\section{The final all-prime deduction}")
            < prime_two_positions[0]
            < s.index(r"\begin{thebibliography}")
        ),
        "new_type_d_labels": [key for key in labels if key.startswith("ep:d-")],
        "external_input_include_commands": re.findall(
            r"\\(?:input|include)\{[^}]+\}", s
        ),
        "resolved_items_present_in_assembled_source": dict(sorted(item_checks.items())),
        "new_type_d_notation_checks": new_type_d_checks,
        "scans": scans,
        "front_matter_checks": {
            fragment: fragment in s
            for fragment in [
                r"\author{Qiyue Tang}",
                r"\email{tangqy24@mails.tsinghua.edu.cn}",
                r"\date{November 14, 2026}",
                r"\documentclass[11pt,reqno]{amsart}",
                "linkcolor=AccentBlue,citecolor=AccentBlue,urlcolor=AccentBlue",
            ]
        },
    }
    results["source_checks_pass"] = (
        all(item_checks.values())
        and all(new_type_d_checks.values())
        and all(results["front_matter_checks"].values())
        and results["prime_two_only_in_final_deduction"]
        and not any(scans.values())
        and not any(
            results[key]
            for key in [
                "duplicate_labels",
                "unresolved_refs",
                "unresolved_citations",
                "uncited_bibliography",
                "external_input_include_commands",
            ]
        )
    )
    return results


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    results = inspect(args.source)
    output = json.dumps(results, indent=2) + "\n"
    if args.output:
        args.output.write_text(output)
    print(output)
    raise SystemExit(0 if results["source_checks_pass"] else 1)


if __name__ == "__main__":
    main()
