# Fresh moving-D regular-anchor audit

Date: 2026-11-14

Auditor: `/root/moving_d_anchor_fresh_attack`

## Scope and verdict

This is an independent audit of the replacement for the moving isolated
type-D paragraph in `brauer_odd_revision/odd_endpoints.tex`. It is not a
certification of the entire Brauer conjecture manuscript or of the preceding
1335-line toral construction.

**The old argument contains a genuine mathematical type error.** Its
annihilator formula uses the block's integral-inner subgroup where the cited
primary argument uses one ordinary character's diagonal inertia. The
hypotheses that force the distinguished central involution into the relevant
component image have not been established for the manuscript's object.

**The replacement by diagonal-orbit cases 1, 2, and 4 closes this particular
gap**, using the already proved simultaneous-witness, strict-Green,
same-label, and linear-extension lemmas. It does not require an unproved
matching of Clifford-correspondent blocks in a proper regular inertia group.
The regular anchor is needed only for orbit 1, where the regular inertia is
the entire regular group. For orbits 2 and 4 the discrepancy extends directly
after the full centralizer has been removed.

The candidate reviewed in full was
`revision_audits/moving_d_anchor_replacement.tex`, SHA256
`f98b0a2cf2080d7795188790979e8855906b3b49f17d9dd4e053f2d3a98f2fb8`.
Two small explicit proof completions were sent to its author and root:

1. Define the scalar cochain by `a(s c r)=eta(c)`, with `s` in the diagonal
   copy of `S`, `c` in the centralizer, and `r` a representative modulo their
   product. This explicitly makes it a function on the quotient by `S`.
2. Before applying same-label to the fibre product, state why restriction
   of the two genuine extensions to the integral-inner subgroup produces
   corresponding blocks: the restrictions are irreducible, the resulting
   blocks are invariant, and block induction is compatible with normal
   restriction. The one-dimensional labels can then be compared.

These are consequences of the stated hypotheses, not additional mathematical
assumptions. The detailed arguments follow.

**V3 integration recheck (preserved historical record):** both completions are present in v3 and were
read again in their actual integrated context. The v3 replacement is present
verbatim in `odd_endpoints.tex` and, with the assembler's bibliography-key
normalization only, in the standalone TeX. The old graph-torsor label and
ill-typed annihilator formula are absent. The final hashes are:

| File | SHA256 |
|---|---|
| `revision_audits/moving_d_anchor_replacement_v3.tex` | `27c152fb3d64d8d21d1f47aecdada4615ac54a77549617c6921670ef9933bf06` |
| `brauer_odd_revision/odd_endpoints.tex` | `64644596793cdfaa46b64f4f772c23edbd304bf7b0c2aa5a538522c6cc5eedf7` |
| `brauer_odd_delivery_20261114/Brauer_kB_odd_primes_20261114.tex` | `a1c6812c51eb43e147e2337a4c4f6cc71565b92a5f4a95502d10623f5b71db9f` |

The source-supported mathematical verdict for this specific moving-D gate
is **closed by the integrated v3 argument**. No additional premise of
selected-block matching in a proper regular inertia group is being used.
This scoped verdict is not a new audit of the rest of the standalone text.

The historical v3 integration checker is preserved as
`revision_audits/moving_d_anchor_fresh_attack_final_check_v3.py`; its receipt is
`revision_audits/moving_d_anchor_fresh_attack_evidence/final_integration_receipt_v3.json`
(the original `final_integration_receipt.json` is retained too).
All seven text/file-scope checks passed. These checks supplement the
mathematical reading; they do not prove the theorem by computation.

### Final frozen version: v4

The root made two further explicitness edits. A direct unified diff was
read: the only changes specify that the section uses `1` for the identity
coset, and that the character being extended to `J/Y` has domain
`K(Y/S)/(Y/S)`. The first normalizes the scalar cochain at the identity;
the second states the quotient domain already used by the preceding
descent. Both are valid clarifications and do not change the mathematical
route or introduce a hypothesis.

The final v4 was independently checked against the integrated endpoint
and standalone TeX, including the two new sentences. **All nine checks
passed**, and the mathematical verdict for this moving-D gate remains
closed. These are the final frozen hashes:

| File | SHA256 |
|---|---|
| `revision_audits/moving_d_anchor_replacement_v4.tex` | `736eb165dd9c31949f17b0b90b72dbae41dcc44e001b6b9570e9acd0e99ceb73` |
| `brauer_odd_revision/odd_endpoints.tex` | `265b90278f69c1d5817d597aaeff8a1e552c71a6720b844b391370ab27be3511` |
| `brauer_odd_delivery_20261114/Brauer_kB_odd_primes_20261114.tex` | `bbd43d426c582f46e437a4a6e7c356938476a7fa305edda3f609b8da336c7f00` |

The current reproducible checker is
`revision_audits/moving_d_anchor_fresh_attack_final_check.py`; it writes
`revision_audits/moving_d_anchor_fresh_attack_evidence/final_integration_receipt_v4.json`.
The v3 checker and both v3 receipt filenames are preserved and have not
been overwritten by the v4 check.

## Primary sources actually read

The local PDF texts, not earlier audit PASS labels, were used.

| Source | Passages read | Role in this audit |
|---|---|---|
| Cabanes--Späth, *The McKay Conjecture on character degrees*, arXiv 2410.20392v2 | Proposition 2.12 and its proof, Theorem 2.18, Proposition 3.8, proof of Theorem 3.11 | All-ordinary simultaneous witnesses; exact scope of the invalid old component argument |
| Brough--Ruhstorfer, *Equivariant character bijections and the inductive Alperin--McKay condition*, arXiv 2307.14730v1 | Section 2 assumptions, Lemmas 2.1--2.2, Proposition 2.3, Section 3 assumptions, Corollary 3.4 and proof, Lemma 3.5, Proposition 3.7, Corollary 4.3, Section 4.2 and Lemma 4.8 | Exact connected-centre block support, source Brauer pair, local unique covering block, maximal extendibility |
| Späth, *Extensions of characters in type D and the inductive McKay condition, II*, Invent. Math. 242 (2025), 45--122 | Theorem A, printed p. 47; Section 3.3, printed pp. 63--64 | Global ordinary good transversal and multiplicity-free regular restriction |

Theorem 4.9 of BR23 is explicitly stated for types B and C; it is **not**
used here as a type-D inductive theorem. Its earlier parameter and
source-pair results have broader, explicitly checked hypotheses. Likewise,
CS25 Proposition 2.12 gives the central character-triple relation, not an
automatic block-isomorphic triple relation. The block assertion needs the
source-pair and Green arguments below.

The extraction program
`revision_audits/moving_d_anchor_fresh_attack_extract.py` records the PDF
hashes and selected pages in
`revision_audits/moving_d_anchor_fresh_attack_evidence/primary_extraction_receipt.json`.
The program performs text extraction and provenance checks; it is not a
computer verification of the mathematical proof.

## 1. Why the old moving-D paragraph fails

The manuscript defines `I_b` as an integral-inner subgroup acting on the
whole block algebra. CS25's proof of Theorem 3.11 instead starts with an
individual character in one of the particular sets treated there. It uses
Lemma 3.12 twice:

1. the distinguished involution `h_0` is in that character's kernel;
2. its diagonal inertia is trivial or generated by the class of `h_0`.

The annihilator of that individual diagonal inertia is the stabilizer of an
overcharacter under the dual linear-twist action. This gives
`h_0` in the corresponding component image. Only then are the hypotheses
of **Proposition** 3.8 satisfied. The manuscript's old paragraph supplied
neither an identification with that individual inertia nor these two
hypotheses. Renaming `I_b` would leave the missing argument intact.

The old text also calls CS25 Proposition 3.8 a lemma. Deleting the obsolete
route removes this erroneous citation. A reference scan found the only
application of `ep:graph-torsor` in that same old paragraph; its associated
field-translation paragraph is therefore dispensable once the new route is
integrated.

## 2. The exact regular blocks really correspond

Work first on the simply connected natural cover; central prime-to-p
quotients can subsequently be handled by the manuscript's existing descent.
Let `X` be its connected-centre regular group, `S` the lower group,
`D` the abelian lower defect, and `Z_p=O_p(Z(X))`.

The quotient `X/(S Z(X))` is a 2-group. Since `p` is odd and
`p` does not divide `|Z(S)|`, a defect of a specified covering block is

`D_tilde = D Z_p`.

Indeed `S Z(X)=S Z(X)_{p'} x Z_p`, with trivial intersection between
`S` and `Z_p`. The central p-factor adds that factor to the defect, and
the remaining extension has prime-to-p index. This defect is abelian.
BR23 Corollary 3.4, applied as in its proof to the regular covering source,
therefore identifies it with `Z(L_tilde)_p`. In particular,

`C_X(D_tilde)=L_tilde` and `N_X(D_tilde)=N_X(D)`.

For the specified regular source `(L_tilde,lambda_tilde)`, set
`c_L_tilde=b_{L_tilde}(lambda_tilde)`. The proof of BR23 Corollary 3.4
explicitly supplies the Brauer subpair

`(Z(L_tilde)_p,c_L_tilde)`.

Its first member is the entire defect group, so it is maximal. This
identifies the **actual** Brauer-correspondent block `c_tilde` of
`N_X(D_tilde)`, independently of the character bijection. Equivalently,
the source-centralizer argument recalled at the start of BR23 Section 4.2
gives the unique normalizer block covering `c_L_tilde`.

Every local character in the source parameterization covers an ordinary
character `theta_tilde` of `c_L_tilde`. Consequently it lies in this
particular `c_tilde`, regardless of which extension map was used to write
the local Clifford parameterization. On the global side, the proof of
BR23 Lemma 2.2 explicitly puts all constituents of the indicated
Harish--Chandra slice in the specified block `b_tilde`; Proposition 3.7
supplies the height-zero exhaustion. The abelian defect and the height-zero
theorem make this the whole ordinary set. Thus the regular map has

`Omega_tilde(Irr(b_tilde)) = Irr(c_tilde)`

separately for each specified covering block. This assertion is stronger
than linear-twist equivariance and is justified by the same maximal source
Brauer pair, rather than assumed.

## 3. Why proper regular inertia groups are unnecessary

Let `r` be the diagonal orbit length of a good ordinary constituent. In
natural type D it is 1, 2, or 4. The global good transversal comes from
Späth's all-ordinary Theorem A. CS25 Proposition 2.12 explicitly states in
its proof that no character-degree hypothesis is used. The local good
transversal and extension systems remain separate earlier inputs of the
manuscript; they have not been inferred from the global theorem.

For `r=1`, `X_chi=X`. Maximal extendibility and the abelian quotient imply
that every regular overcharacter is an actual extension of `chi`.
Full linear-twist covariance identifies the local inertia with the entire
regular normalizer, so its paired overcharacter is likewise an extension.
The two genuine extensions themselves are in the corresponding blocks
proved in Section 2 above. There is no induction from a proper `X_chi`.

For `r=2`, the residual diagonal inertia has order at most two and is
centralized by its field--graph stabilizer. In split type D4, its
nontrivial diagonal line cannot be stabilized by a triality element of
order three. Good-origin factorization therefore makes the actual outer
stabilizer abelian. If the full diagonal group has order two, the diagonal
inertia is trivial and the non-triality field--graph group is abelian as
well.

For `r=4`, the diagonal inertia is trivial, so the actual outer stabilizer
embeds into the field--graph group. The relevant group is a section of
`S_3 x C_f` (cyclic field--graph group in the twisted case). The earlier
invariant-linear-extension lemma applies.

Thus the potentially invalid implication

`matched regular top blocks => arbitrarily chosen proper-inertia Clifford blocks match`

is not used in any of these cases.

## 4. The full centralizer is removed before extending the discrepancy

Write `J=U_chi`, `Z=Z(U)`, `K=I/S`, and let `zeta` be the invariant
linear discrepancy on `K` from factor-completion. The subgroup `S Z/S`
is contained in `K`. The hypothesis `C_U(S)=Z(U)` identifies it exactly
as the kernel of `J/S -> Out(S)`.

For a central element, the strict-Green-compatible implementers are the
same scalar on both sides. One can express this by choosing the identity
implementer before normalization, or by the candidate's finite
prime-to-p scalar-cocycle normalization: a prime-to-p torsion central
unit in the local block centre is scalar, by the simple-root lifting
argument. The strict Green identity equates the two scalars. The
associated projective representations also have the same prescribed
scalar on the full centralizer. Therefore their two kernel cochains have
the same value there, and

`zeta|_{S Z/S}=1`.

The character consequently descends to the corresponding normal subgroup
of the genuine outer stabilizer `J/(S Z)`. For orbit 2, finite abelian
character extension applies. For orbit 4, the field--graph section lemma
applies. Inflation back to `J/S` retains the prescribed centralizer
scalars. No regular anchor is needed in these two cases.

## 5. Removing the central p-factor before using strict Green

The finite regular quotient `X/S` may contain a central p-part; it must
not silently be substituted into a lemma requiring a prime-to-p quotient.
Let `X^0/S` be its Hall prime-to-p subgroup. Since the only p-part comes
from `Z_p`,

`X = X^0 x Z_p`.

The two genuine regular extensions have the same `Z_p` character, by
full central-character compatibility. Their restrictions to `X^0` and
`N_{X^0}(D)` still lie in corresponding blocks, now with defect `D`.
All subsequent strict-Green applications use this prime-to-p regular
group or the prime-to-p fibre product below.

## 6. Explicit fibre-product transport to the actual group

This step is necessary: preserving a regular block is not by itself an
argument about an arbitrary actual central cover.

Let `Y` be the inverse image in `J` of its diagonal outer subgroup, and
let `X_1 <= X^0` have the same image in `Aut(S)`. Define

`F = {(y,x) in Y x X_1 : Int(y)|_S = Int(x)|_S}`.

Embed `S` diagonally. The two projection kernels are `1 x Z(X_1)` and
`Z x 1`, both central prime-to-p groups. The normalizer of diagonal `D`
is the analogous fibre product of the two normalizers. Moreover
`F/Delta S` has prime-to-p order.

Inflate the restrictions of the genuine regular extensions along the
second projection. Their blocks remain Brauer-correspondent: inflation
in the trivial sector of a central prime-to-p kernel preserves the
maximal Brauer pair, and the full preimage of the defect has diagonal
`D` as its unique Sylow p-subgroup.

To compare the integral-inner coefficients, restrict these two genuine
extensions to the integral-inner subgroup of `F` and its local
intersection. Both restrictions are irreducible, since their restrictions
to `Delta S` and its lower normalizer are already irreducible. Their
blocks are invariant under the whole carrier and its normalizer.
Compatibility of Brauer induction with normal restriction pairs these
two kernel blocks: the upper corresponding block covers the induced
local restricted block and the global restricted block, and covered
blocks form one orbit; both candidates here are invariant. Strict Green
and same-label now identify their one-dimensional coefficient labels.
Their kernel-cochain ratio is one.

Let `xi` be the regular central character and `nu` the character of the
actual centralizer `Z` prescribed by the actual block. They agree on
`Z(S)`. On `C=Z x Z(X_1)` define

`eta(z,z_x)=nu(z) xi(z_x)^(-1)`.

It is trivial on `Delta Z(S)`. Choose representatives `r` for
`F/(Delta S C)` and define

`a(s c r)=eta(c)` for `s in Delta S`, `c in C`.

This is well defined and constant on cosets of `Delta S`. It need not
be a linear character; it is a scalar cochain. Multiplying both inflated
matrix systems by `a` gives the common factor

`a(t) a(t') / a(tt')`.

Their common scalar at `(z,z_x)` becomes `nu(z)`. In particular the
kernel `1 x Z(X_1)` acts trivially, so both projective systems descend to
the actual `Y` and its normalizer. Since the cochain is common, it does
not change the ratio of the two inner-kernel cochains. That ratio remains
one after descent.

The full simultaneous systems are transported using the manuscript's
explicit change-of-carrier construction, choosing its representatives to
agree on this subgroup. The regular/external mixed-product formula and
full-centralizer scalar compatibility are retained. This gives

`zeta|_{K intersect (Y/S)}=1`.

Extend `zeta` to `K(Y/S)` trivially on `Y/S`, pass to `J/Y`, and apply
the field--graph invariant-linear-extension lemma. This supplies the
factor-completion correction in orbit 1. The argument never assumes the
desired actual-upper-block matching; that matching is the conclusion of
factor-completion.

## 7. Integration checks

Before freezing the final manuscript:

- Remove the old annihilator/component paragraph rather than changing the
  name of its subgroup.
- Remove the unused graph-torsor lemma and its field-translation paragraph
  if no new applications have been introduced. The scan in this audit
  found only the old moving-D application.
- Retain the CS25 simultaneous-witness criterion and the actual global and
  local good-transversal proofs.
- Keep the exact regular maximal-pair argument, the orbit split, the
  full-centralizer normalization, the `X^0` reduction, and the fibre
  product in the replacement. Omitting any of these loses an interface
  checked here.
- Correct “Lemma 3.7” to “Proposition 3.7” in the earlier BR23 support
  citation as well.
- Run the ordinary TeX cross-reference check after deleting
  `ep:graph-torsor`.

No code or finite computation substitutes for the general group-theoretic
arguments in this report. The code supplied here preserves primary-source
reading evidence only.
