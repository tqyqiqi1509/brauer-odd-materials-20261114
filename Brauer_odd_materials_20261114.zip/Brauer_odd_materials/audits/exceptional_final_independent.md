# Fresh independent audit of the exceptional endpoint module

Date: 2026-11-14. Reviewer: fresh independent subagent assigned by the root reviewer.

## Verdict and exact scope

**This review does not certify an unconditional proof of Brauer's conjecture.**
The endpoint theorem explicitly retains the two classical rational-carrier inputs
in `cl:toral-pending`. They are mathematical hypotheses, not a harmless formatting
qualification. The present endpoint proof can use a successful new proof of those
inputs, but this review does not supply that proof. The separate global-capacity,
foundations and proper-Levi modules also require their own audits.

Within the exceptional module I found two mandatory defects in the presentation
of the argument: the raw/transported Frobenius closing relation was ambiguous in
a way that can double-count the twist, and the global all-character transversal
input for the simultaneous-witness criterion was not explicitly supplied. Both
have now been repaired with precise group dictionaries and applicable primary
theorems. The first was repaired by root after our independent algebraic check;
the second was added by me under root's explicit authorization. I found no further
confirmed false exceptional assertion in the reviewed version. This statement is
limited to the mathematical interfaces and arithmetic checks described below; it
is not a replacement for the remaining classical or global proof.

## Reading record

Initial frozen body:

- File: `brauer_odd_revision/odd_endpoints.tex`.
- 3454 lines.
- SHA-256: `3053592104eefd7546bab82c3207931f0c2c124a1e79047751e883c0abe43b75`.

I read the body sequentially from its beginning to its end. The first ranges were
1–470, 471–1040, 1041–1585 and 1586–2110; the remainder was read in smaller
successive ranges. A truncated tool response was reread and was not counted as a
completed reading. Root's subsequent changes caused overlapping ranges, not an
unread gap. I then reread the complete changed carrier/toral-return passages,
combined-transport hypothesis, characteristic-centre lemma, and the newly added
global-input passage. This is a full sequential base reading plus a full reread of
the changed passages, not a claim that an unchanged old PASS was reused.

Version at completion of my authorized global-input edit and its rereading:

- 3532 lines.
- SHA-256: `864b8f20fde4b7d9432533b8065f4716fcf81951aa5ad38be03c4a429cff0298`.

Root then corrected the algebraic/finite torus notation identified below. I read
that complete changed paragraph again. The final audited body is:

- **3533 lines**.
- **SHA-256: `1cf4a48acc995f90ef8db4608b900415c803186f318e8c40345f0c2edd076654`.**

The prior repair report was used only as a map to changed assertions and sources.
Its verdicts were not treated as evidence.

## 1. Mandatory repairs found in this review

### 1.1 Raw versus transported rational operators

With `j_h(x)=hxh^{-1}` and `h^{-1}F(h)=v`, direct calculation gives

\[
A_h(a)=j_h^{-1}aj_h=\operatorname{Int}(h^{-1}a(h))a,
\qquad A_h(ab)=A_h(a)A_h(b).
\]

Consequently

\[
A_h(\gamma)A_h(F_r)^f=A_h(F)=F_v,
\]

which is already the identity on the finite fixed-point group. An additional
factor `v` in this identity would count the twist twice. In contrast, for the raw
standard lifts in the twisted presentation, the relation

\[
v r_\gamma r_f^f=1
\]

is the correct closing relation. The original hats did not distinguish these two
meanings. The repaired text now defines both dictionaries and never places the
additional `v` in the transported identity.

I checked the original Späth 2009 statements, not just the abstract:

- Theorem D supplies a very good regular Sylow twist.
- Lemma 6.1(a),(b) supplies the identity/longest-lift choices for the retained
  split and twisted E6 cases at `e=1,2`.
- Lemmas 8.1–8.2 supply the normalizer/field/graph equivariance used here.
- Lemma 8.2 explicitly explains that in the exceptional graph-root cases the
  field automorphism is a power of the graph automorphism.

Thus the corrected E6 model is covered by the primary source. In E8 the raw field
map fixes the integral Tits group. The repaired cyclic argument applies to the
**entire local irreducible character**

\[
\psi=\operatorname{Ind}_{N_\vartheta}^N(\Lambda(\vartheta)\eta),
\]

inside its actual inertia group. If `g^m=w in N`, an intertwiner satisfies
`I^m=c rho(w)` and a scalar rescaling imposes the actual power relation. This is
also the right argument for F4 in characteristic two and G2 in characteristic
three: `tau^2=F_r` is retained, rather than treating the graph root and field as
independent cyclic generators. Root also applied the same full-character argument
to the extra E8 cyclotomic cases, removing the earlier coefficient-only shortcut.

The primary paper warns in Lemma 8.3 that a simple-torus extension map need not be
diagonal-equivariant. The current manuscript only asserts normalizer/field/graph
equivariance there. Its separate regular-torus formula proves compatibility with
`Lin(X/S)` twists, and does not assert the prohibited simple-torus diagonal
equivariance.

### 1.2 Global ordinary transversals for the witness criterion

CS25 Proposition 2.12(iii) requires a global external-stable regular transversal
whose characters genuinely extend to their global inertias. A local carrier
extension and an equivariant Jordan bijection do not by themselves establish
this hypothesis. In particular, the split E6 field–graph quotient can be
noncyclic; the earlier local MS16 Theorems 3.17–3.18 do not alone close it.

The precise published input is Späth 2025, **Theorem A**, equivalently CS25
Theorem 2.18. It applies to **all ordinary irreducible characters** of every
ordinary simply connected cover, not just characters of a prescribed degree.
The published PDF was independently obtained and extracted with Python/PyMuPDF.
Its exact statement is on printed page 47. Regular-embedding maximal
extendibility is recalled explicitly in its Section 3.3, printed pages 63–64.

Under root's authorization I inserted a paragraph next to the witness criterion
which gives this input, retains the original central kernel, first takes the
stable union of the relevant regular/external block orbit, and then uses the
already constructed block support and regular anchor to select the prescribed
block. Genuine representations retain their products and actual returns after
restriction and transport. I also wrote out the cyclic diagonal argument for
E6/E7: first extend the central scalar to `Z(X)`, then normalize an intertwiner
against `g^m=y in S Z(X)`. This supplies genuine regular-inertia extensions
without overlooking the central return.

## 2. Classification and coverage

I checked the published KM13 version's source tables, the corrected KM25 block
distribution, KM15's good-prime bridge, and Bonnafé's full geometric list.

### 2.1 Proper-Levi deletion

Bonnafé Table III gives the non-isolated connected centralizers:

| Ambient type | Connected centralizers | Semisimple orders |
|---|---|---|
| E6 | D4, A1^4 | 3, 6 |
| E7 | E6, D4 A1^2, A2^3 | 2, 4, 6 |

The manuscript's canonical-centre inclusion proves a proper Levi for all rational
forms of these entries. This is stronger and more relevant than simply calling
the parameter non-isolated. In particular the discarded E6:A1^2 and E7:A1
carriers are not needed after this reduction. The actual transfer still depends
on the independently audited `lev:theorem`.

### 2.2 Abelian three-defect rows

The row lists match the printed KM13 tables and their completeness propositions:

| Group | Table and numbered rows | Active ranks |
|---|---|---|
| F4 | 2: 4, 6, 8 | 2, 2, 3 |
| E6 | 3: 15 | 1 |
| E7 | 4: 4, 7, 11, 13, 16, 18 | 3, 1, 1, 5, 3, 2 |
| E8 | 6: 5, 11, 13, 14, 15, 16, 17 | 1, 2, 2, 1, 4, 3, 2 |

KM25 Remark 6.8 requires retaining the duplicated E7 blocks separately. KM25
Proposition 6.9 reassigns the indicated E6[theta] series in nonabelian boxes and
does not create an additional abelian row. The current text respects both facts.

### 2.3 High-rank non-toral sources at p >= 5

The explicit crosswalk contains the retained E7 A1^2 and both A1^3 embeddings,
and the E8 A1^2, A1^3, A1^4 and D4 sources. I checked the source columns against
the published tables, including the nonlinear `2A2:phi_21` D4 source and KM25
Table 5's corrected order-six rows.

KM15 Theorem 3.14(d),(e) is the appropriate good odd-prime block bridge; the
table's printed bad block prime is not itself used as a good-prime defect proof.
KM13 Proposition 6.10 and KM25 Theorem 6.5 supply the bad-five interpretation.
The latter's proof explicitly establishes central defect and maximal pairs for
the order-six nonprincipal rows.

### 2.4 Higher-cyclotomic toral sources

I independently expanded the order polynomials for all 16 rational types in the
isolated E8 domain, including the identity and the order-six cases. The exact
Phi_3/Phi_4/Phi_6 multiplicities give precisely:

| e | Centralizers with four factors |
|---|---|
| 3 | E8, E6 A2 |
| 4 | E8, D8, 2A4(q^2) |
| 6 | E8, 2E6 2A2 |

The added `2A4(q^2)` row is necessary. Its semisimple label has order five,
`q = +/-2 mod 5`, and the retained block prime is at least seven. Its factors
`q^4-1`, `q^6+1`, `q^8-1`, `q^10+1` each contain Phi_4. KM13 Table 8 row 25 is
the distinct bad-five D8 row. The principal E8 row at `p=5,e=4` is correctly
sent to the nonabelian branch.

## 3. Theoretical interfaces independently challenged

### 3.1 Full rational Levi gluing and literal carrier multiplication

I followed the Clifford correspondent, the double stabilizer, the common
irreducible overlap representation, the Schur comparison, and the Mackey
restriction in `ep:levi-gluing`. The lemma states the factorization and extension
premises that its proof uses; it does not prove them merely from an abelian
quotient. The exceptional application identifies those premises using the
diagonal transversal and the carrier pinning action.

For `sigma(hq)=rho_phi(h) S_q nu_alpha(q)`, decomposition independence uses the
**central scalar** `phi(z)/phi(1)=alpha(z)` on the actual overlap. It does not
equate characters of different degree. The tensor-permutation operators satisfy
their literal product relation. These identities give a genuine carrier
representation, not only a projective one.

The finite-Weyl coefficient lemma's S3 normalization is valid: after `A^3=B^2=1`
and `BAB^{-1}=zeta A^{-1}`, replacing A by `zeta A` removes the scalar because
`zeta^3=1`. The product-of-components transport formula has the correct order.
The commuting field generator and its central return are handled on the same
coefficient representation. Exceptional inseparable graph roots use the separate
full-local-character cyclic argument described above.

### 3.2 Full ordinary support and combined transport

The toral support argument first identifies an actual Sylow subgroup in the
dual centralizer by the degree/defect equality, then obtains all ordinary
parameters `(t,eta)`. This is the required route; a source series at `t=1`
would not suffice. The relative normalizers and fusion are kept at the rational
group level. The D4 source argument retains its nonlinear Jordan core and uses
the bad-five degree check only where it is needed.

I checked Rossi Theorem 3.4 and its definition of `Aut_F`. It permits bijective
algebraic morphisms commuting with F, including field maps. Root corrected the
manuscript's inaccurate phrase “algebraic automorphism” to that precise wording.
SFTV25 Theorem 6.2 requires connected centers on both sides; the regular connected-
center model is the correct setting for its use here.

The combined action `Z_* semidirect A` decomposes every central twist into its
p and p-prime parts. On a datum stabilizer the central factors act trivially on
the unipotent centralizer and the relative group, so Rossi's theorem applies to
the combined stabilizer, not just separately to its factors. Orbit transport is
independent because two transporters differ by that same stabilizer. The local
gluing formula is compatible with quotient-linear twists: the twist is trivial
on the actual carrier and changes only the rational Clifford correspondent.

The central-character assertion keeps the entire center, not only its p-prime
part. The proof that p-power linear twists fix block idempotents uses reduction
modulo the maximal ideal and unique idempotent lifting. The selected regular
block and maximal Brauer pair remain part of the correspondence. I found no
additional contradiction in this combined-action argument.

### 3.3 Characteristic centres and Murai's same root

The characteristic-centre proof uses a p-group offender theorem. Root made
the previously contextual assumption “D is a finite p-group” explicit.
The valuation contradiction and the mod-three perfect-form incidence argument
have the stated ranges; the perfect-form assumption is essential at valuation
one and was not dropped.

For `ep:source-root`, the quotient has an abelian self-centralizing normal
p-subgroup. An automorphism fixing a Sylow subgroup acts by a derivation
vanishing on that Sylow image; p-prime-index affine averaging gives the required
inner automorphism. The defect-zero source representation gives the displayed
integral matrix algebra isomorphism. I checked Murai's definition of the pairing
and Theorem 3.13/Corollary 3.14 in the original paper. The proof retains the same
`D C_S(D)`, root character and internal pairing group because the actual pair
normalizers and centralizers agree. Thus this transfer of the vanishing pairing
does not rely merely on equal character counts in different groups.

### 3.4 Endpoint induction domain

The current theorem assumes induction over **arbitrary finite groups** at
smaller defect or the same defect and smaller central index. This is necessary:
proper-Levi and published actual-group passages can leave the almost-simple
class. The proof states the strict central-index inequality in those passages.
The global whole-probe paragraph explicitly treats strict inequality and equality
separately. It is consistent with this recursive scope, conditional on the
separately reviewed probe construction and the remaining classical inputs.

## 4. Independent exact checks actually executed

New outputs are in `revision_audits/exceptional_final_independent_checks/`.

1. I reran the two standalone E7/E8 GAP carrier inputs using GAP 4.14.0. Both
   terminated normally with no error output. The unused first E7 carrier was
   explicitly discarded by the new parser. The seven retained rows give
   `31+15+31+63+31+15+15 = 201` nontrivial overlap characters. Every inertia test
   passed; all actual return elements belonged to Q, had the displayed order,
   and commuted with every supplied generator. The inertia abelianization
   exponents divide four.
2. A new Python implementation generated all 240 E8 roots and used exact
   Gaussian elimination modulo five. In the four retained source embeddings
   the vanishing roots were exactly the source roots: 4, 6, 8 and 24. No outside
   root vanished on the active p-torsion.
3. A separate SymPy polynomial-remainder calculation screened all rational
   isolated order factors for Phi_3, Phi_4 and Phi_6. It reproduced precisely
   the seven group/order pairs in the higher-cyclotomic table above.
4. A separate parser read all 166 exported E8 unipotent degree records. It solved
   every affine defect equality for all integral valuations `a>=1`, rather
   than sampling q. At e=1 and e=2 exactly 25 records have defect `4a`, no other
   record attains that defect at an isolated positive integral valuation, and
   the e=1 set equals the supplied D4 Harish–Chandra series.

These computations validate finite arithmetic assertions. They do not prove
carrier exhaustiveness, character-triple compatibility, or the global reduction
by themselves. Those theoretical connections were separately read above.

## 5. Notation cleanup and limits

The rational-torus phase paragraph originally confused the algebraic torus
`bold T` with its finite group `T=bold T^F`: it used `A=T_p` but later wrote
`T^F`. Root corrected the definitions and the formula to
`K=T im(bold K_sc^F)`, as well as the restriction notation. I reread the changed
paragraph. This notation item is closed in the final hash above. I did not edit
that paragraph because my editing authorization was restricted to the global
witness input.

I did not reuse the 52 numerical gate receipts as a proof of their theoretical
actor bounds. I read those derivations and the displayed gate table, but this
round did not independently rerun all 52 gate programs or all 106 finite
character-table inputs. The new finite work was concentrated on the changed
classification/carrier/ordinary-support risks. Previous runs of the other
programs are separate evidence, not counted here as a fresh execution.

Any later change closing `cl:toral-pending`, changing the selected-block
correspondence, or altering the global capacity proof requires a new review of
the changed dependency. This report should not be cited as an unconditional
PASS for such a later revision.
