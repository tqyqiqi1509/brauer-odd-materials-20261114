#!/usr/bin/env python3
"""Reproduce source-location and prime-two-isolation checks for the final audit.

This records document identities and statement locations. It is not a
mathematical proof checker. Requires PyMuPDF; source PDFs are obtained from the
URLs in PRIMARY_SOURCE_INDEX.json and final_selfcontainment_primary_index.json.
No downloaded paper text is included in the output.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re

import fitz


ANCHORS = {
    "Ruh22Sigma.pdf": ["Corollary 12.5"],
    "BR23.pdf": ["Theorem C", "Theorem 9.12"],
    "KM15.pdf": ["Theorem 3.14"],
    "Malle19.pdf": ["Proposition 6.4"],
    "Lee21_fresh.pdf": ["Proposition 2.1", "Table 2.1"],
    "FulmanGuralnick12_fresh.pdf": ["Corollary 1.2"],
    "NS14_fresh_selfcontainment.pdf": ["Proposition 6.2", "Corollary 6.3"],
    "Sambale17_fresh_selfcontainment.pdf": ["Theorem A"],
    "AS22_fresh_selfcontainment.pdf": ["Theorem 17", "Theorem 19"],
}


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-dir", required=True, type=Path)
    parser.add_argument("--manuscript", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    source_records = []
    for filename, anchors in ANCHORS.items():
        path = args.source_dir / filename
        if not path.is_file():
            source_records.append({"file": filename, "missing": True})
            continue
        with fitz.open(path) as pdf:
            texts = [page.get_text("text") for page in pdf]
        matches = []
        for anchor in anchors:
            regex = re.compile(re.escape(anchor) + r"(?![0-9])")
            for page_number, text in enumerate(texts, 1):
                if regex.search(text):
                    matches.append({
                        "anchor": anchor,
                        "pdf_page_1_based": page_number,
                        "extracted_page_sha256": sha(text.encode("utf-8")),
                    })
        source_records.append({
            "file": filename,
            "pdf_sha256": sha(path.read_bytes()),
            "page_count": len(texts),
            "matches": matches,
        })
    manuscript = args.manuscript.read_text(encoding="utf-8")
    body = manuscript.split(r"\begin{thebibliography}", 1)[0]
    final = body.index(r"\section{The final all-prime deduction}")
    citations = list(re.finditer(r"\\cite(?:\[[^\]]*\])?\{[^}]*TangPrimeTwo26[^}]*\}", body))
    late_only = len(citations) == 1 and citations[0].start() > final
    checks = {
        "single_prime_two_citation_in_final_deduction": late_only,
        "odd_main_label_present": r"\label{cap:odd-main}" in body,
        "odd_main_proof_present": r"Proof of Theorem~\ref{cap:odd-main}" in body,
        "no_external_tex_inputs": not re.search(r"\\(?:input|include)\s*\{", manuscript),
    }
    receipt = {
        "audit": "final_selfcontainment_fresh",
        "method": "PyMuPDF extraction, anchor-location hashes and manuscript lexical checks; mathematical interpretation is in the accompanying report.",
        "pymupdf_version": fitz.VersionBind,
        "manuscript_sha256": sha(args.manuscript.read_bytes()),
        "source_records": source_records,
        "checks": checks,
        "prime_two_body_citation_lines": [body.count("\n", 0, match.start()) + 1 for match in citations],
        "missing_source_count": sum(record.get("missing", False) for record in source_records),
        "lexical_checks_pass": all(checks.values()),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(f"Source PDFs found: {len(source_records) - receipt['missing_source_count']}/{len(source_records)}; lexical checks: {receipt['lexical_checks_pass']}")
    raise SystemExit(0 if receipt["lexical_checks_pass"] and receipt["missing_source_count"] == 0 else 1)


if __name__ == "__main__":
    main()
