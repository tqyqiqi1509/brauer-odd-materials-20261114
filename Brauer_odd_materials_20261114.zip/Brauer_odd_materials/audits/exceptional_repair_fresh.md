# Exceptional endpoints: fresh reconstruction and audit handoff

Date: 2026-11-14.  
Edited body: brauer_odd_revision/odd_endpoints.tex.  
Frozen body: 3451 lines, SHA-256
0c501fe6790f9bc73896291bb9567e480ac0dd12f01708fe652afa62baa83f33.

## 1. Verdict

**The complete odd-prime theorem is not certified as unconditionally proved.**
There is a known remaining input in the classical module, recorded in
Remark cl:toral-pending. Its two rational-carrier extension requirements
are not implied merely by the standard active-factor field–graph
transversal. The endpoint theorem used to conceal that dependency.
The revised ep:theorem now explicitly assumes those two inputs for
the classical toral sources used in its proof.

The exact affected routes are d=1 in twisted ambient type D with a
nonempty residual core, and d=2 with a nonempty residual core,
in total rank at least five. The high-generator-rank abelian
endpoints can meet those routes as well as the nonabelian strong-bound
argument in the classical module. Accordingly, the conditionality
cannot be ignored when the endpoint is consumed in the global proof.

I have not established a counterexample to the exceptional endpoint
assertions or to Brauer's conjecture. The changes below supply explicit
candidate proofs of previously compressed exceptional interfaces.
They require the fresh independent review requested by the user;
an author's reconstruction does not by itself replace that review.

## 2. Reading scope

Before editing I read the complete original
revision_audits/global_endpoints_v2.md and all 2841 original lines of
odd_endpoints.tex sequentially. I then read the primary classification
tables and the relevant theorem statements and proofs listed below.
After editing I reread the changed gluing, carrier, field-return,
support, combined-transport, source-classification, and final endpoint
passages. The rest of the nonabelian numerical-budget argument was
read but not independently reconstructed again in this round.

The report from the classical reconstruction was read at handoff.
I do not treat its remaining input as available. The affine,
general-capacity, and foundations proofs are outside my ownership.

## 3. Source exhaustion reconstructed from primary tables

### 3.1 The full geometric list and actual proper-Levi dictionary

KM13 Table 1 is expressly restricted to semisimple orders not divisible
by all bad primes. It is not, by itself, the full list needed at
good primes. Bonnafé's full Proposition 4.9 and Table III were read.

The non-isolated E6 entries have connected centralizer D4 or A1^4
and semisimple order 3 or 6. The non-isolated E7 entries have connected
centralizer E6, D4 A1^2, or A2^3 and order 2, 4, or 6.
All their rational forms have the proper canonical Levi required
in lev:theorem. The body now gives the exact inclusion

\[
Z(\mathbf K)^\circ\leq
Z(C_{\mathbf S^*}(s)^\circ)^\circ,\qquad
C_{\mathbf S^*}(Z(C_{\mathbf S^*}(s)^\circ)^\circ)\leq\mathbf K
\]

for any proper Levi K containing the connected centralizer.
It also checks the action hypothesis: after exceptional finite covers
are removed, the actual ordinary automorphisms lift to the perfect
ordinary cover, preserve the original central kernel, and retain
their multiplication relations. Uniqueness of such lifts follows
from perfectness.

Consequently the formerly retained E6:A1^2 carrier
(KM13 Table 3, row 4) and E7:A1 carrier (Table 4, row 17)
are unnecessary. Their carrier paragraphs and numerical rows were
removed. No equivalence between "non-isolated" and "the reduction
applies" is left without the canonical-Levi and action dictionary.
This deletion remains dependent on the correctness of lev:theorem,
which is independently audited by the foundations/Levi team.

### 3.2 Abelian three-block list

The body gives the actual table/row crosswalk:

| Group | KM13 table and rows | Active ranks |
|---|---|---|
| F4 | 2: 4, 6, 8 | 2, 2, 3 |
| E6 and Ennola partner | 3: 15 | 1 |
| E7 | 4: 4, 7, 11, 13, 16, 18 | 3, 1, 1, 5, 3, 2 |
| E8 | 6: 5, 11, 13, 14, 15, 16, 17 | 1, 2, 2, 1, 4, 3, 2 |

The exact completeness assertions are KM13 Propositions 3.5,
4.3, 5.3, and 6.7. The unipotent exceptions are Proposition
8.3/Table 10, and G2/triality are Lemma 6.13/Table 9.
The thin central-three E6 quotient remains a separate C3^2 case.

KM25 Remark 6.8 is retained: the indicated E7 rows represent
two distinct blocks, not one. KM25 Proposition 6.9 corrects
the placement of E6[theta]-series in two nonabelian boxes;
it does not enlarge the abelian row list.

### 3.3 High-rank abelian non-toral sources at p >= 5

The new longtable records the actual ordinary central quotients,
semisimple orders, rational signs, source type, Jordan core,
active rank, and precise source table row. The retained root types are:

- E7: A1^2 and the two embeddings of A1^3.
- E8: A1^2, A1^3, A1^4, and D4.

The E8 D4 row includes both a unipotent D4 Jordan core and
the nonlinear A2:phi_21 core. The corrected order-six source
rows are explicitly KM25 Table 5, rows 2 and 3.
The order-five A1^4 row is allowed only at p >= 7.

The table reads the e-Harish–Chandra source columns as
prime-independent data. Their good odd-prime block interpretation
is supplied by KM15 Theorem 3.14(d),(e); the bad-five interpretation
is KM13 Proposition 6.10 plus KM25 Theorem 6.5.
It does not borrow a defect assertion for block prime two.

The unipotent scalar high-rank filter is also stated: in the relevant
simply-laced Levi ranks at most four, the only possible non-type-A
cuspidal core is D4. It leaves four central dimensions only in E8.
The e=2 assertion uses the corresponding Ennola data.

### 3.4 Higher-cyclotomic toral rows

The rank filter alone was not used as the exhaustion proof.
I expanded every rational isolated E8 centralizer's order factors
and checked its Phi_3, Phi_4, Phi_6 multiplicities exactly.
The complete additional rows are:

| e | Centralizers with four factors |
|---|---|
| 3 | E8, E6 A2 |
| 4 | E8, D8, 2A4(q^2) |
| 6 | E8, 2E6 2A2 |

The good-prime row 2A4(q^2), e=4 is easy to overlook.
Its label has order 5, q is congruent to +/-2 modulo 5,
and it is used at p >= 7. The four factors
q^4-1, q^6+1, q^8-1, q^10+1 all contain Phi_4.
The old broad row "E8 toral rank at least four" included it,
but did not identify it.

The p=5, e=4 D8 row is KM13 Table 8, row 25.
The principal E8 block at those same parameters has nonabelian
defect, so it is not an abelian endpoint.

## 4. Extension and support repairs

### 4.1 Full rational Clifford gluing

The old gluing paragraph was replaced by ep:levi-gluing.
It now has the precise premises:

\[
L\lhd N=LM,\quad K_0=L\cap M,\quad L/K_0\text{ abelian},
\quad N_{\theta_0}=L_{\theta_0}M_{\theta_0}.
\]

It requires an extension of theta_0 to L_{theta_0} and a
genuine extension sigma to M_{theta_0}. The proof uses the
Clifford correspondent tau, the double stabilizer
J=L_{theta_0}(M_theta intersect M_{theta_0}), the common
irreducible K0-model, Schur's lemma, and Mackey restriction.
The external-equivariance premise and its factorization are explicit.
The lemma itself does not assert that arbitrary applications satisfy
those premises.

For the exceptional regular Levi application, the body identifies
H, A2, Q, K0=H A2, and M=H Q. The diagonal transversal
and its field/pinning stability give the double-stabilizer
factorization. Compatibility on H intersect A2 is correctly
stated using the central character phi(z)/phi(1)=alpha(z),
not equality between characters of different degrees.

### 4.2 Actual carrier domain and joint operators

The source representation is now defined on
H I_{phi,alpha}, where I_{phi,alpha}=Q_phi intersect Q_alpha.
Its overlap, conjugation, and multiplication relations are written
out, including

\[
\sigma(hq)=\rho_\phi(h)S_q\nu_\alpha(q).
\]

For the retained E7/E8 carriers the return
v=n0 n0,H^{-1} centralizes the source pinning and Q.
Its operator on the broad source model is precisely the scalar
nu_alpha(v). Field-label orbits and their closing intertwiners
are now constructed before restriction to a full-Levi stabilizer.

The new ep:relative-joint-extension proves a joint extension for
all ordinary coefficients of a marked finite Weyl group.
The S3 relation is normalized explicitly:
A^3=B^2=1 and B A B^{-1}=zeta A^{-1};
replacing A by zeta A removes the scalar. Tensor transports
are checked by a product identity. The central field return
is then imposed on the same representation by a scalar root.

The carrier arithmetic now claims 201 retained nontrivial
overlap colors, not 279. The old certificates contain the
deleted 15-color E6 and 63-color E7 rows as well. Those
78 rows are archival, unused by the revised endpoint.
Root can exclude them from a minimal final material package.

### 4.3 Toral rational-model dictionary

The new toral paragraph uses Späth09 Theorem D and Lemmas 8.1–8.2,
not the abstract's Theorems A/B as a substitute for equivariance.
The proof explicitly constructs

\[
\Lambda(\vartheta)(tu)=\vartheta(t)\nu_\alpha(u)
\]

on the actual inertia and checks its overlap and product.
Quotient-linear twists are trivial on the carrier, so their
compatibility follows in the same formula.

The rational groups are no longer mixed: the calculation is in
S^{F_v}, T0^{F_v}; h^{-1}F(h)=v transports them to the original
rational group. For an operator a the transported carry is
c_a=h^{-1}a(h), with c_ab=c_a a(c_b).
The retained field/graph closing word is v gamma F_r^f.

For E8 at e=3,4,6 the coefficient group may be a complex reflection
group. The real Weyl-group diagram lemma is not applied to it.
There is only a cyclic field quotient: if g^m=w is the actual
return, an intertwiner satisfies T^m=c rho(w), and scalar
normalization imposes T^m=rho(w). This is the relevant general
cyclic-extension argument.

Späth09 Lemma 8.1 and 8.2 were read in the original preprint.
CS19 Proposition 6.2 cites the same Theorem D/Lemma 8.1/Lemma 8.2
numbering for the published paper and explicitly describes the
central-product normalization of vF. The fresh reviewer should
still check the final transported operator dictionary rather
than treating a citation title as a proof.

### 4.4 Full support, definitions, and combined stabilizer

R_s, R_t, the algebraic C_s, finite C_s, and the nonlinear
source S0 are now defined. The former finite C followed by C^F
notation is gone. R_t=(R_s)_t is proved from the actual normalizers.

The toral-Jordan defect argument is now the explicit chain

\[
|C_s|_p\le |D_X|=|\mathbf M^F|_p\le |C_s|_p.
\]

The first inequality is the semisimple character's defect;
the equality is the central-defect source computation; the
last inequality is subgroup inclusion. An unspecified
"series-defect upper bound" is unnecessary.

The new ep:combined-transport defines
Z_* semidirect A and its action on (s,t,M,mu), including both
z_{p'} and z_p. Its exact combined stabilizer acts on the
connected C(st) while preserving the unipotent source.
Rossi Theorem 3.4 supplies stabilizer equivariance, so two
transporters differ by an element fixing the parametrization.
SFTV Theorem 6.2 and the central-twist axiom then give the
same global action.

The local extension formulas are checked against the same combined
action: a full quotient-linear twist changes tau and leaves
the carrier sigma unchanged. The source and induced local
character keep the same full Z(X)-character. Central p-twists
fix block idempotents because they reduce to 1; prime-to-p
twists transport the selected global and local blocks by the
same operation, compatible with Brauer projection.

For the nonlinear D4/A2 Jordan sources, the body defines
S0=[M,M], uses A_X^* consistently, and computes the full
p-parts of the mutual complements D4 and E6. Sylow conjugacy
is in C_{C_E8(S0)}(s)^F, which fixes both s and S0.

## 5. New complete arithmetic material

Directory: revision_audits/exceptional_repair_fresh_checks.

- exceptional_abelian.g and sporadic_abelian.g are the complete
  58-table and 48-table screening inputs.
- Their full .out and .stderr files are retained.
- collect_abelian_scope.py parses and verifies every record.
- complete_abelian_scope.json contains all 106 table metadata
  records and all 1957 retained positive-defect, all-height-zero
  block records (1119 exceptional and 838 sporadic).
- Each block record has table name, prime, block index, logarithmic
  defect, defect order, ordinary count and generator-rank bound.
- exceptional_cyclotomic_scope.py and its .json contain every
  signed order factor in the higher-cyclotomic screen.
- README.md gives the run commands, meaning of the filters,
  and the unused inherited strong-bound columns.

The finite screen contains all abelian-defect blocks; its use does
not require identifying every all-height-zero block as abelian.
The largest logarithmic defects are 2/4 at p=3 for exceptional/
sporadic, and at most 2 in both domains at p >= 5.
The exact GAP version is 4.14.0 and CTblLib is 1.3.11.
The Python parser and cyclotomic checker were rerun successfully
after writing the full material files.

## 6. Primary-source provenance

The directory revision_audits/exceptional_repair_fresh_sources
contains eleven original PDFs, their Python-extracted text,
layout-preserving text, and source_manifest.json.
The manifest records public URL, PDF SHA-256, byte size,
page count, text SHA-256, and PyMuPDF version.
There are 387 original PDF pages in that directory.
The authoritative KM13 table numbering used in the body is
the published Annals version, not the older arXiv copy.

Primary statements checked:

| Source | Exact material used |
|---|---|
| Bonnafé05 | Proposition 4.9 and full Table III; isolated versus non-isolated entries |
| KM13, published | Tables 2–10; Propositions 3.5, 4.3, 5.3, 6.7, 6.10, 8.3; Lemma 6.13 |
| KM15 | Theorem 3.14(d),(e), source/Brauer-pair hypotheses of Proposition 3.10 |
| KM25 | Theorem 1; Propositions 3.6 and 4.3; Theorem 6.5/Table 5; Remark 6.8; Proposition 6.9 |
| Rossi25 | Theorem 3.4 on a fixed unipotent e-cuspidal pair, with full stabilizer equivariance |
| SFTV25 | Theorem 6.2 for isotypies with connected centers; central-twist compatibility |
| Malle14 | Condition (*), Propositions 2.2–2.3, and their abelian-Sylow scope |
| Späth09 | Theorem D, Lemma 4.2, Corollary 4.3, Lemmas 8.1–8.2 |
| Malle19 | Proposition 6.4 and its unipotent nonprincipal-block reduction |
| Ruh22Sigma | Corollary 12.5 and its proof |

Ruh22Sigma is Quasi-isolated blocks and the Alperin–McKay
conjecture, Forum Math. Sigma 10 (2022), e48.
Its Corollary 12.5 is explicitly for all nondefining primes
ell >= 5 in type A. It is not the prime-two theorem and does
not depend on that theorem. The endpoint citation can remain.
No local Tang prime-two manuscript is cited in this module.

## 7. Verification and remaining independent review

The frozen file has no duplicate labels and balanced proof, lemma,
theorem, longtable, tabular, equation, align and aligned environments.
The standalone wrapper exceptional_repair_fresh_compile.tex includes
the shared preamble, endpoint module and bibliography. It compiled
successfully with pdflatex to a 56-page diagnostic PDF, with no
undefined control sequence, LaTeX error, or overfull box. External
cross-references and legacy bibliography aliases are intentionally
left for root's integrated build; this diagnostic is not the
requested final paper.

The next independent reviewer should especially examine:

1. The rational relative-normalizer identification and combined
   stabilizer in ep:combined-transport, including a compensating
   central p-twist and the fixed covering-block sector.
2. The actual field/graph return after Lang transport in the toral
   construction; distinguish scalar cyclic extension from the
   genuinely mixed source stabilizer.
3. The exceptional regular-Levi double-stabilizer factorization
   and the precise all-character D4 transversal input.
4. The complete source crosswalk, especially the order-six KM25
   additions, the order-five 2A4(q^2), e=4 row, and original
   central-quotient isogenies.
5. Propagation of the explicit cl:toral-pending dependency into
   the global claimed theorem.

The known unfinished classical input is a missing proof interface,
not a counterexample to Brauer's conjecture. It prevents the requested
unconditional proof claim at the present handoff, even if every
exceptional reconstruction above passes the next review.
