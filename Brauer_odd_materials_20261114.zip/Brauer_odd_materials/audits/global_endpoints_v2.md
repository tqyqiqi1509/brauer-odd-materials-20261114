# Odd endpoints and global capacity: independent adversarial audit, round 2

审查人：`/root/odd_global_endpoint_audit_v2`。日期：2026-11-14。

## 1. 范围、读取与结论

本轮按源文件顺序逐句读取了：

- `brauer_article/odd_endpoints.tex`，1–2841 行，SHA-256 `e6e511c5e11d95d71123dd15e3856350dac15f34e12e00b4425eab9aa21a6275`；
- `brauer_article/odd_global_capacity.tex`，1–3059 行，SHA-256 `411c027aa90bd8044f2973d2bc691db3f973db1360b60ce8d1e6718409393bf5`。

另外交叉读取 `odd_classical.tex` 415–497 行，用于核实 Murai 接口。正文未作任何修改。下面行号都对应上述散列版本。

**结论：在这两个指定模块中，我没有找到已经构成反例的错误；global 的 actual-probe、指定相对块、defect product 和等缺陷分支没有发现循环论证。这个结论不能替代整篇论文的确认，也不把其他模块的假设当成已经通过。** 尤其 classical 审查已经指出的 determinant-quotient 问题必须由负责该模块的审查修复，不能被这里的结论覆盖。

目前最需要补成可逐项核对论证的地方，是 exceptional 的完整 ordinary 参数集、组合自同构作用、以及分类表到残余源表的逐行对应。这里有确切记号遗漏和几处过度压缩的证明；我把“原文没有写出足够细节”和“已经证明该断言错误”分开记录。

## 2. 四级问题清单

### I. 确认错误

本轮在指定的两份文件中未建立数学反例，亦未发现一个已经证明为假的引理。因此没有可负责任地列入本级的条目。

### II. 实质未证／尚不足以签发完整性确认

#### II.1 Exceptional residual-source exhaustion 还缺可核对的分类对应

位置：`odd_endpoints.tex` 2605–2644、2646–2694，尤其 2627–2633 和 2679–2685；其总调用在 2775–2782。

正文给出了三素数的剩余 rank 表以及五以上素数的剩余 source 表，并用 KM13/KM15/KM25 统括引用来断言穷尽。rank filter 本身可以检验：非环面源的中心维数至多 7；当 `phi(d)>=2` 时最多容纳三个活动因子；下一层 `d p` 的 cyclotomic degree 至少是 8。这些算术并无明显问题。

但 rank filter **不会自己证明列表里每个可能的 e-Jordan source 已经落入某一行**。例如必须明确哪些 quasi-central cuspidal derived cores 能留下至少四维 scalar torus、哪些 rational forms 被 proper-Levi 入口删除、为什么两个 `A_1^3` 轨道都在而没有第三类 source，及三素数各 rank 上限如何来自实际 selected block 而非 ambient centralizer 的总 p-rank。

我未在本轮完成全部原始分类表的逐行重建，故不能将此入口标为已独立验毕。该问题是**穷尽性验证尚未完成／正文接口过于压缩**，不是已发现一个遗漏族。建议加入一个 source crosswalk：原始文献表号与行号、actual group/isogeny、prime/sign、source/core、defect、被哪个正文分支处理。有限 carrier 的 279 项与 52 项数值通过不承担这个穷尽性结论。

#### II.2 “combined orbits”一句尚未写出组合稳定子的检验

位置：`odd_endpoints.tex` 884–892，继而 1008–1017、2696–2713。

直接核实的公开定理确实分别提供：connected-centre Jordan decomposition 的 isotypy covariance，以及固定 unipotent e-cuspidal pair 的 stabilizer-equivariant Harish–Chandra 参数化。它们的适用范围没有发现题名误用。然而“沿 combined source-normalizer and field/graph orbits transport”还应列出如下构造，才能按用户要求算完整证明：

1. 定义包含 quotient-linear twists 的组合变换群及它对 `(s,t,M,eta)` 的作用；
2. 对一个基点明确其**组合**稳定子，而不只分别列 normalizer 稳定子和 field/graph 稳定子；
3. 证明基点参数化在这个组合稳定子下不变，因此沿任意两条 transporter 运输所得相同；
4. central p-twist 必须同样参加该检验；不能只说明中央 p'-twist 的性质；
5. 写出落到固定 regular-embedding block 与固定 central character 的限制。

这有望利用已引用的定理补成一个短引理：中央 twist 不改变相应 connected centralizer，组合稳定子在该 centralizer 上诱导保留 e-cuspidal pair 的代数自同构；Rossi 的 stabilizer-equivariance 随即保证 transporter 独立性。但这几步在当前正文没有写成可检查的对象和等式。我不把一句“transport”视为已经完成这一强接口，也未找到反例说明它不能补。

### III. 可补的数学细节

#### III.1 完整 exceptional 参数集中的群没有定义

位置：`odd_endpoints.tex` 866–882。

`R_t` 在 870 行首次出现，`R_s` 在 875 行出现；整个文件没有它们的定义。这是核心等式的缺口，不能仅靠读者猜测。应定义所用 algebraic centralizers、source torus `M`、rational relative normalizer

`R_s=N_{C_{X^*}(s)}(M)^F/M^F`

以及实际 stabilizer `R_t=(R_s)_t`（按作者的 convention 调整），并证明它等于 Rossi 定理中 `C_{X^*}(st)` 的 relative Weyl group。由于 `M` 中央化 `t`，这个等同性是可以直接写出的，但必须写出 rational quotient 和作用。然后 `(t,eta)/R_s` 才是一个有定义的集合。

同段的 defect 链也宜展示成两个明确不等式：semisimple character 给 `|C_{X^*}(s)^F|_p <= |D_X|`，series defect bound 给反向不等式；另外说明 source-pair 计算为何给 `|D_X|=|M^F|_p`。只写“lower bound and upper bound”不足以展示三个量的连接。

#### III.2 Murai 的跨群转移可以成立，但需精确字典

位置：`odd_endpoints.tex` 1158–1172；交叉位置 `odd_classical.tex` 485–489。

已直接阅读 Murai 原文 §3。它不是“perfect isometry 自动保持 integral-inner”的定理。正确使用如下。

令 `G_0=N_0<x>`、`G_1=S<x>`。两边的 normal subgroup 分别是 `N_0` 与 `S`。假定正文已经证明的相同 maximal pair 和等式

`N_{N_0}(D,e)=N_S(D,e)`、`C_{N_0}(D)=C_S(D)`。

于是 canonical root 的 group `D C_S(D)`、root character、内部 pairing group `N_S(D,e)`、以及 `<x,D C_S(D)>` 中的实际共轭都是同一个对象。local integral innerness 给 local pairing 消失；逐字相同的 pairing 在 global 侧也消失；Murai Thm 3.13 再给 global innerness。Integral-inner 的识别还应引用或展开 Murai Lemma 2.1。Cor 3.14 只是把作者的 `C!` 与 Dade 的同名群识别，不能单独承担跨群结论。

这个接口本身通过；前提 source-pair maximality 和实际 normalizer/centralizer equality 仍须在各应用中成立。`ep` 已写出这些前提的机制，`cl` 对其压缩得更厉害，应补上述字典。

#### III.3 Carrier representation 的域和乘法检验应明确

位置：`odd_endpoints.tex` 749–808，特别是 767–777。

有限表检验 `alpha` 延拓到 `I_alpha` 有明确必要充分判据；它并不表示一个任意 derived character `phi` 被整个 `I_alpha` 固定。公式 `sigma(hq)=rho_phi(h) S_q nu_alpha(q)` 应明确写在 `H I_{phi,alpha}` 上，其中 `I_{phi,alpha}` 同时固定 `phi` 与 overlap colour。

正文的“equal labels use tensor permutations”已经给出了正确构造方向，补写三条关系即可使其可审：`S_q rho(h) S_q^{-1}=rho(qhq^{-1})`；`S_q S_r=S_{qr}`（或实际 carry 版本）；在 `H cap I_{phi,alpha}` 上 `S_q nu_alpha(q)=rho(q)`。随后引用 gluing 引理时，指明其 `K_0,H',V'` 各对应哪个 actual rational subgroup。

787–793 的 scalar normalization 也应说明 `v` 在 broad derived-source representation 上为何确实只留下所写 `nu_alpha(v)`，把完整 closing operator 与 scalar correction 分开给出。否则读者无法知道正在归一化的是全部 closing word 还是其中一个标量。当前我没有证明这里的 word 错误。

#### III.4 Ordinary relative coefficients 的 simultaneous extension 需显示 commuting operators

位置：`odd_endpoints.tex` 799–808。

“diagram inertia 为 cyclic 或 S3，所以 projective obstruction 为零”只直接处理 diagram 部分。全文所需的是它与 field part、实际 finite return 的联合扩张。建议写出：先取 genuine diagram extension；field 若在 reflection group 上作用平凡则以标量实现；若相差一个已保留的内部/diagram 操作则先扣去该操作；最后用一条 scalar root equation满足实际 power relation。还要说明这些 field operators 与 diagram operators 的 commutator 为何为 1 或为何是所需 actual carry。不能把两个分别存在的 extension 自动换成一个联合 extension。

其前面的 integral prime-field carrier、base-preserving pinning 和 actual return 有望提供这些关系，因此本条目前列“可补细节”，不列确认错误。

#### III.5 正常 p-子群线性化的 block matching 可以保留，但最好显式说明 index set

位置：`odd_global_capacity.tex` 1694–1749。

这里的证明没有误把 `G/A` 的块等同于 `G` 的块；它通过相同 Cartan matrix 的 connected components 来匹配 split/nonsplit extension 的块，然后逐个 `(lambda,c)` packet 计数。这个关键点是正确方向。为使“sum only those packets”完全无歧义，增加一句：`lambda` 取 `H`-orbits 的代表，而每个 inertia quotient block `c` 只计一次。这样不会给读者留下重复计数的疑问。

### IV. 记号与文字

- `odd_endpoints.tex` 856 把 `C` 定义为有限群 `C_{X^*}(s)^F`，878 又用 `C^F`。改为分别使用 algebraic `bold C` 与 finite `C=bold C^F`。
- 962–967 的 `S_0` 没有显式定义；应在 932–934 定义它为实际 derived Jordan source（D4 或 A2）。该处 `A^*` 也应与 855 的 `A_X^*` 区分或统一，说明现在处于 E8 无 regular enlargement 的场景。
- 2679–2683 的 `phi(d)`、`d` 在本局部应提醒是 Euler function 与 `ord_p(q)`；前文既用 `e` 又用 `d` 表示 cyclotomic order，宜统一。
- `odd_global_capacity.tex` 490 的 `C_i^{u_i}` 在本节其他位置容易被读成 equivariantization；这里实际指由 `u_i`-fixed labels 张成的 full subcategory，应改一个记号并立即定义。
- 257–258 全局 proof 内临时 `F=eta F_T` 与 theorem 的 bound `F` 重名。改比较自然变换为 `c` 或 `a`，避免同一证明里一符多义。
- `odd_endpoints.tex` 2596 应直接写“3-blocks with defect at most four”，或 `|D|<=3^4`；“defect exponent”易与 group exponent 混淆。
- 可删的审查式防御文字，包括 ep 2550、2580–2582、2693–2694、2820–2822，以及 global 96–97、174–176、186–187、447、511–512、723、945–946、1110–1112、1290 周边反复解释、1690–1692、2642–2644、2700–2703、2960–2971、3037–3048。删时保留必要数学信息，例如 equality 分支允许 `|L|>|G|` 的事实可浓缩为一句 induction-hypothesis 核对。

## 3. 已核实的关键接口

### 3.1 Actual whole probe：没有从 abstract orbit count 跳到 union of blocks

位置：`odd_global_capacity.tex` 965–1275。

我核查了以下依赖顺序：

1. `U` 为 p'-group，principal-unit cohomology 的消失只在此时使用；由 beta 修正构造 associative integral crossed order。
2. 从 available outer image 取 Hall p'-preimage；central coinduced enlargement 解决 actual group extension 的 H3 obstruction，保留原 S 的嵌入。
3. kernel `K_0` 的 averaging idempotent 选出 evaluation sector，得到指定 corrected order，而不是所有 kernel sectors 之和。
4. 同一个 finite scalar cover 同时实现整组比较数据。1185–1203 用 effective Picard image 的非同构 indecomposable bimodules 排除 central idempotent 的非平凡分裂，因而该 sector 是一个块。
5. p'-index 保留 defect；normal centralizing p'-group 的 Fong reduction 给实际 almost-simple central extension，central index 不增。

An–Eaton04 Thm 3.1 的原文已核实：正缺陷、`O_p(I)=1`、正常 defect-zero block，足以使用其首个一般结论。TI / p-local-rank-one 假设仅属于该定理随后附加结论，此处没有越界调用它。

### 3.2 Relative selector 与 exact defect product

位置：global 2154–2320。

`d` 在选 ordinary character 前固定；`d_0` 来自同一中心 residue。central-specialization lifting 的证明通过 corner modules 与 Nakayama，而不是声称 arbitrary quotient 自动保块。`C_c=C_b tensor C_{d_0}` 的 corner-rank 论证只要求第二 factor 的 R-freeness，正文明确没有使用通常不成立的 `A` 对其中心的 freeness。

Murai Thm 3.5(i) 给固定 `c` 的唯一 upper block，随后 Sylow preimage 与同一 group-basis Brauer projection 给 exact relative p-factor。这支持

`Delta=(product delta_i) delta(d_0) |Q|_p`。

### 3.3 Full ordinary comparison 保留同一个 d0

位置：global 2368–2853。

全 action groupoid 上先取 integral factor，再统一 Teichmuller residue。`N` 内乘法及 conjugation scalar 都来自 `R^times`，因此各 ordinary labels 的 residue 相同。p-primary part 是在一组 finite covering groupoids 中处理；各对象的 central-P lift 由同一 d0 选择，transport compatibility 使 E* 真正 central。中心 permutation-lattice 的 central-character multiplicity 比较因此可用在这个 selector 上。

这里证明的是所需不等式；没有使用“ordinary p-primary twist 不改变 k”这个错误命题。实际 section carry `n(q,r)` 留在第二 factor；因其 associator 是 N-degree-one，剩余 anomaly 才是 scalar。最后 integral inner gauges 的 central ratio 给一个 tuple-independent beta。逐处没有发现选块换成 union 后再误取单块预算的问题。

### 3.4 同缺陷 equality branch 没有要求新增 central cover 的群阶下降

位置：global 2930–3051；ep 2799–2822。

全部 component blocks 为正缺陷与 exact defect product 一起推出只有一个 component、相对 d0 defect zero、effective Q 为 p'-group。它没有推出 `G/S` 为 p'-group，正文也没有这样用。单个 d0 simple 给整组 Q 上的一个 correction；probe realization 再给满足 endpoint 假设的实际 L。

当 central index 相等时，条件 endpoint 只消费 smaller defect 与 same-defect smaller-central-index 两类结果。它不消费 smaller group order，也没有再次用正在证明的 unconditional global statement。因此这个 induction skeleton 本身闭合。是否所有 endpoint 分类分支确已满足仍取决于 II.1–II.2 及其他模块。

### 3.5 E6 scalar quotient 没有直接重复 SL3 determinant 的错误

位置：ep 1582–1630。

scalar source 的实际 root subsystem 是 `SL6 times SL2 / C2`。对 `(123)(456)`，增强格上二阶差分可产生 `(a,a,a,-a,-a,-a)`，在中心向量的商中仍非零；单一三循环有外部坐标可以平衡。这个具体维数条件与 SL3 determinant hyperplane 不同。小 valuation 下，正文又使用 E6 order-three matrices 的 mod-3 rank 下界来排除 quotient 后成为 identity。故其他审查的 PSL3(7) 例子不能直接成为这里的反例。这里必须继续保留实际 quotient 的这段论证，不能改成任意 augmentation lattice 的泛称。

## 4. 直接核对的公开原文及范围

这些是原始研究论文，未用二手综述代替其 theorem hypotheses。

- Murai, *On blocks of normal subgroups of finite groups*, Lemma 2.1、Thms 3.5/3.13、Cors 3.14/3.15：上述 inner/pairing、unique-cover 接口的范围匹配。原文：https://ir.library.osaka-u.ac.jp/repo/ouka/all/26820/ojm50_04_1007.pdf 。
- An–Eaton, *Blocks with trivial intersection defect groups*, Thm 3.1：实际 probe 所用一般首结论范围匹配。原文：https://eprints.maths.manchester.ac.uk/51/1/pc09k1q7ac55wpyb.pdf 。
- Linckelmann–Livesey, *Linear source invertible bimodules and Green correspondence*, Thm 1.1、Example 1.2、Props 2.4/3.3/3.4：Green injection 和 normal-source kernel/image 的用途匹配，确实适用于 actual automorphism bimodules。原文：https://arxiv.org/pdf/2004.10131 。
- Brough–Späth, *On the Alperin–McKay conjecture for simple groups of type A*, Thm 5.2：尽管题名是 type A，该 theorem 的对象是一般 connected reductive groups；要求 odd good prime，及 triality 三素数例外。它只直接给 height-zero support，因此应用中仍需 BHZ 把 abelian-block whole set 变成 height-zero set。原文：https://arxiv.org/pdf/1901.04591 。
- Kessar–Malle, *Jordan correspondence and block distribution of characters*, Thm 1、Props 3.6/4.3：principal block 的 semisimple-block image 和 p>=5 same-core arrow 的用途匹配；不能忽视 twin blocks，正文对此有单列。原文：https://agag-malle.math.rptu.de/~malle/download/blocks3.pdf 。
- Rossi, *Inductive local-global conditions and generalised Harish-Chandra theory*, Thm 3.4：固定 unipotent e-cuspidal pair 上的 stabilizer-equivariant parametrization；它不是非幺幂 exceptional whole-block theorem。正文目前没有这样误称，但需完成 II.2 的组合运输证明。出版原文：https://doi.org/10.1017/fms.2025.10115 。
- Schaeffer Fry–Taylor–Vinroot, *Galois automorphisms and a unique Jordan decomposition in the case of connected centralizer*, Thm 6.2：两端 connected centre 的 isotypy covariance。用途在 regular connected-centre X 上成立；不要直接把这个 theorem 写成 arbitrary disconnected-centre finite group 的结论。原文：https://www.math.wm.edu/~vinroot/2024_SFTaylorVinroot_jordanconcent_publishedJAlg.pdf 。
- Malle, *Height 0 characters of finite groups of Lie type*, Prop 6.5、Cor 6.6：核实了 Sylow-e-torus centralizer 系列的 p'-degree 条件，包含 bad-prime讨论；不必把该处一概限制为 good prime。论文 DOI：https://doi.org/10.1090/S1088-4165-07-00312-3 。
- Sambale, *On blocks with abelian defect groups of small rank*, Thm A：确实是没有 direct elementary-abelian summand of order p^4，不只是 abstract rank<=3。原文：https://www.iazd.uni-hannover.de/fileadmin/iazd/sambale/pdfs/abeldefect.pdf 。
- Ardito–Sambale, *Cartan matrices and Brauer's k(B)-Conjecture V*, Thms 17/19：分别是 abelian three-defect rank<=5 和 all three-blocks defect<=4，正文引用范围正确。原文：https://www.iazd.uni-hannover.de/fileadmin/iazd/sambale/pdfs/cartan5.pdf 。
- Späth, *Extensions of characters in type D and the inductive McKay condition, II*：出版原文提供 full ordinary stable regular transversal 与 extendibility；不是只给 prime-to-p degrees。原文：https://doi.org/10.1007/s00222-025-01354-9 。仍要写清实际 rational carrier 如何落到其 overgroup。

## 5. 对本次重写的建议

1. 先修复其他审查已经给出反例的 classical 段落；本报告不覆盖那项错误。
2. 把 II.1 做成 classification crosswalk，把 II.2 和 III.1–III.4 补成具体引理/算子关系，再交下一批代理核对。
3. global 模块可以按本报告的逻辑骨架保留；压缩重复防御语句，不要删除具体 sector、carry 或 central-index 假设。
4. 这两份文件中局部证明没有引用 p=2 的主定理来推出 odd-prime step。global 3054–3059 的最终 all-prime 拼接是唯一明确该种入口；新稿应把它改成最终公开 p=2 citation。不要误删 odd-prime proof 中“defining characteristic two”或 toral two-kernel 的讨论，它们处理的是 q 偶而 block prime p 奇的情形。
5. 数值验证与理论验收分开。有限整数、矩阵、角色表输出支持正文明确的有限命题；它们不证明源列表穷尽、full ordinary support 或联合 extension 的全称命题。

本轮可给出的最强结论是：**global 收束机制和上述若干高风险公开定理接口通过了独立检查；尚不能由本轮把整篇论文标为“所有过程已无条件逐细节证明”。**
