# Final materials portability and preservation audit

Date: 2026-11-14. Reviewer: `/root/final_materials_portability_audit`.

## Scope

This is an independent delivery audit of the mathematical materials directory,
the advertised replay/build entry points, and the separate runtime archive.
It is not a review of the mathematical proof. The package was still being
refreshed during this inspection; a final staging check is recorded below
when available, rather than treating an intermediate manifest as final.

The source hashes of the entry points actually read are in
`materials_portability_replay/source_scope.json`.

## Main executable entry points

I read `run_verification.py`, `run_audit_checks.py`, `run_fresh_checks.py`,
`build_paper.py`, `check_primary_sources.py`, and `extract_source_pdf.py`,
and inspected their subordinate script paths and input manifests.

- The current mathematical runners resolve source files relative to their own
  script locations. They do not rely on the original workspace working directory.
- The three computation runners make isolated working copies and new output
  directories. They preserve reference files, test process exit codes, and report
  missing outputs or failed comparisons as failures.
- The exceptional manifest distinguishes Python recomputation, reference GAP
  outputs, and GAP regeneration. Its JSON comparisons compare full output data.
- The fresh runner preserves the full independent output comparisons for affine,
  exceptional, two-cycle, rank-three, and degree-bound checks.
- I parsed 31 current runner/check Python files with `ast.parse`; no syntax error
  was found. Their imports require the standard library, included local modules,
  SymPy, or PyMuPDF. The two local imports are shipped in their source directories.
- No `/workspace`, `/mnt/data`, or `/home/agent` path was found in those current
  runner/check sources. Paths in recorded commands are execution provenance.
- The primary-reading command accepts the user's source-PDF directory, checks
  exact PDF bytes, page count, and all page-text hashes. The extractor accepts an
  arbitrary input path and creates a new output directory.
- The standalone article builder uses the supplied single TeX file. Its optional
  assembler reads the included modular source and embedded bibliography.

I inspected the actual execution receipts rather than claiming to rerun the
mathematical programs in this audit:

| Recorded run | Observed result |
| --- | --- |
| `final_portable_python_replay/run_receipt.json` | All 9 top-level requested checks passed; the affine child suite has its own detailed receipt. |
| `portable_degree_added_replay/run_receipt.json` | All 11 requested execution/output-comparison records passed. |
| `runtime_source_build_replay/run_receipt.json` | A new GAP source build completed; CTblLib/SmallGrp smoke checks passed. |

These receipts concern finite computations, installation, or input identity.
They are not certificates for the universal theorem.

## Independent archive checks

I read the runtime ZIP directly, tested every ZIP member's CRC, and verified
every entry of its embedded SHA-256 manifest.

- Runtime ZIP: 13 members, 112,453,276 bytes.
- Runtime SHA-256:
  `7ca308639408d366404c78ce1e570505226760d151fc89196897710bb19839ff`.
- All 12 non-manifest entries matched their declared hashes.
- The archive contains original GAP 4.14.0, CTblLib 1.3.11, GAPDoc 1.6.7,
  AtlasRep 2.1.9, Utils 0.85 and SmallGrp 1.5.4 source distributions; the pinned
  SymPy/mpmath/PyMuPDF wheels; source metadata; and the build helper.
- Original distribution archives are retained intact, including their original
  license and package metadata. The source index records their origin and hash.

I separately compared the historical complete-source ZIP in `history/` with the
original preserved file. The two are byte-for-byte identical, all 411 members
pass CRC checks, and the shared SHA-256 is
`60310428c8c79228fdbe4b4d61e41f0a3d7fd4391d4803c71abef13c79628a7e`.
The historical README explicitly distinguishes that original version from the
current paper and retains the older prime-two certificate family only as history.

These exact checks are recorded in
`materials_portability_replay/archive_integrity_receipt.json`.

## Concrete delivery findings sent to the editor

1. `requirements.txt` initially pinned only SymPy, while the README described
   both SymPy and mpmath as pinned. Add `mpmath==1.3.0` or narrow that statement.
2. The provenance-copy list initially omitted `integrate_moving_d_repair.py`.
   Include this integration script to preserve the complete revision process.
3. Some historical helpers under `audits/` assume the old workspace tree, for
   example the old sectional compile TeX and the moving-D audit extraction and
   integration scripts. They are not called by the advertised portable runners.
   Classify them explicitly as historical audit programs, or supply path/layout
   arguments before advertising them as directly runnable in the new package.
4. The initial staging still contained raw third-party paper extraction `.txt`
   files, despite excluding the original PDFs. The editor planned to exclude these.
   Filtering future copies alone is insufficient: already staged raw extracts
   must also be removed from the final distributable copy. Source URLs, hashes,
   reading receipts, and extraction scripts preserve reproducibility.
5. Final staging must synchronize the standalone TeX and its modular source.
   In the first temporary relocation test, the staged TeX was still the earlier
   `8d481a13...` snapshot, while its then-staged modules rebuilt as `ec8379b4...`.
   The assembler itself ran successfully from `/tmp` using only relocated package
   files. This was a detected intermediate-staging mismatch, not a mathematical
   finding. The final source must be re-staged and checked for byte-identical
   reassembly before packaging.

The temporary relocation receipt is
`materials_portability_replay/relocated_assembly_receipt.json`.

## Disclosed runtime limits

The PyMuPDF wheel targets CPython 3.10+ on Linux x86_64 with glibc 2.28+;
other platforms need the same PyMuPDF version from its official distribution.
GAP compilation needs a C/C++ toolchain and GNU make; the archive-extraction
helper uses Python 3.12+. TeX Live and the operating system are not bundled.
These limits are already stated in the runtime/main READMEs.

The original GAP3/CHEVIE exceptional-degree export is retained as supplied data
with its generating source, but its historical generation was not replayed in
GAP3 in this audit. The bundled GAP4 runtime does not by itself reproduce that
separate historical export. The advertised current verification instead checks
the identified data and the independent modern-source reconstruction. This is
explicitly distinguished in the documentation.

## CTblLib bibliography version crosscheck

The editor asked whether the article's inherited `version 1.3.9` bibliography
entry should be retained. I inspected the original complete ZIP and the actual
ordinary-table outputs, not merely the installed runtime version. The retained
odd-prime G6 and exceptional reference tables explicitly identify CTblLib 1.3.11
(the original producer identifies GAP 4.16.1). The current ordinary-table and
height-zero replays explicitly identify GAP 4.14.0 and CTblLib 1.3.11. Therefore
using CTblLib 1.3.11 in the current odd-prime article is supported by the data.

The older 1.3.9 references are genuine historical records: the prime-two
results summary in the untouched archive identifies that version, and the
exceptional README distinguishes a previous replay with 1.3.9 from the later
1.3.11 replay. They should not be retroactively rewritten. The exact source
headers and byte hashes are in
`materials_portability_replay/ctbllib_version_receipt.json`.

## Final-stage verification

The final staging was independently checked after the editor completed the
five delivery corrections above and added the original supplied archives.
There is no remaining delivery-specific blocker in this reviewed snapshot.

| Final article artifact | SHA-256 |
| --- | --- |
| Standalone TeX | `00b072a50a96e7b45b7657c696688308c75e44c063dae0b2d8585fb9abe7492f` |
| PDF (170 pages) | `1e2b33e52988f4deb47598771e082939ff61cc8a5931571a48c20187b52c2f6c` |

I copied the entire final `paper/` source tree into a separate directory and
ran its assembler with `/tmp` as the process working directory. The command
returned zero and regenerated exactly the same TeX bytes and SHA-256 shown
above. This closes the initial staging mismatch. The portable assembler and
all included modules suffice; no file from the original workspace tree was
needed. The receipt is `materials_portability_replay/final_relocated_assembly_receipt.json`.

The following 14 final-stage checks passed:

- All six historical ZIPs were preserved byte-for-byte and pass member CRC checks.
- Newly downloaded raw paper-text extracts are absent from the audit directory.
- Temporary relocation copies and the virtual environment are absent.
- Newly downloaded original PDFs are absent; their reading metadata remains.
- `mpmath==1.3.0` is pinned in requirements.
- The moving-D integration script is retained in provenance.
- Historical helpers are explicitly distinguished from portable replay commands.
- Original odd-table producer and current replay versions are distinguished.
- The source-check edition status describes the reviewed delivery.
- The final standalone TeX hash matches the frozen source.
- The final PDF hash matches the frozen PDF.
- The standalone TeX has no external input/include/image dependency.
- The source-check metadata identifies those exact TeX bytes.
- The primary-source index contains the expected 32 identified entries.

The exact records, including each delivered archive hash and byte comparison,
are in `materials_portability_replay/final_staging_receipt.json`. The six
preserved archives are the supplied r3, r4, r5 and prime-two sources, the old
manuscript checkpoint, and the old complete-source delivery. Their unchanged
source identities were also checked independently before staging in
`materials_portability_replay/original_input_archives_receipt.json`.

Finally I ran the advertised `run_verification.py --integrity-only` command on
the staged package: all 400 manifest entries matched, with no missing file or
byte mismatch. The editor will add this final report and final delivery status,
then regenerate the manifest and ZIP; that later packaging pass is required
because these report/status bytes are additional to the inspected 400-entry
snapshot. No subsequent mathematical-program rerun is implied by this check.
