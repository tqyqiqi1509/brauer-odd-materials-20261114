#!/usr/bin/env python3
"""Rebuild page-location/digest evidence for the final integrated proof audit.

Requires PyMuPDF.  Input PDFs must already be present in revision_audits/primary.
The output records extraction evidence; it is not a mathematical proof certificate.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re

import fitz


ANCHORS = {
    "CS25": [
        "Proposition 2.12", "Remark 2.22", "Proposition 3.8",
        "Theorem 3.11", "Lemma 3.13", "Theorem 4.1",
        "Corollary 4.12", "Proposition 4.14", "Proposition 5.30",
        "Assumption 6.1",
    ],
    "MS16": [
        "Proposition 3.8", "Corollary 3.13", "Theorem 3.17", "Theorem 3.18",
    ],
    "CS13": ["Theorem 5.1", "Corollary 5.14"],
    "BR23": [
        "Lemma 2.2", "Proposition 2.3", "Corollary 3.4", "Lemma 3.5",
        "Proposition 3.7", "Corollary 4.3", "Assumption 4.5",
        "Proposition 4.7", "Lemma 4.8", "Theorem 4.9",
    ],
    "BS19": ["Lemma 2.3", "Theorem 2.4", "Proposition 2.5"],
}


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    output = args.output or root / "revision_audits/final_integrated_primary_receipt.json"
    sources = []
    missing = []
    for name, anchors in ANCHORS.items():
        path = root / "revision_audits/primary" / f"{name}.pdf"
        if not path.is_file():
            missing.append(str(path.relative_to(root)))
            continue
        with fitz.open(path) as document:
            pages = [page.get_text("text") for page in document]
        matches = []
        for anchor in anchors:
            pattern = re.compile(re.escape(anchor) + r"(?![0-9])")
            for number, page in enumerate(pages, 1):
                if pattern.search(page):
                    matches.append({
                        "anchor": anchor,
                        "pdf_page_1_based": number,
                        "extracted_page_sha256": digest(page.encode("utf-8")),
                    })
        sources.append({
            "file": str(path.relative_to(root)),
            "pdf_sha256": digest(path.read_bytes()),
            "page_count": len(pages),
            "matches": matches,
        })
    receipt = {
        "method": (
            "PyMuPDF text extraction and numbered-anchor locations. Matches include "
            "both statements and cross-references. Statement contents were read "
            "separately. Digests establish the extracted source version, not proof validity."
        ),
        "pymupdf_version": fitz.VersionBind,
        "sources": sources,
        "missing_inputs": missing,
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(f"Wrote {output}: {len(sources)} PDFs; {len(missing)} missing inputs.")


if __name__ == "__main__":
    main()
