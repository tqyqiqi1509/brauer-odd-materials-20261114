# Fresh independent audit of the global odd-prime reduction

Date: 14 November 2026

Reviewer task: `final_global_claim_fresh`.

## Result and precise scope

I found **no new confirmed mathematical obstruction in the global reduction and induction that I reviewed**. In particular, the final equality branch does not obtain a complete same-defect probe budget from the assertion it is trying to prove. It realizes one specified correction as one actual block, and then uses either a strictly smaller central index or the separately stated almost-simple endpoint.

This is a mathematical audit of specified arguments, not a computer-formal proof of the whole paper. The result does not amount to a new independent certification of every classification calculation, every Lie-type source construction, or the externally cited prime-two theorem. Those are not replaced by this report.

The audit was conducted by reading the arguments themselves before consulting other reviewers' conclusions. I read all of `odd_global_capacity.tex`, including the categorical capacity lemmas, actual-probe construction, normal-subgroup reductions, selected relative block, selected residual comparison, and the final induction. I independently checked in greater detail the group/block arguments from `cap:probe` through `cap:odd-main`. I also read the opening affine theorem and its induction convention; the hypotheses of the proper-Levi and endpoint theorems; and the endpoint's exhaustion/closing argument, including all three internal uses of `cap:probe`.

The initially supplied standalone TeX had SHA-256

`bbd43d426c582f46e437a4a6e7c356938476a7fa305edda3f609b8da336c7f00`.

The final standalone TeX after delivery cleanup has SHA-256

`00b072a50a96e7b45b7657c696688308c75e44c063dae0b2d8585fb9abe7492f`.

I inspected the complete diff against `pre_final_delivery_cleanup/frozen_reviewed_text.tex`. It deletes four retrospective sentences about assumptions not used, corrects the CTblLib version to 1.3.11, and adds a final-page enlargement command. No mathematical hypothesis or deduction is removed by that diff.

The global module I read has SHA-256

`1147b60c12ad806b48f90de03dff42efce0a68f347da927e913629c8ee5eedfa`

and 3,068 lines. The endpoint module has SHA-256

`265b90278f69c1d5817d597aaeff8a1e552c71a6720b844b391370ab27be3511`.

## 1. The actual-probe theorem is independent of the desired bound

The input of `cap:probe` is a quasisimple group with prime-to-p center, a positive-defect block, a prime-to-p subgroup of its **integral Picard image**, and one admissible whole residual correction. The proof never assumes the conjecture for that block, that group, or its correction.

I checked the following points separately.

1. The principal-unit correction is legitimate over the local center order. The center is commutative; raising principal units to the order of the prime-to-p actor is an automorphism. Thus the positive-degree cohomology used to remove the remaining associator vanishes. This is not an averaging argument in a noncommutative unit group.
2. Pullback to the actual outer preimage retains a genuine group action. A Hall prime-to-p subgroup surjects onto the required actor because its intersection with the normal kernel has the full prime-to-p part of that kernel.
3. The coinduced central group removes the group-theoretic three-cocycle while preserving the literal original quasisimple subgroup. The diagonal central subgroup has trivial intersection with its copy, by injectivity of the displayed coinduction map.
4. The evaluation idempotent for the ineffective kernel is integral. Normalization makes that kernel a genuine commuting group algebra inside the pulled-back crossed order. Averaging over it selects exactly the desired correction, with an explicit inverse to the evaluation map.
5. The scalar-cover comparison uses central units and their residues, so it preserves all ordinary character phases up to the stated integral gauge. It does not replace a character-dependent collection of corrections with an unproved common one.
6. The selected sector is one block. The homogeneous bimodules represent distinct effective Picard classes and are nonisomorphic indecomposables. A central idempotent therefore has one common scalar on the diagonal of the semisimple quotient of their endomorphism ring. Its image is either zero everywhere or one everywhere; the radical contains no nonzero idempotent.
7. The quotient of the realized group by the original quasisimple subgroup has prime-to-p order. Normal-block defect intersection therefore preserves the actual defect group, not only an upper estimate for its order.
8. The centralizing enlargement is removed only after an actual block has been constructed. Fong--Reynolds selects the inertia of a character of the normal prime-to-p centralizing subgroup. Its p-core is trivial: any normal p-subgroup lies in the quasisimple subgroup, and hence in its prime-to-p center.
9. The first conclusion of An--Eaton's Theorem 3.1 applies at exactly that point. The later extra statement in that theorem concerning local rank is not needed.
10. The derived subgroup above the simple socle is perfect and quasisimple. In the resulting central extension, the centralizer of that subgroup equals the scalar kernel, because the quotient is almost simple. This proves the central-index bound advertised in `cap:probe`.

Thus the theorem supplies actual blocks with precisely the parameter needed by the later induction. It does not merely supply a semisimple algebra of the desired rank.

## 2. The normal-p reduction retains a specified block

The central-fiber lemma proves its two assertions by different arguments. The equality of decomposition-matrix Gram matrices does not by itself prove the row-count bound. The latter is separately obtained from the center as a direct summand of a permutation lattice for the central p-subgroup. The transitive summands have local endomorphism rings; their trivial-character multiplicity dominates every other character multiplicity. I found this distinction essential and correctly made.

For an abelian normal p-subgroup, the nonsplit and split groups have the same p-regular lifting and centralizer data. This gives the same Cartan matrix on the inflated Brauer characters and hence the same partition into blocks. The proof then checks the ordinary packets `(lambda,c)` using nonnegative modular induction and the connected column-incidence graph of the central-fiber matrix. This identifies the **same matched block**, rather than comparing only the total number of ordinary irreducibles of the two groups.

The iteration through a central elementary series is also compatible with the group action. After splitting one layer, the remaining normal p-subgroup in the complement acts trivially on that layer. The next central layer is therefore normal in the new split group and commutes with the already split layers. At the end their direct sum has order equal to the original normal p-subgroup.

In `cap:normal-p-descent`, the subgroup `V x K` is the actual centralizer of `V`. Every covering block has nonzero Brauer image at the normal p-subgroup `V`; two distinct images would be nonzero orthogonal idempotents below its one selected block. This proves uniqueness of the upper block. The exact defect product is then obtained by the normal p-index block theorem and the matching Brauer-map coefficient deletion, followed by normal-block intersection for the converse bound.

Consequently a violating block with nontrivial p-core produces a violating block of **strictly smaller defect order**. The use of the affine theorem here is an input, not a consequence of the global induction.

## 3. Defect-zero descent and the minimal configuration

The defect-zero descent correctly removes the p-primary part of the ordinary Clifford multiplier. On a Sylow p-preimage, a height-zero character gives a projective multiplicity degree prime to p; the determinant kills the restricted multiplier by that degree, while finite-group cohomology kills it by the p-power group order. The restricted class is therefore trivial. Restriction/corestriction removes the global p-part.

For the integral passage, the valuation exact sequence gives the required injectivity from unit-valued second cohomology into fraction-field second cohomology, since the preceding first cohomology with integer coefficients vanishes. The residue-one adjustment preserves the selected primitive block idempotent. This proves a genuine matrix equivalence for one block and the required central-index estimate.

I checked each parameter decrease in the lexicographic minimum:

- a proper inertia group contains the original center, so its central index is strictly smaller;
- a noncentral normal prime-to-p subgroup gives a strictly smaller central index after defect-zero descent;
- a kernel in the selected central character can be quotiented without increasing central index and with strictly smaller group order;
- a nontrivial product of defect-zero components, together with the center, is normal and gives another strict central-index step.

This leaves an all-positive component layer with prime-to-p central identifications and centralizer equal to the center. The selected layer block is the asserted tensor product. Integral innerness of a factorwise automorphism descends to each factor by Krull--Schmidt cancellation of the restricted bimodules; a nontrivial permutation of positive-defect components is excluded because it moves an ordinary character tuple. The ineffective quotient therefore embeds in the product of the component outer groups and is solvable.

## 4. The relative block and the exact defect product

The relative idempotent is selected before specializing at ordinary characters. The residual block `d_0` is determined by that one idempotent, and the lifting argument uses the complete local center order and Nakayama on the off-diagonal corners. There is no later independent block choice over different ordinary labels.

In the Cartan calculation, the second-factor primitive corners are projective and hence free over the local commutative center order. The argument does not assume that the first-factor primitive corners are free over that center. Their ordinary ranks multiply with the second factor's center-ranks, giving the Kronecker product of Cartan matrices. The largest p-power elementary divisor then gives the product of defect orders.

Murai's Lemma 2.1 is explicitly an integral block-algebra characterization. It identifies the present integral-inner subgroup with the ramification subgroup. His Theorem 3.5(i) supplies the needed uniqueness of the covering block. Since the lower idempotent is stable, uniqueness makes it the upper idempotent as well. This justifies the Brauer-map comparison with the preimage of a Sylow p-subgroup and yields

`Delta = (product_i delta_i) delta(d_0) |Q|_p`.

The argument uses both inequalities for the defect order. An upper bound alone would not be enough for the later equality branch.

## 5. The selected residual comparison retains kernels and returns

I traced the ordinary groupoid cocycle, its restriction to the ineffective kernel, and its full normalizer action. The two restrictions are evaluations of integral central units; all ordinary evaluations have the same residue. Thus the residual kernel algebra and its normalizer action are independent of the ordinary label.

The principal-unit part is replaced by one finite p-root cocycle on each connected groupoid component, then pulled back by explicitly chosen arrows. The valuation and residue adjustments make the intervening gauge residue one. Accordingly it retains the original lower block selector after specialization.

The finite covering groupoid uses the same central p-kernel at all objects. The sum of the selected lower lifts is central because every arrow carries a selected lift to the next selected lift, with the already specified normalizer action. Comparing character multiplicities in its center permutation lattice therefore compares the two central-character sectors **with that same selected lower block**. It does not replace an individual selected block by an uncontrolled sum on just one side.

The quotient section retains its actual kernel carry. The second factor's scalar associator is obtained from the degree-one part of the twisted kernel algebra, while the first factor has the opposite anomaly. The final comparison with the component tensor action is evaluated from a single integral central ratio, so the cochain `beta` is one whole scalar correction. Intertwiners for each selected `d_0`-character are then taken on its full inertia; their corrections need not extend to the whole quotient and the proof does not require such an extension.

## 6. Actor and capacity interfaces

I checked the source of the actor estimate against Linckelmann--Livesey. The relevant theorem injects the linear-source Picard group into that of the Brauer correspondent and preserves the trivial-source subgroup. Group automorphism bimodules are within that subgroup. The normal-defect source-algebra calculation has kernel controlled by `Hom(E,k^*)` and image in the fusion-automorphism quotient, as used in the manuscript.

The Schur--Zassenhaus complement used in the order estimate contains `E`: inside the product of the normal p-kernel and `E`, the prime-to-p complement is unique. The Frattini action is faithful for the resulting prime-to-p group. The extra factor of p in the independent-base-pair count follows because the right `GL_2(p)` stabilizers of free-group orbits have prime-to-p order. I found no reversal of the inequality there.

The capacity theorem is invoked only after complete prime-to-p probes have been supplied for each relevant component. Its actors are solvable quotients of component outer groups. The final coordinate permutation quotient is allowed to be nonsolvable; the theorem does not assume otherwise. The defect-three case is routed through the independently stated affine bound, not through the odd-prime block theorem being proved.

I read the categorical capacity chain, including the two-factor return, coinduced categories, Hall-section passage, coupled cycles and permutation estimate. I did not discover a concrete contradictory step. This audit is not a replacement for a separate full verification of the pointed-fusion-category equivalences used in that chain.

## 7. The final induction has no same-parameter probe loop

The two branches of the final proof are distinct and exhaustive.

If every component defect is smaller than `Delta`, every whole prime-to-p probe is realized at that smaller defect. The first coordinate of minimality therefore supplies the **complete** probe budget; the size or central index of its realizing group is irrelevant. Capacity bounds each actual relative-character inertia, and the displayed sum is at most the exact defect product.

If one component defect equals `Delta`, positivity of all component defects and the exact product force exactly one component, a defect-zero relative block, and a prime-to-p effective quotient. The single ordinary character of the relative block supplies **one** opposite correction. The proof realizes just that correction with an actual outer group already present in `G`; hence its central index is at most the original central index.

When this index is smaller, minimality applies. When it is equal, the actual realized group has all the endpoint hypotheses: a normal quasisimple subgroup with prime-to-p center, prime-to-p quotient, and centralizer equal to the center. The endpoint's smaller-defect and smaller-central-index induction hypotheses follow from the original minimum for all finite groups. The target of a proper-Levi reduction need not remain almost simple, and both the endpoint statement and the global induction explicitly allow that.

I also traced the endpoint's uses of `cap:probe`. The relevant small-defect occurrences pass to an actual block and invoke a universal theorem for the specified defect range. They do not feed the realized same-parameter block back into the global conjecture. The final compatibility paragraph restates the same two-way central-index argument; it does not add another assumption.

## 8. Source-reading receipts and limits

The accompanying script `final_global_claim_primary_reading.py` rereads three original PDFs with PyMuPDF and records their byte hashes, extraction hashes and locations of the named statements. It accepts `--source-dir` and `--output`, and writes no third-party extracted text into the receipt. The recorded version of PyMuPDF is 1.26.6.

- Murai, *On blocks of normal subgroups of finite groups*: PDF pages 5 and 8 contain the relevant Lemma 2.1 and Theorem 3.5. The source's integral coefficient convention was also checked.
- An--Eaton, *Blocks with trivial intersection defect groups*: PDF page 9 states the general first conclusion of Theorem 3.1. Its extra local-rank clause is separate.
- Linckelmann--Livesey, *Linear source invertible bimodules and Green correspondence*: PDF pages 2, 5--6 and 10 contain the injection, source-algebra description and kernel statements used here. The downloaded original is `LL20_global_fresh.pdf`, SHA-256 `a6d9de7244aadfffa418894a9447ebc98c8e4842179c5848a68e26039734d53c`.

The source locations are in `final_global_claim_primary_reading.json`. These extraction checks establish what was read and make that reading reproducible; they do not certify mathematical validity by program execution.

No TeX changes are requested by this audit. The remaining independent mathematical inputs include the affine theorem in full, the Lie-type proper-Levi equivalences, the classification/exhaustion of almost-simple endpoints, and the prime-two theorem used only in the final all-prime corollary. This report verifies the reviewed global use of those inputs and does not silently promote them to newly re-proved results.
