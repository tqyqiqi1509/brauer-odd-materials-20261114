# 全新顺序对抗审查：一般归约、整体修正与全局计数链

日期：2026-11-14。审查者：`global_chain_final_attack_new`。

## 1. 结论及适用边界

本次没有发现独立于局部端点输入的新的确定数学反例，也没有发现一般归约在等号分支中调用自身结论的循环。把独立的 affine theorem、实际 almost-simple endpoint 和 proper-Levi theorem 作为已证输入时，当前一般链的最后两条分支确实给出反证：严格较小分量缺陷分支使用完整整体探针预算；同缺陷分支使用一个实际实现的 almost-simple block，再按中央指数严格下降或调用端点。

这不是对完整论文的无条件认证。本报告未完整重审 affine classification、classical/exceptional endpoint classification 或 proper-Levi theorem 的几何构造中段。当前 `cap:odd-main` 本身明确以 `cl:toral-pending` 的两个 source-extension 输入为条件；本报告不把该已知待证输入重新包装成一个新发现，也不把它当作本次查错的唯一目标。非平凡三余循环的所有情形也没有被有限计算穷举。

本次有一个有价值的实质性紧例：三标签上的 `C2` 反演模型、对角基群和交换返回，完整探针预算为 `F=3`，固定简单对象数为 `f_y=4`。因此将缺陷三直接塞入普通的 `3^{-support/2}` 估计会失败；现稿单独处理缺陷三的分支确实避开了这个问题。这个紧例并不反驳正文所述两循环定理，其正好达到 `(F+1)^2/4`。

新增 `ep:cyclic-outer-completion` 也作了独立审查。原初版本对中央子群上 discrepancy 为一的说明省略了 implementer 分母；我已向主审查员指出这一点。主审查员补入共同标量 implementer 的论证后，该处可由前面的 `ep:strict-green` 直接推出，不再留下独立阻塞。下文给出完整核对。

## 2. 版本、顺序阅读及哈希

没有读取先前审查报告或使用旧 PASS。先顺序读完整个 `preliminaries.tex` 和 `integral_foundations.tex`，再按连续区间 `1–420, 421–840, 841–1260, 1261–1680, 1681–2100, 2101–2520, 2521–2940, 2941–3073` 读完最初的 global 文件。之后只作定点复核及原始文献核对。

`odd_global_capacity.tex` 初读版本 SHA-256 是 `277090440070f9f432830071ad8cb38f5c108a60815af585318555dc19fdba27`，共 3073 行。主审查员随后仅把旧行 2791–2792 的句子收为 `This retains the actual return.`；本报告下列 global 行号按这个 3072 行版本记，后半段比初读版本少一行。该编辑未改变数学内容。

| 文件 | 审查版本 SHA-256 | 覆盖 |
|---|---|---|
| `brauer_odd_revision/odd_global_capacity.tex` | `832b0f639bd05675b70512b39ffbc1eae6c3773377d135c672fecfec3b1d91b5` | 全文，初读后复核唯一语言变更 |
| `brauer_odd_revision/preliminaries.tex` | `e9fae91208a028c02acada7585ef94972f6de9d36e42cc7a736de51f268dd183` | 全部 139 行 |
| `brauer_odd_revision/integral_foundations.tex` | `e248a3db903a2c141b15f657dce045f4c1a79cd5071ec5e8e2a977a5d30a9ce4` | 全部 158 行 |
| `brauer_odd_revision/all_prime_levi.tex` | `146d84c48326b440acc9f2563eb02c7dd4886be8f47d39cabfcc23eeb1c3224b` | 1–240、895–1282；仅一般链所需接口，未声称全文审查 |
| `brauer_odd_revision/odd_endpoints.tex` | `8468eadae161f540d117f27667bc051009ed6ba0445368f1229d1620ea87c55a` | 端点假设/最终分支，以及新增循环外自同构补全周围 54–305；非全文 |
| `revision_audits/primary/Murai13.txt` | `75921f1e92002a9038f661973650af2fe8b541362a77ff47eeb7a210284a0dc5` | 原始定义、Lemma 2.1、Theorem 3.5(i) |

若主审查员在上述哈希之后又作编辑，尤其是端点文件，不能把本报告的具体行号自动移植到新哈希；稳定定位应同时使用标签。

## 3. 顺序覆盖记录：检查的具体数学内容

以下记录的是读过的论证及实际攻击点，不是逐条形式化“通过”的清单。

### 3.1 基础两文件

| 文件/行段 | 检查内容与结果 |
|---|---|
| preliminaries 1–55 | 检查 `k_p(H)≤|H|_p` 只使用每个 p 元素类交 Sylow；核对 Cartan 最大初等因子与缺陷阶的使用方式。 |
| preliminaries 57–87，`pre:projective-count` | twisted center 按 regular classes 分解，得到 simple 数不超过普通类数；没有把 projective representation 的维数误当数量。 |
| preliminaries 89–110，`pre:class-counts` | subgroup class bound 与 Clifford orbit-size 求和；后者确实要用每个实际惯性群，稿件没有把惯性统一放大后重复计数。 |
| preliminaries 112–139，`pre:commuting-pairs` | 从 triples `(x,a,b)` 重建平均式；`V*≈Irr(V)` 的等变性及分裂 inertia 的线性字符延拓均成立。 |
| integral foundations 1–43 | 对称形式给出两个 dual identifications；两边投射性保证外侧投射、张量积 O-free。 |
| integral foundations 45–101 | 逐一检查四个 triangle identities 的方向；`Q→Q⊗Q` 与反向映射分别有整系数分裂，泛纤维同构才推出补空间秩零。 |
| integral foundations 103–127 | 关键不是“泛 Morita 自动整 Morita”。稿件先让中央元素 z 在有限整扩张 `End_{B-B}(Q)` 中可逆，再用其逆的整方程推出 z 已在 `Z(A)` 中可逆；这一步补足了最危险的整系数跃迁。 |
| integral foundations 129–158 | 检查 `Q` 属于 G 的本质像、F 在该像上检测同构；`qj=1` 给出 B 的中央幂等元，再由实际右作用识别 `Bc=End_A(M)^op`。没有只凭泛维数断言满生成元。 |

### 3.2 global 1–946：范畴容量

| 行段/标签 | 逐段检查与攻击点 |
|---|---|
| 1–72，`cap:probe-budget` | 区分一个全局 scalar cochain 与逐 orbit 任意修正；完整预算确实是整个目标范畴的预算，并包含 U=1。 |
| 73–151，`cap:two-cycle`、`cap:kernel-identification` | 重建 subdirect K 的两个 normal axes、mixed bicharacter 与 radicals。核对 transitive action groupoid 上的自然变换方程仅剩 isotropy character，所以 radical 是实际 module-functor kernel。 |
| 153–192，`cap:full-image` | 关注 quotient associator 是否被臆造。这里先取实际 endofunctor category 的 full tensor image，再取 skeleton，因此 quotient tensorator 来自真实 tensor functor。右侧 descent 使用的是已经带 B-module 结构的 functors；稿件没有断言任意 A-module functor 都能下降。 |
| 194–231 | 检查右 endofunctor simples 的计数：normal stabilizer 使 orbit graph 数为 `|X|`，左 translations 在每个 graph 上提供 1-dimensional projective trivialization，非退化 pairing 让剩余 characters 恰好穷尽。GP16 的 invertibility criterion 与这里的使用相符。 |
| 233–266，`cap:double-coinduction` | 目标不被粗暴 quotient；`Fun_A(B_q,C)` 的 coinduction adjunction保留 module transformations。dominant quotient 的 restriction 保持 transitive/indecomposable，因而继承的是完整 F 预算。 |
| 268–311，`cap:return-separates` | 实际检查其所需假设是同一个 whole correction 和 tensor-form return。radical 双轴的 mixed cocycle 在消去轴限制后有平凡 commutator，才允许一个共同 gauge。之后的 transport 分到两轴；没有假定 `y²=1`。此处仍是全文最精细的 coherence 论证之一，有限测试不认证非平凡 associator 的全部情形。 |
| 313–361，`cap:hom-matrix`、`cap:column-budget` | `m` 是 coinduced module summand 数；每个 h_ij 正数来自非零 twisted stabilizer algebra。对固定列应用完整目标预算，才得到 `h_ij≤F−m+1`；若只给单个 orbit 预算，该结论会失败。fixed pair 数至多 m，不要求两个 bijections 互逆。 |
| 363–426，`cap:hall-coset` | 重建 cyclic Clifford eigenspace 与 coset class-function 维数；E/L 为 p′ 循环群、central C 的特征固定；Hall conjugator 可移到 L，且 label 与 loop 必须同时移动。 |
| 428–528，`cap:mixed-two-cycle` | p-primary correction 的处理是所选 central-character coset dimension 的单向比较；并非相等。p-section lift 的唯一性用于保持正常化者作用。固定 p 类的 transporter 修改及删除 p-part 保留交换作用（此处需要 p 奇）。Hall 投影只落到 `C_{H_i}(u_i)` 中，故 fixed-label full subcategory 稳定。 |
| 530–586，`cap:stationary` | transformation algebra 的 Hall index freeness 给出限制矩阵两条正维数向量等式；谱半径和 trace 得出 rank bound。没有把一般 restriction multiplicity 矩阵当置换矩阵。 |
| 588–655，`cap:long-cycle` | 逐项重建 coset trace；centralizer 的一个坐标投影单射，fixed tuple 由首标签确定。丢弃 closing condition 只会放大界，实际 closing coefficient 仍在原 trace 中。 |
| 657–695，`cap:cyclic-completion` | fixed simple 消去 quotient H³ 障碍；`H³(C_m,μ_{p′})→H³(C_m,C×)` 单射。quotient cochain 在含 K0 的 mixed arguments 上为一，且 m 次方根规范可保留既定 closing operator。 |
| 697–752，`cap:coupling` | 先处理 projection kernel K0，再逐 actual inertia 使用第一因子预算。stable-orbit average 没有假设 coupled subgroup 分裂为直积；两个 p-parts 的乘积精确为 `|U|_p`。 |
| 754–820，`cap:permutation` | 传递情形分 b≥3 与二元码 b=2；convexity 的方向正确。非传递时取的是 complement-action kernel，确保所引用的 normal-coset inequality 作用在忠实的单个 F-orbit 上。 |
| 822–905，`cap:capacity` 普通分支 | 支撑损耗仅作用于真正移动的坐标。顶层 permutation quotient 无 solvability 假设；solvability 只用于坐标基群及其 kernels。actual inertia class bound 与加权 orbit 双计数相配。 |
| 907–946，缺陷三分支 | signed-permutation action 在 V 上的忠实性来自 effective total actor。仅在这一分支使用独立 affine theorem；任意 scalar correction 可用 projective class inequality。三标签紧例说明该分支不是可随意删除的冗余。 |

### 3.3 global 948–1566：整体探针实际实现与 actor 质量预算

| 行段/标签 | 逐段检查与攻击点 |
|---|---|
| 948–994 | local block centre 的唯一残余映射保证所有普通 central evaluations 的 Teichmüller residue 一致；普通稳定 lattices 可先在有限 projective cover 上取所有 translates 的和。 |
| 996–1073，`cap:probe` 第一段 | 同一个 β 先加入 integral crossed order；U 为 p′，principal-unit cohomology 消失可消去余下 H³ 与 inertia H²，不需要对不同 labels 另换 whole β。 |
| 1075–1143 | Hall J 满射 onto U 的理由是 quotient index 同时为 p-power 与 p′；coinduced centre C 中显式 cochain `c(j,l)(x)=z(x,j,l)` 消去 outer H³，原 S 确实嵌入。没有假设原中央字符存在 J-invariant extension。 |
| 1145–1179，`cap:evaluation-isomorphism` | K0 是 p′ 群，所以 averaging idempotent integral；`e0 T→Rβ` 的逆与 identity coefficient 检查确保 evaluation 没有杀掉 A。 |
| 1181–1243 | 统一 inner gauge 后乘法比值在 `Z²(H,R×)`；p′-root cover 给出真实群代数 sector。各 homogeneous bimodule Picard classes 不同，endomorphism ring 的半单商中 central idempotent 的所有对角余数相同，因此 sector 确实是一个 block，不是 blocks 的和。 |
| 1245–1306，`cap:fong-cover` | 核对 An–Eaton Theorem 3.1 的实际条件：positive defect、`O_p(I)=1`、normal defect-zero block；不是误用该论文的 TI 分类结论。`Sβ=[E0,E0]` 完美，p′ 中心和 centralizer equality 由 almost-simple quotient 推出。 |
| 1308–1386，`cap:actor-order` | LL20 的 map 适用于实际 group automorphism trivial-source bimodules。normal-source kernel 的范围是 `Hom(E,k×)`，不是整个 Picard group；fusion image quotient 必须包含内 p 群 U0。逆像在 mod U0 后为 p′，才能选含 E 的 Schur–Zassenhaus complement。 |
| 1388–1424 | independent base-pair 论证无阶数偷换。`GL2(p)` 在 `P\B` 的 stabilizer 是 p′，故每个 orbit size 被 p 整除，获得额外的除 p，而非只使用普通 base-two 的平方界。 |
| 1426–1505，`cap:mass-from-probes` | 两个 cyclic probes 的预算及 V4 的三个 C2 probes 都是完整 category 的预算。逐 orbit 贡献分别为 a+b≥4 或固定的 6，能控制 orbit 数；未将不同 orbit 任意纠正后相加。 |
| 1507–1566 | 对 C5 与 C3 使用的是整个 effective actor 的阶界；C3 若全固定则可纠正 probe rank 为 6，违反 F=3，故必须是一固定点加一 transposed pair。 |

### 3.4 global 1568–2353：正常 p 子群、最小反例与精确缺陷乘积

| 行段/标签 | 逐段检查与攻击点 |
|---|---|
| 1579–1633，`cap:central-fiber` | Fourier PIM 计算给 `DλᵀDλ=Cc/|Z|`；primitive corners 对 central local kZ 的 freeness 给 `Cc=|Z|Cbar`。这只给 Gram identity，稿件另行证明 row-count，未混同两者。 |
| 1635–1660 | 所选 block centre 是 class-sum permutation OP-lattice 的 direct summand；P abelian 确保每个 transitive permutation lattice 的 end ring local。Krull–Schmidt 因而给指定 λ 的重数不超过 trivial 重数。 |
| 1662–1724，`cap:normal-p-linearization` | G 与 A⋊G/A 的 p-regular lifts 和 centralizer orders 对应；full Brauer Gram 的 inverse 是 full Cartan，所以 target block partition 是实际指定的 partition。这里没有把 G/A 的块直接认作 G 的块。 |
| 1726–1782 | 对每个 `(λ,c)` packet，`DλᵀDλ=Cc` 的 column connectivity 与 induction matrix 非负性保证整个 packet 进入同一个 block。相同 modular induction 和 block partition 使 split packet 匹配同一个目标 block；求和每个 packet 一次。 |
| 1784–1807 | 沿 G-invariant central elementary series 迭代；之前已 split 的 layers 被剩余 Q/A 中央化，所以最终真是直和 V，阶数精确 |Q|。 |
| 1809–1903，`cap:normal-p-descent` | `C_L(V)=V×K` 中的 primitive block 及 Br_V 的非零性给唯一覆盖块；Clifford 求和使用实际 `T_{λ,χ}`。Sylow inverse image 和同一个 idempotent 的 Brauer maps 给精确 `|V|δ(b)|T|_p`，不是只有上界。 |
| 1905–2025，`cap:defect-zero` | inertia Sylow 上 height-zero degree 的 determinant 消掉 Clifford class 的 p-part；valuation exact sequence 保证 integral cohomology 注入，余数为一的 gauge保留原 block selector。Cartan 最大初等因子足够给相同缺陷阶。 |
| 2027–2092，`cap:minimum` | 比较的次序是 defect、central index、group order。proper inertia 包含 Z(G)，故 central index 真严格下降；central p′ kernel quotient 即使指数不降，也降低第三坐标。 |
| 2094–2183 | defect-zero components 被整体剥离；剩余 positive-defect component 至少两个 ordinary labels，非平凡 component permutation 不会 integrally inner。factorwise innerness 用 bimodule Krull–Schmidt 而非普通字符置换核。于是 N 嵌入产品 Out(S_i)，是 solvable。 |
| 2185–2253 | 相对 selector d 在 ordinary evaluation 之前选定。central specialization 的 idempotent lifting 使用 off-diagonal finite R-modules 的 Nakayama，保持 centrality 与 primitivity；d0 是一个共同真实 block。 |
| 2255–2309，`cap:cartan-product` | 第二 tensor factor 的各 corner 对 local R 自由已经足够计算 O-ranks，不需要错误断言 `e_iAe_j` 对 R 自由。tensor Smith forms 给 defect product。 |
| 2311–2353，`cap:exact-defect-product` | Murai 的 integral-inner characterization 与 M 完全匹配；unique cover 加 G-stability 使 B 与 c 是同一 ambient idempotent。Sylow inverse image 的非零 Brauer image 在 G 中仍非零，所以 Q 的 p-part 全额出现，reverse inequality 来自正常块缺陷交。 |

### 3.5 global 2355–3072：同一个 d0、实际返回和最终归纳

| 行段/标签 | 逐段检查与攻击点 |
|---|---|
| 2355–2431，`cap:global-comparison` | 一开始在整条 Γ-action groupoid 上选 lattices；N-factor 是同一个 central cocycle a 的 ordinary evaluation，非逐 orbit 独立挑选 cocycle。 |
| 2433–2500 | 检查 normalizer conjugation formula 的 translated denominator：N 固定 labels 才允许消去平移。centralizer line 的 central unit z(g,n) residue 与 label 无关，因此 residual N algebra 和全部 normalizer arrows 对每个 ordinary label 共同。 |
| 2502–2590 | principal-unit cohomology 的像为 p-primary；用实际 transport arrows 把有限 p-root isotropy cocycles 拉回整条 groupoid。valuation one-cocycle 由 object gauge 去掉，余数再由 Teichmüller one-cocycle 去掉，得到 residue-one gauge。 |
| 2592–2677 | groupoid 中不同 object 的 N-preimages 可有不同 p-cocycles，但 quotient by P 是同一个 residual N algebra。unique central-P block lift 和 residue-one gauge共同保留 d0；所有 arrows transport 同一 selector，故 E_* 是 integral central idempotent。 |
| 2679–2736，`cap:selected-fiber-domination` | 比较的对象是先选 E_* 和同一个 integral C-sector 后的 centre lattice。此后才比较 P 的字符重数；因此没有偷偷把 d0 换成另一个 block，也没有用整群未选 block 的 k 数代替相对预算。 |
| 2738–2800 | quotient section carry `n(q,r)` 留在 actual twisted N algebra。其 associator 的 N-degree 为一，因此 discrepancy 在 degree-one homogeneous line K 中为 scalar；并非把整个 centre误认作K。cycle product 仍包含 `σ(q)^a`。 |
| 2801–2860 | 先在 integral units 层比较 actual 与 factorwise transports；其 ratio 在 R×，所有 ordinary evaluations residue 相同，才得到一个 whole β。不是逐 character 另作 correction。 |
| 2862–2885 | 只在 actual Q-orbits 的 full inertia 上抽取 η_z；η_z 不必延拓全 Q，且可含 p-primary part。容量定理允许任意 whole correction，故接口匹配。 |
| 2887–2962 | `δ_i<Δ` 时每个探针由 actual-probe theorem 实现成缺陷 δ_i 的真实块，第一归纳参数足够；不需要其阶数/中央指数变小。容量预算随后只应用 actual Q_z，最终求和 ≤`|Q|_p k(d0)`。 |
| 2964–2996 | 精确 defect product 强迫 t=1、relative defect=1、Q p′；这里只有一个所需整体探针，并未假设同缺陷的完整探针预算已经成立。 |
| 2998–3065 | actual P0 控制 probe realization 的中央指数。若严格小，直接归纳；若相等，调用端点所要求的恰好是所有较小 defect 或同 defect 较小 central index 的块，与当前 minimum 完全一致。无须假设 realizing group 的阶数小于 G。 |
| 3067–3072 | odd conclusion 仍带 `cap:odd-main` 的条件。p=2 外部结果不是本次 odd global 审查的已验输入。 |

## 4. 几个重点攻击的展开结果

### 4.1 为什么这里的 whole probe 不是虚构群

`cap:probe` 的有效性不能仅由“有限根的 cocycle 可以中央扩张”来说明，因为初始实现元是 block units，未必是原群元素。正文实际做了三个不同步骤：先造 integral corrected order；再把 original quasisimple S 嵌入带 centralizing enlargement 的真实有限群；最后用 p′ scalar cover 和 evaluation idempotent 选出该 order。非同构 homogeneous Picard bimodules 的 local endomorphism rings 才保证选出的 sector 是一个 block。

其后 An–Eaton correspondence 只用来清除 normal p′ centralizing enlargement，并恢复 almost-simple quotient。这一步不假设原中央字符延拓到 enlargement，也不依赖 TI defect。Theorem 3.1 的一般第一结论的假设在此确实得到验证。

### 4.2 同一个 d0 的 domination 是单向比较

最容易出错的替换是把普通 p-primary factor 全部删掉并宣称 rank 不变。正文没有这样做。它先把各 ordinary specialization 的 d 提升到同一 residual d0 的 central-P block lift，取这些 lifts 的共同 central selector E_*，然后在所选 centre lattice 内比较一个 P-character 的重数与 trivial character 的重数。

一个基本压力例说明为什么只能期待 inequality：阶 `p^3` 的指数 p extraspecial group，以中心 P=Cp 为 central kernel。其 principal block 的 trivial central fibre 有 `p^2` 个 ordinary characters，每个非平凡 central fibre 仅有一个 degree-p character；各 fibre 的 decomposition Gram 都是 `[p^2]`。因而“Gram 相同”不意味着“行数相同”，而正文分别证明 Gram identity 与 row-count domination 的安排正是必要的。

### 4.3 精确 defect product 不是装饰性等式

最后的 t=1 与 Q p′ 结论需要等式而非粗不等式。这里有两个独立来源：inner quotient 的 Cartan product 贡献 `δ(d0)`；effective quotient 的 full relative defect 贡献 `|Q|_p`。后者依赖 Murai 的唯一覆盖块结论，让 Sylow inverse image 与原 ambient group 使用同一个 idempotent。其 Brauer maps 删除的是同一组 group-basis coefficients，非零性才可向上保留。

正常 p 子群下降中的相应等式采用同样逻辑，但唯一性改由 `C_L(V)=V×K` 和 Br_V 的 primitivity 给出。两处都没有把“任何唯一覆盖关系自动 full relative defect”作为未经说明的黑箱。

### 4.4 等号分支没有循环用同缺陷探针预算

严格分支从较小 defect 得到每一个 probe 的完整预算，然后才使用容量定理。等号分支没有做这件事：它只从所选 defect-zero relative block 得到一个修正 ξ，将该 ξ 实现为一个 actual almost-simple block。若中央指数相同，端点定理本身给直接界或严格 proper-Levi descent；这与全局最小反例假设相容。中央扩张可能增加 group order，但在这一分支从来没有用第三坐标来声称下降。

## 5. 新增循环外自同构补全：独立攻击及已补细节

审查定位：`odd_endpoints.tex`，`ep:strict-green`（129–188）、`ep:same-label`（190–217）、`ep:factor-completion`（219–250）、新增 `ep:cyclic-outer-completion`（252–305，以上述哈希为准）。这里只在该 subsection 的既定设定中使用：D abelian、U/S 为 p′、`C_U(S)=Z(U)`，c 是 b 的实际 Brauer correspondent。

令 Z=Z(U)。`Z(S)=1` 给 `SZ=S×Z`，而 `U/SZ` 循环给 `U/S` abelian。由 Frattini 和 Ω 的 N-equivariance，χ 与 ψ 的 inertia quotients 确实相同，`J=Uχ=S Nψ`。可以在 `N_J(D)` 中选 g 投影为 `J/SZ` 的生成元；其真实关系是 `g^m=s z`，其中 s 属于 `N_S(D)`。g 还中央化 s，因为它中央化自身 m 次幂且 z 中央。

在 χ 的表示中，`Tχ^m ρχ(s)^{-1}` 中央化 S，故为 scalar。乘一个 m 次方根使 `Tχ^m=ρχ(s)ν(z)` 后，S、Z、g 的生成关系全部保留，给出真实 extension。对 ψ 的 normalizer inertia 使用同一个 g、s、z，同样得到真实 extension。因此两 associated projective systems 的 factor 都为一，且在 `C_J(S)=Z` 上同为 ν；没有把 actual g 的返回改成分裂返回。

必须另外检查 discrepancy 在 Z 上为一，因为它定义为 `λχ/λψ`，其中 λ 包含 inner implementer 分母。主审查员已补入：对 z0∈Z 同时取实际代表 z0；由于 S∩Z=1，这些代表可在整个 Z 上构成群嵌入。u_z0、v_z0 中央，其 `|z0|` 次方来自共同有限 p′ scalar cocycle，所以二者本身均为 p′ scalar roots。`t_z0=1` 和 strict-green identity 给 `u_z0=v_z0`。因此

```
λχ(z0S) = ν(z0)/u_z0 = ν(z0)/v_z0 = λψ(z0S).
```

`SZ/S≤K` 来自 Z 的共轭作用恒等，`K≤J/S` 来自 inner action 固定所有 ordinary characters。故 discrepancy 可降到 `K/(SZ/S)`，它是循环群 `J/SZ` 的子群；选择生成元值的相应根即可延拓，并在 SZ/S 上保持一。这样满足 `ep:factor-completion` 的实际 cochain matching 条件；随后 `same-label` 才保证匹配同一个所选 τ 与 actual normalizer block。

对于当前 centreless F4/E8 应用，没有需另外固定的非平凡 diagonal regular anchor；这里保留的 anchor 是 S 及 prescribed Z-character。此引理不应被擅自解释成“任意额外指定 regular-anchor 数据都自动保持”，但正文此次调用不需要这种更强结论。

## 6. 可复跑有限攻击

完整材料在 `revision_audits/global_chain_fresh_checks/`：

- `check_two_cycle.py`：实际执行脚本，SHA-256 `a9f62d213070fbc475eb29e59f19531555138d324f66e89b9cf2579dcbae55f5`。
- `input.json`：完整输入和枚举域，SHA-256 `96fcfc3cc43b4e9fa906703f1329bd60b0f4ae9b7149fd3fa6343c93184c8c29`。
- `output.json`：实际运行输出，SHA-256 `45d04fa9d91c57eff4fbdbfc451a7a557d0f5d8c0d6be5a87bd4940004cef549`。
- `README.md`：数学计算式、紧例及边界。
- `dependencies.json`：CPython 3.12.14，只有标准库，无 GAP、外部表或网络依赖。

| H | subdirect K 数 | 正规化交换返回数 | 非空标签模型数 | 检查的带标签组合数 | y²非恒等组合数 | 最大 `4f_y/(F+1)^2` |
|---|---:|---:|---:|---:|---:|---:|
| C2 | 2 | 8 | 8 | 64 | 32 | 1 |
| C3 | 3 | 27 | 8 | 216 | 144 | 3/4 |
| C4 | 4 | 64 | 26 | 1664 | 1248 | 2/3 |
| V4 | 16 | 128 | 242 | 30976 | 23232 | 48/49 |
| S3 | 8 | 108 | 80 | 8640 | 5760 | 1 |
| 合计 | — | — | — | 41560 | 30416 | — |

每个 H 的全部 transitive H-set 类型 H/U 按 subgroup conjugacy representatives 枚举，各类型 multiplicity 取 0、1、2，排除全零。K 是 H×H 中投影到两个 H 的所有 subgroups；返回为全部正规化 K 的 `(a,b)swap`，保留 `y²=(ab,ba)`。这些是带标签组合，未将所有同构情形或同 K-coset 的返回去重。

每个 F 直接由所有 U≤H 的实际 stabilizer class counts 算出。trace 用 exact rational commuting-loop sum 计算；另外对每个 H 的最大比率例和一个非恒等平方返回例，直接构造 K 对 `(x1,x2,t)` loops 的共轭类，并计算 y 固定了哪些 classes，独立复核平均式，共十例。

所有直接计算的 intrinsic associators 和 whole corrections 都为一；未枚举非平凡 H²/H³、projective stabilizer factors 或一般 anomalous module categories。结果只能称“枚举域中未发现反例”，不能称 universal verification。

紧例的直接解释：H=C2 在 X={0,+,−} 上反演，K=diag(C2)。在 X² 的 K-equivariantization 中，原点给两个 simples，四个非零±轨道各给一个；swap 交换坐标轴的两个轨道，固定两个对角轨道，并固定原点的两个 simples，所以 `f_y=4`。同时 trivial probe 与 C2-equivariant probe 的 rank 都是 3，故 F=3。

## 7. 原始来源核对与剩余未审接口

本次直接打开并核对以下原始来源，未以综述或旧审查替代：

- Linckelmann–Livesey, *Linear source invertible bimodules and Green correspondence*, [arXiv:2004.10131](https://arxiv.org/pdf/2004.10131)，Theorem 1.1、Example 1.2、Propositions 2.4、3.3、3.4。其 injection 没有 abelian-defect 限制；但只适用于所述 source subgroups，稿件的 actual group automorphisms 正在 trivial-source 范围内。
- Galindo–Plavnik, *Tensor functors between Morita duals of fusion categories*, [arXiv:1407.2783v4](https://arxiv.org/pdf/1407.2783v4)，Remark 3.1 与 Theorem 7.9。这里用于实际 pointed bimodule 的 invertibility，没有把普通 rank equality 误当 tensor equivalence。
- An–Eaton, *Blocks with trivial intersection defect groups*, [作者版](https://eprints.maths.manchester.ac.uk/51/1/pc09k1q7ac55wpyb.pdf)，Theorem 3.1 的一般 defect-zero reduction 部分。该部分与随后的 TI/p-local-rank 特殊结论分开，当前调用只取前者。
- Murai, *On blocks of normal subgroups of finite groups*, [DOI](https://doi.org/10.18910/26820)，本地原始文本的 integral-block convention、Lemma 2.1(iii)、Theorem 3.5(i)。这确认 M 的定义和 unique-cover 接口，而非只凭相似记号推断。

以下仍是本报告的外部输入或明确范围边界：

1. `aff:theorem` 的全部分类与数值证明，特别不能由本次 two-cycle 有限试验代替。
2. classical/exceptional endpoint 的 source-extension 输入、实际 source-carrier descent 和完整分类覆盖；这由其他独立审查处理。
3. `all_prime_levi.tex` 中 241–894 的几何与全 actor scalar construction。这里仅确认其给出的 ambient functors、中央关系保留及中央指数严格下降足以接入 global induction；不声称重新证明其中段。
4. finite-category 全部 coherence 的机器形式化验证不存在。本次是逐段数学重建与有限压力测试，不能以脚本输出取代 `cap:two-cycle` 的 anomalous case 证明。

在这些范围界定下，本次没有额外留下一个已定位但无法补足的 global 内部推理接口。应保持 conditional theorem 的表述，直到独立局部输入的真实证明完成；不应把本报告升级为完整 Brauer conjecture 的无条件完成声明。
