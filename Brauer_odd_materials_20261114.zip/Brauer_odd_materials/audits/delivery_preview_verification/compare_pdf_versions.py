#!/usr/bin/env python3
"""Compare original and distributed PDFs without removing document metadata."""
from pathlib import Path
import argparse
import hashlib
import json
import fitz


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('original', type=Path)
    p.add_argument('preview', type=Path)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    with fitz.open(a.original) as x, fitz.open(a.preview) as y:
        if len(x) != len(y):
            raise SystemExit('PDF page counts differ.')
        text_differences, render_differences = [], []
        for i in range(len(x)):
            if x[i].get_text() != y[i].get_text():
                text_differences.append(i+1)
            u = x[i].get_pixmap(matrix=fitz.Matrix(.5, .5), alpha=False)
            v = y[i].get_pixmap(matrix=fitz.Matrix(.5, .5), alpha=False)
            if ((u.width, u.height, hashlib.sha256(u.samples).hexdigest()) !=
                    (v.width, v.height, hashlib.sha256(v.samples).hexdigest())):
                render_differences.append(i+1)
        result = {
            'original_compiled_sha256': hashlib.sha256(a.original.read_bytes()).hexdigest(),
            'download_preview_sha256': hashlib.sha256(a.preview.read_bytes()).hexdigest(),
            'original_bytes': a.original.stat().st_size,
            'preview_bytes': a.preview.stat().st_size, 'pages': len(x),
            'page_text_differences': text_differences,
            'raster_differences_at_36_dpi': render_differences,
            'pymupdf_version': fitz.VersionBind,
            'scope': 'Exact extracted-text and 36-dpi pixel comparison, allowing metadata bytes to differ.'
        }
    a.output.parent.mkdir(parents=True, exist_ok=True)
    a.output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))
    return int(bool(text_differences or render_differences))


if __name__ == '__main__':
    raise SystemExit(main())
