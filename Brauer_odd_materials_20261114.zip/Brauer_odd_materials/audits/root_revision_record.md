# Root revision record — 2026-11-14

## Status

The unconditional odd-prime theorem has **not yet been certified**. Three first-pass reviewers read all five original odd-prime modules in full. Three different agents are repairing the foundations, classical sources, and exceptional endpoints. A further fresh review must read the rewritten files. This record is an audit aid, not part of the mathematical article.

## Files owned and changed by root

### `brauer_odd_revision/preliminaries.tex`

New independent odd-prime notation: modular system, ordinary/Brauer characters, decomposition and Cartan matrices, defect orders, central characters, group structure, scalar factor sets, projective regular-class bound, elementary Clifford inequalities, permutation counts. The decomposition matrix is `Q_b`; `D_b` remains a defect group. No citation or reference to the old prime-two paper occurs.

The regular-class bound is proved by the action of twisted basis elements on each conjugacy-class subspace. The class inequalities and commuting-pair identity are also proved. Standard block theory and Clifford theory remain established public inputs.

### `brauer_odd_revision/odd_affine.tex`

1. Replaced the ordinary p-solvable two-cycle paragraph by the exact input dictionary from the independent first review. The actors are `H_i=pr_i(K)`, not arbitrary full primitive normalizers. The categories are `Rep_C(U_i)` with strict linear pullback actions. All p-prime subgroup probes, for every common multiplier, are bounded by the coprime k(GV) theorem. The y-compatible equivalence with the affine representation category and the actual y² return are stated.
2. Defined `D=dim_K V` and `z=|Z|` at the start of the primitive component subsection. Defined `e=|A:A_0|` and `r(phi)` before the field-transfer inequality.
3. Rebuilt the scalar-average estimate. For a linear subgroup `B <= A_0` containing Z, the set P consists of specified conjugacy classes of B/Z; `K_* = |P|` and `H_*` is the sum of `q^{-sigma(x_P)}`. The definition of sigma uses the largest fixed eigenspace over scalar multiples. Averaging commuting partners over scalar cosets yields the three terms with coefficients 1,2,1; the three substitutions (x,y), (y,x), (xy,y) give 3,6,3. The later high-motion application explicitly takes B=A_0 and the high-motion projective classes.
4. Removed repeated editorial warnings about class marks, subgroup monotonicity, and induction cycles. The relevant actual-kernel hypotheses and strict dimension inequalities remain.

The scalar-average expansion is a **new root derivation to be independently checked**. First-pass reports reviewed the old compressed paragraph, not this expansion.

### `brauer_odd_revision/odd_global_capacity.tex`

1. Renamed the corrected tensor comparison from F to `mathfrak a` so it does not collide with the numerical probe bound F.
2. Defined `C_i[u_i]` as the full subcategory on u_i-fixed simple labels, distinguishing it from equivariantization.
3. Made the normal-p linearization sum run explicitly over one G-orbit representative lambda and each actual quotient block c once.
4. Added a direct count in the pointed-bimodule invertibility step. After radicals are divided out, endofunctors are supported on graphs in X×X. There are |X| such graphs, each with abelian stabilizer N_2/R_2; a left-translation functor trivializes its multiplier, leaving |N_2/R_2| simples. This matches the number of distinct full left translations. The standard Morita criterion is still cited accurately. This **new expansion requires fresh review**, especially the graph/support description and the passing-to-full-image comparison maps.
5. Removed repeated defensive prose in the equality-defect branch without changing its relative block, specified probe, or strict central-index induction.
6. The old final reference to the prime-two label remains temporarily, pending final assembly. It must become the sole external TangPrimeTwo26 citation in the final all-prime deduction.

### `introduction_history.tex`, `bibliography.tex`, `preamble.tex`

The introduction is historical prose only so far; no new unconditional abstract has been written. It uses Brauer 1946, Brauer–Feit 1959, Fong 1961, Nagao 1962, Brauer 1963, Dade 1966, the coprime solution, Malle 2018, Sambale 2019, Ardito–Sambale 2022, height zero 2024, the 2025 history, and current Lie-type methods. The date on a refreshed 2026 Sambale PDF is not treated as its publication date.

New bibliography keys: Fong61, MNST24, RizoSchaefferFry25, Sambale19, TangPrimeTwo26. Legacy endpoint aliases will be normalized using the mapping in `finalize_brauer.py`. In particular `ep:Ruh22` means Ruh22Sigma, whose Corollary 12.5 is an odd-prime type-A result; the endpoint reviewer is verifying its exact source.

The style follows the user's selected public Hexagon TeX: 11pt AMS article, Latin Modern, black title/text, blue links and numbers; no AI-use, credit, or acknowledgments section. The blue reference text in the selected Hexagon source used normal 11pt body text, with no local font-size command.

## New exact verification

`revision_audits/verify_type_a_scope.py` is a new standard-library-only checker. It verifies PSL3(7) by exact finite-field matrices, including the element outside the Levi centralizing its 3-torus quotient and the elementary abelian defect group. For PSL3(19), it constructs the quotient torus and A/3A from matrices and derives the conjugation matrix from these quotient labels. The matrix is not merely inserted as an expected input.

Result: `type_a_scope_result.json`, all assertions passed. The q=19 example refutes the old Jordan-block step; the checker does not decide characteristicity of A in that example.

## External status and preservation

ProofAtlas, November 12, 2026 edition: rank 298, “Open · subcases solved”. The literature search located no independently published solution for all odd primes, within the documented public search scope. This is not evidence that the supplied argument is correct.

The revision checkpoint is distinct from the old complete delivery. The current checkpoint contains working claims and is explicitly marked under audit. Primary-paper PDFs are excluded from redistribution unless their license has been separately verified; the final supplement should retain source URLs, exact computational inputs, scripts, and execution records.

## Recovery and new independent pass, 08:41 UTC

All core manuscripts and prior deliveries were found intact after the reported interruption. A 240-file preservation checkpoint was saved and validated, retaining the archived original delivery separately from the current working revision.

The affine/classical fresh review found the full outer-automorphism bound false at PSL3(4); the prime-to-three bound actually used in the budgets has been proved and checked. Two independently written toral type-D repairs are now available. A new reviewer found that image-level stabilizer splitting alone cannot be pulled back across the lifted E(check K) kernel; the revised argument must use separability in the standard external semidirect product before transport and inflation. An abstract C2×C2 example records why this distinction matters.

The new reviewer also found an unstated prime-degree hypothesis in the old d>=3 citation to CS25 Corollary 4.12(b). Its all-character replacement uses Corollary 4.12(a), the explicit eta=1 induction argument, and Proposition 4.14. This replacement is being written and independently checked; it is not treated as closed by the earlier scope report.

The exceptional final reviewer completed a new full reading and independent calculations. The raw/transported Lang return and the missing global all-ordinary transversal input have been repaired. A wholly new global reviewer has started a separate attack on the complete capacity, probe, normal-p, and relative-block chain. No unconditional final certification has yet been issued.

The portable added checks were rerun after relocation: exact type-A matrices, the 106-table screen parser, all 16 E8 order polynomials, fresh affine arithmetic, and the independent 201-color/E8-root/166-degree calculations all passed. Their finite scopes remain separate from the proof audit.
