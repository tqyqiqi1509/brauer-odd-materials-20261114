# Fresh exceptional audit checks

These are newly executed checks for the independent endpoint audit dated
2026-11-14. They check the finite arithmetic described in the accompanying
report, not the unconditional Brauer k(B) theorem.

From the workspace root, the carrier runs were:

```sh
brauer_runtime/gap-4.14.0/gap --bare -q -b -T brauer_article/ep_certificates/carriers/e7_overlap_gap4.g > revision_audits/exceptional_final_independent_checks/e7_fresh.out 2> revision_audits/exceptional_final_independent_checks/e7_fresh.stderr
brauer_runtime/gap-4.14.0/gap --bare -q -b -T brauer_article/ep_certificates/carriers/e8_overlap_gap4.g > revision_audits/exceptional_final_independent_checks/e8_fresh.out 2> revision_audits/exceptional_final_independent_checks/e8_fresh.stderr
python revision_audits/exceptional_final_independent_checks/verify_independent.py
```

The Python script independently checks:

- All 201 retained overlap colors in the new GAP outputs, with unused archival
  E7 colors excluded.
- The E8 source centralizer root test modulo five.
- All 16 rational isolated E8 order polynomials at e=3,4,6.
- The full 166 exported E8 generic-degree valuation profiles for e=1,2.

It requires Python 3 and SymPy. The source generic-degree export is in
`brauer_article/ep_certificates/e8_degrees/`; the GAP permutation inputs are in
the carrier directory shown above. Those files must accompany a relocated
version or the two BASE paths in the script must be adjusted to the relocated
certificate tree.

`SpaethD25_published.pdf` is the published 78-page original from the DOI URL in
`SpaethD25_source_manifest.json`. Its text was extracted by PyMuPDF 1.26.6.
Theorem A, printed page 47, and Section 3.3, printed pages 63–64, were checked
for the global ordinary-character transversal and maximal extendibility input.

`independent_results.json` contains the new exact results and input hashes.
