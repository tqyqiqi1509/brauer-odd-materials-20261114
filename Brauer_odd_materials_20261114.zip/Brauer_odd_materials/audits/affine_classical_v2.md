# odd_affine / odd_classical 第二次独立强审

审查人：`odd_affine_classical_audit_v2`  
日期：2026-11-14  
结论：**现文不通过。已经核实一个源引理的适用范围错误，以及同一证明中的错误 Jordan 块断言；未发现 Brauer 猜想本身的反例。** 下列修补需要改稿后由新审查人再次核验，不能把“有修补路线”当成“已经修好”。

## 1. 覆盖、方法与结果边界

完整按顺序读完 `brauer_article/odd_affine.tex` 第 1–3619 行和 `brauer_article/odd_classical.tex` 第 1–989 行。为了核实 affine 的 two-cycle 接口，另外顺序读了 `odd_global_capacity.tex` 第 21–500 行，重点对照两个完整 probe 定义、纯 two-cycle 定理和 mixed two-cycle 引理。本审查不继承上一轮的 pass 结论，也未修改正文。

| 部分 | 本轮判定 |
|---|---|
| affine 的严格维数归纳、semisimplification 顺序 | 未发现同维循环；具体依赖见第 4 节 |
| affine ordinary p-solvable two-cycle 的 probe 接口 | 通过，现文宜以第 3 节的明确字典替代重复略述 |
| ternary signed-code、四群标记、n=8 边界和 coarse-cycle 闭合 | 顺序核完；未发现计数错误或普通字符/共同共轭类偷换 |
| GT05 的 19 个例外、GS03 的 socle-conjugate 范围 | 原论文陈述已核，匹配当前应用 |
| classical all-level 系数、determinant/central quotient 算术 | 解析步骤已读；本轮复跑 34,752 个系数诊断和 1,000 个 graph/equal-factor 权重，全部通过；有限核验不代替无限尾证明 |
| classical source Levi / characteristic scalar base | **不通过：表中 type A 未限定，存在下述精确反例** |
| classical rational extensions / actual actor | 有具体未定义对象及未展开的相容性步骤；不能据当前文字宣布完全自包含 |
| defect 81 | 普通/投射 rank 没有在文字上直接混同；对 cap:probe 的最终 block-realization 依赖仍须由该定理负责，数字 81 本身不能替代它 |

计算材料：

- 新写并运行：`brauer_article/revision_audits/affine_classical_source_scope_check.py`。
- 复跑现有系数程序的副本：`brauer_article/revision_audits/classical_exact_v2.py`。
- 本次独立运行产生的收据：`brauer_article/revision_audits/classical_exact.json`。

## 2. 已核实的数学错误：type A 源的范围

### 2.1 确切位置

`odd_classical.tex`：

- 第 388–396 行的 source 参数表明确包含 type A。
- 第 416–425 行以“independent active coordinates”直接推出
  \[
  A=Z(L)_p,\qquad C_S(A)=L=A\times K,
  \]
  并称 residual central isogenies 是 2-primary。
- 第 460–466 行声称 A 是 D 的 characteristic subgroup，其证明使用：非平凡 moved p-power cycle 在 A/pA 上有长度至少 p 的 Jordan 块。

对于含 determinant-one 和 central-p quotient 的 principal type-A 情形，独立坐标模型不能这样使用。

### 2.2 精确反例：PSL_3(7)，p=3

在 SL_3(7) 中令
\[
a=\operatorname{diag}(1,2,4),\qquad
w=\begin{pmatrix}0&0&1\\1&0&0\\0&1&0\end{pmatrix},\qquad
Z=\langle2I\rangle.
\]
令 T 是 determinant-one diagonal torus，令 T_3 是它的 3-part。则
\[
|T|=36,\qquad T_3\cong C_3^2,\qquad |Z|=3.
\]
置
\[
S=\operatorname{PSL}_3(7),\qquad L=T/Z,\qquad A=T_3/Z.
\]
于是 |L|=12、A=Z(L)_3\cong C_3。直接矩阵乘法给出
\[
waw^{-1}=\operatorname{diag}(4,1,2)=4a,
\qquad [w,a]=4I\in Z.
\]
因此 wZ 中央化 A，但 wZ 不在 L 中。这直接否定该范围下的
\[
C_S(A)=L.
\]
同时
\[
D=\langle T_3,w\rangle/Z=\langle aZ,wZ\rangle\cong C_3^2.
\]
aZ,wZ 是一个基；交换两个基的 D-automorphism 把 A=\langle aZ\rangle 送到 \langle wZ\rangle。因此 A 不是 characteristic in D。

新脚本枚举了 27 个上覆矩阵以及中心 3 的等价类，核实了群阶、wZ 不属于 L、wZ 中央化 A、D 为 abelian exponent-three、两个生成元独立等全部断言。

**对主结论的影响。** 第 341–345 行已经知道这个 quotient defect 是 abelian C_3^2，并将它排除在 nonabelian strict estimate 外。所以这不是主定理的反例。但 source 命题本身没有写出这一范围限制；它的泛称不能保持原样。

### 2.3 非abelian defect 81 中仍然错误的证明句：PSL_3(19)

取 q=19、p=3、s=(q-1)_3=9。由 determinant-one 3-torus 除以中心三得到
\[
A\cong C_9\times C_3,\qquad |A|=27,
\qquad |D|=81,
\]
且 D 非abelian。用 determinant-one torus 的两个指数作为坐标，在 A/3A\cong\mathbb F_3^2 上，三循环的矩阵是
\[
\sigma=\begin{pmatrix}2&2\\1&0\end{pmatrix},\qquad
\sigma-I=\begin{pmatrix}1&2\\1&2\end{pmatrix},\qquad
(\sigma-I)^2=0.
\]
所以第 464–465 行所谓长度至少 p=3 的 Jordan 块不存在；此处的非平凡 Jordan 块长度是 2。脚本还精确核实 D 的阶为 81 且非abelian。

这里**没有证明 A 非characteristic**；反驳的是正文所给的证明步骤。全 3-adic 模块上的 (σ−1)^2 仍可非零，因此可以另证其 characteristicity。但这需要另外的论证。

现文第 953 行的 defect-81 分流明写 s=w=3；PSL_3(19) 的参数是 s=9、w=3，所以不能声称现有分流已经自动处理了这句错误。若重新构造 actual corrected block probe 并明确给所有 |D|≤81 的分支，AS22 可能提供另一条路线，但单独说“81 已知”不够。

### 2.4 最小正确修补路线

建议使用现稿本来已经存在的分流，而不是修补一个不必要的 type-A characteristic-base 泛命题。

1. 将第 374–497 行 source construction 的范围写清：首先只覆盖 B,C,D 的独立 active scalar coordinates。若继续包括 type A，至少明确排除 d_A=1 的 determinant/central-p 情形；对于 d_A>1，另列 independent coordinates 及 p'-central-isogeny 的证明。
2. 第 425 行“residual central isogenies are 2-primary”仅适用于相应 B,C,D 源。即便 d_A>1，type A 的中心也可能含奇数 p' 因子，不能统称 2-primary。所需的正确条件是 relevant isogeny kernel 为 p'，并说明它如何进入 K。
3. 将第 821–837 行的 principal type-A 路线写成一个独立引理。d_A=1 时是 principal block；以 actual maximal Brauer pair (D,e_D) 为起点，写出 C_S(D)/Z(D) 为 p'-group、canonical root character 是 trivial character、其在实际 inertial normalizer 上的 extension 仍为 trivial，以及 defect-centralizing ambient operator 与 Murai pairing 的对应。
4. 这一引理直接给 integral-inner 结论，不再以 A characteristic 或 C_S(A)=L 为前提；因此同时覆盖 central-p quotient。然后再用已证明的 determinant / central quotient 数值上界。
5. 保留第 341–345 行 abelian C_3^2 分流。它排除 strict nonabelian estimate 中的数值例外，不能代替上面的 source 范围修改。

这种修补避免删去一个反例却留下同一错误 proof pattern。具体 Murai 字典由 root/global 审查正在补全：同一 canonical θ、T=N(D,e)、C(D)、e，以及 actual conjugation / local overgroup 需要逐项写出。

## 3. ordinary-cycle 的 p-solvable two-cycle 接口：可复核的通过字典

对应 `odd_affine.tex` 第 1859–1901 行；依赖 `odd_global_capacity.tex` 第 402–500 行的 mixed two-cycle 引理。此处不必再次以几句文字重复 entire currying proof。

### 3.1 分类对象与实际作用

在 r=2 时，定义
\[
H_i=\operatorname{pr}_iK\le\operatorname{GL}(U_i),\qquad
\mathcal C_i=\operatorname{Rep}_{\mathbb C}(U_i).
\]
H_i 是 K 的实际 quotient；K p-solvable 时它们也 p-solvable。不要把 H_i 取成可能非p-solvable的完整 primitive B_i 或其 normal E_i。

每个 C_i 的 simple labels 是 Irr(U_i)。H_i 的线性作用给出严格拉回作用，其 associator ω_i=1，故为 residual action。K 是 H_1×H_2 的 subdirect subgroup。实际有限 transporter y 交换两个 U_i，正规化 K，并把 H_1 送到 H_2；其 y^2 是实际 closing return。

在 E=K\langle y\rangle 上取 whole correction η=1。标准 equivariant-module construction 给出与 y-return 相容的等价
\[
(\mathcal C_1\boxtimes\mathcal C_2)^K
\simeq
\operatorname{Rep}_{\mathbb C}((U_1\oplus U_2)\rtimes K).
\]
故 cap 引理里的 fixed-simple 数正是 affine 命题的 f。

### 3.2 完整 p'-probe 的独立支付

对每个 J≤H_i、p∤|J|，及同一个 scalar multiplier α，probe 的 rank 为
\[
\sum_{[\lambda]\in\Irr(U_i)/J}
 k_{\alpha|_{J_\lambda}}(J_\lambda)
\le
\sum_{[\lambda]} k(J_\lambda)
=
k(U_i\rtimes J)
\le |U_i|=Q.
\]
第一步是 twisted group algebra 的 regular-class bound；等号是 split affine little-groups formula；末步是独立的 coprime k(GV) theorem (GMRS04)。J 在 U_i 上 faithful，因为它就是实际线性 subgroup。

这一证明支付 **所有** p'-subgroups 和 **所有** whole residual corrections，不是只支付一个喜欢的 stabilizer cocycle。因此满足 complete p'-probe 定义，而不是偷换成逐个 orbit 的较弱估计。对 u_i-fixed labels，其稳定 full subcategory 的 probe 是同一 whole probe 的 direct summand，所以仍有 Q 上界。

### 3.3 实际 p-sections 与 return

对 y 的 p'-part y_0，因 p 为奇数，coordinate permutation 仍是 exchange。每个 y_0-stable p-class 可选 z∈Ky_0 中央化代表 u。z 的 p-part 位于 C_K(u)，在相应 equivariant category 上 inner；去掉该部分后仍有 actual p'-exchange。

cap:hall-coset 的输入是 C_K(u)\langle z_{p'}\rangle 及同一 scalar central sector。该群 p-solvable，其 Hall base projections 是 H_i 的 p'-subgroups。cap:mixed-two-cycle 于是逐 section 给 (Q+1)^2/4；section 数至多 k_p(K)≤|K|_p。得到现文第 1861–1862 行。

**此接口没有调用 global block induction、cap:probe block-realization，或当前维数的 weak affine theorem。** 这里需要保留的是 cap:mixed-two-cycle 自身的独立证明；其前提与本应用匹配。本轮没有发现这一接口的数学缺口。

建议把第 1864–1901 行压缩为上述对象字典、probe 支付、一次应用。第 1886–1897 行再次略述 radicals/currying，既不增添证明，也容易把 row/column normalization 写得不清楚。

## 4. affine 覆盖和归纳的独立核对

末端第 3549–3618 行的归纳是先在固定 N 证明 completely reducible case，再在相同 N 做 semisimplification。后者使用已经证明的同维 completely reducible case，并不循环。

- reducible completely reducible case：实际 kernel / quotient 作用在严格较小的 summands。
- primitive case：使用 affine 前半部的 independent almost-simple、core 和 component calculations。
- imprimitive Q≥5：固定 coordinate factor 的维数严格变小；moved cycles 的 ordinary-cycle 可调用较小维数 affine。非p-solvable transposition 第 1915–1920 行用的是一个 coordinate U 上的 faithful C_K(z) action，其维数小于两个坐标的总维数。
- Q=3：signed theorem 的 affine 调用仅是较小 coarse block，或 primitive coordinate group 的 regular ternary socle E，维数 a<n=3^a。
- binary-profile、primitive-class-ratio 和 coarse-profile 没有调用一般 affine inequality。subnormal projections 通过 actual kernel filtration 保留，没有使用 J_3 对任意 subgroup 的虚假单调性。
- p-solvable ordinary transposition 使用第 3 节的 independent complete probes。

p=2 技术删除方面：这两个受审文件的主体本身已在 odd-prime 范围重新陈述了所用 affine/counting 技术；不存在一句“由我们的 p=2 本地稿”来支付 ordinary two-cycle。它们仍调用本论文的全局基础或通用引理，删除 prime_two 后必须把相关通用定义与证明迁入独立 preliminaries；这一部分的完整依赖清单由 foundations 审查负责。

本轮没有从 affine 部分找到可复核的反例，但这不是对其数十项分类表、未在本轮重建的全部公共输入的形式认证。下面两项定义欠账必须修。

## 5. classical 系数、central quotient、actual actor 与 defect 81

### 5.1 系数与 determinant 算术

第 1–205 行 all-level generating functions 的正系数缩放、prime-power level tail 和 factorial defect 比较已逐步读；没有发现把高 level 尾项删掉的步骤。第 210–244 行 graph mark 比较保留了 all-level series。第 257–340 行 cyclic Clifford h²/s 权重与 scalar-stabilizer divisor sum 保留 central loss；第 341–345 行排除了确切 abelian quotient 例外。

复跑诊断参数：p∈{3,5,7,11,13,17,19,23,29,31}，a=1,…,4，所有 c|(p−1)，weight≤180，共 192 参数行、34,752 系数；另 graph/equal-factor 比较到 weight 1000。全部通过。该诊断来自现有脚本的原样副本，并非新写的第二套算法；新独立工作是对数学推导的顺序审核以及第 2 节矩阵反例。

### 5.2 extension gluing 不能只保留“差一个 scalar”一句

第 563–579 行的 gluing 可以成立，但需明确以下完整假设及 construction：

- K_0=L∩M；从 H≤L、M=HV'、V'∩L=H' 可推出。
- θ_0∈Irr(K_0) 确实有 genuine extension τ 到 L_{θ_0}。
- 使用的是 M 中稳定 **τ** 的 subgroup，或先通过 Clifford uniqueness 证明所用 m 稳定 τ；仅 m 稳定 θ_0 不足。
- σ 在该 subgroup 上 genuinely extends θ_0，并与 τ 的 K_0-restriction 选为同一矩阵 representation。
- 对 m，τ-invariance 的 intertwiner 与 σ(m) 在 K_0 上都 intertwine θ_0，因 Schur lemma 差 scalar；这才推出
  \[
  \sigma(m)\tau(l)\sigma(m)^{-1}=\tau(mlm^{-1}).
  \]
- 因此 ρ(lm)=τ(l)σ(m) 定义在实际 product 上；需检验 intersection relation 后才能 induction。

现文“its M-stabilizer”没有明确稳定的是 θ_0、原 θ 还是 correspondent τ；不能把上述关键不变性略掉。更后面的 (NE)_θ-invariance 还需所选 extension map 的实际 equivariance，而不是只存在某个 extension。此处本轮未构造反例；判定为证明欠账，不是已证为假的结论。

### 5.3 actual actor / defect 81

第 974–985 行对 actual H≤A_b 的普通界
\[
\sum k_{\eta_\chi}(H_\chi)\le |H|k(b)
\]
与 |H|_{p'}≤|A_b|_{p'} 配合是正确的；没有把 projective character degree 当 ordinary defect degree。

第 953–969 行在 s=w=3 时依赖 cap:probe 把 whole residual probe 实现为 finite central cover 上的真实 block β，并保持 defect D，再用 AS22。这个逻辑不能缩成“twisted rank≤81”；它要求完整的 actual realization 与 common central sector。文字现在保留了这些要求，本轮未发现它在此处擅自略去 cocycle。然而 cap:probe 本身的全面正确性不在本报告重复认证范围内。

## 6. 未定义记号和需要重写的局部对象

### affine

- 第 1149 行首次使用指数中的 D，却没有在此前局部定义 D=dim_{F_q}V；第 1181 行只说 total degree D≥4，仍不如正式定义。
- 第 1172 行 r(φ) 需要定义为相应 field image φ 的 order，并说明固定域为 F_{q^{1/r(φ)}}。
- 第 1156–1161 行 K_*、H_* 的 summation set 和“threefold charge”应在公式前明定。现在可以猜到是 projective packets 和 pair charging，但自包含文字不应让读者猜。
- 第 1815 行又把 D 用作 Hall core，虽局部可行，但若前节总维数也叫 D，建议保持明显 section-local 定义，或使用 d_V / R_0 等不同语义记号。

### classical

- 第 385–386 行 L_s^* 未定义。必须先给 dual semisimple label s_0、selected cuspidal datum、algebraic ambient group、F 和 L_s^* 的构造。
- 第 380–381 行 ε 被定义为由 d 决定的 sign，表第 395 行却继续用 type-A 的 linear/unitary sign 语义。两种 sign 应区分，或将 type-A 参数表移回自己的定义域。
- 第 403–406 行 primitive weights 的 ζ、ε_i、active matching basis 没有定义。
- 第 505–514 行 c_i,h_i,h_0,p_i' 需要给出 Tits generators / torus elements 的定义；仅给 c_i'=c_{2i−1}c_{2i} 不能定义右边对象。
- 第 533–554 行 V'、E、regular enlargement、good representative、derived transversal 没有在本文完整定义其群、作用和选取条件。
- 第 586–590 行 ψ,ζ,x,h,t,F 的局部群和字符没有字典。给修正公式以前必须说明这些符号属于哪个 actual finite group。
- 第 601–605 行 Butterfly restriction / central-triple correspondence 需给本次使用的准确 statement 与映射，尤其是何者保留 faithful central values、实际 multiplication 和 outer return。
- 第 620–621 行 M_0、t_1,t_2 未定义。

这些不是为了机械增加篇幅。它们决定 source / actual extension / integral unit 是否来自同一群，是 self-contained odd-prime 论证中的实质数据。

## 7. 表述清理建议

以下位置是可删除或以肯定性数学句代替的防御性说明，不属于证明所必需的条件：

- affine 1999–2000：never replaced actual return…
- affine 2133–2135、3119–3122：解释共同固定 conjugacy classes 不可替代；正文保留 precise definition / equality 即可，审查理由可放材料。
- affine 2377：No splitting…；可直接在引理写 B/D cyclic，证明保留 closing relation。
- affine 2682–2684、2725–2726、3166–3167：多次重复没有用任意 subgroup monotonicity。只保留每次 actual subnormal chain 的证明。
- affine 2917、3512–3513、3536–3542、3614–3616：有些是有价值的 induction/domain 信息，但可汇为一次明确的 induction ordering，而不在每个小节重复否认错误路线。
- classical 489–490、527、607–608、963–964、971、974：区分真正假设/return relation 与对审查过程的解释。保留必要 mathematical information，删去审查叙述口气。

“actual”在很多地方确实有数学作用（指定 subgroup、return、central extension），不应一律删。只在对象已经定义后删去连续重复的修饰。

## 8. 本轮外部原文核验

- Guralnick–Tiep, *The non-coprime k(GV) problem*, J. Algebra 293 (2005), Thm 1.4、1.6：原论文全文中，Thm 1.4 的 almost quasisimple / O_p(G)=1 范围、cross-characteristic 19 个 socle 例外，与 affine 200–207 行一致。读到原文同时说明 reducible reduction 与 semisimplification，现文的独立扩展没有借 p=2。
  原论文文本：[author-associated full paper](https://www.academia.edu/164985282/The_non_coprime_k_GV_problem)。DOI：10.1016/j.jalgebra.2005.02.001。
- Guralnick–Saxl, *Generation of finite almost simple groups by conjugates*, J. Algebra 268 (2003)：原文 α 使用 socle-conjugates；Thm 4.1 对 prime-order elements 的低维 graph exceptions，以及 Thm 4.3/4.4 的 arbitrary-element bounds 与稿内用法匹配。
  原论文文本：[publisher paper transcription](https://www.academia.edu/95917548/Generation_of_finite_almost_simple_groups_by_conjugates)。DOI：10.1016/S0021-8693(03)00182-0。
- Malle–Navarro–Robinson, *Conjugacy class numbers and π-subgroups*：作者 PDF 的 Thm 2.9 及 proof/low-rank cases 已核。其一般 Lie-type unipotent witness 可以支付 defining-characteristic ordinary class bound；小例外须保留稿中的分支。
  [作者 PDF](https://agag-malle.math.rptu.de/~malle/download/GGG.pdf)。

本轮没有把网络摘要、旧 local manuscript 或旧代理的 pass 结论当作上述定理的证明。BR23 / CS25 的全套 extension-map statements 仍须在下一批补写/核对中给出对象字典及确切范围；本报告不宣称已经重新证明这些外部深结果。

## 9. 提交给下一批的最低验收条件

1. 修正 source scope，并新增 principal type-A root lemma；重新用 q=7 与 q=19 检查，无一 false general statement 留在正文。
2. 给 classical source/extension 的所有 actual groups、characters、central elements、stabilizers 和 return maps 逐一定义；重写 gluing 并核 τ-invariance。
3. 写出 N→S 的 Murai root/pairing 字典，不以一个模糊“same pairing”句替代。
4. 把 affine p-solvable two-cycle 换成第 3 节的完全匹配应用；保留独立 cap:mixed-two-cycle proof。
5. 删除 p=2 正文时，将所需通用 foundations 原地重证；odd proof 不得重新引用本地 p=2 稿。
6. 再由新代理从修改后的 statements 开始顺序审核，不能只核本报告列出的补丁。

**当前可交付判断：现稿尚不能以“已完成无条件、完全自包含证明”通过本轮强审。已核实错误有明确局部修补路线；修补后的整体正确性仍须再审。**
