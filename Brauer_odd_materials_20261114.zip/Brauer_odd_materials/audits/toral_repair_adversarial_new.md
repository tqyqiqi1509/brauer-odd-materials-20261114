# Mixed toral type D: fresh adversarial review and exact supplementary proof

审查员：`/root/toral_repair_adversarial_new`  
日期：2026-11-14  
任务范围：`cl:toral-pending` 的两个输入；兼查 `cl:toral-transfer` 及直接消费者。没有修改论文正文。

## 1. 结论及其精确范围

在逐项核对原始文献、重新推导全部群接口之后，我没有找到所述 mixed toral 结论的反例。对于下面列明的范围，候选方案能够补成一个完整的、以明确列出的已发表/公开定理为输入的证明：

- \(d=1\) 且 ambient type D twisted，或 \(d=2\)；
- residual factor 非空，total rank 至少五；
- active rank 至少四，或 active rank 三的 \(\mathrm{SL}_4(q)/\mathrm{SU}_4(q)\)；
- 包括偶数 \(q\)，包括 residual rank 一的 torus；
- 所有 active toral \(\lambda\)，没有 ordinary-degree 的 \(p'\) 限制；
- 对每个 compatible、已选入实际 residual good transversal 的 \(\varphi _2\)，对**每个** \(\psi\in\Irr(N^\circ\mid\Phi)\)，得到到原实际 \(\widehat N_\psi\) 的 genuine extension。

原候选文字不能在省略所有解释的情况下直接盖章。发现且在下文补齐的真正逻辑精度问题是：CS25 Definition 5.24 用的是作用在有限对角扩张 \(\check K_i\) 上的群，而非仅其在 \(K_i\) 上的像；此外，**image subgroup 的 stabilizer factorization 一般不能直接拉回**。本报告第 7 节给出完整修复，且提供一个抽象反例说明为什么需要这一步。

这不是全篇 \(k(B)\) 论文的无条件通过证书。本审查没有重新审完全部 exceptional endpoints、integral foundations、global induction。正文在本次读取时继续保留 conditional statement 是正确的。这里通过的是所显示的 toral 接口，在接受第 3 节精确外部定理输入、并写入下面补证之后的数学闭合。

本报告也不把“引用到定理”称为“已经将该定理的证明全部自包含重写”。若最终文章仍要求对 MS16/CS13 的 torus extension-map 构造作全文自包含展开，该写作要求须另行完成。

## 2. 实际阅读和快照记录

完整阅读：

1. `affine_classical_final_fresh.md` §6.1–6.7；
2. `toral_gap_independent_attack.md` 最初的 579 行版本，之后又核对其冻结修订版的改动；
3. `odd_classical.tex` 全文，尤其两个 Clifford lemmas、actual rational groups、`cl:toral-pending`、actor consumer 和 `cl:strong-bound`；
4. `odd_endpoints.tex` 的定理前提及 classical-source consumer；`odd_global_capacity.tex` 的 conditional reduction 和 almost-simple invocation；
5. CS25 原始文本的 §2.B–2.E、Proposition 4.14 及证明、§5 的 group definitions/comparison、Definition 5.24、Propositions 5.25/5.30、§6.A generic construction；MS16 §3.A–3.C 及 Theorem 3.18；CS13 §5.1、Proposition 5.9、Corollary 5.14。

额外用原始 CS25 PDF 第 48 页核对了 `check` 和 lifted actor 记号。Rossi 2023 直接检查了机构仓库中的正式出版版本 Proposition 2.4、其证明及 Proposition 2.2。没有沿用其他审查人的 PASS 标签作数学依据。

| 文件 | SHA-256 |
|---|---|
| `affine_classical_final_fresh.md` | `04559a2aa3b512482da900b12844d172d321c2e7c10d482a74f570687dd88e0d` |
| `toral_gap_independent_attack.md`，首次完整读 | `b81c084d40e075611e98b22116eaa5c16991702e358f5f48a08188acdeb48ed6` |
| 同文件，冻结修订版 | `195f946b6812f6500c6ab832ee1f05fe7b809d32adb6e732a21fc864cda353d7` |
| `odd_classical.tex`，首次完整读 | `8158106e133ab59696e5520820ce851725b5cbe085b65f457975d786482a2bc9` |
| 同文件，root 增加 ordinary-quasisimple setup 后 | `3924e3a44ebc8eebcc96c27b1acc7f6258461e5b752a8eb3925f4c007cdbc362` |
| `odd_endpoints.tex`，首次 consumer 读 | `12a18c2a75e960f01418a89c91e5ddbd9859e35684dbe9269de9d0df639a8671` |
| 同文件，审查期间另一作者更新后的快照 | `1cf4a48acc995f90ef8db4608b900415c803186f318e8c40345f0c2edd076654` |
| `odd_global_capacity.tex` | `277090440070f9f432830071ad8cb38f5c108a60815af585318555dc19fdba27` |
| `primary/CS25.pdf` | `9f95e88fb175cf3e82d2ab9e7cfa167cddb154ec8388d103f1a5c34e2543754e` |
| `primary/CS25.txt` | `132179073b8f2002d95ef105037a17e71ec132c569bb3e43a422fcd425a2b142` |
| `primary/MS16.pdf` | `52f788543920f20e4f11323deb85995f346bba43ec05a8fffe417b6b5f80e68b` |
| `primary/MS16.txt` | `c6c5f3e6f2ad23667a71610733a95033daaae748f38f070172698e2d3fd49156` |
| `primary/CS13.pdf` | `536f7a8565b3b6faf81d90d5c684e53a1821069f5a7ae46fda3cda14c128e221` |
| `primary/CS13.txt` | `b228ff79b69e160a49bd898b9bbe87a5138a5287062e5ee8fd6a94cb417fcdc8` |

共享目录中正文仍在由其他作者编辑；本报告不把将来的文件 hash 当作已读过的内容。

## 3. 原始输入的真实范围

| 输入 | 真正提供的结论 | 本证明如何使用 |
|---|---|---|
| MS16 Cor. 3.13，pp. 880–881 | 对**全部** \(\lambda\in\Irr(T)\) 的 \(NE\)-equivariant map；每个值有线性 genuine extension，其核含 \(v\widehat F\) | active rank 至少四、odd \(q\) 的 standard toral map |
| MS16 Prop. 3.4，pp. 876–877 | 用一个 Lang conjugation 及定义返回元的商，传到 actual standard finite groups | transport whole map；不得只搬字符作用而忽略核 |
| CS13 Prop. 5.9，pp. 18–19；Prop. 5.3，pp. 13–14 | analogous full-character map 与 actual descent | active rank 三；见第 5 节的 isotypic-line 精化 |
| CS25 Remark 2.22，p. 15 | type D、\(d=1,2\) 的 A(d)、B(d) | 验证 Prop. 4.14 前提 |
| CS13 Thm. 5.1、Cor. 5.14 | type A 的 A(d)，equivariant regular-embedding map | active \(D_3=A_3\) 的 A(d)、B(d) |
| CS25 Prop. 4.14(b)，pp. 36–37 | \(\mathcal G_d(K)\leftrightarrow\Irr(N)\) 的**全 ordinary** bijection 和 central triple relation | 没有在 \(\Irr_{p'}\) 之外误用 McKay bijection |
| CS25 Lemmas 5.14/5.19，pp. 43–45 | actual restriction images 的 equality 或 diagonal conjugacy modulo inners | 构造一个统一 \(\Lambda _1\)，传递 splitting |
| CS25 Def. 5.24、Prop. 5.25(e)，pp. 48–49 | lifted actual actor 的 good/bad sets；\(f\) odd 时 extension-obstruction sets empty | 必须与 restriction image 分清；见第 7 节 |
| CS25 Prop. 5.30(b)，p. 51 | actual \(M^\circ\lhd ME(M)\) 上全部 relevant characters 的 maximal extendibility | 最终 actual mixed extension；保留所有 central returns |
| CS25 Def. 2.5、Lemma 2.6、Thm. 2.8，pp. 10–11 | equal factor sets、equal centralizer scalars、actual carrier change | 第 8 节列出全部 maps/preimages |
| Rossi 2023 Prop. 2.4，pp. 45–46 | 先给 full ordinary lifting；prime-degree clause 是另一个附加结论 | \(K=K_1,A_0=N_A(\mathbf S),J=M^\circ\) |

Rossi 原始正式版本：[The McKay Conjecture and central isomorphic character triples](https://boa.unimib.it/retrieve/a172679d-3dd0-42a7-af2c-6fd44456e140/Rossi-2023-J%20Algebra-VoR.pdf)，J. Algebra 618 \(2023\), 42–55，DOI 10.1016/j.jalgebra.2022.12.004。

CS25 §6 明确整体假设 \(d\ge3\)。因此本修补没有直接把其 Proposition 6.3 或 Lemma 6.6 的陈述应用到 \(d=1,2\)；下面只重建其不依赖 \(d\ge3\) 的 generic argument。

## 4. Actual groups：几何接口逐项复算

固定 CS25 Notation 5.1/Table 5.1 的实际模型。将 active factor 记为 \(K_1\)、residual factor 记为 \(K_2\)，而**不强制**它们分别等于原文的 \(G_1,G_2\)。例如 \(d=1\) twisted ambient 下，active split factor 是表中的 \(G_2\)。

令 \(F\) 为该模型的实际 Frobenius，

\[
M_0=K_1K_2,\quad M^\circ=(\mathbf K_1\mathbf K_2)^F,
\quad M=M^\circ\langle n\rangle,
\quad\widehat M=ME(M),\quad E(M^\circ)=E(M)\langle n,h_0\rangle.
\]

这里 \(K_1\cap K_2=\langle h_0\rangle\)，偶数 \(q\) 时 \(h_0=1\)。令 \(\mathbf S\) 是 active Sylow \(d\)-torus，\(\mathbf T_1=C_{\mathbf K_1}(\mathbf S)\)。在本范围内它是 maximal torus：\(d=1\) active split；\(d=2\) active sign 为 \((-1)^{\ell _1}\)。

取

\[
C_1=\mathbf T_1^F,\quad N_1=N_{K_1}(\mathbf S),\quad
C=C_{M^\circ}(\mathbf S),\quad N^\circ=N_{M^\circ}(\mathbf S),
\]
\[
H=N_{M_0E(M^\circ)}(\mathbf S),\quad
\widehat N=N_{\widehat M}(\mathbf S),\quad C_0=C_1K_2.
\]

由于两个 algebraic factors 逐点交换，

\[
C_{\mathbf K_1\mathbf K_2}(\mathbf S)=\mathbf T_1\mathbf K_2.
\]

因此 \(C_1\le Z(C)\)，而 rational central-product exact sequence 给出 \([C:C_0]\le2\)。若 quotient 非平凡，由 connected torus 上的 Lang theorem 取 \(u_1\in\mathbf T_1\)，满足 \(u_1^{-1}F(u_1)=h_0\)。取原来的 \(t_2\in\mathbf K_2\)，其 Lang value 同为 \(h_0\)。则 \(u_1t_2\in C\)，并代表 \(M^\circ/M_0\) 的非平凡 coset。因此

\[
M^\circ=CM_0=CK_1,\qquad N^\circ=CN_1.
\]

这里换的是**计算 coset 时使用的代表元**，没有重新定义原 \(t_1,t_2,n,E(M)\)。特别是 \(t_1t_2\) 的平方仍是原来的 \(t_1^2t_2^2\)。

由 CS25 Lemmas 5.13(a)/5.18(a)，

\[
E(M^\circ)\cap M^\circ=\langle h_0\rangle\le M_0,
\quad M^\circ\cap M_0E(M^\circ)=M_0.
\]

故 \(C\cap H=C\cap M_0=C_0\)。再由 \(\widehat M=C M_0E(M^\circ)\)，取 \(\mathbf S\)-normalizer 得 \(\widehat N=CH\)。\(K_i\lhd\widehat M\)，而 \(H\) 保持 \(K_1\) 和 \(\mathbf S\)，所以 \(H\) normalizes \(N_1\)。\(K_2\lhd\widehat N\)，\([N_1,K_2]=1\)，且 \(C,C_0,N^\circ\lhd\widehat N\)。`cl:toral-transfer` 的全部 group hypotheses 得到实际验证。

## 5. 不带 degree 限制的标准 \(\eta=1\) 引理

在 twisted standard coordinates 中写 \(T\lhd N\)，\(T\) abelian。令 \(B=NE^\dagger\)，\(\widetilde N=N\widetilde T\)，其中 \(\widetilde T\) centralizes \(T\)。假设已有一个 \(B\)-equivariant map \(\Lambda^0\)，且每个 \(\Lambda^0(\lambda)\) 扩张为 \(B_\lambda\) 的线性字符 \(\widehat\lambda\)，其核含 central return \(z=v\widehat F\)。

定义 \(\psi_\lambda=\Ind_{N_\lambda}^{N}\Lambda^0(\lambda)\)。Clifford correspondence 给出 irreducibility。

### 5.1 Stabilizer splitting

若 \(te\) fixes \(\psi_\lambda\)，其中 \(t\in\widetilde T,e\in E^\dagger\)，restrict 到 \(T\) 可知 \(\lambda^e\) 与 \(\lambda\) 在同一 \(N\)-orbit。存在 \(n\in N\) 使 \(\lambda^{ne}=\lambda\)。equivariance 给 \(\Lambda^0(\lambda)^{ne}=\Lambda^0(\lambda)\)，故 \(\psi_\lambda^{ne}=\psi_\lambda\)。内共轭 \(n\) 不改变 \(N\) 的 irreducible characters，所以 \(e\) fixes \(\psi_\lambda\)，继而 \(t\) fixes 它。于是

\[
(\widetilde N E^\dagger)_{\psi_\lambda}
=\widetilde N_{\psi_\lambda}(E^\dagger)_{\psi_\lambda}.
\]

此证明没有用 \(|N:N_\lambda|_{p}=1\)，也没有把某个 toral extension 值换成同一 fiber 中的另一个值。

### 5.2 Genuine extension

同一 argument 给出 \(B_{\psi_\lambda}=N B_\lambda\)。令

\[
\widehat\psi_\lambda=\Ind_{B_\lambda}^{B_{\psi_\lambda}}\widehat\lambda.
\]

由于 \(B_\lambda\cap N=N_\lambda\)，单 double-coset restriction formula 给

\[
\widehat\psi_\lambda|_N
=\Ind_{N_\lambda}^{N}\Lambda^0(\lambda)=\psi_\lambda.
\]

所以诱导表示不可约且为 genuine extension。\(z\) central 并在诱导表示的核中，因此可以 quotient by \(\langle z\rangle\)。

### 5.3 Odd \(q\)、rank 至少四的 descent

MS16 Cor. 3.13 正好给出上述两个前提。其 Prop. 3.4 的 Lang conjugation 是按群选一次，不依赖 \(\lambda\)；它把定义 Frobenius return 的核送到 \(\langle v\widehat F\rangle\)。因此 whole map 和 whole selected \(\eta=1\) family 同时传到 actual standard groups。这一步没有选择 unspecified diagonal conjugate。

在 active rank 四，只需 ambient 诱导的 natural graph involution；MS16 的较大 diagram-equivariance 可先 restrict 到该 subgroup。

### 5.4 Rank 三：不能超读 CS13 Prop. 5.3

用 CS13 Prop. 5.9 构造 toral \(\Lambda^0\)，其中每个 \(\lambda\) 为 linear character，适用 5.1–5.2。Prop. 5.3 的证明首先传递的是 \(\psi_\lambda\in\Irr(N)\) 的 splitting 和 extension；Cor. 5.14 的证明说明同一个 transported toral map 的 normalizer equivariance。

如果文章还需要逐字声明**map value 本身**扩张到 actual toral inertia，可从已得到的 \(\widehat\psi_\lambda\) 中取 \(\lambda\)-isotypic line：\(\psi_\lambda|_T\) 的每个 conjugate constituent multiplicity 为一，且 equivariance 给 \(B_\lambda\le B_{\psi_\lambda}\)。这条线在 \(B_\lambda\) 下稳定，其在 \(N_\lambda\) 上的字符正是选定的 \(\Lambda^0(\lambda)\)。因此得到所要求的 genuine linear extension。无需假称 Prop. 5.3 原文就是关于 map values 的定理。

### 5.5 Even \(q\) 的独立补证

此时 \(h_\alpha(-1)=1\)。简单反射的 Tits lifts 满足 Coxeter relations，并生成 \(V\cong W\)，\(V\cap\mathbf T=1\)。在标准 \(vF\)-coordinates，

\[
N=T\rtimes V^{vF}.
\]

这是实际 fixed-point decomposition：每个 fixed Weyl element 在 \(V\) 中有唯一的、因此 fixed 的 lift；再把任意 normalizer 元除以此 lift，余下元素在 \(T\) 中。field 和 graph generators preserve complement。

对 \(\lambda\in\Irr(T)\)，定义

\[
\Lambda^0(\lambda)(tw)=\lambda(t)
\quad(w\in(V^{vF})_\lambda).
\]

同一个公式在 \(B_\lambda=T\rtimes(V^{vF}E^\dagger)_\lambda\) 上是 genuine linear character：乘法成立正因为 complement 的该 stabilizer fixes \(\lambda\)。它在 \(z=v\widehat F\) 上取一。\(T\)-conjugation 产生的 commutator 被 \(\lambda\) 杀掉；complement conjugation 直接传递该公式。因此 whole map equivariant。

在本 active \(d=1,2\) 情况甚至 \(V^{vF}=V\)：\(d=1\) split；\(d=2\) 的 \(w_0\phi=-1\) centralizes Weyl group，而 \(V\to W\) 为同构。不存在未证明的 nonsplit Tits fixed-point surjectivity。

## 6. Full ordinary \(\Omega\) 和 standard global good properties

CS25 Proposition 4.14(b) 的域是 \(\mathcal G_d(K_1)\)，值域是全部 \(\Irr(N_1)\)。其 degree statement 是附加兼容性，不是这个 bijection 的定义域限制。

Rank 至少四的 A(d)、B(d) 来自 Remark 2.22。Rank 三用 type A 的 CS13 Thm. 5.1/Cor. 5.14；此外 regular embedding 的 \(\widetilde N/N\) 为 cyclic，故 N 的 maximal extendibility 也满足 B(d)。torus-centralizer 一侧的 maximal extendibility 已包含在 Cor. 5.14 的 extension map 中。

令 \(\Omega:\mathcal G_d(K_1)\to\Irr(N_1)\)，\(\chi_\lambda^0=\Omega^{-1}(\psi_\lambda^0)\)。标准 regular embedding 的 group 记为 \(\widetilde K_1\rtimes E^0\)。Sylow \(d\)-tori 的 \(K_1\)-conjugacy 给

\[
(\widetilde K_1\rtimes E^0)_{\chi_\lambda^0}
=K_1N_{\widetilde K_1\rtimes E^0}(\mathbf S)_{\psi_\lambda^0}.
\]

第 5 节的 splitting 因而传为

\[
(\widetilde K_1\rtimes E^0)_{\chi_\lambda^0}
=(\widetilde K_1)_{\chi_\lambda^0}\rtimes(E^0)_{\chi_\lambda^0}.
\tag{6.1}
\]

标准 actual overgroup 上的 central triple relation，通过第 8 节同样的 carrier change 给出。第 5 节 genuine local extension 和 CS25 Lemma 2.6(b) 遂给 \(\chi_\lambda^0\) 到 \(K_1\rtimes(E^0)_{\chi_\lambda^0}\) 的 genuine extension。

中心 compatibility 来自 central triple 的 scalar condition：对 \(z\in Z(K_1)\)，

\[
\frac{\chi_\lambda^0(z)}{\chi_\lambda^0(1)}
=\frac{\psi_\lambda^0(z)}{\psi_\lambda^0(1)}
=\lambda(z).
\tag{6.2}
\]

尤其 \(h_0\) 的 faithful value 没有消失。

## 7. Actual mixed actor：必须补齐的 lifted-group 证明

### 7.1 区分三个群

设 \(K=K_1\)，\(I=\Inn(K)\)，\(D=\operatorname{im}(\check K\to\Aut(K))\)。令

\[
\mathscr E=E_M(\check K)\le\Aut(\check K),\qquad
r:\mathscr E\longrightarrow\Aut(K),\qquad E'=r(\mathscr E).
\]

这里 \(\mathscr E\) 是 **Definition 5.24 的 lifted actor**；\(E'\) 是 Lemmas 5.14/5.19 比较的有限 restriction image。定义其准确的核

\[
L=\ker r=\{e\in\mathscr E:e(k)=k\text{ for every }k\in K\}.
\tag{7.1}
\]

不需要、也不能无条件声称 \(\mathscr E=E'\) 或 \(\mathscr E\) cyclic。

### 7.2 同一个 diagonal transporter 和 whole map

普通 configuration 有 \(E'=E^0\)。Exceptional Hypothesis 5.15 中，若 active 是原 \(G_2\) 也有此 equality；若 active 是原 \(G_1\)，Lemma 5.19 给 diagonal \(a_0\) 使

\[
IE'=(IE^0)^{a_0}.
\]

取 \(i\in I\) 使 \(a=a_0i\in D_{\mathbf S}\)。由于 \(I\lhd IE'\)，该 equality 不变。用一个固定的 \(a\) 定义

\[
\Lambda_1(\lambda)=\Lambda^0(\lambda^{a^{-1}})^a.
\tag{7.2}
\]

它定义在恰当的 \((N_1)_\lambda\) 上并扩张 \(\lambda\)。inner-diagonal automorphisms 是 algebraic conjugations，逐点固定 algebraic center；故 \(a(h_0)=h_0\)。

若 \(b\in N_{IE'}(\mathbf S)\)，则 \(aba^{-1}\in N_{IE^0}(\mathbf S)\)，从 whole-map equivariance 得

\[
\Lambda_1(\lambda)^b
=\Lambda^0((\lambda^{a^{-1}})^{aba^{-1}})^a
=\Lambda_1(\lambda^b).
\]

再由 \(\Omega\) 的完整 equivariance，

\[
\psi_\lambda=(\psi^0_{\lambda^{a^{-1}}})^a,
\qquad\chi_\lambda=\Omega^{-1}(\psi_\lambda)
=(\chi^0_{\lambda^{a^{-1}}})^a.
\tag{7.3}
\]

### 7.3 为什么只说“image splitting 拉回”不够

反例：令两份 \(C_2\) 各自在二点集上交换两点，\(C_2\times C_2\) 按二者的乘积作用。image 中每一点的 stabilizer 为一，因此 image 的 factorization 成立。但原 direct product 的 point stabilizer 是 diagonal \(C_2\)，两个 factor stabilizers 的乘积却为一。

所以候选文字中从 \((DE')_\chi=D_\chi E'_\chi\) 笼统直接拉回的说法需要补证。下面的逐元素方法完全补掉这一点，并控制 possible mixed kernel。

### 7.4 正确拉回：从 standard actual semidirect product 出发

式 (6.1) 是**实际半直积**中的 equality，factor decomposition 唯一。因此对任意 \(d\in D,e_0\in E^0\)，

\[
(\chi^0)^{de_0}=\chi^0
\quad\Longrightarrow\quad
(\chi^0)^d=\chi^0=(\chi^0)^{e_0}.
\tag{7.4}
\]

证明是任选 \(d\) 的 regular-embedding lift，应用 (6.1)，再利用实际半直积的唯一 ordered factors。

现在设 \(\chi=(\chi^0)^a\)，\(d\in D,e'\in E'\)，且 \(\chi^{de'}=\chi\)。由 \(IE'=(IE^0)^a\)，写 \(e'=i e_0^a\)，\(i\in I,e_0\in E^0\)。将 (7.4) conjugate by \(a\)，并用 inner automorphisms 在 \(\Irr(K)\) 上平凡，得 \(e_0^a\) fixes \(\chi\)，\(di\) fixes \(\chi\)。所以 \(e'\) 和 \(d\) 分别 fixes \(\chi\)。

最后令 \(\check g\in\check K,e\in\mathscr E\)，若 \((\check g,e)\) fixes \(\chi\)，其对 characters 的作用正是 \(d\,r(e)\)。上一段给出 \(\check g\in(\check K)_\chi\)、\(e\in\mathscr E_\chi\)。故

\[
(\check K\rtimes\mathscr E)_\chi
=(\check K)_\chi\rtimes\mathscr E_\chi.
\tag{7.5}
\]

这正是 Definition 5.24 的 splitting，且没有丢弃任何混合 kernel element。

### 7.5 Genuine extension 的 inflation：exact map、exact kernel

若 \(R\) 为 \(K\rtimes E'_\chi\) 上延拓 \(\chi\) 的 ordinary representation，定义

\[
q:K\rtimes\mathscr E_\chi\longrightarrow K\rtimes E'_\chi,
\qquad q(k,e)=(k,r(e)).
\tag{7.6}
\]

\(q\) 为 surjective homomorphism，因为 \(r(e)\) 就是 \(e\) 在 \(K\) 上的作用，且 \(\mathscr E_\chi=r^{-1}(E'_\chi)\)。其核**恰为** \(\{1\}\times L\)。所以 \(R\circ q\) 是 genuine representation，restrict to \(K\) 仍为 \(R|_K\)，即延拓 \(\chi\)。

这个 inflation 杀掉的只是 external factor 中的 restriction kernel。它在 normal subgroup \(K\) 上为 identity，故 \((h_0,1)\) 从未被除掉，原 \(h_0\) 标量保持不变。这与稍后 mixed group 的 centralizer kernel 不是同一操作。

### 7.6 Exceptional case 的 \(f\) 与 cyclicity：精确适用

Hypothesis 5.15 给 \(\epsilon_1=-1,\epsilon_2=1\)，两份 rational \(Z_i\) 均为四阶。CS25 2.24(c) 于是迫使 \(q\equiv3\pmod4\)、原 \(\ell _1\) odd、原 \(\ell _2\) even。写 \(q=r^f\)，有 \(r\equiv3\pmod4\) 和 \(f\) odd。这不是任意 twisted type D 的结论；只用于 Hypothesis 5.15。

在 finite restriction image 上，原 \(G_1\) 的 actor 为

\[
E'_1=\langle t_1\gamma_1,F_r^2\rangle.
\]

两生成元交换，前者平方为一，后者在 twisted \(G_1\) 上的 order divides odd \(f\)；故 \(E'_1\) cyclic。原 \(G_2\) 的 image 等于 \(\langle\gamma_2,F_r\rangle\)，同理由互素阶 commuting factors 得 cyclic。任何 \(E'_\chi\) 亦 cyclic。

对于 cyclic quotient，取生成元 lift \(u\) 和 intertwiner \(T\)。若 quotient order 为 \(m\)，Schur 引理给 \(T^m\rho(u^{-m})=cI\)；乘以 \(c^{-1/m}\) 后 \(T^m=\rho(u^m)\)，于是给出普通 representation。这控制了实际 return，而不仅是 projective extension。由 7.5 inflation，得到 Definition 5.24 所需的 lifted genuine extension。

这也独立解释了 Prop. 5.25(e) 的 \(\mathcal E_1=\mathcal E_2=\varnothing\)，没有从 outer conjugacy 推出 genuine extendibility。

### 7.7 更明确的 active restriction kernels（非必要但有助于防错）

在 active rank 至少三、上述 pinned normalization 中，普通 configuration 的 \(\mathscr E\) 是标准 \(\langle F_r,\gamma_i\rangle\) 在 \(\check K\) 上的限制，故

\[
L=\langle F_K|_{\check K}\rangle,
\]

这里 \(F_K\) 是 active defining Frobenius。理由是标准 semilinear group 在 \(K=\mathbf K^{F_K}\) 上的 restriction kernel 由 \(F_K\) 生成；再 restrict 到 \(\check K\)。该群可能非平凡，不能省略。

Exceptional active 为原 \(G_1\) 时，\(\mathscr E=\langle F_r^2,t_1\gamma_1\rangle\)，其 restriction kernel 为 \(\langle F_q^2|_{\check K}\rangle\cong C_2\)。具体地，原 rank odd，algebraic center 为 \(C_4\)，\(F_K=\gamma_1F_q\) 在这个 center 上平凡。对 \(x^{-1}F_K(x)=z\in C_4\)，有 \(F_K^2(x)=xz^2\)。Lang surjectivity 给 order-four \(z\)，故 \(F_K^2=F_q^2\) 在 \(\check K\) 上非平凡且平方为一；而 \(F_r^2\) 在 \(K\) 上 order \(f\)。所以 lifted actor 可以是 \(C_2\times C_{2f}\)，并**不 cyclic**。

Exceptional active 为原 \(G_2\) 时，\(\mathscr E=\langle F_r^2,\gamma_2\rangle\)；rank even、center \(C_2^2\)、split \(F_q\) 在 center 上平凡，故 \(F_q^2=1\) 在 \(\check K\) 上。因此 \(F_r^2\) 在 \(\check K\) 上仍为 odd order \(f\)，restriction kernel trivial。

第 7.5 节的证明只需核的 exact definition (7.1)，不依赖这两项 numerical description。

### 7.8 Pull back 到 actual \(H\)-action

令 \(\rho:M_0E(M^\circ)\to\Aut(K_1)\) 为 conjugation。其 image 是 \(IE'\)。该有限 automorphism action 在 \(F\)-stable algebraic subgroups 上 well-defined：定义 Frobenius powers 稳定每个 \(F\)-stable subgroup，而 central algebraic elements 的 conjugation 平凡。active ranks 三以上不出现特殊 graph-field isogeny 例外。

故

\[
\rho(H)=N_{IE'}(\mathbf S),\qquad
\ker(\rho|_H)=C_H(K_1).
\]

kernel 中每个元素逐点固定 \(N_1\le K_1\)，因而不改变任何 selected map value 的 character。第 7.2 节的 equivariance 拉回给实际 \(H\)-equivariance。此处没有声称 kernel 在后续 mixed representations 上取一；后续 central scalars 必须保留。

综上，对所有 \(\lambda\)，有一个统一 \(H\)-equivariant map，且

\[
\Omega^{-1}\!\left(\Ind_{(N_1)_\lambda}^{N_1}\Lambda_1(\lambda)\right)
\in\mathcal T_1
\tag{7.7}
\]

其中 \(\mathcal T_1\) 是原 Definition 5.24 的实际 good set。

## 8. Butterfly：全部群、像、核与 full preimage

令 \(\widetilde T\) 是 CS25 Lemma 5.7 的 ambient regular diagonal torus，

\[
A=(M\widetilde T)E(M),\qquad J=M^\circ,\qquad A_0=N_A(\mathbf S).
\]

\(K_1,J\lhd A\)。Sylow \(d\)-tori conjugacy 给 \(A=K_1A_0\)。定义

\[
\kappa:A\to\Aut(K_1),\qquad Z_A=\ker\kappa=C_A(K_1).
\]

这里 \(Z_A\) 不必是 abelian group，也不必是 \(Z(A)\)。不能因记号像中心就把它除掉。它包含整个 \(K_2\)，并满足 \(Z_A\le A_0\)。最后一点用的是 finite automorphisms 在 \(F\)-stable algebraic subgroups 上的 action，而非把 algebraic torus \(\mathbf S\) 错当作 \(K_1\) 的有限 subgroup。

固定 \(\chi_1\in\mathcal G_d(K_1)\)、\(\psi_1=\Omega(\chi_1)\)。设

\[
\Gamma_0=\kappa(A_0),\qquad
\Gamma_\chi=\Gamma_0\cap\Aut(K_1)_{\chi_1}.
\]

首先把 full Prop. 4.14 relation 限制为

\[
(K_1\rtimes\Gamma_\chi,K_1,\chi_1)
\ge_c(N_1\rtimes\Gamma_\chi,N_1,\psi_1).
\tag{8.1}
\]

restriction 合法，因为 \(\Gamma_\chi\le\Aut(K_1)_{\mathbf S,\chi_1}\)。在两边用实际 conjugation map \((k,g)\mapsto\Inn(k)g\)。左 image 是 \(I\Gamma_\chi\)，右 image 是 \(\Gamma_\chi\)，因为 \(\Inn(N_1)\le\Gamma_\chi\)。

另一方面，\(A=K_1A_0\) 与 inner invariance 给

\[
\kappa(A_{\chi_1})=I\Gamma_\chi.
\]

右侧 image 的完整 preimage 为

\[
\kappa^{-1}(\Gamma_\chi)\cap A_{\chi_1}
=(A_0)_{\chi_1}=(A_0)_{\psi_1}.
\tag{8.2}
\]

第一个 equality 包含两方向：任何 \(A_0\)-element 的 image preserving \(\mathbf S\)；反过来，若 image preserving \(\mathbf S\)，任选相同 image 的 \(A_0\)-lift，两者相差 \(\ker\kappa\le A_0\)，故原元素也在 \(A_0\)。最后的 character equality 用 \(\Omega\)-equivariance。

因此 CS25 Thm. 2.8 给

\[
(A_{\chi_1},K_1,\chi_1)
\ge_c((A_0)_{\psi_1},N_1,\psi_1).
\tag{8.3}
\]

这一步保留**完整** \(C_A(K_1)\)。按 Definition 2.5，存在 associated projective representations \(P,P'\)，factor sets 在 local group 上相同，且对每个 \(z\in C_A(K_1)\)，

\[
P(z)=s(z)I_{\chi_1(1)},\qquad
P'(z)=s(z)I_{\psi_1(1)}.
\tag{8.4}
\]

特别是这对整个 \(K_2\) 和 \(h_0\in K_1\cap K_2\) 成立。

## 9. 提升到 \(J=M^\circ\)：为什么 \(K_2\) constituent 真被保留

将 Rossi Prop. 2.4 的符号代为

\[
K=K_1,\quad A_0=N_A(\mathbf S),\quad J=M^\circ,
\quad\mathcal S=\mathcal G_d(K_1),\quad\mathcal S_0=\Irr(N_1),
\quad\Psi=\Omega.
\]

所有 group/equivariance/central-triple hypotheses 已在第 8 节验证。其 full ordinary assertion 给一个 \(A_0\)-equivariant bijection

\[
\Pi:\Irr(J\mid\mathcal G_d(K_1))\longrightarrow\Irr(N_J(\mathbf S))
=\Irr(N^\circ),
\]

并给相应 central triple relation。因此对应 \(\chi\leftrightarrow\psi\) 满足

\[
A_\chi=J(A_0)_\psi,
\quad \chi\text{ extends to }U
\Longleftrightarrow
\psi\text{ extends to }N_U(\mathbf S)
\tag{9.1}
\]

对 \(J\le U\le A_\chi\) 成立。

这里的 residual compatibility 还可直接核算，不能只用“存在一个 bijection”代替。固定 \(\chi_1\)，在 inertia quotients

\[
J_{\chi_1}/K_1
\cong N_J(\mathbf S)_{\psi_1}/N_1
\]

上取同一个 inverse-factor-set projective representation \(Q\)。对应的 ordinary representations 为 \(P\otimes Q\) 和 \(P'\otimes Q\)。对 \(k_2\in K_2\)，由 (8.4)，两侧分别为

\[
I_{\chi_1(1)}\otimes(s(k_2)Q(k_2)),\qquad
I_{\psi_1(1)}\otimes(s(k_2)Q(k_2)).
\]

所以两侧在 \(K_2\) 上含有完全相同的 irreducible constituent types，仅 multiplicities 随 active degree 改变。对 \(h_0\)，\(Q\) 因子为 identity，因为它来自 quotient by \(K_1\)，原 common central value 就是 \(s(h_0)\)。

再作 Clifford induction。可从 \(N_J(\mathbf S)\) 中取同一组 coset representatives，因为 \(J=K_1N_J(\mathbf S)\)，且 \(K_1\) centralizes \(K_2\)。因此两侧得到相同的 conjugate pairs，保留的是**配对后的** \(\chi_1.\varphi_2\)，而非分别只检查两个 restriction constituent lists。故

\[
\Pi\bigl(\Irr(J\mid\chi_1.\varphi_2)\bigr)
=\Irr(N^\circ\mid\psi_1.\varphi_2).
\tag{9.2}
\]

选择 projective data 时可在 \(A_0\)-orbits 的代表元上选一次，再 transport；\(K_2\lhd A\) 保证上述 property 在 transport 后仍成立。Rossi 的 ordinary lifting theorem 正是给出所需 coherent choices 和 inertia-level triple relation 的工具。

## 10. 从实际 Proposition 5.30(b) 到每个 \(\widehat N_\psi\)

CS25 Prop. 5.25(a) 与 good-set splitting 给 \(E'\)-stable diagonal transversal \(\mathscr T_2\subseteq\mathcal T_2\)。具体构造：先在 field–graph group 对 diagonal orbits 的每个 orbit 中选一个 good representative，再取其 field–graph orbit。splitting 的逐元素性质保证 diagonal orbit 的 external stabilizer fixes 该 representative，所以构造 well-defined。

\(\widetilde T\) 在 residual factor 上诱导 full diagonal action，见 Lemma 5.7(b) 的 generators；\(H\) 在 residual factor 上通过 inner automorphisms 和实际 \(E'_2\) 作用。因此 \(\mathscr T_2\) 是 \(H\)-stable。

取 compatible \(\lambda\) 和 \(\varphi_2\in\mathscr T_2\)，设

\[
\psi_1=\Ind_{(N_1)_\lambda}^{N_1}\Lambda_1(\lambda),\quad
\chi_1=\Omega^{-1}(\psi_1),\quad\Phi=\psi_1.\varphi_2.
\]

由 (6.2)、\(a(h_0)=h_0\)，\(\chi_1.\varphi_2\) 是原 central product 上的 well-defined character。由 (7.7)，\(\chi_1\in\mathcal T_1\)。

对任意 \(\psi\in\Irr(N^\circ\mid\Phi)\)，令 \(\chi=\Pi^{-1}(\psi)\)；(9.2) 给

\[
\chi\in\Irr(M^\circ\mid\chi_1.\varphi_2)
\subseteq\Irr(M^\circ\mid\mathcal T_1.\mathcal T_2).
\]

Prop. 5.30(b) **没有 \(d\ge3\) 前提**，给 \(\chi\) 到实际 \(\widehat M_\chi\) 的 genuine extension。令 \(U=\widehat M_\chi\) 应用 (9.1)，得到 \(\psi\) 到

\[
N_{\widehat M_\chi}(\mathbf S)
=N_{\widehat M}(\mathbf S)_\psi
=\widehat N_\psi
\]

的 genuine extension。quantifier 是每个 \(\psi\)，并非只存在一个 diagonal conjugate good constituent。

实际关系

\[
(t_1t_2)^2=t_1^2t_2^2,\qquad
[n,t_1\gamma]=h_0,\qquad n^2=h_0
\]

在原组中一直保留；最后两项是 exceptional configuration 的关系。绝未把 \(n\) 和 \(t_1\gamma\) 当作 commuting involutions，亦未令 faithful \(h_0\) 强行取一。

最后，若 \(ch\) fixes \(\varphi_2\)，则 \(\varphi_2^h\) 既在其 diagonal orbit 中，又在选定 stable transversal 中，故 \(\varphi_2^h=\varphi_2\)，然后 \(c\) 也 fixes。于是

\[
(CH)_{\varphi_2}=C_{\varphi_2}H_{\varphi_2}.
\]

这补齐 `cl:toral-transfer` 的 (i)、(ii)，第 4 节补齐其 groups，而第 7 节给 \(H\)-equivariant map。该 lemma 遂给每个 selected \(\tau\in\Irr(C\mid\lambda.\varphi_2)\) 到 actual \(\widehat N_\tau\) 的 genuine extension。

## 11. `cl:toral-transfer` 本身的独立检查

两个 index-at-most-two Clifford cases 均正确。

若 \(\tau|_{C_0}=\theta\)，令 \(V=(N_1)_\tau\)。\(C_1\le V\)，\(J=(N^\circ)_\tau=CV\)，且 \(C\cap VK_2=C_0\)。两个 representations 在 irreducible \(C_0\)-module 上相合，Schur lemma 保证用 \(\sigma=(\Lambda_1(\lambda)|_V).\varphi_2\) 的 matrices 实现整个 \(C\)-representation 的 conjugation。得到 \(J\) 上的 extension \(\rho\)，并由同一 Schur argument 得 \(\widehat N_\tau\)-invariance。

若 \(\tau=\Ind_{C_0}^{C}\theta\)，则两个 \(C\)-conjugates 有不同 residual constituents，因为 \(C\) fixes \(\lambda\)。由 \([N_1,K_2]=1\)，\(J=C(N_1)_\lambda\)，从 \((N_1)_\lambda K_2\) 诱导 \(\Lambda_1(\lambda).\varphi_2\) 给 multiplicity-one extension \(\rho|_C=\tau\)。假设 (i) 正好用于 \(\widehat N_\tau=CH_\theta\)，避免任意交换两个 residual constituents。

两种情形中 \(\psi=\Ind_J^{N^\circ}\rho\) 的 restriction to \(N_1K_2\) 含 \(\Phi\)。第一种情形可先经 \((N_1)_\lambda K_2\) 诱导，Frobenius reciprocity 保证所选 \(\Lambda_1(\lambda).\varphi_2\) 出现；第二种用 induction transitivity。由 \(\rho\)-invariance，\(\widehat N_\psi=N^\circ\widehat N_\tau\)。假设 (ii) 给 extension 后，\(\tau\)-isotypic subspace 的维数恰为 \(\tau(1)\)，所以 restriction 是真正延拓而非多个拷贝。

没有发现该 finite-group lemma 本身需要额外未列假设。

## 12. Adversarial tests 与边界清单

### 12.1 全 ordinary 检验是实质要求

在 active \(K=\mathrm{SU}_4(5)\)、\(d=2,p=3\) 的 diagonal torus 中，用四元 exponent labels modulo common translation 描述 toral characters。取 label \((0,0,1,3)\) modulo six；其 multiset 中唯一重复值是零，所以任何保 label 的 permutation-plus-translation 必须 translation zero；Weyl stabilizer 恰为交换两个零的 \(S_2\)。因此 \(|W:W_\lambda|=24/2=12\)，\(\psi_\lambda(1)=12\) 被三整除。

这个例子说明若把本论证偷换为 \(\Irr_{p'}\) correspondence，会漏掉实际 active toral characters。第 5–6 节的证明仍覆盖此例。

### 12.2 Outer action 不能决定 genuine extension

令 normal subgroup \(X=C_2=\langle z\rangle\)，取 faithful linear \(\chi(z)=-1\)。在 \(C_2^3\) 中它可延拓；在 \(Q_8\) 中把 \(X=Z(Q_8)\) 时它不能线性延拓，因为 \([Q_8,Q_8]=X\)。两个 quotient 都是 \(C_2^2\)，在 \(X\) 上的外作用全平凡。

所以从相同 outer actions 推 genuine extension 的推理确实错误。当前补证将 outer conjugacy 限于 map/splitting，另用 actual cyclic restriction image、inflation、最后实际 Prop. 5.30(b)，避开这个反例。

### 12.3 \(q\) even

\(h_0=1\)、rational join index 为一；仍有实际 graph carrier \(n\)。第 5.5 节没有援引 MS16 difficult proof 中的 odd-\(q\) reduction。CS25 §5 本身允许 \(q\) even，定义 \(\varpi=1\)；Hyp. 5.15 不会发生。

### 12.4 Active rank 三与 residual low rank

\(d=1\) active \(\mathrm{SL}_4(q)\)，\(d=2\) active \(\mathrm{SU}_4(q)\)；CS13 所需 map 是 all-character statement。total rank 至少五时 residual rank 至少二。CS25 §5 的 factors 按 Def. 3.17 明确包括 ranks 一、二、三。Residual rank 一的情况只会伴随较高 active rank；其 diagonal action 平凡，linear character 对 semidirect stabilizer 的 extension 直接可得，但实际 \(n,t_i\) gluing 仍按 Prop. 5.30(b) 处理。

### 12.5 同步 diagonal transport

只把 residual datum 放入 \(\mathscr T_2\) 时，active \(\lambda\) 一并被同一个 diagonal transporter 改变。若 transporter 移动 \(\mathbf S\)，用 active \(K_1\)-inner correction 把 torus 放回；此 correction centralizes \(K_2\)。整个 source tuple、block、carrier 同时 transport。因为第 7.7 式是 all-\(\lambda\)，不必再独立“正规化”active representative。

### 12.6 原始来源的一个排印问题

CS25 Prop. 5.25 proof 的首句写 exceptional comparison “unless \(i=2\)”；其紧随的句子和 Lemma 5.19 实际都把非平凡 conjugacy 放在原 \(G_1\)，而 \(G_2\) 的 restriction image equality 保持。应以 Lemma 5.19 的准确陈述和 actual generators 为准，不应传播该首句笔误。

## 13. 相邻 \(d\ge3\) 句子的额外发现与可用修复

完整读正文时发现，原 \(d\ge3\) 段落若不证明 \(\ell\nmid|N:N_\lambda|\)，不能直接援引 CS25 Cor. 4.12(b) 把所有 induced toral characters 的 inverse images 放进 good set。该 degree hypothesis 在原文 p. 35 明列。这一问题已立即通知 root。

同一个补法有效，但必须写出来：Cor. 4.12(a) 对每个 \(\lambda\) 给 actual standard \((K E^0)_{\mathbf S}\)-equivariant map，且其值 genuine extends to \((K E^0)_{\mathbf S,\lambda}\)。因此第 5 节的 all-character \(\eta=1\) lemma 和全 ordinary Prop. 4.14 重复适用，不需要 Cor. 4.12(b) 的 degree 前提。

该输入的 precise scope 是 \(d=d_\ell(q)\) doubly regular、\(\ell\nmid2q\)、active type D rank 至少四，来自 Thm. 4.1 的 setting。正文 nonabelian \(d\ge3\) 的 active rank 至少十，abelian endpoint 使用处至少八，满足 rank gate。Cor. 4.12(a) 已是 actual finite standard group 的 genuine extension，不能额外声称任意 ambient central return 已被它杀掉；actual mixed return 仍通过本报告第 8–10 节及 Prop. 5.30(b) 处理。

## 14. 最终审查判定表

| 断言 | 本次判定 |
|---|---|
| all-\(\lambda\) standard map（rank 至少四，odd \(q\)） | 原始 MS16 定理确实提供；whole-map descent 已核 |
| rank 三 actual descent | 可证；若声称 map value extension，补 isotypic-line argument |
| even \(q\) map | 由 split Tits complement 直接证明 |
| \(\eta=1\) whole family splitting / genuine extension | 独立逐式证明，无 \(p'\)-degree 假设 |
| full ordinary \(\Omega\) | Prop. 4.14 范围匹配；不能替换为仅 McKay bijection |
| actual \(H\)-equivariance | 统一 diagonal \(a\) 加 exact action kernel 后成立 |
| Hyp. 5.15 \(\Rightarrow f\) odd | 精确成立；不推广到任意 twisted configuration |
| actual \(E'\) cyclic \(\Rightarrow\) lifted good membership | 加 explicit inflation 后成立；lifted actor 本身未必 cyclic |
| image splitting 直接拉回 | 一般错误；第 7.4 节已给完整修复 |
| Butterfly carrier change | group images 和 full preimage 均验证，centralizing kernel 保留 |
| 固定 residual \(K_2\)-constituent | 由相同 centralizer scalars 和同一个 \(Q\) 证明 |
| 每个 \(\psi\) 到 actual \(\widehat N_\psi\) genuine extension | Prop. 5.30(b) + 第 9 节等价，成立 |
| \(h_0,t_1t_2,n,[n,t_1\gamma]\) | 原组与原 scalar data 保留，没有 split replacement |
| `cl:toral-transfer` 的 finite-group proof | 未发现缺口，已重新核对两种 Clifford cases |
| 全篇 odd-prime theorem 无条件成立 | **本报告不作此判定**；需全部其余接口独立闭合 |

本报告的 mathematical conclusion 是一个可供集成的 toral 接口补证；不是对尚未读到的后续 integrated TeX 版本或整个论证链的自动认可。

## 15. 冻结时的集成状态与交接

本报告冻结时，root 已要求另换一位完全新的审查员检查 integrated TeX。我的认证范围仍是上面记录 hash 的两份候选证明与本报告的补证。

| 精度补丁 | 我实际核对的状态 |
|---|---|
| Definition 5.24 的 lifted actor 与 restriction image 区分 | 原独立作者冻结稿已加 restriction-kernel 说明；完整 map/kernel/inflation 在本报告 §7.1、7.5 给出 |
| image factorization 不可直接拉回 | 原候选的笼统措辞不足；本报告 §7.3 给反例，§7.4 给完整修复 |
| standard actual semidirect product 的逐元素 separability | 新 TeX 作者已消息确认采用；我没有读取新 TeX，不能认证其具体实现 |
| rank 三 actual map-value extension | 已把 §5.4 的 isotypic-line 补证通知作者；作者另写了 signed-monomial reconstruction，该新证明不在本轮已审范围 |
| 相邻 d≥3 的 degree hypothesis | 已通知 root；作者准备统一采用 Cor. 4.12(a) + all-ordinary lemma + Prop. 4.14；尚未由我核对集成结果 |
| explicit Butterfly factor-set 公式 | 新作者称在新文件中另写；我这里只核验 source-based generic Butterfly 及全群/核/preimage/scalar dictionary，没有审其新增公式 |

新文件为 brauer_odd_revision/toral_type_d_repair.tex。它不应因本报告的 toral 数学结论而自动获得 PASS。新 reviewer 尤其应重新核对该文件中新增的 explicit cocycle multiplication formula、D-root conjugation 的符号约定、rank-three construction，以及所有 consumer 是否已转用全 ordinary 命题。

最后的 scope gate 保持：只有整个论文所有必要接口各自证明后，才可把 conditional audit edition 改为无条件版本。
