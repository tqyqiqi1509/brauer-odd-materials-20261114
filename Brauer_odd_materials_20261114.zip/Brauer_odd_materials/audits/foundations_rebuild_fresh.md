# 奇素数 Levi 基础重建交接

日期：2026-11-14。代理：/root/odd_foundations_rebuild_fresh。

## 结论、冻结文件与编译

已完成并冻结：

- brauer_odd_revision/integral_foundations.tex：158 行。
- brauer_odd_revision/all_prime_levi.tex：1282 行。

逐句自审后，未发现足以反驳本模块构造的确定反例。这个判断只覆盖上述两文件；**不构成整个 Brauer 猜想、其他 odd 模块或全局覆盖范围的认证**。新一批代理仍须独立读全文。未修改其他正文模块。

根代理应在 all_prime_levi.tex 前输入 integral_foundations.tex。一般引理标签为 lev:partial-morita。

SHA-256：

- integral：e248a3db903a2c141b15f657dce045f4c1a79cd5071ec5e8e2a977a5d30a9ce4
- Levi：146d84c48326b440acc9f2563eb02c7dd4886be8f47d39cabfcc23eeb1c3224b

静态记录：revision_audits/foundations_rebuild_fresh_checks.json。

局部 amsart driver：/tmp/levi_review/levi_check.tex。latexmk exit 0，PDF 20 页（包含现有完整 bibliography）。最终 log 没有 overfull box、未定义引用、未定义控制序列、重复标签或 LaTeX error。这份临时局部 PDF 未作为用户交付，未做最终逐页视觉验收；整篇 PDF 验收仍由根代理执行。

环境默认 TeX 数据库未索引已安装的 amsart.cls。编译使用：
TEXMF='{.,/usr/share/texlive/texmf-dist,/usr/share/texmf,/etc/texmf}'
并在新正文目录运行 latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=/tmp/levi_review /tmp/levi_review/levi_check.tex。

## 实际阅读范围

1. 完整读 revision_audits/foundations_v2.md。
2. 完整按序读旧 brauer_article/all_prime_levi.tex，645 行。
3. 读旧 prime_two.tex 的一般技术部分：4637–4795、4940–5160、5280–5405。迁入技术在新文重证；新文没有引用旧文件或其结果。
4. 原文核验：BR03 Theorem 11.7、B′；BDR17 §7.A、Theorem 7.2、Lemma 7.4、§7.C；Ruhstorfer v1 Lemma 2.10、Corollary 2.13、Lemma 3.1 及证明、Remark 4.7、Proposition 4.8 的有理调整论证；Taylor19 的 regular-embedding 设置、Lemma 6.5 及证明、§8.2–8.8。
5. 新稿写作后完整按顺序读两个文件，逐式核验伴随、群商、诱导算子、factor set、中心商、环境群 Hom/tensor 逆函子。
6. 最终两个模块的 ref/eqref 全部在自身有定义；无重复 label、无未定义书目 key。旧 geo:*、sec:geometry、Part~I、prime_two、p=2 的引用命中数均为零。

## 主要数学修补

### 完整对称阶引理

新 integral_foundations.tex 给出双侧投射、泛型左忠实且右作用泛型满射条件下的积分支撑 Morita 引理。证明包括：

- 对称型给出的 M-dual 的两种 Hom 识别；
- 左、右 dual basis 与四个单位／余单位；
- 四个三角恒等式；
- 两侧张量后的分裂、泛型同构与自由秩零补项；
- Z(A) 到 End_{B-B}(Q) 的泛型同构、积分单射、有限整性；
- 逆元首一方程，证明中心单位下降；
- 积分伴随同构、全忠实函子检测同构；
- 正则 B-双模中心投影、右作用映射的代数识别；
- 生成性与中心幂等元本原性。

根代理另行完整读了此新引理并报告未发现反例。新文保留证明，不依赖旧摘要。

### 普通覆盖与几何

定理只对 odd p 陈述；普通覆盖允许 r=2。B2(2^f)、F4(2^f)、G2(3^f) 的 exceptional inseparable graph 归入 Steinberg-root 命题。定理把 perfect ordinary cover 前提显式写出。

定义了 Y_U、中间次数、左／右算子与完整 diagonal operator；证明完美中心覆盖提升唯一性、C_G(D) 的平凡 lifted action。正规嵌入有权坐标构造、F 与 diagram 兼容、Lang 满射、固定点指数等式。

field unfolding 写出正幂 quotient-variety 逆映射和实际 field return；整个覆盖积统一构造，graded Künneth 符号明确。

删除旧 p=2 分支。p=3、D4 的 semisimple connected centralizer 等式、固定环面与根范数论证独立保留，涵盖所有 3′ 标签。

### 完整 actor、积分端同态与 scalar obstruction

bar X_b 现定义为标签群中的实际像，避免让 Gamma 原投影错误穿过 K0。写出 K0 正规性与平凡算子。

upstairs BR03 调用先验证 full centralizer 条件。完整写 free lifted orbit 的积分 full-idempotent Morita 构造、induction/restriction、左右投射性、左生成性、诱导右作用、transporter 公式、每个 source/target series 的投影独立性与 Frobenius 维数等式。

保留积分 double-centralizer 桥梁，证明 E_b^A 是固定中心局部环，再选 Sylow-fixed primitive summand。

scalar obstruction 展开相对 factor set、根单位 cocycle、Sylow 限制、H1(P,k×)=0 的注入、restriction-corestriction、Hensel 唯一 p′ 次开根。section 改用 varsigma，避免覆盖半单标签 s。

**本轮额外修补的关键接口：cochain 调整后的 corner-span。** 调整单位从 E_e 延到其余 primitive summands 的恒等，再沿 diagonal block orbit 共轭延拓为全 X 单位。随后对调整后的 intertwiners 重新应用诱导算子、独立性及维数论证。不能仅声称任意 E_e 单位调整自动保留旧 span。

### 中央核先降下，后处理 actual ambient group

重排为：

1. 覆盖积 S 上得到 O S b_S 与 O hat J_S c_S 的局部等价；
2. 通过有理 Levi/series 调整证明 G=DH0，再由 primitive transitivity 得 G=DH；
3. 把同一 R_e cocycle 拉回实际 H；
4. 用 z m=m z 限制两个逆函子到所有 z−1 消灭的模；
5. 得到原 D 与 hat J=hat J_S/Z0 的商双模 Mbar；
6. 在 Mbar 上定义实际 G 与 hat H 的环境群 Hom/tensor 逆函子。

这样未假定整个 G 存在一个未构造的中央覆盖。中央 p 核以模范畴商处理；只对 p′ sector 使用积分字符幂等元。

正文逐式验证 Phi 的 D-线性、Psi 的平衡关系和 scalar cancellation、两作用在 J 上吻合、实际 D semidirect H 的核、evaluation 与 unit 的 equivariance。C_G(D) 每个原算子均保留；最后给出 k、Cartan、缺陷阶及严格中心指数。

### Steinberg-root 范围变化

lev:steinberg 现显式要求：F0 在有限覆盖群上的阶和模 inner-diagonal automorphisms 的阶均为 m。这个条件保证 cyclic action 与规定 diagonal action 的交集没有遗漏。仅知 F0 在有限群上的阶为 m，对任意抽象 cyclic lift 不足以排除更早的 inner-diagonal return。

正文在实际 exceptional gamma 家族验证：

- gamma²=F_r，F=gamma^a，子群取 gamma^d，d|a，m=a/d；
- 实际 outer 阶为 m；
- finite diagonal outer part 平凡；
- F4/G2 双对偶中央化子由 simply connected 性连通；
- B2 定义特征二的中心 isogeny 是 universal homeomorphism，保持中央化子连通；
- 非完美小参数群不在该命题范围，须由全局 endpoints 另行覆盖。

新的 quotient-variety 计算逐分量写出，只有 F0 的正幂，没有取不可分映射的逆。F0-compatible smooth regular embedding 由已读原文的 Taylor19 Lemma 6.5 提供。

## 外部基础输入的精确边界

| 输入 | 条件与用途 |
|---|---|
| BR03 Theorem 11.7；BDR17 §7.A | canonical Levi 包含 C°(s)，推出非中间次数上同调消失。 |
| BR03 Theorem B′ | 必须包含整个 dual centralizer。新文只对 regular embedding 的 lifted label 调用，并先证明连通性和包含。 |
| BDR17 Theorem 7.2；Ruh v1 Lemma 3.1 及证明 | 同 Levi 的 integral middle module 比较，且完整 diagonal 等变。 |
| BDR17 Lemma 7.4、§7.C | lifted rational series 的自由轨道、upstairs full-idempotent Morita。未直接把它当作 downstairs full external extension。 |
| Ruh v1 Lemma 2.10、Corollary 2.13、Remark 4.7 | rational Levi duality、automorphism 兼容、F0 与其幂的 Levi 对偶兼容。后续 normalizer 调整在正文展开。 |
| Taylor19 Lemma 6.5 | 任意 Steinberg endomorphism 可延至 smooth regular embedding；已读原证明。 |
| Taylor19 §8.2–8.8 | cyclic-product 固定点和 rational series 对应。本文 quotient-variety 同构另行证明，未把 Taylor 未取商 Lang fiber 的仿射纤维误称同构。 |
| Steinberg68 | simply connected derived group 的 semisimple connected-centralizer theorem；Lang–Steinberg。 |
| Carter72、Carter85 的 ordinary automorphism description | ordinary perfect cover 的 inner-diagonal kernel、有限中心与代数中心识别；exceptional roots 的实际 outer 阶及 diagonal part。此次未重新逐页读两部书的完整 automorphism 分类证明。 |
| Carter85 order formula | proper Levi 的 defining-characteristic order part 严格较小。 |

## 新一批审查重点与剩余疑点

1. **全局覆盖假设。** 每个调用必须满足 perfect ordinary cover、实际作用提升和中央核保持。例外有限 Schur cover、小参数端点不能由本模块自动处理。
2. **基础 automorphism description 的精确出处。** 新文明确使用 C_tildeS(S)=Z(tildeS)、Z(S)=Z(boldS)^F 以及 exceptional root 的 outer 阶；这些是所引用经典分类输入，本轮没有逐页重证，建议核对适用的小参数范围。
3. **有理调整的对偶代表选择。** 正文选择限制到 Levi 仍互为对偶的 rational representatives，随后 n* normalizer 与 series 调整完整。建议新代理核对该选择与 rational-Levi duality 在 unfolded product、组件置换下的匹配。
4. **Steinberg 新增交集条件。** 必须逐个核对全局应用，不能套给任意未核验 cyclic outer lift。
5. **cochain 调整后的 span 与 diagonal orbit 延拓。** 这是本轮主动补出的接口，值得再独立核验。
6. **中央核商和环境群方向。** 建议独立复算 overlap、右作用反序、scalar inverse character、evaluation/unit 两式。
7. 本报告没有审查全局 endpoint 表、source algebra 技术、classical torus lemma、完整归纳或新颖性；这里的局部判断不能替代那些审查。
