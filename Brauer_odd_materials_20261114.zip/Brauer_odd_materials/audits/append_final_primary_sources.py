#!/usr/bin/env python3
"""Append exact identities of the four final-review source PDFs to an index."""
from pathlib import Path
import argparse
import hashlib
import json
import fitz

SOURCES = [
    ('LL20_global_fresh.pdf', 'LL20',
     'https://arxiv.org/pdf/2004.10131v1',
     'a6d9de7244aadfffa418894a9447ebc98c8e4842179c5848a68e26039734d53c'),
    ('NS14_fresh_selfcontainment.pdf', 'NS14',
     'https://ems.press/content/serial-article-files/31954?nt=1',
     '6073cbea9a7f3573636da58b7316b04d617d0b81170ceb34553b45f34d428423'),
    ('Sambale17_fresh_selfcontainment.pdf', 'ep:Sambale17',
     'https://www.iazd.uni-hannover.de/fileadmin/iazd/sambale/pdfs/abeldefect.pdf',
     'ca82d85dc07dc00807c091eb591b4e14d1b705c41b39d609fc304ca64de52808'),
    ('AS22_fresh_selfcontainment.pdf', 'AS22',
     'https://benjaminsambale.github.io/pdfs/cartan5.pdf',
     '0dc1b1a56e7c3ad29cdf3c52be20cd2a0dba1f3849af60ea8f3008f1050789d7'),
]


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--index', required=True, type=Path)
    p.add_argument('--source-dir', required=True, type=Path)
    args = p.parse_args()
    if fitz.VersionBind != '1.26.6':
        raise SystemExit('Use PyMuPDF 1.26.6 for the recorded extraction hashes.')
    index = json.loads(args.index.read_text())
    entries = {e['filename']: e for e in index['files']}
    for name, key, url, expected in SOURCES:
        path = args.source_dir / name
        data = path.read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        if digest != expected:
            raise SystemExit('Source bytes differ: ' + name)
        with fitz.open(path) as doc:
            entry = {
                'filename': name, 'bibliography_key': key, 'urls': [url],
                'sha256': digest, 'bytes': len(data), 'pdf_pages': len(doc),
                'extraction_engine': 'PyMuPDF 1.26.6',
                'page_text_sha256': [hashlib.sha256(page.get_text().encode()).hexdigest()
                                     for page in doc],
                'reading_scope': 'Named statements and interfaces identified in the final global/self-containment review reports.'
            }
        if name in entries and entries[name] != entry:
            raise SystemExit('An incompatible index entry already exists: ' + name)
        if name not in entries:
            index['files'].append(entry)
        print(name, entry['pdf_pages'], digest)
    index['purpose'] = ('Exact identities of the inspected primary PDF versions. '
                        'Newly retrieved papers are obtained from their public sources; '
                        'the original user-supplied archives are preserved intact.')
    args.index.write_text(json.dumps(index, ensure_ascii=False, indent=2)+'\n')
    print('Indexed PDF versions:', len(index['files']))


if __name__ == '__main__':
    main()
