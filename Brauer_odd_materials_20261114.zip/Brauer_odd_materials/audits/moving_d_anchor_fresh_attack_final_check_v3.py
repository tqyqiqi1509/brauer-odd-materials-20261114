#!/usr/bin/env python3
"""Bind the moving-D audit to the final integrated text; not a theorem prover."""
from __future__ import annotations

import ast
import hashlib
import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
FILES = {
    "candidate_v3": ROOT / "revision_audits/moving_d_anchor_replacement_v3.tex",
    "endpoint": ROOT / "brauer_odd_revision/odd_endpoints.tex",
    "standalone": ROOT
    / "brauer_odd_delivery_20261114/Brauer_kB_odd_primes_20261114.tex",
}


def main() -> None:
    contents = {key: path.read_text(encoding="utf-8") for key, path in FILES.items()}
    start = r"\paragraph{Regular blocks and diagonal stabilizers in type \(D\).}"
    body = contents["candidate_v3"].split(start, 1)[1]
    body = start + body
    # The publication assembler canonicalizes bibliography keys.  Read its
    # literal alias table without importing/running the assembly program.
    tree = ast.parse((ROOT / "assemble_brauer_odd_final.py").read_text())
    aliases = next(
        ast.literal_eval(node.value)
        for node in tree.body
        if isinstance(node, ast.Assign)
        and any(isinstance(target, ast.Name) and target.id == "ALIASES" for target in node.targets)
    )
    cite = re.compile(r"(\\cite\w*(?:\[[^\]]*\])*)\{([^}]+)\}")
    normalized_body = cite.sub(
        lambda match: match.group(1)
        + "{" + ",".join(dict.fromkeys(aliases.get(key.strip(), key.strip())
                                    for key in match.group(2).split(","))) + "}",
        body,
    )
    checks = {
        "candidate_body_in_endpoint": body.strip() in contents["endpoint"],
        "candidate_body_in_standalone_after_bibliography_aliases": normalized_body.strip() in contents["standalone"],
        "old_graph_torsor_label_removed": r"ep:graph-torsor" not in contents["endpoint"],
        "ill_typed_annihilator_removed": r"\epAnn(I_b)" not in contents["endpoint"],
        "explicit_cochain_definition": r"a(s c r)=\eta(c)" in body,
        "explicit_inner_kernel_restriction": r"I_{\mathcal F}" in body,
        "central_p_split_present": r"X=X^0\times Z_p" in body,
    }
    receipt = {
        "description": "File-scope and text-integration check only; mathematical audit is in the Markdown report",
        "files": {
            key: {
                "path": str(path.relative_to(ROOT)),
                "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            }
            for key, path in FILES.items()
        },
        "checks": checks,
        "all_passed": all(checks.values()),
    }
    target = ROOT / "revision_audits/moving_d_anchor_fresh_attack_evidence/final_integration_receipt.json"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(receipt, ensure_ascii=False, indent=2))
    if not receipt["all_passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
