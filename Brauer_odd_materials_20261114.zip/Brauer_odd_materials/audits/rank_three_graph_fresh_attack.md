# Fresh audit of the rank-three pinned graph and central return

Date: 14 November 2026.

## Scope and conclusion

This is an independent adversarial review of the rank-three construction in
`brauer_odd_revision/toral_type_d_repair.tex`. I checked the signed-monomial
extension map, the passage from inverse transpose to the pinned graph,
the genuine representation of the actual split inertia group, the unitary
Lang transport, its covering return, the separate extension in the standard
unitary inertia group, and the interfaces with `tdr:eta-one`,
`tdr:standard-O`, `tdr:standard-good`, and `tdr:standard-global-extension`.
The earlier all-one antidiagonal construction was not accepted.

The repaired version reviewed here has no remaining mathematical obstruction
in this rank-three passage, subject to the explicitly invoked standard
Lang theorem and the stated Cabanes--Späth character-correspondence inputs.
This scoped conclusion does not certify the whole manuscript or reprove the
external character-correspondence theorems. In particular, I did not repeat
the full rank-at-least-four Tits construction, the mixed-carrier theorem
CS25 Proposition 5.30(b), the general finite-group reduction, or the
exceptional-group endpoint audit.

Reviewed TeX checkpoint:

```text
484b69f8805cd90e8f78d4f67a909258339ba0acdefa412809331c03e778e509
```

Two notation clarifications were requested after this checkpoint: explicitly
identify the transported unitary torus/normalizer/character, and distinguish
the generic rank-at-least-four descent paragraph from the separate
rank-three passage. These do not alter the group or representation arguments
below. The final checkpoint is recorded at the end of this report after
those clarifications are inspected.

## 1. The old graph was the wrong graph

Let `gamma0(g)=(g^T)^(-1)`. In dimension four let `j` be the all-one
antidiagonal matrix, and let

\[
v_0=\begin{pmatrix}
0&0&0&1\\
0&0&-1&0\\
0&1&0&0\\
-1&0&0&0
\end{pmatrix}.
\]

Both matrices have determinant one, but

\[
j^2=I,\qquad v_0^2=-I.
\]

For the lower simple-root parametrizations
`x_i(t)=I+tE_(i+1,i)`, `i=1,2,3`, direct multiplication gives

\[
\operatorname{Int}(v_0)\gamma_0(x_i(t))=x_{4-i}(t),
\qquad
\operatorname{Int}(j)\gamma_0(x_i(t))=x_{4-i}(-t).
\]

Thus `Int(j) gamma0` is not the pinned graph used in CS13 Section 3.2.
In odd characteristic the middle simple-root group already distinguishes
them. Replacing the symbol `j` by `v0` in a putative semidirect-product
isomorphism would not repair the proof: the element `v0 gamma0` in the
external carrier has square `-I`, although the pinned automorphism itself
has order two. The repair must retain and normalize this central return.

The revised manuscript now uses the correct matrix and explicitly computes
the root action and the return in `tdr:A-pinned-return`.

## 2. The regular toral map really exists for every torus character

Let `Vtilde` be the signed monomial group in dimension four, let `delta`
be its determinant, and put `V=ker(delta)`, `Dtilde` equal to its diagonal
sign subgroup, and `D0=Dtilde cap V`. Every character of `D0` is the
restriction of

\[
\lambda_A(\operatorname{diag}(\epsilon_1,\ldots,\epsilon_4))
  =\prod_{i\in A}\epsilon_i.
\]

The only ambiguity in `A` is complementation. On the stabilizer of `A`
inside `Vtilde`, determinant on the `A` block defines a linear extension
`rho_A`. On the common block stabilizer,

\[
\rho_{A^c}=\rho_A\delta.
\]

This identity is valid because each block determinant is a sign. Thus
`rho_A` and `rho_(A^c)` agree after restriction to `V`. The stabilizer
of `lambda_A|D0` either preserves `A` or, when `|A|=2`, also interchanges
`A` and its complement. Its quotient by the first stabilizer has order
at most two. The displayed linear character is invariant under that
quotient, so the cyclic-extension lemma extends it to the full inertia
subgroup of `V`.

Choosing one such extension on each `V`-orbit and transporting it gives
a `V`-equivariant map. No prime-to-index or prime-to-degree hypothesis
occurs. Every signed monomial matrix is fixed by the prime field
Frobenius and by `gamma0`, since it is orthogonal. The map consequently
extends trivially across the covering field--graph group.

For the regular torus normalizer `N=TV`, the common-extension lemma
then gives a genuine linear character

\[
\widehat\lambda(tu)=\lambda(t)\widehat\mu(u)
\]

on its actual stabilizer. Equality on `T cap V=D0` proves that this
formula is well defined. The stabilizer condition gives multiplicativity.
The defining Frobenius lift acts as one because the extension on the
covering field--graph generators was chosen trivial.

In characteristic two the sign subgroup is trivial, `V=S4`, and the
same formula is the split torus semidirect-product formula. The arguments
involving `-I` below reduce to the identity in that characteristic.

## 3. Split rank three: the scalar correction is a representation

Let `z0=-I`. Let `E1=<Fr,gamma0>` and `E0=<Fr,gamma>` be the actual
external field--graph groups on `SL4(q)`, each isomorphic to `C_f x C_2`.
The selected character `psi` of `N` already extends to
`N semidirect (E1)_psi` by the toral map and the eta-one induction lemma.
Write its representation as `R`.

Since `v0` belongs to `N`, the automorphisms `gamma` and `gamma0` act
identically on `Irr(N)`. Their external stabilizers therefore correspond
under `Fr^a gamma^b <-> Fr^a gamma0^b`. This correspondence does not
require a stabilizer to be a product of its field and graph projections.

For `x=(n,Fr^a gamma^b)`, with `b` equal to zero or one, put

\[
\sigma(x)=(nv_0^b,F_r^a\gamma_0^b).
\]

The field and inverse-transpose operators fix `v0`. For a second element
with graph exponent `b'`, the exact multiplication identity is

\[
\sigma(x)\sigma(y)=z_0^{bb'}\sigma(xy).
\]

One can see every factor directly: the standard graph acts as
`Int(v0) gamma0`, and reducing `b+b'` modulo two replaces `v0^2` by
`z0`. There are no additional field commutators because `Fr(v0)=v0`.

The scalar of `z0` in the irreducible representation of `N` is
`omega=lambda(z0)`. Choose `c` with `c^2=omega^(-1)`. Then

\[
R^0(x)=c^bR(\sigma(x))
\]

obeys

\[
R^0(x)R^0(y)
 =c^{b\oplus b'}(c^2\omega)^{bb'}R(\sigma(xy))
 =R^0(xy).
\]

This proves a genuine extension on the full actual external stabilizer,
including cyclic or noncyclic subgroups generated by mixed field--graph
elements. When `b=0` the formula restricts to `R(n)`, so no central value
on `N` changes. In particular, the common element `h0` in the type-D
carrier keeps its original scalar. For the odd-characteristic `D3=SL4`
model that unique central involution is `-I`.

Equivariance of the entire toral map also survives: the new graph is the
old graph followed by conjugation by `v0`, and the original map was
equivariant under `N` and the old graph separately. The scalar `c` is
needed only to exhibit an extension, not to redefine the toral map.

## 4. Unitary rank three: keep two distinct returns

Set `F1=gamma0 Fr^f` and `F=Int(v0)F1=gamma Fr^f`. The revised choice
of Lang element is

\[
hF_1(h)^{-1}=v_0.
\]

It follows, without passing to a central quotient, that

\[
F_1(h)=v_0^{-1}h,\quad
F(h)=hv_0^{-1},\quad
F_1^2(h)=-h,\quad F_1^4(h)=h.
\]

Hence `h` lies in `SL4(q^4)`. Conjugation `theta=Int(h)` identifies
the fixed-point groups of `F1` and `F` and transports the selected torus,
normalizer, extension map, and characters together. In the finite cover
whose field generator has order `4f`, the actual defining return is

\[
\theta(\widehat F_1)=z=v_0\widehat F_1,
\qquad
z^2=(-I)\widehat F_r^{2f}.
\]

The transported representation kills `z`, because the original killed
`Fhat1`. Consequently the quotient by `z` imposes
`Fhat_r^(2f)=-I`. This is not the standard split finite field-operator
relation `Fr^(2f)=1`. The revision correctly states the relation instead
of identifying these two carriers.

For passage of the character action, put `a_r=h Fr(h)^(-1)`. Then

\[
\begin{aligned}
F(a_r)
 &=h v_0^{-1}\bigl(F_r(h)v_0^{-1}\bigr)^{-1}
 =a_r,\\
\theta F_r\theta^{-1}&=\operatorname{Int}(a_r)F_r.
\end{aligned}
\]

The same calculation works for `gamma0`, and `v0` itself is `F`-fixed.
Thus the changed operators differ from the standard ones by actual
inner automorphisms of `K=SL4^F`, rather than merely diagonal
automorphisms. This is sufficient to transport the whole map and the
`K`-saturated stabilizer factorization.

The genuine extension in the standard unitary carrier is constructed
separately. On `K=SU4(q)` the standard group is cyclic:

\[
E^0=\langle F_r\rangle,\qquad
F_r^{2f}=1,\qquad \gamma=F_r^{-f}.
\]

The inertia subgroup in `N_(K semidirect E0)(S)` modulo the transported
normalizer is therefore cyclic. For any lift `u` of a generator of
order `s`, an intertwiner `T` can be scaled to satisfy
`T^s=R(u^s)`, using Schur's lemma. This gives an ordinary representation
with the actual return `u^s` in the normalizer. It extends the specified
transported character, so its scalars on the central intersection remain
unchanged. No claim that the Lang-cover quotient is the standard
semidirect product is needed.

## 5. The interfaces used after rank three

The eta-one argument is valid for all torus characters. Its restriction to
the torus is the sum of distinct conjugates of `lambda`, each with
multiplicity one. If `tx` fixes the induced character, with `t` in the
regular diagonal torus, then `lambda^x` is conjugate to `lambda` by `N`.
After that inner correction, equivariance fixes the chosen extension
itself. Hence `t` and `x` separately fix the induced character. This is
the asserted stabilizer factorization, without a degree restriction.

For the unitary comparison, transport sends every external operator to
an inner element times a standard external operator. After adjoining
`K`, the inner element is already in the saturated stabilizer, and can
be removed. The regular-embedding group also transports correctly.
Thus `tdr:standard-O` follows with the specified standard complement.

The extension of `psi` recovers an extension of the selected
`Lambda(lambda)` on the one-dimensional `lambda`-isotypic space. This
space is stable under the inertia group of `lambda` and restricts to the
selected value by Clifford correspondence. The revision now makes this
recovery part of the proof, rather than an optional remark.

The full-character Omega input is compatible with rank three. CS13
Theorem 5.1 is stated for every irreducible character of the regular
normalizer, not only prime-to-degree characters. Corollary 5.14 supplies
the regular extension map, its operator equivariance, and compatibility
with quotient linear characters. The quotient of the regular normalizer
by the special-linear normalizer is cyclic, giving the remaining maximal
extendibility requirement. These verify the hypotheses used in CS25
Proposition 4.14 for this type-A realization. Proposition 4.14(b) itself
has the full `G_d -> Irr(N)` domain; its prime-to-degree clause is an
additional assertion, not a restriction of that domain.

This checks the rank-three input to the subsequent central-triple
carrier change. It does not turn a review of that input into a review
of every later mixed-carrier assertion.

## 6. Independent exact computation

The directory `revision_audits/rank_three_graph_fresh_checks/` contains
the complete script, input, output, README, and primary-reading receipt.
The script needs only the Python standard library. Its first run used
Python 3.12.14 and completed successfully.

The exact computation checks:

- the 192 determinant-one signed monomial matrices;
- the alternating antidiagonal matrix and its square `-I`;
- 21 simple-root matrix identities at the seven specified integer
  parameters, including explicit failures of the old all-one graph;
- all 147,456 pairs of signed monomial matrices and graph parities for
  the central multiplication defect;
- exact scalar cancellation for both possible central values, using
  exponents of `i` modulo four;
- the unitary cover return for field degrees 1 through 8.

No floating point, downloaded group tables, or old checker outputs are
used. The script records its own hash and the input hash. It does not
test arbitrary torus characters or all finite fields. The symbolic
arguments in Sections 2–5 are the mathematical justification of those
general statements.

Script SHA-256:

```text
e1b8c0d490237f7414a47591dace1d6aa608b55ef1504a94f48fd29761c4f111
```

Input SHA-256:

```text
2c00abcb43396d30718979312449d596063bdead2fdc338a4dd676c10e0bd595
```

## 7. Primary statements inspected

The exact PDF byte hashes and extraction hashes are recorded in
`rank_three_graph_fresh_checks/primary_reading.json`. PyMuPDF 1.26.6
was used to check the source versions and extract the relevant pages.
The page-hash operation identifies the source text; it is not a
mathematical certification.

| Source | Statements checked | Use in this review |
|---|---|---|
| Cabanes–Späth, arXiv:1305.6407v1 | Section 3.2, Theorem 5.1, Proposition 5.3, Corollary 5.14 | Pinned graph, exact transport convention, full character scope and regular extension input |
| Cabanes–Späth, arXiv:2410.20392v2 | Conditions 2.19–2.20, Proposition 4.14 | All-character Omega scope and the rank-three hypotheses |

Public source URLs:

- https://arxiv.org/abs/1305.6407v1
- https://arxiv.org/abs/2410.20392v2

## Final checkpoint reinspection

The writer's final version has 1,335 lines and SHA-256:

```text
cbdc921d1842e7bc2bdc9474478d8fadd252799f705aaae358e9c47054c5d036
```

I reread the changed rank-three and `standard-O` passages in this exact
version. The transported objects are now explicitly defined at
`tdr:A-transported-normalizer`, the cyclic quotient is
`(X^theta)_(psi^theta) / N^theta`, and its actual return is stated as
`u^s in N^theta`. The generic `iota^(-1)` complement argument is now
explicitly restricted to ranks at least four, while rank three uses the
separate action comparison and the two genuine extension constructions.
Both requested clarifications are resolved. No remaining blocker was
identified in the rank-three passage within the scope stated above.

