# Fresh attack on the integral and blockwise foundations

Date: 2026-11-14 (UTC)

Auditor: `/root/fresh_foundational_counterexample_attack`

## Finding

I did not find a counterexample or an additional unproved hypothesis in the four foundational arguments audited below. This is a local mathematical review, not a certification of the general Brauer conjecture or the complete manuscript. In particular, I did not audit the moving type-D endpoint, the classification of simple-group blocks, or the entire two-cycle capacity theorem in this task.

The review was based on the current mathematical source, not on treating the conclusions of earlier audit reports as premises. The inherited conversation contained excerpts of an earlier global report, but I did not open that report or use its PASS conclusions to justify the arguments below.

## Exact source snapshot and coverage

| Source | SHA-256 | Coverage |
| --- | --- | --- |
| `brauer_odd_revision/integral_foundations.tex` | `e248a3db903a2c141b15f657dce045f4c1a79cd5071ec5e8e2a977a5d30a9ce4` | All 158 lines, including each unit, counit, triangle identity, and the final integral central summand. |
| `brauer_odd_revision/odd_global_capacity.tex` | `74e9b957353096fe05348431d021e22f591b7dbaeed87461865449515887e905` | `cap:probe`, `cap:central-fiber`, `cap:normal-p-linearization`, `cap:defect-zero`, the relative-selector and Cartan-product construction, and `cap:global-comparison` through its final quotient-action comparison. These were read as continuous sections, not only their statements. |

The global source had 3,070 lines at the hash above. Label anchors should be used if further editing moves line numbers.

## 1. The integral Morita criterion

The potentially false shortcut would be to infer integral Morita equivalence from generic Morita equivalence alone. The current proof does not make that shortcut. Its double projectivity and symmetry hypotheses are used in essential places.

Write

\[
P=M\otimes_B M^\vee,
\qquad Q=M^\vee\otimes_A M.
\]

The symmetrizing forms identify the same dual lattice with both appropriate module duals. Thus the displayed unit and counit maps really give adjunctions in both directions. The generic assumptions imply that the supported generic right algebra is the full commutant and that every simple left module occurs. Therefore both generic maps between \(KP\) and \(KA\) are isomorphisms.

The important integral step is the pair of maps

\[
Q\longrightarrow Q\otimes_B Q,
\qquad
Q\otimes_B Q\longrightarrow Q.
\]

One has a left inverse and the other has a right inverse by the explicit triangle identities. Because the modules in question are finite free over the discrete valuation ring, the complementary direct summand has generic rank zero and is zero. Consequently both maps are integral isomorphisms. This use of a split map is what prevents an undetected torsion cokernel.

For the subsequent central element \(z=\epsilon_A\eta_A\), the proof uses the injective map

\[
Z(A)\longrightarrow\operatorname{End}_{B-B}(Q).
\]

Its target is a commutative finite \(\mathcal O\)-algebra: its generic fiber is the generic center, and torsion freeness eliminates commutators already zero generically. Every element of that target is integral over \(\mathcal O\), hence also over the subring \(Z(A)\). The action of \(z\) is invertible, so the monic relation for its inverse really proves that \(z^{-1}\) lies in \(Z(A)\). Thus \(\eta_A\) has an integral splitting, and the same rank argument applies again.

Finally, the use of full faithfulness is in the correct direction: the invertibility of the counit \(FG\to1\) makes the right adjoint \(G\) fully faithful. The object \(Q=G(M)\) lies in its image, where \(F\) detects isomorphisms. This proves that the displayed split summand of the regular \(B\)-bimodule is an actual central idempotent summand. The canonical tensor-to-endomorphism map identifies it with the original right-action map. I found no missing integral surjectivity assumption at this point.

This review does not weaken the lemma to one-sided projectivity or to arbitrary nonsymmetric orders; those variants were not asserted and do not follow from this proof.

## 2. Central fibers and the blockwise normal-p comparison

### 2.1 The central-fiber matrix formula

The Fourier argument applies to each projective indecomposable character on the cosets of the central p-subgroup. On p-regular elements it gives

\[
D_\lambda^{\mathsf T}D_\lambda=C_c/|Z|.
\]

The second equality \(C_c=|Z|C_{\bar c}\) follows from freeness over the central local algebra \(kZ\) of the primitive corners. Thus every decomposition column is present in every central fiber, and the column-incidence graph is connected because the resulting Gram matrix is the Cartan matrix of one block. The proof does not infer a row-count inequality merely from equality of Gram matrices.

The independent row-count argument uses the multiplication action of \(Z\) on class sums in \(Z(\mathcal O T)\), not conjugation by \(Z\). This is a permutation action. The block center is an equivariant direct summand. Since \(Z\) is an abelian p-group, each transitive permutation lattice has local endomorphism ring \(\mathcal O[Z/H]\). Krull--Schmidt therefore shows that every summand is a sum of these lattices. Their trivial-character multiplicity is one, and their multiplicity at any specified linear character is zero or one. This gives the claimed inequality for each block and central character.

### 2.2 Matching blocks before counting ordinary characters

For an abelian normal p-subgroup \(A\), the two groups \(G\) and \(A\rtimes(G/A)\) have the same p-regular class data relative to their common quotient. In the preimage of the cyclic group generated by a p-regular quotient element, complements are conjugate. Applying that conjugacy statement to a lift of a quotient centralizer element proves the surjectivity of the centralizer map, with kernel \(C_A(x)\). Hence the weights in the p-regular scalar product are the same in both groups.

If \(S\) denotes the scalar-product Gram matrix of the inflated irreducible Brauer characters, duality with the projective characters gives \(SC=1\). Thus \(S=C^{-1}\), and the complete Cartan matrices in the two groups are equal in the common simple-module labeling. This determines the same connected block components and defect orders. No identification of the blocks of \(G\) with those of the quotient itself is needed.

For a fixed \((\lambda,c)\)-packet, the ordinary-to-Brauer matrix in its central fiber has connected column incidence. Every row of the modular induction matrix is nonzero. An induced ordinary character from the full inertia group is irreducible, so its nonnegative decomposition row has support in just one target block. A common row of the fiber matrix forces all induction supports of its participating columns into that same block. Connectivity then puts the entire packet into one target block. Since both the induction matrix and the target partition are common to the split and original groups, the packets enter the same matched block in both groups.

In the split inertia, the central-fiber character has its canonical extension trivial on the complement, giving exactly \(k(c)\) members. The original central fiber has at most \(k(c)\) members by the preceding lattice argument. The summation takes one representative per orbit and one quotient block per packet, so I found no double counting or hidden change of the target block.

For nonabelian \(Q\), after splitting \(A\leq Z(Q)\), the complement subgroup \(Q/A\) remains normal in the new group because it centralizes the already split layer \(A\). This justifies repeating the comparison. The final normal elementary abelian group is the direct sum of the central factors and has order \(|Q|\), as required.

## 3. Realizing a whole residual probe

I checked the following possible failure points in `cap:probe`.

1. **Principal-unit cohomology.** The groups used here have order prime to p. On the complete local commutative center, raising a principal unit to that order is an automorphism. This does justify the vanishing in positive-degree cohomology used to correct the entire multiplication system.

2. **Embedding the original quasisimple group.** The coinduced-center construction does not quotient out an extra part of \(S\): the map \(a\mapsto(x\mapsto\alpha_x(a))\) is injective. Its equivariance and the displayed cochain identity turn the original outer obstruction into a genuine finite extension after adjoining the centralizing p-prime group. No invariant extension of the original central character is required.

3. **The evaluation sector.** The averaging idempotent for the kernel is integral, because the kernel has p-prime order. Its explicit inverse on the evaluation sector verifies the isomorphism with the corrected order and preserves the copy of \(A\).

4. **One block rather than a sum of blocks.** Distinct elements of the effective Picard image give nonisomorphic indecomposable homogeneous bimodules. The semisimple quotient of their full bimodule endomorphism ring is the product of the residue fields. A central idempotent has the same diagonal residue in every component, so it is zero or one. This is a genuine block-primitivity argument.

5. **Defect and the almost-simple replacement.** All p-subgroups of the constructed group lie in \(S\). The normal-block defect intersection theorem therefore retains a defect group of \(b\). In the later Fong step, the chosen inertia has no nontrivial normal p-subgroup, because such a subgroup would be normal in the quasisimple \(S\) and lie in its p-prime center.

The last step cites An--Eaton's Theorem 3.1. I retrieved the original published article, read the theorem on PDF page 9 using Python/PyMuPDF, and verified that its first conclusion has precisely the positive-defect, normal defect-zero block, and \(O_p(G)=1\) hypotheses used here. The extra p-local-rank-one conclusion is separate. The manuscript is not using the TI hypothesis from the article's main theorem in this application.

## 4. Removing the p-primary factor while retaining the selected lower block

This was the main attack on `cap:global-comparison`. A comparison of the total projective character count with an untwisted group count would not suffice; the original lower block must survive. The current argument explicitly retains it.

The restriction of the groupoid factor to the integral-inner subgroup is the ordinary evaluation of one central-unit cocycle. The same is true of every normalizer conjugation coefficient. Since all ordinary evaluations of the local block center have the same residue, the residual lower twisted algebra and its full normalizer action are independent of the ordinary label.

The p-primary cohomology class can be represented on each finite isotropy group by roots of p-power order, and the specified arrows pull these representatives back to the entire groupoid. The valuation of the intervening cochain is a groupoid one-cocycle; it vanishes on finite isotropy and can be removed by an object gauge. Dividing by the Teichmüller lift of its remaining residue then produces a residue-one gauge. Both operations leave its coboundary unchanged.

At every object, the quotient by the central p-group has the same lower block \(d_0\). Central-p block lifting is unique. The residue-one gauge therefore identifies the selected lift with the original specialized selector. The equality of residual normalizer actions ensures that all arrows transport the selected lift to the selected lift. Their sum is consequently an integral central idempotent in the whole covering groupoid algebra. This is stronger than choosing a possibly different block at each character orbit.

After this choice, the center lattice is a direct summand of the permutation lattice on conjugacy sums of loops. The prescribed p-prime scalar-character projector is integral and commutes with the central p-group action, so retaining it preserves the direct-summand argument. The same Krull--Schmidt multiplicity comparison as in the central-fiber lemma applies **inside this selected sector**. It gives a one-sided inequality, not an equality after deleting p-primary factors.

The quotient section still has its actual carry in the lower twisted algebra. The associator there lies in its degree-one homogeneous component, which is the scalar field. This is the reason the residual anomaly is scalar; the proof does not assume that the full center of the lower algebra is scalar. Finally the ratio of actual and factorwise product systems is taken in the integral block center before ordinary evaluation. Its common residue supplies one whole correction, not independent choices on different labels.

I found no additional choice of an unproved favorable lower block in these steps.

## 5. Primary-source check and reproducibility

New source downloaded for this task:

- An--Eaton, *Blocks with trivial intersection defect groups*, published article, 27 PDF pages including cover. URL: <https://eprints.maths.manchester.ac.uk/51/1/pc09k1q7ac55wpyb.pdf>.
- Local file: `revision_audits/primary/AnEaton04_fresh_foundations.pdf`.
- Bytes: 378,421.
- SHA-256: `8f75e187e67daeed699be4c307419878055660fd939ed12a97613f9edb034c50`.
- Extraction engine: PyMuPDF 1.26.6.
- Full page hashes and the exact source URL are recorded in `revision_audits/fresh_foundational_primary_reading.json`.
- The mathematical statement actually checked is Theorem 3.1 on PDF page 9 (printed page 468), together with the preceding block-uniqueness paragraph on that page.

I also checked Murai's original Lemma 2.1 and Theorem 3.5(i) directly through Python extraction of the retained PDF (PDF pages 5 and 8). They do identify the manuscript's integral-inner subgroup and supply the stated uniqueness of a covering block. The extra occurrences found on later pages are cross-references, not additional mathematical statements audited. The extraction receipt is `revision_audits/fresh_foundational_murai_reading.json`.

No finite group enumeration was added, because the potential failures in this task concerned universal integral, block-selection, and cohomological arguments. A small numerical test would not validate those steps and would add no independent evidence beyond the direct reconstruction above.

## Scope of the conclusion

The four audited foundational interfaces can remain as written on the identified source hash. This conclusion does not discharge the separate endpoint inputs or assert that every classification, degree bound, or category-coherence step elsewhere in the manuscript is correct. The paper's final completeness decision must still depend on those independent audits and on resolution of any outstanding endpoint issue.
