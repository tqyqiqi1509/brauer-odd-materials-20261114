# Fresh degree and order budget checks

Run `python3 check_degree_order_bounds.py` from this directory. Only the Python
standard library is required. The script writes `output.json` and records the
exact input and program hashes. Run without Python's `-O` or `-OO` options.

The input retains the ordinary-root order-bound starts, the separate Suzuki
and Ree inequalities, the finite ordinary exceptions, the defining small
cases, and both degree-two A5 cases where the full outer-group half bound
fails but the implemented linear outer group gives the required bound.
The distinction between an exact class number and a safe upper bound is
explicit: the supplied Tits table has 22 classes, while 58 is a safe bound;
G2(3) has 23 classes, while 24 is the bound used in the paper.

The program checks finite integer arithmetic. It does not prove the source
degree estimates, the classification lists, or their infinite continuations.
Those arguments and the primary statements read are described in the report
`affine_degree_bound_final_fresh.md`. `primary_reading_index.json` identifies
the exact Lee and Fulman–Guralnick PDFs read in this review.
