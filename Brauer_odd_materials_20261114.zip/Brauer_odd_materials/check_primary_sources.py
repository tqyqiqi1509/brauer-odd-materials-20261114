#!/usr/bin/env python3
"""Check exact primary PDF bytes and repeat the recorded Python extraction.

Obtain the PDFs from PRIMARY_SOURCE_INDEX.json and place them under the listed
filenames in --source-dir. This checks document identity and page extraction;
it does not verify the mathematics of the papers.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-dir', type=Path, required=True)
    parser.add_argument('--only', nargs='+', help='Exact filenames from the index.')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    try:
        import fitz
    except ImportError:
        parser.error('Install requirements_reading.txt before running this command.')
    index = json.loads((ROOT/'PRIMARY_SOURCE_INDEX.json').read_text())
    indexed = {row['filename']:row for row in index['files']}
    selected = args.only or list(indexed)
    unknown = sorted(set(selected)-set(indexed))
    if unknown:
        parser.error('Unknown source filename(s): '+', '.join(unknown))
    if args.output.exists():
        parser.error('Choose a new output filename; existing receipts are preserved.')
    rows = []
    for name in selected:
        expected = indexed[name]
        path = args.source_dir/name
        row = {'filename':name, 'expected_sha256':expected['sha256']}
        try:
            data = path.read_bytes()
            row['sha256'] = hashlib.sha256(data).hexdigest()
            row['bytes_match'] = row['sha256'] == expected['sha256']
            with fitz.open(path) as document:
                row['pdf_pages'] = len(document)
                hashes = [hashlib.sha256(page.get_text().encode()).hexdigest()
                          for page in document]
            row['page_count_matches'] = row['pdf_pages'] == expected['pdf_pages']
            row['page_text_hashes_match'] = hashes == expected['page_text_sha256']
            row['status'] = ('passed' if row['bytes_match'] and row['page_count_matches']
                             and row['page_text_hashes_match'] else 'failed')
        except Exception as exc:
            row.update(status='failed', error=f'{type(exc).__name__}: {exc}')
        print(row['status'].upper()+': '+name)
        rows.append(row)
    passed = all(row['status']=='passed' for row in rows)
    result = {'completed_utc':datetime.now(timezone.utc).isoformat(),
              'python':sys.version, 'PyMuPDF':fitz.VersionBind,
              'scope':'Exact primary-document identity and reproducible page extraction.',
              'all_requested_checks_passed':passed, 'files':rows}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    return int(not passed)


if __name__=='__main__':
    raise SystemExit(main())
