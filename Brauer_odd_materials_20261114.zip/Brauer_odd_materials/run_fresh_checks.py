#!/usr/bin/env python3
"""Run the fresh independent arithmetic, two-cycle, and rank-three checks.

The default consumes the recorded, identified GAP carrier outputs.
--regenerate-carriers regenerates the E7 and E8 outputs before checking them.
The program verifies finite arithmetic and data, not the general theorem.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--regenerate-carriers', action='store_true')
    parser.add_argument('--gap-executable', default='gap')
    parser.add_argument('--output', type=Path)
    parser.add_argument('--timeout', type=int, default=1800)
    args = parser.parse_args()
    if sys.flags.optimize:
        parser.error('Do not disable assertions with -O or -OO.')
    if args.timeout <= 0:
        parser.error('--timeout must be positive.')
    output = (args.output or ROOT/'verification_records'/'fresh_runs'/
              datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')).resolve()
    for source in ('audit_checks', 'certificates'):
        if output.is_relative_to((ROOT/source).resolve()):
            parser.error('Output must be outside the source input directories.')
    output.mkdir(parents=True, exist_ok=False)
    work = output/'work'
    for source in ('audit_checks', 'certificates'):
        shutil.copytree(ROOT/source, work/source,
                        ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    logs = output/'logs'
    logs.mkdir()
    env = os.environ.copy()
    env.pop('PYTHONOPTIMIZE', None)
    env['PYTHONHASHSEED'] = '0'
    checks = []

    def run(name, command, cwd, stdout=None, stderr=None):
        start = time.monotonic()
        row = {'id': name, 'command': command}
        try:
            result = subprocess.run(command, cwd=cwd, env=env, input='',
                                    text=True, capture_output=True, timeout=args.timeout)
            (logs/(name+'.stdout')).write_text(result.stdout)
            (logs/(name+'.stderr')).write_text(result.stderr)
            if stdout is not None:
                stdout.write_text(result.stdout)
            if stderr is not None:
                stderr.write_text(result.stderr)
            row['returncode'] = result.returncode
            if result.returncode or re.search(r'(?m)^(?:Error,|Syntax error|#E|brk>)',
                                               result.stdout+'\n'+result.stderr):
                raise RuntimeError('Program reported an error.')
            row['status'] = 'passed'
        except Exception as exc:
            row.update(status='failed', error=f'{type(exc).__name__}: {exc}')
        row['elapsed_seconds'] = round(time.monotonic()-start, 6)
        checks.append(row)
        print(row['status'].upper()+': '+name, flush=True)
        return row['status'] == 'passed'

    affine = work/'audit_checks/fresh_affine'
    if run('fresh_affine_arithmetic', [sys.executable, str(affine/'verify_arithmetic.py')], affine):
        actual = json.loads((affine/'arithmetic_results.json').read_text())
        expected = json.loads((affine/'expected_arithmetic_results.json').read_text())
        checks.append({'id':'complete_affine_output_comparison',
                       'status':'passed' if actual == expected else 'failed'})
    exceptional = work/'audit_checks/fresh_exceptional'
    gap_ok = True
    if args.regenerate_carriers:
        located = shutil.which(args.gap_executable)
        gap = str(Path(located or args.gap_executable).resolve())
        for family in ('e7', 'e8'):
            script = work/'certificates/exceptional/carriers'/(family+'_overlap_gap4.g')
            gap_ok &= run('fresh_'+family+'_carrier_generation',
                          [gap, '--bare', '-q', '-b', '-T', str(script)], exceptional,
                          exceptional/(family+'_fresh.out'), exceptional/(family+'_fresh.stderr'))
    if gap_ok and run('fresh_exceptional_arithmetic',
                      [sys.executable, str(exceptional/'verify_independent.py')], exceptional):
        actual = json.loads((exceptional/'independent_results.json').read_text())
        expected = json.loads((exceptional/'expected_independent_results.json').read_text())
        actual_hashes = sorted(actual.pop('input_hashes').values())
        expected_hashes = sorted(expected.pop('input_hashes').values())
        checks.append({'id':'complete_exceptional_output_comparison',
                       'status':'passed' if actual == expected else 'failed'})
        checks.append({'id':'three_identified_input_byte_hashes',
                       'status':'passed' if actual_hashes == expected_hashes else 'failed'})
    global_dir = work/'audit_checks/fresh_global'
    if run('fresh_global_two_cycle',
           [sys.executable, str(global_dir/'check_two_cycle.py')], global_dir):
        actual = json.loads((global_dir/'output.json').read_text())
        expected = json.loads((global_dir/'expected_output.json').read_text())
        actual.pop('python')
        expected.pop('python')
        checks.append({'id':'complete_global_output_comparison',
                       'status':'passed' if actual == expected else 'failed'})
    rank_three = work/'audit_checks/fresh_rank_three'
    if run('fresh_rank_three_graph',
           [sys.executable, str(rank_three/'check_rank_three_graph.py')], rank_three):
        actual = json.loads((rank_three/'output.json').read_text())
        expected = json.loads((rank_three/'expected_output.json').read_text())
        actual.pop('python')
        expected.pop('python')
        checks.append({'id':'complete_rank_three_output_comparison',
                       'status':'passed' if actual == expected else 'failed'})
    degree = work/'audit_checks/fresh_degree'
    if run('fresh_degree_order_bounds',
           [sys.executable, str(degree/'check_degree_order_bounds.py')], degree):
        actual = json.loads((degree/'output.json').read_text())
        expected = json.loads((degree/'expected_output.json').read_text())
        actual.pop('python')
        expected.pop('python')
        checks.append({'id':'complete_degree_output_comparison',
                       'status':'passed' if actual == expected else 'failed'})
    passed = all(x['status'] == 'passed' for x in checks)
    receipt = {'completed_utc':datetime.now(timezone.utc).isoformat(),
               'python':sys.version, 'regenerated_carriers':args.regenerate_carriers,
               'scope':'Finite independent computations; not a proof-correctness certificate.',
               'checks':checks, 'all_requested_checks_passed':passed,
               'checked_script_hashes':{str(p.relative_to(work)):
                   hashlib.sha256(p.read_bytes()).hexdigest()
                   for p in sorted((work/'audit_checks').rglob('*.py'))}}
    (output/'run_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(output/'run_receipt.json')
    return int(not passed)


if __name__ == '__main__':
    raise SystemExit(main())
