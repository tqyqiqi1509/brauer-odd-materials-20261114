# Verification scope

The executable checks in this package certify finite arithmetic, polynomial,
matrix, character-table, and file-integrity statements. They do not certify the
general odd-prime form of Brauer's k(B)-conjecture. The mathematical audit and
the status of the proof arguments are separate deliverables.

## Included computational families

- `certificates/affine_classical/`: exact affine bounds, small primitive
  actions, wreath calculations, and classical generating-function coefficients.
- `certificates/exceptional/`: finite character tables, exceptional carrier
  calculations, polynomial bounds, and the supplied exceptional degree data.
- `audit_checks/`: independent checks added during the current audit,
  including the central-quotient examples and the complete height-zero screen.

No prime-two certificate family is needed by these programs. The odd-prime
mathematical revision contains the general techniques formerly used in the
prime-two text as independent arguments.

## Reproduction

Use Python 3.10 or newer without `-O` or `-OO`; the programs use assertions.
Install the versions listed in `requirements.txt`. From this directory run:

```sh
python3 run_verification.py --integrity-only
python3 run_verification.py --python
python3 run_verification.py --all --gap-executable /absolute/path/to/gap
python3 run_audit_checks.py
python3 run_fresh_checks.py
```

The `--python` mode uses the identified reference GAP outputs. The `--all`
mode also regenerates the GAP checks selected by each certificate manifest.
The separate audit runner accepts `--regenerate-gap` for the added complete
height-zero screen. A run writes into a new directory; existing reference
outputs are preserved. Missing dependencies and failed checks are errors.

The fresh runner checks the independent outer-order arithmetic, the failure
of an extra uniform factor two, central quotient invariants, the 201 retained
carrier colors, 240 independently generated E8 roots, 16 rational centralizer
order polynomials, and all 166 supplied generic-degree profiles. Its optional
`--regenerate-carriers --gap-executable /absolute/path/to/gap` mode regenerates
the E7 and E8 carrier outputs first.

It also runs an independent exact enumeration of 41,560 labeled two-cycle
cases for actors C2, C3, C4, V4, and S3, retaining the actual return square.
Ten cases are cross-checked by a separate loop-orbit enumeration. These are
honest permutation module categories with trivial intrinsic cochains and
associators; they do not test the general anomalous case. The complete input,
reference output, script hashes, and scope are in `audit_checks/fresh_global/`.

The rank-three check in `audit_checks/fresh_rank_three/` constructs all 192
determinant-one signed monomial matrices and checks 147,456 multiplication
and graph-parity combinations. It verifies the pinned simple-root signs,
both central character values, and the retained unitary covering return at
eight field degrees. The general Lang and character-extension arguments
are given in the paper and the separate audit report.

The fresh degree checks in `audit_checks/fresh_degree/` verify 22 exact
boundary estimates, including the corrected A5 implemented-outer cases.
They complement the general estimates in the paper rather than enumerate
all groups.

## Primary-document reading

`PRIMARY_SOURCE_INDEX.json` identifies exact primary PDFs by their public URLs,
byte hashes, page counts and page-text hashes. It records which document version
was inspected; the audit reports identify the actual statements checked.
The third-party papers are obtained from those sources rather than redistributed
here. Install `requirements_reading.txt`, obtain the relevant PDFs, and run:

```sh
python3 check_primary_sources.py --source-dir /path/to/primary_pdfs \
  --only CS25.pdf MS16.pdf CS13.pdf GMP17_fresh.pdf \
  --output verification_records/my_primary_reading.json
python3 extract_source_pdf.py --help
```

The extraction check requires the recorded PyMuPDF version for identical
page-text hashes. A changed PDF version or extraction engine is reported as a
mismatch; it is not silently accepted. PDF extraction and page hashes establish
which text was read, not that its hypotheses or proof are mathematically valid.

## Data provenance

The exceptional E8 unipotent-degree export originates in the supplied
GAP3/CHEVIE data. Its generating source, exported input, and later exact
Python checks are included. The current session did not regenerate that
historical export in GAP3. The symbolic checks of its supplied data and the
independent modern CHEVIE-source reconstruction are identified separately in
the execution records.

The height-zero screen treats odd primes that do not divide the center of
the table group. For these primes it retains every positive-defect block in
its 106 specified character tables for which all ordinary characters have
height zero. It is a superset of the abelian-defect cases by the abelian-defect
implication of Brauer's height-zero theorem. The resulting order bounds are
used only for those finite tables. Neither the screen nor the carrier checks
prove that a classification list is exhaustive.

`MANIFEST_SHA256.json` records the delivered bytes. An integrity pass means
that the delivered files match this manifest. It is not a proof-correctness
certificate.
