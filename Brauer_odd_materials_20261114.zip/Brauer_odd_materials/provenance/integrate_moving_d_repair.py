#!/usr/bin/env python3
"""Integrate the independently reviewed moving type-D replacement once."""
from pathlib import Path
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'brauer_odd_revision' / 'odd_endpoints.tex'
REPAIR = ROOT / 'revision_audits' / 'moving_d_anchor_replacement_v3.tex'
BACKUP = ROOT / 'revision_audits' / 'pre_moving_d_integration'


def sha(text):
    return hashlib.sha256(text.encode()).hexdigest()


def main():
    old = SOURCE.read_text()
    replacement = REPAIR.read_text()
    # Keep the mathematical text, not the draft handoff comments.
    replacement = replacement[replacement.index(r'\paragraph{Regular blocks'):]
    assert r'a(s c r)=\eta(c)' in replacement
    assert 'kernel' in replacement and r'\mathcal F' in replacement
    start = old.index(r'\begin{lemma}\label{ep:graph-torsor}')
    stop = old.index('The associated simultaneous-witness criterion is', start)
    current = old[:start] + old[stop:]
    start = current.index('In the moving isolated \\(D\\)-block branch,')
    stop = current.index(r'\subsection{Integral exceptional source carriers}', start)
    current = current[:start] + replacement.rstrip() + '\n\n' + current[stop:]
    assert 'ep:graph-torsor' not in current
    assert r'\epAnn(I_b)' not in current
    BACKUP.mkdir(exist_ok=False)
    (BACKUP / SOURCE.name).write_text(old)
    (BACKUP / REPAIR.name).write_text(REPAIR.read_text())
    diff = ''.join(difflib.unified_diff(old.splitlines(True), current.splitlines(True),
                                       fromfile='before/odd_endpoints.tex',
                                       tofile='after/odd_endpoints.tex'))
    (BACKUP / 'integration.diff').write_text(diff)
    receipt = {'source_before_sha256': sha(old), 'source_after_sha256': sha(current),
               'reviewed_fragment_sha256': hashlib.sha256(REPAIR.read_bytes()).hexdigest(),
               'changes': ['Removed the unused graph-torsor route and its field-factor paragraph.',
                           'Replaced the incorrect Ann(I_b) equation with regular-block Brauer-pair matching.',
                           'Split diagonal orbits 1/2/4 and retained the actual central carries via a fibre product.']}
    SOURCE.write_text(current)
    (BACKUP / 'integration_receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
