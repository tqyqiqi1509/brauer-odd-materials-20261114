#!/usr/bin/env python3
"""Assemble the reviewed modules into a standalone publication candidate."""
from pathlib import Path
import collections
import hashlib
import json
import re
import unicodedata

ROOT = Path(__file__).resolve().parent
SRC = ROOT / 'brauer_odd_revision'
OUT = ROOT / 'brauer_odd_delivery_20261114'
OUT.mkdir(exist_ok=True)
ALIASES = {
 'ep:AS22':'AS22','ep:ATLAS':'Atlas85','ep:BR22':'BroughRuhstorfer22',
 'ep:BR25':'BR23','ep:Bonnafe05':'Bonnafe05','ep:CS25':'CS25',
 'ep:Carter85':'Carter85','ep:Eng13':'Enguehard13',
 'ep:FG12':'FulmanGuralnick12','ep:KM13':'KM13','ep:KM25':'KM25',
 'ep:MS16':'MS16','ep:Malle18':'Malle18','ep:NS14':'NS14',
 'ep:Ruh22':'Ruh22Sigma','ep:SW99':'SuleimanWilson99','Maroti04':'Maroti05',
}
CITE = re.compile(r'(\\cite\w*(?:\[[^\]]*\])*)\{([^}]+)\}')


def normalize(s):
    def cite(m):
        keys = list(dict.fromkeys(ALIASES.get(k.strip(),k.strip())
                                  for k in m.group(2).split(',')))
        return m.group(1)+'{'+','.join(keys)+'}'
    s = CITE.sub(cite,s)
    def display(m):
        body = m.group(1)
        if r'\label{' not in body:
            return m.group(0)
        body = re.sub(r'\\tag\*?\{[^{}]*\}', '', body)
        return r'\begin{equation}'+body+r'\end{equation}'
    return re.sub(r'(?<!\\)\\\[(.*?)\\\]',display,s,flags=re.S)


names = ['preamble.tex','introduction_history.tex','preliminaries.tex',
         'integral_foundations.tex','all_prime_levi.tex','odd_affine.tex',
         'odd_classical.tex','odd_endpoints.tex','odd_global_capacity.tex']
sources = {name:normalize((SRC/name).read_text()) for name in names}
global_text = sources['odd_global_capacity.tex']
cuts = [global_text.index(r'\subsection{Coupled cycles'),
        global_text.index(r'\section{Realizing every whole residual probe}'),
        global_text.index(r'\section{Blockwise reductions'),
        global_text.index(r'\begin{proof}[Proof of Theorem~\ref{main:theorem}]')]
global_parts = [global_text[:cuts[0]],global_text[cuts[0]:cuts[1]],
                global_text[cuts[1]:cuts[2]],global_text[cuts[2]:cuts[3]],
                global_text[cuts[3]:]]
main_match = re.search(r'\\begin\{theorem\}\\label\{cap:odd-main\}.*?\\end\{theorem\}',
                       global_parts[3], re.S)
if main_match is None:
    raise ValueError('The unconditional odd-prime theorem statement is missing.')
main_statement = main_match.group(0)
global_parts[3] = global_parts[3].replace(main_statement+'\n\n\\begin{proof}',
    '\\begin{proof}[Proof of Theorem~\\ref{cap:odd-main}]', 1)
intro = sources['introduction_history.tex'].replace(
    '\\subsection*{The original question}',
    'Our main result is the following.\n\n'+main_statement+
    '\n\n\\subsection*{The original question}', 1)
intro += r'''

\subsection*{The proof}

We use a minimal counterexample with respect to
\[
 (|D|,\,|G:Z(G)|,\,|G|).
\]
The normal-subgroup reductions retain one specified block, its
central character and its exact defect order. The remaining
components carry actions by their stabilizers in the ambient group.
For such an action, the ordinary character count is the rank of an
equivariant category, including the scalar factor sets supplied by
the actual multiplication in the extension.

The capacity theorem bounds this rank for coupled products of
component character categories. Its two-cycle estimate retains the
square of the exchange operator and uses the full subgroup budget
of one component. Longer cycles give fixed-space estimates, and
the permutation quotient is controlled by a weighted orbit count.
The defect-three case uses the separate affine bound.

Every required component budget is realized by an actual block of
the same defect on a finite group. Smaller component defect allows
induction. At equality, there is one positive-defect component and
a prime-to-$p$ quotient. The almost-simple endpoint then gives a
direct bound, a correspondence with the specified Brauer-normalizer
block, or a same-defect transfer to a group of smaller central index.
The classical source constructions retain the joining elements and
their central returns; the exceptional cases use their ordinary
character supports and relative Weyl groups.

The final section combines Theorem~\ref{cap:odd-main} with the
prime-two case to obtain the conjecture for every finite group.
'''

front = r'''\documentclass[11pt,reqno]{amsart}
'''+sources['preamble.tex']+r'''
\title[Brauer's $k(B)$-conjecture at odd primes]{Brauer's $k(B)$-conjecture at odd primes}
\author{Qiyue Tang}
\address{Zhili College, Tsinghua University, Beijing 100084, China}
\email{tangqy24@mails.tsinghua.edu.cn}
\date{November 14, 2026}
\subjclass[2020]{20C20, 20C33}
\keywords{Brauer's $k(B)$-conjecture, blocks, defect groups, character extensions}
\begin{document}
\begin{abstract}
We prove Brauer's $k(B)$-conjecture, proposed in 1946, for every odd
prime. Together with the prime-two case, this establishes the
conjecture for all finite groups.
\end{abstract}
\maketitle
\section{Introduction}
'''
order = [front,intro,sources['preliminaries.tex'],
         global_parts[0],sources['odd_affine.tex'],global_parts[1],
         sources['integral_foundations.tex'],sources['all_prime_levi.tex'],
         global_parts[2],sources['odd_classical.tex'],sources['odd_endpoints.tex'],
         global_parts[3],r'''
\section{The final all-prime deduction}
\begin{corollary}\label{main:theorem}
If $B$ is a block of a finite group with defect group $D$, then
$k(B)\le |D|$.
\end{corollary}
''',global_parts[4].replace('Proof of Theorem~\\ref{main:theorem}',
                          'Proof of Corollary~\\ref{main:theorem}')]
body = '\n\n'.join(order)
raw_bib = (SRC/'bibliography.tex').read_text()
matches = list(re.finditer(r'\\bibitem(?:\[[^\]]*\])?\{([^}]+)\}',raw_bib))
entries = {m.group(1):raw_bib[m.start():matches[i+1].start() if i+1<len(matches)
                             else len(raw_bib)].strip()
           for i,m in enumerate(matches)}
cited = {k.strip() for m in CITE.finditer(body) for k in m.group(2).split(',')}
missing_cites = sorted(cited-set(entries))
if missing_cites:
    raise ValueError('Missing bibliography keys: '+repr(missing_cites))


def author_sort(item):
    key,entry = item
    line = next((s.strip() for s in entry.splitlines()[1:]
                 if s.strip() and not s.startswith('%')),key)
    author = line.split(' and ')[0].split(',')[0]
    author = re.sub(r'\\(?:[A-Za-z]+|.)','',author.replace('~',' '))
    tokens = re.findall('[A-Za-z]+',unicodedata.normalize('NFKD',author))
    return (tokens[-1].lower() if tokens else key.lower(),author,key)


bib = '\n\n'.join(e for k,e in sorted(entries.items(),key=author_sort) if k in cited)
flat = (body+'\n\\begin{thebibliography}{999}\n'+bib+
        '\n\\enlargethispage{2\\baselineskip}\n\\end{thebibliography}\n\\end{document}\n')
clean = re.sub(r'(?<!\\)%[^\n]*','',flat)
labels = re.findall(r'\\label\{([^}]+)\}',clean)
refs = re.findall(r'\\(?:ref|eqref|pageref|autoref)\{([^}]+)\}',clean)
duplicates = sorted(k for k,v in collections.Counter(labels).items() if v>1)
missing_refs = sorted(set(refs)-set(labels))
stack=[]
errors=[]
for op,name in re.findall(r'\\(begin|end)\{([^}]+)\}',clean):
    if op=='begin':
        stack.append(name)
    elif not stack or stack[-1]!=name:
        errors.append([op,name,stack[-1] if stack else None])
    else:
        stack.pop()
report={'edition_status':'reviewed delivery; review scope and computation limits are recorded in AUDIT_STATUS.json',
        'source_files':{name:hashlib.sha256((SRC/name).read_bytes()).hexdigest()
                        for name in names+['bibliography.tex']},
        'duplicate_labels':duplicates,'missing_references':missing_refs,
        'missing_citations':missing_cites,'environment_errors':errors,
        'unclosed_environments':stack,'labels':len(labels),'citation_keys':len(cited),
        'prime_two_citation_count':len(re.findall(r'\\cite[^\n]*\{TangPrimeTwo26\}',body)),
        'external_inputs':re.findall(r'\\(?:input|include|includegraphics)\{([^}]+)\}',flat),
        'sha256':hashlib.sha256(flat.encode()).hexdigest(),
        'characters':len(flat),'whitespace_words':len(flat.split())}
if duplicates or missing_refs or errors or stack:
    raise ValueError(json.dumps(report,indent=2))
name='Brauer_kB_odd_primes_20261114'
(OUT/(name+'.tex')).write_text(flat)
(OUT/(name+'_source_check.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
