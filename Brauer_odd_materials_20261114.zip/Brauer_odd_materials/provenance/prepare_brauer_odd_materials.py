#!/usr/bin/env python3
"""Stage the manuscript, audit trail, and portable computation materials.

This preserves historical deliveries and never decides mathematical validity.
Run again after the final manuscript and review records have been frozen.
"""
from pathlib import Path
import hashlib
import json
import shutil

ROOT = Path(__file__).resolve().parent
DELIVERY = ROOT / 'brauer_odd_delivery_20261114'
DEST = DELIVERY / 'Brauer_odd_materials'


def copy(source, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)


def main():
    for p in sorted((ROOT / 'brauer_odd_revision').glob('*.tex')):
        copy(p, DEST / 'paper' / 'modules' / p.name)
    stem = 'Brauer_kB_odd_primes_20261114'
    for suffix in ('.tex', '.pdf', '_source_check.json'):
        source = DELIVERY / (stem + suffix)
        if source.exists():
            copy(source, DEST / 'paper' / source.name)
    assembler = (ROOT / 'assemble_brauer_odd_final.py').read_text()
    assembler = assembler.replace("SRC = ROOT / 'brauer_odd_revision'", "SRC = ROOT / 'modules'")
    assembler = assembler.replace("OUT = ROOT / 'brauer_odd_delivery_20261114'", "OUT = ROOT")
    (DEST / 'paper' / 'assemble.py').write_text(assembler)
    for name in ('assemble_brauer_odd_final.py', 'integrate_brauer_odd_revision.py',
                 'integrate_moving_d_repair.py',
                 'prepare_brauer_odd_materials.py', 'save_brauer_checkpoint.py'):
        copy(ROOT / name, DEST / 'provenance' / name)

    audit_root = ROOT / 'revision_audits'
    excluded_parts = {'primary', 'offline_runtime_venv', '__pycache__',
                      'working_layout_preview', 'final_layout_preview',
                      'work', 'source_extraction_replay', 'relocated_paper'}
    def excluded(rel):
        if set(rel.parts) & excluded_parts:
            return True
        if rel.suffix in {'.pdf', '.pyc', '.png', '.jpg', '.fmt', '.aux', '.fls', '.fdb_latexmk'}:
            return True
        if 'SpaethD25_published' in rel.name:
            return True
        if rel.suffix == '.txt' and ({'exceptional_repair_fresh_sources',
                                     'moving_d_anchor_fresh_attack_evidence'} & set(rel.parts)):
            return True
        return False
    # Only the distributable staging copy is cleaned. Original audit records,
    # downloaded papers, and intermediate files remain in the workspace.
    for p in sorted((DEST / 'audits').rglob('*')):
        if p.is_file() and excluded(p.relative_to(DEST / 'audits')):
            p.unlink()
    for p in sorted(audit_root.rglob('*')):
        if not p.is_file():
            continue
        rel = p.relative_to(audit_root)
        if excluded(rel):
            continue
        copy(p, DEST / 'audits' / rel)

    for p in sorted((ROOT / 'revision_sources').glob('*.json')):
        if p.name in {'final_delivery_receipt.json', 'final_library_identity.json'}:
            continue  # Post-archive publication receipts are retained in the checkpoint.
        copy(p, DEST / 'provenance' / p.name)
    for name in ('Brauer_delivery_audit_20261114.txt',):
        p = DELIVERY / name
        if p.exists():
            copy(p, DEST / name)

    old = ROOT / 'brauer_delivery' / 'Brauer_kB_complete_source_20261114.zip'
    copy(old, DEST / 'history' / old.name)
    for p in sorted((ROOT / 'brauer_inputs').glob('*.zip')):
        copy(p, DEST / 'history' / 'original_inputs' / p.name)
    old_checkpoint = ROOT / 'brauer_delivery' / 'Brauer_kB_manuscript_checkpoint_20261114.zip'
    if old_checkpoint.exists():
        copy(old_checkpoint, DEST / 'history' / old_checkpoint.name)
    for name in ('Brauer_odd_working_revision_20261114.pdf',
                 'Brauer_odd_working_revision_20261114.tex',
                 'Brauer_odd_working_revision_20261114_source_check.json'):
        p = DELIVERY / name
        if p.exists():
            copy(p, DEST / 'history' / name)
    (DEST / 'history' / 'README.txt').write_text(
        'HISTORICAL MATERIALS — PRESERVED, NOT THE CURRENT ARTICLE\n\n'
        'The original complete-source archive, earlier manuscript checkpoint, and\n'
        'intermediate conditional working edition are retained without altering\n'
        'their bytes. The input archives r3, r4, r5 and the supplied prime-two source are preserved\n'
        'intact in original_inputs/. These supplied historical archives may retain\n'
        'their original reference documents. Newly downloaded third-party papers\n'
        'are identified by URL and hash, with extraction programs, rather than\n'
        'added in full to this delivery. Historical completeness claims and\n'
        'unresolved-input lists must be read with the\n'
        'dated audit records. Use paper/ for the current mathematical text and\n'
        'AUDIT_STATUS.json for its delivery status. The old prime-two certificate\n'
        'family remains inside the original archive for preservation; the current\n'
        'odd-prime executable checks do not depend on that family.\n')
    print('Staged current text, modular sources, audits, provenance, and historical archive.')


def write_manifest():
    files = []
    for p in sorted(DEST.rglob('*')):
        if not p.is_file() or p.name == 'MANIFEST_SHA256.json' or '__pycache__' in p.parts:
            continue
        if 'verification_records' in p.relative_to(DEST).parts:
            continue
        files.append({'path': p.relative_to(DEST).as_posix(),
                      'size_bytes': p.stat().st_size,
                      'sha256': hashlib.sha256(p.read_bytes()).hexdigest()})
    (DEST / 'MANIFEST_SHA256.json').write_text(
        json.dumps({'schema_version': 1, 'path_base': '.', 'files': files}, indent=2) + '\n')
    print('Manifest:', len(files), 'files')


if __name__ == '__main__':
    main()
    write_manifest()
