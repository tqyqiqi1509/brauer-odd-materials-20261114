#!/usr/bin/env python3
"""Preserve the Brauer workspace with its exact dated review status."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'Brauer_odd_revision_checkpoint_20261114.zip'
SKIP_SUFFIXES = {'.aux', '.fls', '.fdb_latexmk', '.fmt', '.synctex.gz', '.pyc'}
files = {}
for dirname in ['brauer_odd_revision', 'revision_audits', 'revision_sources',
                'brauer_odd_delivery_20261114/Brauer_odd_materials']:
    for p in sorted((ROOT / dirname).rglob('*')):
        if not p.is_file() or p.suffix in SKIP_SUFFIXES:
            continue
        rel = p.relative_to(ROOT)
        if set(rel.parts) & {'primary', '__pycache__', 'offline_runtime_venv',
                             'work', 'relocated_paper'}:
            continue
        if p.name == 'pdftex.map' or 'SpaethD25_published' in p.name:
            continue
        if p.suffix == '.pdf' and 'revision_audits' in rel.parts:
            continue
        if set(rel.parts) & {'working_layout_preview', 'final_layout_preview'}:
            continue
        if p.suffix == '.txt' and ({'exceptional_repair_fresh_sources',
                                   'moving_d_anchor_fresh_attack_evidence'} & set(rel.parts)):
            continue
        if 'source_extraction_replay' in rel.parts and p.name != 'extraction_receipt.json':
            continue
        files[str(rel)] = p.read_bytes()
for name in ['assemble_odd_working_revision.py', 'assemble_brauer_odd_final.py',
             'integrate_brauer_odd_revision.py', 'integrate_moving_d_repair.py',
             'prepare_brauer_odd_materials.py', 'save_brauer_checkpoint.py',
             'brauer_odd_delivery_20261114/Brauer_delivery_audit_20261114.txt',
             'brauer_odd_delivery_20261114/Brauer_kB_odd_primes_20261114.tex',
             'brauer_odd_delivery_20261114/Brauer_kB_odd_primes_20261114.pdf',
             'brauer_odd_delivery_20261114/Brauer_kB_odd_primes_20261114_source_check.json',
             'brauer_odd_delivery_20261114/Brauer_odd_working_revision_20261114.tex',
             'brauer_odd_delivery_20261114/Brauer_odd_working_revision_20261114.pdf',
             'brauer_odd_delivery_20261114/Brauer_odd_working_revision_20261114_source_check.json',
             'brauer_delivery/Brauer_kB_complete_source_20261114.zip',
             'brauer_delivery/final_delivery_receipt.json']:
    p = ROOT / name
    if p.is_file():
        files[name] = p.read_bytes()
status = {
    'saved_utc': datetime.now(timezone.utc).isoformat(),
    'status': 'Reviewed manuscript and complete revision record; see the exact scoped outcome below.',
    'current_review': json.loads((ROOT / 'brauer_odd_delivery_20261114' / 'Brauer_odd_materials' / 'AUDIT_STATUS.json').read_text()),
    'new_work': 'The toral type-D, rank-three central-return, and moving isolated type-D repairs are integrated. Independent mathematical reports, source-reading records, portable runners, original input archives, and finite-check receipts are preserved.',
    'previous_delivery': 'The previous delivery is preserved as historical material. Its old completeness claims are superseded by the current audit.',
    'primary_sources': 'Primary-paper URLs and reading receipts are retained. Newly retrieved third-party PDFs and raw full-text extracts are omitted. The original user-supplied archives are preserved intact, including any documents they originally contained.',
}
files['STATUS.json'] = (json.dumps(status, ensure_ascii=False, indent=2)+'\n').encode()
manifest = {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
            for name, data in sorted(files.items())}
files['CHECKPOINT_SHA256.json'] = (json.dumps(manifest, indent=2)+'\n').encode()
temp = OUT.with_suffix('.zip.tmp')
with zipfile.ZipFile(temp, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for name, data in sorted(files.items()):
        archive.writestr(name, data)
with zipfile.ZipFile(temp) as archive:
    assert archive.testzip() is None
    for name, expected in manifest.items():
        assert hashlib.sha256(archive.read(name)).hexdigest() == expected['sha256']
temp.replace(OUT)
print(json.dumps({'path': str(OUT), 'files': len(files), 'bytes': OUT.stat().st_size,
                  'sha256': hashlib.sha256(OUT.read_bytes()).hexdigest()}, indent=2))
