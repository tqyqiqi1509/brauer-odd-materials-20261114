#!/usr/bin/env python3
"""Integrate the independently reviewed toral argument into its consumers."""
from pathlib import Path
import difflib
import hashlib
import json
import shutil

ROOT = Path(__file__).resolve().parent
SRC = ROOT/'brauer_odd_revision'
BACKUP = ROOT/'revision_audits/pre_toral_integration'
BACKUP.mkdir(parents=True, exist_ok=False)
NAMES = ['toral_type_d_repair.tex', 'odd_classical.tex',
         'odd_endpoints.tex', 'odd_global_capacity.tex']
before = {name:(SRC/name).read_text() for name in NAMES}
for name in NAMES:
    shutil.copy2(SRC/name, BACKUP/name)
reviewed_hash = 'cbdc921d1842e7bc2bdc9474478d8fadd252799f705aaae358e9c47054c5d036'
if hashlib.sha256((SRC/NAMES[0]).read_bytes()).hexdigest() != reviewed_hash:
    raise ValueError('The toral source differs from the frozen reviewed version.')


def replace_once(text, old, new):
    if text.count(old) != 1:
        raise ValueError('Ambiguous edit anchor: '+old[:100])
    return text.replace(old, new)


toral = before['toral_type_d_repair.tex']
toral = replace_once(toral,
    'The next lemma has no degree hypothesis.  It applies also when $d\\geq3$.',
    'The following lemma applies to every $\\lambda\\in\\Irr(T)$, also when $d\\geq3$.')
toral = replace_once(toral,
    'This statement concerns $J\\lhd\\widehat M$ and all indicated characters;\n'
    'it has no hypothesis $d\\geq3$ and no character-degree restriction.\n',
    'This statement applies to every indicated ordinary character of\n'
    '$J\\lhd\\widehat M$ in each configuration above.\n')
toral = replace_once(toral,
    '\\subsubsection{The same full-character argument for larger regular orders}',
    '\\subsubsection{Larger regular orders}\\label{tdr:larger-orders}')
toral = replace_once(toral,
    'Thus this application uses part~(a) of Corollary~4.12 and the\n'
    'all-character Proposition~4.14.  The prime-degree clause in\n'
    'Corollary~4.12(b), whose hypothesis is\n'
    '$\\ell\\nmid|N_1:(N_1)_\\lambda|$, is unnecessary.\n', '')

classical = before['odd_classical.tex']
start = classical.index('For a type-$D$ source with nonempty residual core,')
pending = classical.index('\\begin{remark}[The remaining toral extension input]')
end = classical.index('\\end{remark}', pending)+len('\\end{remark}')
split_start = classical.index('For $d=1$ in split ambient type $D$,', start)
retained = classical[split_start:pending]
retained = retained.replace('\\cite[Corollary~4.12]{CS25}',
                            '\\cite[Corollary~4.12(a)]{CS25}')
retained += r'''
For a nonempty residual core of total rank at least five, the actual
extension is supplied by Theorem~\ref{cl:toral-completion} below.
When $d\ge3$, the doubly regular conditions are
\[
 d\mid2\ell_1,\qquad \varepsilon_1=(-1)^{2\ell_1/d}.
\]
Together with $\ell_1\ge4$, these are the hypotheses of
\cite[Assumption~6.1]{CS25}. Section~\ref{tdr:larger-orders}
constructs the full-character extension in that case.

'''
classical = classical[:start]+retained+toral+classical[end:]
classical = replace_once(classical,
    'Frobenius-stable Levi. For the sources listed in\n'
    'Remark~\\ref{cl:toral-pending}, assume the two extension inputs\n'
    'stated there. Except for the one-factor ternary parameter\n',
    'Frobenius-stable Levi. Except for the one-factor ternary parameter\n')

endpoints = before['odd_endpoints.tex']
endpoints = replace_once(endpoints,
    'For the classical toral sources occurring below, assume also\n'
    'the two rational-carrier extension inputs of\n'
    'Remark~\\ref{cl:toral-pending}.\n', '')
endpoints = replace_once(endpoints,
    'torus preserves the nonzero/zero-weight decomposition, so its full\n'
    'normalizer is the actual product normalizer. For \\(d\\geq3\\),\n'
    'the local construction in\n'
    '\\cite[Assumption 6.1, Lemma 6.6 and Proposition 6.7]{ep:CS25}\n'
    'requires double regularity only in \\(K_1\\); it places no Sylow\n'
    '\\(d\\)-torus requirement on the residual \\(K_2\\).\n',
    'torus preserves the nonzero/zero-weight decomposition, so its full\n'
    'normalizer is the actual product normalizer. For \\(d\\geq3\\),\n'
    'Section~\\ref{tdr:larger-orders} applies to the doubly regular\n'
    'active factor and its actual residual factor.\n')
a = endpoints.index('For \\(d=1,2\\), the active-torus all-ordinary extension construction is')
b = endpoints.index('At the rank-four endpoint,', a)
endpoints = endpoints[:a]+r'''For a nonempty residual core in twisted ambient type \(D\) at
\(d=1\), or at \(d=2\), Theorem~\ref{cl:toral-completion}
gives the simultaneous extension on the actual rational carrier.
Its proof constructs the full toral map and retains the central
returns through the character-triple correspondence.
With empty residual core, use the full Sylow-torus construction
\cite[Theorems 3.1, 3.17 and 3.18]{ep:MS16} directly.
For \(d=2\), the extension in the proof of Theorem 3.18 is
supplied by the all-\(d=1,2\) Theorem 3.17 on the required inertia.
The actual \(vF\)-kernel is retained.
'''+endpoints[b:]
endpoints = replace_once(endpoints,
    'The conditional form of Theorem~\\ref{ep:theorem} is also\n'
    'the one required by Theorem~\\ref{cap:capacity}.',
    'The induction hypothesis of Theorem~\\ref{ep:theorem} is\n'
    'the one used in the global equality case.')
endpoints = replace_once(endpoints,
    'It fixes every ordinary character of $b$, so $K\\le J/S$.',
    'The group $K$ fixes every ordinary character of $b$.')
endpoints = endpoints.replace('\\texttt{ep\\_certificates}',
                               '\\texttt{certificates/exceptional}')

global_text = before['odd_global_capacity.tex']
global_text = replace_once(global_text,
    '\\begin{theorem}[Conditional reduction]\\label{cap:odd-main}\n'
    'Assume the two source-extension inputs of\n'
    'Remark~\\ref{cl:toral-pending} in each of its parameter ranges.\n',
    '\\begin{theorem}\\label{cap:odd-main}\n')
global_text = replace_once(global_text,
    'the conditional almost-simple\nendpoint', 'the almost-simple\nendpoint')

after = {'toral_type_d_repair.tex':toral, 'odd_classical.tex':classical,
         'odd_endpoints.tex':endpoints, 'odd_global_capacity.tex':global_text}
for name,text in after.items():
    if 'cl:toral-pending' in text:
        raise ValueError('An obsolete pending-input reference remains: '+name)
    (SRC/name).write_text(text)
    (BACKUP/(name+'.diff')).write_text(''.join(difflib.unified_diff(
        before[name].splitlines(keepends=True), text.splitlines(keepends=True),
        fromfile='before/'+name, tofile='after/'+name)))
record = {'reviewed_toral_sha256':reviewed_hash,
          'status':'Integrated candidate for a fresh complete dependency review.',
          'before':{n:hashlib.sha256(s.encode()).hexdigest() for n,s in before.items()},
          'after':{n:hashlib.sha256(s.encode()).hexdigest() for n,s in after.items()}}
(BACKUP/'integration_receipt.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
