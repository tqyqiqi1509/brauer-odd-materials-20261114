#!/usr/bin/env python3
"""Extract a primary PDF page by page and record its exact input digest.

Usage: python3 extract_source_pdf.py article.pdf --output new_directory
Requires PyMuPDF 1.26.6 for byte-identical text-extraction receipts. Extraction
helps locate statements; checking mathematical symbols requires the PDF page.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import fitz


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('pdf', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--expected-sha256')
    parser.add_argument('--render-pages', nargs='*', type=int, default=[],
                        help='One-based PDF page numbers to render at 150 dpi.')
    args = parser.parse_args()
    path = args.pdf.resolve()
    sha = hashlib.sha256(path.read_bytes()).hexdigest()
    if args.expected_sha256 and sha != args.expected_sha256:
        parser.error('The input digest differs from the expected primary PDF.')
    doc = fitz.open(path)
    if any(n < 1 or n > len(doc) for n in args.render_pages):
        parser.error('A requested PDF page is outside the document.')
    args.output.mkdir(parents=True, exist_ok=False)
    record = {'input_filename': path.name, 'input_sha256': sha,
              'input_bytes': path.stat().st_size,
              'pymupdf_version': fitz.VersionBind, 'pages': []}
    combined = []
    for index, page in enumerate(doc, 1):
        text = page.get_text('text', sort=False)
        target = args.output/f'page_{index:04d}.txt'
        target.write_text(text)
        combined.append(f'\n--- PDF PAGE {index} ---\n'+text)
        row = {'pdf_page': index, 'text_file': target.name,
               'text_sha256': hashlib.sha256(text.encode()).hexdigest(),
               'characters': len(text)}
        if index in args.render_pages:
            image = args.output/f'page_{index:04d}.png'
            page.get_pixmap(dpi=150).save(image)
            row['render_file'] = image.name
            row['render_sha256'] = hashlib.sha256(image.read_bytes()).hexdigest()
        record['pages'].append(row)
    (args.output/'all_pages.txt').write_text(''.join(combined))
    (args.output/'extraction_receipt.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps({'input_sha256': sha, 'pages': len(doc),
                      'receipt': str(args.output/'extraction_receipt.json')},indent=2))


if __name__ == '__main__':
    main()
