#!/usr/bin/env python3
"""Reproduce the independent checks added in the November 14 audit.

Default: exact matrix calculations and parsing of the identified reference
GAP outputs. --regenerate-gap also recreates the 106-table height-zero screen.
The mathematical theorem status is not determined by this program.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def now():
    return datetime.now(timezone.utc).isoformat()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--regenerate-gap', action='store_true')
    parser.add_argument('--gap-executable', default='gap')
    parser.add_argument('--timeout', type=int, default=1800)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    if sys.flags.optimize:
        parser.error('Assertions are required: do not use -O or -OO.')
    if args.timeout <= 0:
        parser.error('--timeout must be positive.')

    output = (args.output or ROOT/'verification_records'/'audit_runs'/
              datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')).resolve()
    if output.is_relative_to((ROOT/'audit_checks').resolve()):
        parser.error('The output directory must be outside audit_checks.')
    output.mkdir(parents=True, exist_ok=False)
    work = output/'work'
    shutil.copytree(ROOT/'audit_checks', work,
                    ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    logs = output/'logs'
    logs.mkdir()
    env = os.environ.copy()
    env.pop('PYTHONOPTIMIZE', None)
    env['PYTHONHASHSEED'] = '0'
    receipt = {'started_utc': now(), 'python': sys.version,
               'regenerated_gap': args.regenerate_gap, 'checks': [],
               'scope': 'Exact finite checks; no certification of the general conjecture.'}
    failed = False

    def run(identifier, command, cwd, stdout_file=None, stderr_file=None):
        nonlocal failed
        row = {'id': identifier, 'command': command, 'started_utc': now()}
        start = time.monotonic()
        try:
            p = subprocess.run(command, cwd=cwd, input='', text=True,
                               capture_output=True, timeout=args.timeout, env=env)
            (logs/(identifier+'.stdout')).write_text(p.stdout)
            (logs/(identifier+'.stderr')).write_text(p.stderr)
            if stdout_file is not None:
                stdout_file.write_text(p.stdout)
            if stderr_file is not None:
                stderr_file.write_text(p.stderr)
            row['returncode'] = p.returncode
            if p.returncode:
                raise RuntimeError('Nonzero process exit status.')
            if re.search(r'(?m)^(?:Error,|Syntax error|#E|brk>|MISSING\|)',
                         p.stdout+'\n'+p.stderr):
                raise RuntimeError('GAP reported an error or a missing table.')
            row['status'] = 'passed'
        except Exception as exc:
            failed = True
            row['status'] = 'failed'
            row['error'] = f'{type(exc).__name__}: {exc}'
        row['elapsed_seconds'] = round(time.monotonic()-start, 6)
        receipt['checks'].append(row)
        print(row['status'].upper()+': '+identifier, flush=True)
        return row['status'] == 'passed'

    matrix = work/'type_a'
    matrix_output = matrix/'new_result.json'
    if run('type_a_exact_matrices', [sys.executable, str(matrix/'verify_type_a_scope.py')],
           matrix, stdout_file=matrix_output):
        actual = json.loads(matrix_output.read_text())
        expected = json.loads((matrix/'type_a_scope_result.json').read_text())
        same = actual == expected
        failed |= not same
        receipt['checks'].append({'id': 'type_a_complete_output_comparison',
                                  'status': 'passed' if same else 'failed'})

    screen = work/'height_zero_screen'
    gap_ok = True
    if args.regenerate_gap:
        located = shutil.which(args.gap_executable)
        gap = (str(Path(located).resolve()) if located else
               str(Path(args.gap_executable).resolve()) if os.sep in args.gap_executable
               else args.gap_executable)
        for family in ('exceptional', 'sporadic'):
            stem = screen/(family+'_abelian')
            for suffix in ('.out', '.stderr'):
                stem.with_suffix(suffix).unlink(missing_ok=True)
            ok = run(family+'_gap_height_zero',
                     [gap, '--bare', '-q', '-b', '-T', str(stem.with_suffix('.g'))],
                     screen, stdout_file=stem.with_suffix('.out'),
                     stderr_file=stem.with_suffix('.stderr'))
            gap_ok &= ok

    expected = json.loads((screen/'complete_abelian_scope.json').read_text())
    (screen/'complete_abelian_scope.json').unlink()
    if gap_ok and run('parse_complete_height_zero_screen',
                      [sys.executable, str(screen/'collect_abelian_scope.py')], screen):
        actual = json.loads((screen/'complete_abelian_scope.json').read_text())
        keys = ('table_count', 'retained_block_count', 'maximum_log_defect_by_prime',
                'tables', 'blocks')
        same = all(actual['families'][family][key] == expected['families'][family][key]
                   for family in ('exceptional', 'sporadic') for key in keys)
        failed |= not same
        receipt['checks'].append({'id': 'all_106_tables_and_1957_retained_blocks',
                                  'status': 'passed' if same else 'failed',
                                  'compared_fields': list(keys)})
        receipt['gap_metadata'] = {family: actual['families'][family]['metadata']
                                   for family in ('exceptional', 'sporadic')}
    elif not gap_ok:
        receipt['checks'].append({'id': 'parse_complete_height_zero_screen',
                                  'status': 'failed',
                                  'error': 'Required GAP regeneration failed.'})
        failed = True

    cyclotomic_json = screen/'exceptional_cyclotomic_scope.json'
    expected_cyclotomic = json.loads(cyclotomic_json.read_text())
    cyclotomic_json.unlink()
    if run('e8_complete_cyclotomic_arithmetic',
           [sys.executable, str(screen/'exceptional_cyclotomic_scope.py')], screen):
        same = json.loads(cyclotomic_json.read_text()) == expected_cyclotomic
        failed |= not same
        receipt['checks'].append({'id': 'all_16_centralizer_polynomial_inputs',
                                  'status': 'passed' if same else 'failed'})

    receipt['completed_utc'] = now()
    receipt['all_requested_checks_passed'] = not failed
    receipt['work_file_sha256'] = {str(p.relative_to(work)): digest(p)
                                  for p in sorted(work.rglob('*')) if p.is_file()}
    target = output/'run_receipt.json'
    target.write_text(json.dumps(receipt, indent=2)+'\n')
    print(target)
    return int(failed)


if __name__ == '__main__':
    raise SystemExit(main())
