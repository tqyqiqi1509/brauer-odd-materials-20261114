#!/usr/bin/env python3
"""Exact rank-three graph and central-return checks; standard library only.

The symbolic scalar check uses powers of i modulo four, never floating point.
The monomial enumeration concerns the order-192 integral Tits group, not all
finite field extensions or all irreducible characters. See input.json.
"""
from pathlib import Path
from itertools import permutations, product
import hashlib
import json
import platform
import sys

ROOT = Path(__file__).resolve().parent


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def multiply(a, b):
    return tuple(tuple(sum(a[i][k] * b[k][j] for k in range(len(a)))
                       for j in range(len(a))) for i in range(len(a)))


def transpose(a):
    return tuple(zip(*a))


def monomial_multiply(a, b):
    return tuple((1 if x > 0 else -1) * b[abs(x)-1] for x in a)


def monomial_inverse(a):
    inverse = [0] * len(a)
    for i, x in enumerate(a):
        inverse[abs(x)-1] = (i+1) * (1 if x > 0 else -1)
    return tuple(inverse)


def monomial_matrix(a):
    return tuple(tuple((1 if x > 0 else -1) if abs(x) == j+1 else 0
                       for j in range(len(a))) for x in a)


def permutation_sign(p):
    inversions = sum(p[i] > p[j] for i in range(len(p))
                     for j in range(i+1, len(p)))
    return (-1) ** inversions


def root_element(n, row, column, parameter):
    return tuple(tuple(int(i == j) + (parameter if (i, j) == (row, column) else 0)
                       for j in range(n)) for i in range(n))


def main():
    if sys.flags.optimize:
        raise RuntimeError('Run without -O or -OO.')
    specification = json.loads((ROOT/'input.json').read_text())
    n = specification['matrix_dimension']
    require(n == 4, 'This check is specifically for rank three / dimension four.')
    identity = tuple(range(1, n+1))
    minus_identity = tuple(-x for x in identity)
    v0 = tuple((-1)**i * (n-i) for i in range(n))
    j = tuple(range(n, 0, -1))
    v0_inverse = monomial_inverse(v0)
    require(monomial_multiply(v0, v0) == minus_identity, 'v0 squared must be -I.')
    require(monomial_multiply(j, j) == identity, 'All-one antidiagonal squared is I.')

    group = []
    for permutation in permutations(range(1, n+1)):
        for signs in product((-1, 1), repeat=n):
            determinant = permutation_sign(permutation)
            for sign in signs:
                determinant *= sign
            if determinant == 1:
                group.append(tuple(signs[i] * permutation[i] for i in range(n)))
    group = sorted(group)
    require(len(group) == specification['expected_signed_monomial_group_order'],
            'Unexpected Tits group order.')
    require(v0 in group and j in group, 'Both matrices must have determinant one.')
    vmat, jmat = monomial_matrix(v0), monomial_matrix(j)
    vi, ji = transpose(vmat), transpose(jmat)

    roots_checked = 0
    old_graph_failures = []
    for i in range(1, n):
        for t in specification['root_parameters']:
            # gamma0(I+tE_(i,i-1)) = I-tE_(i-1,i).
            inverse_transpose = root_element(n, i-1, i, -t)
            actual = multiply(multiply(vmat, inverse_transpose), vi)
            expected = root_element(n, n-i, n-i-1, t)
            require(actual == expected, 'The alternating matrix must preserve pinning.')
            old = multiply(multiply(jmat, inverse_transpose), ji)
            require(old == root_element(n, n-i, n-i-1, -t),
                    'The old graph must reverse the root parameter.')
            if old != expected:
                old_graph_failures.append({'simple_root': i, 'parameter': t})
            roots_checked += 1

    for a in group:
        matrix = monomial_matrix(a)
        require(multiply(matrix, transpose(matrix)) == monomial_matrix(identity),
                'gamma0 must fix every signed monomial matrix.')
    pair_checks = 0
    for a in group:
        for b in group:
            for epsilon in (0, 1):
                for eta in (0, 1):
                    ve = v0 if epsilon else identity
                    vf = v0 if eta else identity
                    vef = v0 if epsilon ^ eta else identity
                    conjugated_b = monomial_multiply(
                        monomial_multiply(ve, b), monomial_inverse(ve))
                    standard_product_matrix = monomial_multiply(a, conjugated_b)
                    image_of_product = monomial_multiply(standard_product_matrix, vef)
                    product_of_images = monomial_multiply(
                        monomial_multiply(a, ve), monomial_multiply(b, vf))
                    correction = minus_identity if epsilon * eta else identity
                    require(product_of_images == monomial_multiply(correction, image_of_product),
                            'The exact central multiplication defect must be (-I)^(epsilon*eta).')
                    pair_checks += 1

    scalar_checks = []
    for value in specification['central_character_values']:
        # value = i^s; choose c = i^c_power, so c^2 * value = 1.
        s = 0 if value == 1 else 2
        c_power = 0 if value == 1 else 1
        require((2*c_power + s) % 4 == 0, 'Wrong square normalization.')
        for epsilon, eta in product((0, 1), repeat=2):
            lhs = (c_power*(epsilon+eta) + s*epsilon*eta) % 4
            rhs = c_power*(epsilon ^ eta) % 4
            require(lhs == rhs, 'The complex scalar must cancel the central defect.')
        scalar_checks.append({'central_value': value, 'c_power_of_i': c_power,
                              'parity_pairs_checked': 4})

    # In V x (C_(4f) x C_2), F_r and gamma0 act trivially on V.
    cover_checks = []
    for f in specification['field_degrees']:
        order = 4*f
        def cover_multiply(a, b):
            return (monomial_multiply(a[0], b[0]),
                    (a[1]+b[1]) % order, (a[2]+b[2]) % 2)
        z = (v0, f, 1)
        z2 = cover_multiply(z, z)
        z4 = cover_multiply(z2, z2)
        require(z2 == (minus_identity, 2*f, 0), 'Wrong unitary central return square.')
        require(z4 == (identity, 0, 0), 'The covering return must have fourth power one.')
        cover_checks.append({'field_degree': f, 'cover_field_order': order,
                             'z_squared': {'matrix': list(z2[0]), 'field_power': z2[1],
                                           'graph_power': z2[2]},
                             'z_fourth_power_identity': True})

    output = {
        'status': 'PASSED_EXACT_FINITE_CHECKS',
        'universal_verification': False,
        'python': platform.python_version(),
        'dependencies': 'Python 3 standard library only',
        'input_sha256': hashlib.sha256((ROOT/'input.json').read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'v0_matrix': vmat,
        'v0_squared': monomial_matrix(minus_identity),
        'pinned_simple_root_checks': roots_checked,
        'old_all_one_graph_failures': old_graph_failures,
        'signed_monomial_group_order': len(group),
        'monomial_pair_parity_checks': pair_checks,
        'scalar_normalizations': scalar_checks,
        'unitary_cover_checks': cover_checks,
        'scope': specification['scope'],
        'unitary_quotient_warning': 'The relation z=1 implies Fhat_r^(2f)=-I in this cover quotient; this is not the standard split finite field-operator return. Actual unitary inertia extensions require the separate cyclic-quotient argument.'
    }
    (ROOT/'output.json').write_text(json.dumps(output, indent=2)+'\n')
    print(json.dumps({key: value for key, value in output.items()
                      if key not in ('old_all_one_graph_failures', 'unitary_cover_checks')}, indent=2))


if __name__ == '__main__':
    main()
