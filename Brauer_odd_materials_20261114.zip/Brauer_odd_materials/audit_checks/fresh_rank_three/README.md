# Rank-three pinned graph and central return

Run from this directory:

```sh
python3 check_rank_three_graph.py
```

This requires Python 3 with its standard library only. It writes `output.json`
and records the exact input and script hashes. No external tables, floating
point arithmetic, or previously generated outputs are used.

The checker constructs the order-192 determinant-one signed monomial group.
It verifies the alternating antidiagonal matrix, its square `-I`, the pinned
action on all three simple roots at the specified integer parameters, and
the failure of the old all-one antidiagonal matrix to preserve those root
parameters. It checks the central multiplication defect on every pair of
signed monomial matrices and both graph parities (147,456 cases), and cancels
that defect using exact powers of `i` for either central character value.

For the eight supplied field degrees it also retains the full unitary cover
return `z = v0 Fhat_1`, with `z^2 = (-I) Fhat_r^(2f)`. In particular, quotienting
this cover by `z` does not give the standard field-operator return. The
mathematical proof uses a separate cyclic-quotient extension for the actual
unitary inertia group.

These finite checks support the explicit matrix calculation. They do not prove
Lang's theorem, enumerate all torus characters, certify all downstream
character-triple arguments, or certify Brauer's conjecture. The general
symbolic multiplication calculation is in the accompanying audit report.
