#!/usr/bin/env python3
"""Fresh audit: retained carrier outputs, independent root and valuation checks.

This verifies arithmetic inputs only. It makes no claim that the source theory,
Clifford correspondence or the global k(B) reduction follows from computation.
"""
from pathlib import Path
from fractions import Fraction
from collections import Counter
import ast, hashlib, json, re
import sympy as sp

HERE = Path(__file__).resolve().parent
BASE = HERE.parent.parent
out = {}

# Newly executed GAP outputs, not prior PASS receipts.
retained = []
for typ, omit_first in [('e7', True), ('e8', False)]:
    text = (HERE / (typ + '_fresh.out')).read_text()
    err = (HERE / (typ + '_fresh.stderr')).read_text()
    assert not re.search(r'Error,|Syntax error|brk>|Assertion failed', text + err)
    chunks = re.split(r'(?m)^orders=', text)[1:]
    assert len(chunks) == 4
    for pos, chunk in enumerate(chunks):
        m = re.match(r'(\d+),(\d+),(\d+) expected=(\d+),(\d+),(\d+) toral_kernel=true', chunk)
        assert m and m.groups()[:3] == m.groups()[3:]
        orders = list(map(int, m.groups()[:3]))
        colors = re.findall(r'colour=(\d+) inertia=(\d+) comm_intersection=(\d+) abelian=\[([^]]*)\]', chunk)
        assert [int(x[0]) for x in colors] == list(range(1, orders[1]))
        assert 'bad=[  ]' in chunk
        ret = re.search(r'return_in_Q=true order=(\d+) centralizes_all=true', chunk)
        assert ret
        abelian_exponents = [int(n) for x in colors for n in re.findall(r'\d+', x[3])]
        assert all(4 % n == 0 for n in abelian_exponents)
        if omit_first and pos == 0:
            continue
        retained.append(dict(type=typ, row=pos+1, orders=orders,
                             colors=len(colors), return_order=int(ret[1])))
assert sum(r['colors'] for r in retained) == 201
out['retained_carriers'] = retained
out['retained_colors'] = 201

# Generate E8 roots by an independent breadth-first reflection calculation.
C = [[2,0,-1,0,0,0,0,0], [0,2,0,-1,0,0,0,0],
     [-1,0,2,-1,0,0,0,0], [0,-1,-1,2,-1,0,0,0],
     [0,0,0,-1,2,-1,0,0], [0,0,0,0,-1,2,-1,0],
     [0,0,0,0,0,-1,2,-1], [0,0,0,0,0,0,-1,2]]
root_set = {tuple(int(i == j) for i in range(8)) for j in range(8)}
frontier = list(root_set)
while frontier:
    v = frontier.pop(0)
    for i in range(8):
        w = list(v)
        w[i] -= sum(C[i][j]*v[j] for j in range(8))
        w = tuple(w)
        if w not in root_set:
            root_set.add(w)
            frontier.append(w)
assert len(root_set) == 240 and sp.Matrix(C).det() == 1

def rank_mod(rows, p):
    a = [[x % p for x in row] for row in rows]
    k = 0
    for j in range(8):
        pivot = next((i for i in range(k, len(a)) if a[i][j]), None)
        if pivot is None:
            continue
        a[k], a[pivot] = a[pivot], a[k]
        u = pow(a[k][j], -1, p)
        a[k] = [x*u % p for x in a[k]]
        for i in range(len(a)):
            if i != k:
                u = a[i][j]
                a[i] = [(x-u*y) % p for x,y in zip(a[i], a[k])]
        k += 1
    return k

centres = []
for label, nodes, expected in [('A1^2',[1,2],4), ('A1^3',[1,2,5],6),
                               ('A1^4',[1,2,5,7],8), ('D4',[2,3,4,5],24)]:
    indices = [i-1 for i in nodes]
    constraints = [C[i] for i in indices]
    vanished = []
    for root in root_set:
        functional = [sum(root[j]*C[j][i] for j in range(8)) for i in range(8)]
        if rank_mod(constraints+[functional], 5) == len(nodes):
            vanished.append(root)
    exact = [v for v in root_set if all(v[j] == 0 for j in range(8) if j not in indices)]
    assert set(vanished) == set(exact) and len(exact) == expected
    centres.append(dict(source=label, nodes=nodes, active_rank=8-len(nodes),
                        roots_vanishing_mod_5=len(vanished), no_outside_root=True))
out['e8_source_centres'] = centres

# Independent polynomial remainder calculation for all rational isolated types.
x = sp.Symbol('x')
def A(n, unitary=False, power=1):
    return [x**(power*i) - ((-1)**i if unitary else 1) for i in range(2,n+2)]
def D(n, minus=False):
    return [x**(2*i)-1 for i in range(1,n)] + [x**n + (1 if minus else -1)]
def E6(unitary=False):
    return [x**i + (1 if unitary and i in (5,9) else -1) for i in (2,5,6,8,9,12)]
types = {
    'E8':[x**i-1 for i in (2,8,12,14,18,20,24,30)],
    'D8':D(8), 'E7 A1':[x**i-1 for i in (2,6,8,10,12,14,18)]+A(1),
    'D5 A3':D(5)+A(3), '2D5 2A3':D(5,True)+A(3,True),
    'A7 A1':A(7)+A(1), '2A7 A1':A(7,True)+A(1),
    'A8':A(8), '2A8':A(8,True),
    'E6 A2':E6()+A(2), '2E6 2A2':E6(True)+A(2,True),
    'A4^2':A(4)*2, '2A4^2':A(4,True)*2, '2A4(q^2)':A(4,True,2),
    'A5 A2 A1':A(5)+A(2)+A(1), '2A5 2A2 A1':A(5,True)+A(2,True)+A(1)}
cyclotomic = {name:{e:sum(sp.rem(f,sp.cyclotomic_poly(e,x),x)==0 for f in fs)
                          for e in (3,4,6)} for name,fs in types.items()}
high = {(name,e) for name,es in cyclotomic.items() for e,n in es.items() if n>=4}
assert high == {('E8',3),('E8',4),('E8',6),('D8',4),('E6 A2',3),
                ('2E6 2A2',6),('2A4(q^2)',4)}
out['cyclotomic_multiplicities'] = cyclotomic

# The exact 166-degree export is public CHEVIE data; solve affine valuation
# equalities for every integer a>=1 instead of sampling finite field orders.
degree_path = BASE/'certificates/exceptional/e8_degrees/e8_unipotent_five_identity_output.txt'
records=[]
for line in degree_path.read_text().splitlines():
    if line.startswith(('HC|','DEG|')):
        records.append(line)
    elif records and line.startswith((' ','[')):
        records[-1] += line.strip()
degrees={}
series={}
for record in records:
    f=record.split('|')
    if f[0]=='HC':
        series[f[1]]=ast.literal_eval(f[2])
    else:
        degrees[int(f[1])]=(Fraction(f[3]),ast.literal_eval(f[4]))
assert len(degrees)==166 and sorted(degrees)==list(range(1,167))
def v5(n):
    assert n
    exponent=0
    while n%5==0:
        exponent+=1
        n//=5
    return exponent
profiles={}
for e in (1,2):
    affine={}
    for i,(constant,phis) in degrees.items():
        shift=v5(abs(constant.numerator))-v5(constant.denominator)
        j=5*e
        while j<=len(phis):
            shift+=phis[j-1]
            j*=5
        affine[i]=(8-phis[e-1],2-shift)
    exact=[i for i,(m,b) in affine.items() if (m,b)==(4,0)]
    exceptional=[]
    for i,(m,b) in affine.items():
        if m!=4:
            solution=Fraction(-b,m-4)
            if solution.denominator==1 and solution>=1:
                exceptional.append((i,int(solution)))
    assert len(exact)==25 and not exceptional
    if e==1:
        assert set(exact)==set(series['D_4'])
    profiles[e]={'exact_defect_4a':exact,'additional_integer_solutions':exceptional,
                 'defect_profiles':{str(k):v for k,v in Counter(affine.values()).items()}}
out['e8_166_degree_profiles']=profiles
out['input_hashes']={str(p.relative_to(BASE)):hashlib.sha256(p.read_bytes()).hexdigest()
                     for p in [degree_path, HERE/'e7_fresh.out', HERE/'e8_fresh.out']}
(HERE/'independent_results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'retained_colors':201,'e8_roots':240,'source_centres':centres,
                  'high_cyclotomic_rows':sorted(high),'e8_degrees':166,
                  'exact_defect_4a_count':25},indent=2))
