# Fresh exceptional-endpoint arithmetic checks

Date: 2026-11-14.

These inputs supplement the article's existing finite carrier and degree files.
They verify two additional finite arithmetic claims. They do not verify the
general character-correspondence, equivariance, or Levi-descent arguments.

## 1. Complete finite-cover abelian-defect order screen

The two GAP programs contain the same complete domains as the original
exceptional-cover and sporadic-cover check: 58 and 48 tables. For each odd
prime not dividing the center order, PrimeBlocks supplies each block's
ordinary heights and defect. The programs retain every positive-defect
block whose ordinary heights all vanish. This set contains every block
with abelian defect. The proof only uses the upper bound
generator_rank(D) <= log_p(|D|).

The new screen uses GAP 4.14.0 with CTblLib 1.3.11. The local runtime was
invoked through brauer_runtime/gap4-bare, which starts GAP with --bare
and explicitly loads SmallGrp. An ordinary complete GAP installation can run:

~~~sh
gap -q -b -T exceptional_abelian.g > exceptional_abelian.out 2> exceptional_abelian.stderr
gap -q -b -T sporadic_abelian.g > sporadic_abelian.out 2> sporadic_abelian.stderr
python collect_abelian_scope.py
~~~

The exact local executable was
/workspace/scratch/8a38714ad82e/brauer_runtime/gap4-bare,
with arguments -q -b -T followed by the script path.

The complete_abelian_scope.json file contains all 106 table metadata
records and all 1957 retained block records: 1119 from the exceptional
domain and 838 from the sporadic domain. Each record includes the exact
table identifier, prime, block index, logarithmic defect, defect order,
ordinary count, zero-height filter, and generator-rank bound. It also
records SHA-256 hashes of the GAP programs, complete stdout, and stderr.

The inherited last two GAP output fields compare an outer-order multiple
with the defect order. They belong to the older strong-bound calculation
and are explicitly marked unused in the JSON; a false value in those
fields is not a failure of this abelian-defect rank screen.

The compact conclusions are:

| Domain | At 3 | At primes at least 5 |
|---|---:|---:|
| Exceptional covers | log defect at most 2 | log defect at most 2 |
| Sporadic covers | log defect at most 4 | log defect at most 2 |

The older abelian_order_scope.json records maxima and rows attaining
them; the complete JSON is the authoritative full receipt.

## 2. Higher-cyclotomic toral sources in E8

~~~sh
python exceptional_cyclotomic_scope.py
~~~

This standard-library Python program uses every rational isolated
centralizer type from KM13 Tables 5--8, the order-six correction from
KM25 Table 5, and the identity label. It writes the order factors and
their exact Phi_3, Phi_4, Phi_6 multiplicities to
exceptional_cyclotomic_scope.json.

The nonidentity possibilities of multiplicity four are:

- E6(q) A2(q), e = 3;
- D8(q), e = 4;
- 2A4(q^2), e = 4;
- 2E6(q) 2A2(q), e = 6.

In particular 2A4(q^2) is a necessary good-prime row: its four
factors q^4-1, q^6+1, q^8-1, q^10+1 all contain Phi_4.
The article treats it at p >= 7, since its semisimple label has order 5.
The unipotent E8 e=4 case at p=5 has nonabelian defect and is outside
this abelian endpoint.
