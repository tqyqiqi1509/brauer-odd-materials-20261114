LoadPackage("ctbllib");;
SetInfoLevel(InfoCharacterTable,0);;
SizeScreen([240,100000]);;
base := [ ["M11",1,1],["M12",2,2],["M22",12,2],["M23",1,1],["M24",1,1],["J1",1,1],["J2",2,2],["J3",3,2],["J4",1,1],["Co1",2,1],["Co2",1,1],["Co3",1,1],["Fi22",6,2],["Fi23",1,1],["Fi24'",3,2],["HS",2,2],["McL",3,2],["He",1,2],["Ru",2,1],["Suz",6,2],["ON",3,2],["HN",1,2],["Ly",1,1],["Th",1,1],["B",2,1],["M",1,1],["2F4(2)'",1,2] ];;
Print("META|GAP|",GAPInfo.Version,"|CTblLib|",PackageInfo("ctbllib")[1].Version,"\n");
for row in base do
 for cen in DivisorsInt(row[2]) do
  if cen=1 then nm:=row[1];else nm:=Concatenation(String(cen),".",row[1]);fi;
  t:=CharacterTable(nm);
  if t=fail then Print("MISSING|",nm,"\n");continue;fi;
  Print("TABLE|",Identifier(t),"|",Size(t),"|",Length(Irr(t)),"|",row[3],"|",cen,"\n");
  for p in Filtered(PrimeDivisors(Size(t)),p->p<>2 and cen mod p<>0) do
   bl:=PrimeBlocks(t,p);
   for j in [1..Length(bl.defect)] do
    inds:=Positions(bl.block,j); kk:=Length(inds); d:=bl.defect[j];
    posh:=Number(inds,x->bl.height[x]>0);
    if posh=0 and d>0 then
     Print("BLOCK|",Identifier(t),"|",p,"|",j,"|",d,"|",p^d,"|",kk,"|",posh,"|",row[3],"|",row[3]*kk<=p^d,"\n");
    fi;
   od;
  od;
 od;
od;
QUIT;
