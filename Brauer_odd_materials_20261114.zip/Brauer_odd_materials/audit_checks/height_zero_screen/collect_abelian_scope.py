#!/usr/bin/env python3
"""Parse the complete 106-table height-zero screening receipts.

Run after:
  gap -q exceptional_abelian.g > exceptional_abelian.out 2> exceptional_abelian.stderr
  gap -q sporadic_abelian.g > sporadic_abelian.out 2> sporadic_abelian.stderr

The screen retains EVERY positive-defect block with no positive-height
ordinary character. In particular it contains every abelian-defect block.
The generator-rank bound is log_p(|D|), so it needs no reconstruction of D.
The historical final two GAP fields concern a different strong inequality;
they are copied as data and are NOT used in this rank screen.
"""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
result = {"method": __doc__, "families": {}}
for family, expected in (("exceptional", 58), ("sporadic", 48)):
    stem = HERE / f"{family}_abelian"
    raw = stem.with_suffix(".out").read_text()
    stderr = stem.with_suffix(".stderr").read_text()
    assert not any(x in raw + stderr for x in ("MISSING|", "Error,", "Syntax error", "brk>"))
    tables, blocks, metadata = [], [], []
    for line in raw.splitlines():
        if line.startswith("META|"):
            metadata.append(line.split("|"))
        elif line.startswith("TABLE|"):
            _, name, order, irr, out, center = line.split("|")
            tables.append(dict(table=name, order=int(order), ordinary_characters=int(irr),
                               outer_order_bound=int(out), center_order=int(center)))
        elif line.startswith("BLOCK|"):
            _, name, p, number, d, order, k, posh, out, strong = line.split("|")
            assert int(posh) == 0 and int(d) > 0 and int(order) == int(p) ** int(d)
            blocks.append(dict(table=name, prime=int(p), block=int(number),
                               defect_log_p=int(d), defect_order=int(order),
                               generator_rank_bound=int(d), k=int(k),
                               positive_height_count=int(posh),
                               outer_pprime_order_bound=int(out),
                               unused_strong_inequality=(strong == "true")))
    assert len(tables) == expected, (family, len(tables), expected)
    assert len({t["table"] for t in tables}) == expected
    maxima = {p: max(b["defect_log_p"] for b in blocks if b["prime"] == p)
              for p in sorted({b["prime"] for b in blocks})}
    receipt = {"metadata": metadata, "table_count": len(tables),
               "retained_block_count": len(blocks), "maximum_log_defect_by_prime": maxima,
               "tables": tables, "blocks": blocks,
               "sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                          for p in (stem.with_suffix(".g"), stem.with_suffix(".out"),
                                    stem.with_suffix(".stderr"))}}
    result["families"][family] = receipt
    print(family, len(tables), len(blocks), maxima)
target = HERE / "complete_abelian_scope.json"
target.write_text(json.dumps(result, indent=2) + "\n")
print(target)
