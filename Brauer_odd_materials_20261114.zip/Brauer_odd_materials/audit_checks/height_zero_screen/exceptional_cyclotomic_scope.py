#!/usr/bin/env python3
"""Exact Phi_3/Phi_4/Phi_6 screen for every isolated E8 centralizer.

Inputs are the complete rational centralizer types in KM13 Tables 5--8
and the additional order-six types in KM25 Table 5, plus s=1.
Each pair (n,c) represents the factor q**n+c in its prime-to-defining-
characteristic order. These polynomial inputs use the standard orders of
the actual root-datum groups; central isogeny does not change the order.
This is a cyclotomic arithmetic check, not a substitute for the published
classification of isolated semisimple classes or e-cuspidal sources.
"""
import json
from pathlib import Path

def A(rank, twisted=False, power=1):
    return [(power*i, -((-1)**i if twisted else 1))
            for i in range(2, rank+2)]

def D(rank, twisted=False):
    return [(2*i, -1) for i in range(1, rank)] + [(rank, 1 if twisted else -1)]

def E6(twisted=False):
    return [(i, 1 if twisted and i in (5, 9) else -1)
            for i in (2, 5, 6, 8, 9, 12)]

e7 = [(i, -1) for i in (2, 6, 8, 10, 12, 14, 18)]
e8 = [(i, -1) for i in (2, 8, 12, 14, 18, 20, 24, 30)]
rows = [
    ("E8(q)", 1, "all q", e8, "unipotent"),
    ("D8(q)", 2, "q odd", D(8), "KM13 Tables 7--8"),
    ("E7(q) A1(q)", 2, "q odd", e7+A(1), "KM13 Tables 7--8"),
    ("D5(q) A3(q)", 4, "q=1 mod 4", D(5)+A(3), "KM13 Tables 7--8"),
    ("2D5(q) 2A3(q)", 4, "q=-1 mod 4", D(5,True)+A(3,True), "KM13 Tables 7--8"),
    ("A7(q) A1(q)", 4, "q=1 mod 4", A(7)+A(1), "KM13 Tables 7--8"),
    ("2A7(q) A1(q)", 4, "q=-1 mod 4", A(7,True)+A(1), "KM13 Tables 7--8"),
    ("A8(q)", 3, "q=1 mod 3", A(8), "KM13 Tables 5,7"),
    ("2A8(q)", 3, "q=-1 mod 3", A(8,True), "KM13 Tables 5,7"),
    ("E6(q) A2(q)", 3, "q=1 mod 3", E6()+A(2), "KM13 Tables 5,7"),
    ("2E6(q) 2A2(q)", 3, "q=-1 mod 3", E6(True)+A(2,True), "KM13 Tables 5,7"),
    ("A4(q) A4(q)", 5, "q=1 mod 5", A(4)*2, "KM13 Tables 5,6"),
    ("2A4(q) 2A4(q)", 5, "q=-1 mod 5", A(4,True)*2, "KM13 Tables 5,6"),
    ("2A4(q^2)", 5, "q=+/-2 mod 5", A(4,True,2), "KM13 Tables 5,6"),
    ("A5(q) A2(q) A1(q)", 6, "q=1 mod 6", A(5)+A(2)+A(1), "KM25 Table 5"),
    ("2A5(q) 2A2(q) A1(q)", 6, "q=-1 mod 6", A(5,True)+A(2,True)+A(1), "KM25 Table 5"),
]

def divides_quadratic(n, c, e):
    # Phi_e = x^2 + b*x + 1, e = 3,4,6.
    b = {3: 1, 4: 0, 6: -1}[e]
    constant, linear = 1, 0
    for _ in range(n):
        constant, linear = -linear, constant-b*linear
    return constant+c == 0 and linear == 0

result = []
for name, order, condition, factors, reference in rows:
    exponents = {e: sum(divides_quadratic(n,c,e) for n,c in factors)
                 for e in (3,4,6)}
    result.append(dict(centralizer=name, semisimple_order=order,
                       rational_condition=condition,
                       source_reference=reference,
                       order_factors=[{"degree": n, "constant": c} for n,c in factors],
                       cyclotomic_exponents=exponents,
                       rank_four_candidates=[e for e,v in exponents.items() if v >= 4]))

expected = {
    ("E8(q)", 3), ("E8(q)", 4), ("E8(q)", 6),
    ("D8(q)", 4), ("E6(q) A2(q)", 3),
    ("2E6(q) 2A2(q)", 6), ("2A4(q^2)", 4)
}
actual = {(row["centralizer"],e) for row in result for e in row["rank_four_candidates"]}
assert actual == expected, (actual, expected)
target = Path(__file__).with_suffix(".json")
target.write_text(json.dumps({"method": __doc__, "rows": result}, indent=2)+"\n")
for name,e in sorted(actual):
    print(name, "e =", e)
print(target)
