Fresh degree and order-bound boundary checks

Run: python check_degree_order_bounds.py
Dependencies: Python standard library only.

This checks 22 exact finite boundary values and the two implemented-outer
corrections for A5 over fields of orders 11 and 19. It does not enumerate
all groups or prove the general inequalities. The general estimates and
monotonicity arguments are stated in the manuscript.

input.json supplies the exact numerical inputs; expected_output.json is
the retained output. primary_reading_index.json identifies the public
PDFs examined by the independent degree-bound reviewer.
