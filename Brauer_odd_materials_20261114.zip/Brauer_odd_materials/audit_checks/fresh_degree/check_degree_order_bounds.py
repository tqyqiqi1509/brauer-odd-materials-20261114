#!/usr/bin/env python3
"""Exact finite checks for the fresh degree-gate review; standard library only."""
from pathlib import Path
import hashlib
import json
import platform

ROOT = Path(__file__).resolve().parent
source = ROOT/'input.json'
data = json.loads(source.read_text())
results = []
for row in data['root_estimate_starts'] + data['exceptional_root_bound_starts']:
    lhs = 256 * row['positive_roots'] * (row['rank'] + 1)
    rhs = row['field'] ** (2 * row['positive_roots'] - 1)
    assert lhs <= rhs, row
    results.append(dict(row, family='root_estimate', lhs=lhs, rhs=rhs))
for row in data['suzuki_ree_starts']:
    rhs = row['field'] ** row['exponent']
    assert row['lhs'] <= rhs, row
    results.append(dict(row, family='Suzuki_Ree_margin', rhs=rhs))
for row in data['finite_order_margins']:
    lhs = 4 * row['class_bound'] * row['outer_order']
    assert lhs <= row['order'], row
    results.append(dict(row, family='finite_order_margin', lhs=lhs))
for row in data['defining_small_cases']:
    assert row['class_bound'] <= row['p_part'], row
    results.append(dict(row, family='defining_class_bound'))
for row in data['half_bound_exceptions']:
    assert 2 * row['full_outer_beta'] > row['field'], row
    assert 2 * row['linear_outer_beta'] <= row['field'], row
    results.append(dict(row, family='implemented_outer_correction'))
output = {'status':'PASSED_EXACT_FINITE_CHECKS', 'universal_verification':False,
          'python':platform.python_version(), 'dependencies':'Python standard library only',
          'input_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
          'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'scope':data['scope'], 'results':results}
(ROOT/'output.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps({'status':output['status'],'finite_checks':len(results),
                  'universal_verification':False}))
