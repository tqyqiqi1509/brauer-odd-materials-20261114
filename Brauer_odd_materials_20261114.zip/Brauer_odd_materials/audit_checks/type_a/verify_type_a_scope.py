#!/usr/bin/env python3
"""Exact type-A checks for the two source-scope issues found in the old draft.

Uses only the Python standard library.  The output verifies the counterexample
to C_S(Z(L)_3)=L in PSL(3,7), and derives the length-two Jordan action in
PSL(3,19) from matrix conjugation on the actual quotient torus.
It does not assert that the quotient torus in PSL(3,19) is noncharacteristic.
"""
from __future__ import annotations

import json
from collections import Counter
from itertools import product


def verify(q: int, root: int, torus_exponent: int) -> dict:
    one = (1, 0, 0, 0, 1, 0, 0, 0, 1)

    def mul(x, y):
        return tuple(sum(x[3*i+k]*y[3*k+j] for k in range(3)) % q
                     for i in range(3) for j in range(3))

    def power(x, n):
        ans = one
        while n:
            if n & 1:
                ans = mul(ans, x)
            x = mul(x, x)
            n //= 2
        return ans

    def diag(a, b, c):
        return (a, 0, 0, 0, b, 0, 0, 0, c)

    assert pow(root, torus_exponent, q) == 1
    assert all(pow(root, n, q) != 1 for n in range(1, torus_exponent))
    scalar = pow(root, torus_exponent // 3, q)
    center = {diag(pow(scalar, i, q), pow(scalar, i, q),
                   pow(scalar, i, q)) for i in range(3)}
    torus = {diag(pow(root, i, q), pow(root, j, q),
                  pow(root, (-i-j) % torus_exponent, q))
             for i, j in product(range(torus_exponent), repeat=2)}
    full_torus = {diag(a, b, pow(a*b, -1, q))
                  for a, b in product(range(1, q), repeat=2)}
    cycle = (0, 0, 1, 1, 0, 0, 0, 1, 0)
    assert power(cycle, 3) == one
    assert {mul(mul(cycle, x), power(cycle, 2)) for x in torus} == torus
    sylow_cover = {mul(x, power(cycle, i)) for x in torus for i in range(3)}

    def canon(x):
        return min(mul(x, z) for z in center)

    a_bar = {canon(x) for x in torus}
    d_bar = {canon(x) for x in sylow_cover}
    l_bar = {canon(x) for x in full_torus}
    identity = canon(one)

    def quotient_order(x):
        for n in range(1, len(d_bar) + 1):
            if canon(power(x, n)) == identity:
                return n
        raise AssertionError("order exceeds group order")

    abelian = all(canon(mul(x, y)) == canon(mul(y, x))
                  for x, y in product(d_bar, repeat=2))
    centralizes_a = all(canon(mul(cycle, x)) == canon(mul(x, cycle))
                        for x in a_bar)
    result = {
        "q": q, "block_prime": 3,
        "primitive_torus_root": root, "torus_exponent": torus_exponent,
        "center_order": len(center), "cover_torus_order": len(torus),
        "quotient_torus_order": len(a_bar), "quotient_levi_order": len(l_bar),
        "quotient_defect_order": len(d_bar), "defect_is_abelian": abelian,
        "cycle_outside_levi": canon(cycle) not in l_bar,
        "cycle_centralizes_quotient_torus": centralizes_a,
        "quotient_torus_order_distribution": dict(sorted(Counter(
            quotient_order(x) for x in a_bar).items())),
    }
    assert len(center) == 3 and canon(cycle) not in l_bar
    if q == 7:
        a = diag(1, 2, 4)
        conjugate = mul(mul(cycle, a), power(cycle, 2))
        commutator = mul(conjugate, power(a, 2))
        assert conjugate == diag(4, 1, 2)
        assert commutator == diag(4, 4, 4)
        assert len(a_bar) == 3 and len(d_bar) == 9 and len(l_bar) == 12
        assert abelian and centralizes_a
        assert all(quotient_order(x) in {1, 3} for x in d_bar)
        assert len({canon(mul(power(a, i), power(cycle, j)))
                    for i, j in product(range(3), repeat=2)}) == 9
        result.update({"conjugate_waw_inverse": conjugate,
                       "commutator": commutator,
                       "defect_structure": "C3 x C3",
                       "characteristic_torus": False,
                       "witness": "The basis swap aZ <-> wZ moves A=<aZ>."})
    elif q == 19:
        assert len(a_bar) == 27 and len(d_bar) == 81 and not abelian
        cubes = {canon(power(x, 3)) for x in a_bar}
        assert len(cubes) == 3

        def coinvariant(x):
            return min(canon(mul(x, z)) for z in cubes)

        e1 = diag(root, 1, pow(root, -1, q))
        e2 = diag(1, root, pow(root, -1, q))
        coordinates = {coinvariant(mul(power(e1, i), power(e2, j))): (i, j)
                       for i, j in product(range(3), repeat=2)}
        assert len(coordinates) == 9
        cols = [coordinates[coinvariant(mul(mul(cycle, x), power(cycle, 2)))]
                for x in [e1, e2]]
        sigma = tuple(tuple(cols[j][i] for j in range(2)) for i in range(2))
        nilpotent = tuple(tuple((sigma[i][j] - int(i == j)) % 3 for j in range(2))
                          for i in range(2))
        square = tuple(tuple(sum(nilpotent[i][k]*nilpotent[k][j]
                                 for k in range(2)) % 3 for j in range(2))
                       for i in range(2))
        assert sigma == ((2, 2), (1, 0))
        assert nilpotent != ((0, 0), (0, 0)) and square == ((0, 0), (0, 0))
        assert result["quotient_torus_order_distribution"] == {1: 1, 3: 8, 9: 18}
        result.update({"quotient_torus_structure": "C9 x C3",
                       "matrix_on_A_mod_3A": sigma,
                       "sigma_minus_identity": nilpotent,
                       "square_of_sigma_minus_identity": square,
                       "nontrivial_Jordan_block_length": 2,
                       "characteristic_torus": "not decided by this check"})
    return result


if __name__ == "__main__":
    if not __debug__:
        raise RuntimeError("Do not run with Python -O or -OO: assertions are required.")
    rows = [verify(7, 2, 3), verify(19, 4, 9)]
    print(json.dumps({"all_assertions_passed": True, "cases": rows}, indent=2))
