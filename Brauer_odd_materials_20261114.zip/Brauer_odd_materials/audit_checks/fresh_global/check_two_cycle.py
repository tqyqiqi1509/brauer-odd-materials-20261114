#!/usr/bin/env python3
"""Exact finite stress test, using only the Python standard library.

This enumerates honest H-sets and untwisted exchange returns, not anomalous
Vec(H,omega)-module categories or nontrivial whole cochains. See input.json.
The count is of labeled cases, not isomorphism classes of actions/returns.
"""
import hashlib
import itertools
import json
import platform
from fractions import Fraction
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def make_group(degree, generators):
    identity = tuple(range(degree))
    def multiply(a, b):
        return tuple(a[b[i]] for i in range(degree))
    elements, queue = {identity}, [identity]
    while queue:
        a = queue.pop()
        for generator in generators:
            b = multiply(a, generator)
            if b not in elements:
                elements.add(b)
                queue.append(b)
    elements = [identity] + sorted(elements - {identity})
    index = {a: i for i, a in enumerate(elements)}
    table = [[index[multiply(a, b)] for b in elements] for a in elements]
    inverse = [next(j for j in range(len(elements)) if table[i][j] == 0)
               for i in range(len(elements))]
    return elements, table, inverse


def all_subgroups(table):
    def close(generators):
        answer, queue = {0}, [0]
        while queue:
            a = queue.pop()
            for b in generators:
                c = table[a][b]
                if c not in answer:
                    answer.add(c)
                    queue.append(c)
        return frozenset(answer)
    seen = {frozenset({0})}
    queue = list(seen)
    while queue:
        subgroup = queue.pop()
        for element in range(len(table)):
            if element not in subgroup:
                larger = close(tuple(subgroup) + (element,))
                if larger not in seen:
                    seen.add(larger)
                    queue.append(larger)
    return sorted(seen, key=lambda s: (len(s), sorted(s)))


def conjugate(table, inverse, g, x):
    return table[table[g][x]][inverse[g]]


def class_number(table, inverse, subgroup):
    remaining, number = set(subgroup), 0
    while remaining:
        x = min(remaining)
        remaining -= {conjugate(table, inverse, g, x) for g in subgroup}
        number += 1
    return number


def transitive_actions(table, inverse, subgroups):
    n = len(table)
    remaining, representatives = set(subgroups), []
    while remaining:
        subgroup = min(remaining, key=lambda s: (len(s), sorted(s)))
        remaining -= {frozenset(conjugate(table, inverse, g, x) for x in subgroup)
                      for g in range(n)}
        representatives.append(subgroup)
    actions = []
    for subgroup in representatives:
        cosets = {frozenset(table[g][x] for x in subgroup) for g in range(n)}
        cosets = sorted(cosets, key=min)
        index = {coset: i for i, coset in enumerate(cosets)}
        action = [[index[frozenset(table[g][x] for x in coset)] for coset in cosets]
                  for g in range(n)]
        actions.append(action)
    return representatives, actions


def disjoint_union(actions, multiplicities, n):
    result, offset = [[] for _ in range(n)], 0
    for action, count in zip(actions, multiplicities):
        for _ in range(count):
            for g in range(n):
                result[g].extend(offset + x for x in action[g])
            offset += len(action[0])
    return result


def honest_budget(table, inverse, subgroups, action):
    budgets = []
    for subgroup in subgroups:
        remaining, rank = set(range(len(action[0]))), 0
        while remaining:
            x = min(remaining)
            remaining -= {action[g][x] for g in subgroup}
            stabilizer = frozenset(g for g in subgroup if action[g][x] == x)
            rank += class_number(table, inverse, stabilizer)
        budgets.append(rank)
    return max(budgets)


def loop_class_return_check(table, inverse, action, subgroup, a, b):
    """Independent finite orbit count on loops, without the averaged formula."""
    n, labels = len(table), len(action[0])
    loops = set()
    for x1 in range(labels):
        for x2 in range(labels):
            for t in subgroup:
                if action[t // n][x1] == x1 and action[t % n][x2] == x2:
                    loops.add((x1, x2, t))
    class_of, representatives = {}, []
    while loops:
        x1, x2, t = min(loops)
        orbit = {
            (action[h // n][x1], action[h % n][x2],
             conjugate(table, inverse, h // n, t // n) * n
             + conjugate(table, inverse, h % n, t % n))
            for h in subgroup
        }
        number = len(representatives)
        for loop in orbit:
            class_of[loop] = number
        loops -= orbit
        representatives.append((x1, x2, t))
    fixed = 0
    for number, (x1, x2, t) in enumerate(representatives):
        image = (action[a][x2], action[b][x1],
                 conjugate(table, inverse, a, t % n) * n
                 + conjugate(table, inverse, b, t // n))
        fixed += class_of[image] == number
    return fixed, len(representatives)


def check_actor(specification, multiplicity_domain):
    elements, table, inverse = make_group(specification['degree'], specification['generators'])
    n = len(elements)
    subgroups = all_subgroups(table)
    stabilizers, actions = transitive_actions(table, inverse, subgroups)
    product = [[table[a // n][b // n] * n + table[a % n][b % n]
                for b in range(n * n)] for a in range(n * n)]
    subdirects = [subgroup for subgroup in all_subgroups(product)
                  if {x // n for x in subgroup} == set(range(n))
                  and {x % n for x in subgroup} == set(range(n))]
    returns = []
    for subgroup in subdirects:
        for a in range(n):
            for b in range(n):
                image = {conjugate(table, inverse, a, x % n) * n
                         + conjugate(table, inverse, b, x // n) for x in subgroup}
                if image != set(subgroup):
                    continue
                terms = []
                for k in subgroup:
                    s1, s2 = table[k // n][a], table[k % n][b]
                    for t in subgroup:
                        t1, t2 = t // n, t % n
                        if table[t1][s1] == table[s1][t2] and table[t2][s2] == table[s2][t1]:
                            terms.append((table[s1][s2], t1))
                returns.append((subgroup, a, b, terms))
    number, nontrivial_square, maximum = 0, 0, Fraction(0)
    extremal = None
    loop_checks = []
    tested_nontrivial_square = False
    for multiplicities in itertools.product(multiplicity_domain, repeat=len(actions)):
        if not any(multiplicities):
            continue
        action = disjoint_union(actions, multiplicities, n)
        budget = honest_budget(table, inverse, subgroups, action)
        fixed_by_two = [[sum(action[g][x] == x and action[h][x] == x
                             for x in range(len(action[0]))) for h in range(n)] for g in range(n)]
        for subgroup, a, b, terms in returns:
            trace = Fraction(sum(fixed_by_two[g][h] for g, h in terms), len(subgroup))
            assert trace.denominator == 1
            assert 4 * trace <= (budget + 1) ** 2, (specification['name'], multiplicities, budget, trace)
            square = (table[a][b], table[b][a])
            number += 1
            nontrivial_square += square != (0, 0)
            ratio = 4 * trace / (budget + 1) ** 2
            candidate = {
                'orbit_multiplicities': multiplicities, 'label_count': len(action[0]),
                'F': budget, 'f_y': int(trace), 'K_order': len(subgroup),
                'K_elements': sorted(subgroup), 'return': [a, b], 'return_square': square
            }
            if ratio > maximum:
                maximum, extremal = ratio, candidate
            if square != (0, 0) and not tested_nontrivial_square:
                independently_fixed, rank = loop_class_return_check(table, inverse, action, subgroup, a, b)
                assert independently_fixed == trace
                loop_checks.append(dict(candidate, independent_loop_fixed=independently_fixed,
                                        loop_class_count=rank, reason='nontrivial return square'))
                tested_nontrivial_square = True
    extremal_action = disjoint_union(actions, extremal['orbit_multiplicities'], n)
    independently_fixed, rank = loop_class_return_check(
        table, inverse, extremal_action, frozenset(extremal['K_elements']), *extremal['return'])
    assert independently_fixed == extremal['f_y']
    loop_checks.append(dict(extremal, independent_loop_fixed=independently_fixed,
                            loop_class_count=rank, reason='maximum observed ratio'))
    return {
        'actor': specification['name'], 'element_index_permutations': elements,
        'subgroups': len(subgroups), 'transitive_actions': [
            {'stabilizer_elements': sorted(s), 'label_count': len(a[0])}
            for s, a in zip(stabilizers, actions)],
        'subdirect_subgroups': len(subdirects), 'normalizing_returns': len(returns),
        'tested_labeled_cases': number, 'cases_with_nonidentity_return_square': nontrivial_square,
        'maximum_ratio_4fy_over_Fplus1_squared': str(maximum),
        'extremal_case': extremal, 'independent_loop_class_checks': loop_checks
    }


def main():
    input_path = ROOT / 'input.json'
    data = json.loads(input_path.read_text())
    results = [check_actor(actor, data['transitive_orbit_multiplicities']) for actor in data['actors']]
    total = sum(result['tested_labeled_cases'] for result in results)
    assert total == data['expected_labeled_cases']
    output = {
        'status': 'NO_COUNTEREXAMPLE_IN_ENUMERATED_HONEST_ACTIONS',
        'universal_verification': False,
        'python': platform.python_version(),
        'dependencies': 'Python 3 standard library only',
        'input_sha256': hashlib.sha256(input_path.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'total_labeled_cases': total,
        'total_cases_with_nonidentity_return_square': sum(
            result['cases_with_nonidentity_return_square'] for result in results),
        'cocycle_scope': data['cocycle_scope'],
        'results': results
    }
    (ROOT / 'output.json').write_text(json.dumps(output, indent=2) + '\n')
    print(json.dumps({key: value for key, value in output.items() if key != 'results'}, indent=2))
    for result in results:
        print(result['actor'], result['tested_labeled_cases'],
              result['maximum_ratio_4fy_over_Fplus1_squared'])


if __name__ == '__main__':
    main()
