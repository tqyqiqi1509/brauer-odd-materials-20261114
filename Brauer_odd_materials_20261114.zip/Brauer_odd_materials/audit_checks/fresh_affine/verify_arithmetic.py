#!/usr/bin/env python3
"""Independent arithmetic and primary-PDF checks for the fresh audit.

This does not claim to verify the representation-theoretic proofs.
Run from any working directory; the JSON is written next to this script.
"""

from __future__ import annotations

import hashlib
import json
from math import comb, factorial, gcd
from pathlib import Path



BASE = Path(__file__).resolve().parent


def valuation(n: int, p: int) -> int:
    result = 0
    while n and n % p == 0:
        n //= p
        result += 1
    return result


def prime_to(n: int, p: int) -> int:
    return n // p ** valuation(n, p)


def multiply(a: list[int], b: list[int], n: int) -> list[int]:
    return [sum(a[j] * b[i - j] for j in range(i + 1)) for i in range(n + 1)]


def coloured_product(n: int, colours: int, scale: int = 1) -> list[int]:
    coefficients = [1] + [0] * n
    for j in range(scale, n + 1, scale):
        factor = [0] * (n + 1)
        for k in range(n // j + 1):
            factor[j * k] = comb(colours + k - 1, k)
        coefficients = multiply(coefficients, factor, n)
    return coefficients


def coefficient(p: int, s: int, c: int, w: int) -> int:
    assert (p - 1) % c == 0 and (s - 1) % c == 0
    b0 = c + (s - 1) // c
    b = (s - s // p) // c
    coefficients = coloured_product(w, b0)
    power = p
    while power <= w:
        coefficients = multiply(coefficients, coloured_product(w, b, power), w)
        power *= p
    return coefficients[w]


def main() -> None:
    result: dict[str, object] = {
        "description": "Fresh independent finite arithmetic and primary-PDF integrity checks",
        "date": "2026-11-14",
        "does_not_machine_verify_representation_theory": True,
    }
    exceptions = []
    for name, mu, outer in (
        ("A6", 6, 4),
        ("PSL2(27)", 28, 2 * 3),
        ("PSL3(4)", (4**3 - 1) // (4 - 1), 2 * gcd(3, 4 - 1) * 2),
        ("PSL3(16)", (16**3 - 1) // (16 - 1), 2 * gcd(3, 16 - 1) * 4),
    ):
        outer3 = prime_to(outer, 3)
        assert outer3**2 <= 4 * mu
        exceptions.append({
            "group": name,
            "minimum_degree": mu,
            "outer_order": outer,
            "outer_prime_to_three": outer3,
            "prime_to_three_bound_verified": outer3**2 <= 4 * mu,
            "full_outer_bound_holds": outer**2 <= 4 * mu,
        })
    assert exceptions[2]["full_outer_bound_holds"] is False
    result["outer_order_exceptions"] = exceptions

    margins = []
    for p, c, w, multiplier, expected in ((3, 2, 3, 2, 23), (5, 2, 5, 32, 254), (7, 6, 7, 64 * 6, 12406)):
        s = p
        k = coefficient(p, s, c, w)
        defect = s**w * p ** valuation(factorial(w), p)
        assert k == expected
        assert multiplier * k < defect < 2 * multiplier * k
        margins.append({
            "p": p,
            "s": s,
            "c": c,
            "w": w,
            "K": k,
            "defect": defect,
            "existing_cost": multiplier * k,
            "doubled_cost": 2 * multiplier * k,
            "blanket_extra_factor_two_fails": 2 * multiplier * k > defect,
        })
    result["factor_two_margins"] = margins

    quotient_checks = []
    for a in range(1, 6):
        s = 3**a
        relation_columns = ((s, 0), (0, s), (s // 3, s // 3))
        first = gcd(*(abs(v) for col in relation_columns for v in col))
        minors = [
            abs(relation_columns[i][0] * relation_columns[j][1]
                - relation_columns[j][0] * relation_columns[i][1])
            for i in range(3) for j in range(i + 1, 3)
        ]
        determinant_gcd = gcd(*minors)
        second = determinant_gcd // first
        assert (first, second) == (s // 3, s)
        assert 3 * first * second == s * s
        quotient_checks.append({"a": a, "A_invariant_factors": [first, second], "D_order": s*s})
    nilpotent = ((1, 2), (1, 2))
    square = [[sum(nilpotent[i][k] * nilpotent[k][j] for k in range(2)) % 3 for j in range(2)] for i in range(2)]
    assert square == [[0, 0], [0, 0]] and any(x % 3 for row in nilpotent for x in row)
    result["central_quotient_checks"] = quotient_checks
    result["quotient_jordan_square_mod_three"] = square

    output = BASE / "arithmetic_results.json"
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"outer_exceptions":len(exceptions), "margin_checks":len(margins), "quotient_checks":len(quotient_checks), "all_assertions_passed":True}))

if __name__ == "__main__":
    main()
